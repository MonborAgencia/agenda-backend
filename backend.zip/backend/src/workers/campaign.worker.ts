import cron from 'node-cron';
import { PrismaClient } from '@prisma/client';
import { CampaignService } from '../services/campaign.service';
import { ClientReactivationService } from '../services/client-reactivation.service';
import { CampaignStatus, CampaignType } from '../types/campaign.types';

const prisma = new PrismaClient();
const campaignService = new CampaignService();
const reactivationService = new ClientReactivationService();

export class CampaignWorker {
  private isRunning = false;

  // Inicializar worker de campanhas
  start() {
    console.log('🚀 Campaign Worker iniciado');

    // Executar campanhas agendadas a cada hora
    cron.schedule('0 * * * *', async () => {
      if (this.isRunning) return;
      
      this.isRunning = true;
      try {
        await this.processScheduledCampaigns();
      } catch (error) {
        console.error('Erro ao processar campanhas agendadas:', error);
      } finally {
        this.isRunning = false;
      }
    });

    // Verificar campanhas de reativação diariamente às 9h
    cron.schedule('0 9 * * *', async () => {
      try {
        await this.processReactivationCampaigns();
      } catch (error) {
        console.error('Erro ao processar campanhas de reativação:', error);
      }
    });

    // Atualizar métricas de campanhas a cada 6 horas
    cron.schedule('0 */6 * * *', async () => {
      try {
        await this.updateCampaignMetrics();
      } catch (error) {
        console.error('Erro ao atualizar métricas:', error);
      }
    });

    // Limpeza de campanhas antigas semanalmente
    cron.schedule('0 2 * * 0', async () => {
      try {
        await this.cleanupOldCampaigns();
      } catch (error) {
        console.error('Erro na limpeza de campanhas:', error);
      }
    });
  }

  // Processar campanhas agendadas
  private async processScheduledCampaigns() {
    console.log('📅 Processando campanhas agendadas...');

    const now = new Date();
    const scheduledCampaigns = await prisma.campaign.findMany({
      where: {
        status: CampaignStatus.ACTIVE,
        startDate: {
          lte: now,
        },
        OR: [
          { endDate: null },
          { endDate: { gte: now } },
        ],
      },
    });

    for (const campaign of scheduledCampaigns) {
      try {
        // Verificar se já foi executada hoje
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const todayExecution = await prisma.campaignExecution.findFirst({
          where: {
            campaignId: campaign.id,
            createdAt: {
              gte: today,
            },
          },
        });

        if (!todayExecution) {
          console.log(`Executando campanha: ${campaign.name}`);
          await campaignService.executeCampaign(campaign.id);
        }
      } catch (error) {
        console.error(`Erro ao executar campanha ${campaign.name}:`, error);
      }
    }
  }

  // Processar campanhas de reativação automática
  private async processReactivationCampaigns() {
    console.log('🔄 Processando campanhas de reativação...');

    // Buscar todos os tenants ativos
    const tenants = await prisma.tenant.findMany({
      where: { isActive: true },
    });

    for (const tenant of tenants) {
      try {
        // Detectar clientes inativos
        const inactiveClients = await reactivationService.detectInactiveClients(tenant.id, 90);
        
        if (inactiveClients.length > 0) {
          console.log(`Tenant ${tenant.name}: ${inactiveClients.length} clientes inativos detectados`);

          // Verificar se já existe campanha de reativação ativa
          const existingCampaign = await prisma.campaign.findFirst({
            where: {
              tenantId: tenant.id,
              type: CampaignType.REACTIVATION,
              status: CampaignStatus.ACTIVE,
              createdAt: {
                gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // Última semana
              },
            },
          });

          if (!existingCampaign) {
            // Criar campanha automática de reativação
            await reactivationService.createReactivationCampaign({
              name: `Reativação Automática - ${new Date().toLocaleDateString()}`,
              description: 'Campanha automática para clientes inativos',
              tenantId: tenant.id,
              inactivityThreshold: 90,
              personalizedOffers: true,
              discountPercentage: 20,
              validityDays: 30,
            });

            console.log(`Campanha de reativação criada para tenant ${tenant.name}`);
          }
        }
      } catch (error) {
        console.error(`Erro ao processar reativação para tenant ${tenant.name}:`, error);
      }
    }
  }

  // Atualizar métricas de campanhas
  private async updateCampaignMetrics() {
    console.log('📊 Atualizando métricas de campanhas...');

    const activeCampaigns = await prisma.campaign.findMany({
      where: {
        status: {
          in: [CampaignStatus.ACTIVE, CampaignStatus.COMPLETED],
        },
      },
      include: {
        executions: {
          include: {
            targets: true,
          },
        },
      },
    });

    for (const campaign of activeCampaigns) {
      try {
        let totalSent = 0;
        let totalOpened = 0;
        let totalClicked = 0;
        let totalConverted = 0;

        campaign.executions.forEach(execution => {
          totalSent += execution.successCount;
          
          execution.targets.forEach(target => {
            if (target.openedAt) totalOpened++;
            if (target.clickedAt) totalClicked++;
            if (target.convertedAt) totalConverted++;
          });
        });

        // Atualizar totais da campanha
        await prisma.campaign.update({
          where: { id: campaign.id },
          data: {
            totalSent,
            totalOpened,
            totalClicked,
            totalConverted,
          },
        });

        // Criar/atualizar métrica diária
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        await prisma.campaignMetric.upsert({
          where: {
            campaignId_date: {
              campaignId: campaign.id,
              date: today,
            },
          },
          update: {
            sent: totalSent,
            opened: totalOpened,
            clicked: totalClicked,
            converted: totalConverted,
          },
          create: {
            campaignId: campaign.id,
            date: today,
            sent: totalSent,
            opened: totalOpened,
            clicked: totalClicked,
            converted: totalConverted,
          },
        });
      } catch (error) {
        console.error(`Erro ao atualizar métricas da campanha ${campaign.name}:`, error);
      }
    }
  }

  // Limpeza de campanhas antigas
  private async cleanupOldCampaigns() {
    console.log('🧹 Limpando campanhas antigas...');

    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    try {
      // Deletar execuções antigas
      const deletedExecutions = await prisma.campaignExecution.deleteMany({
        where: {
          createdAt: {
            lt: sixMonthsAgo,
          },
          status: 'COMPLETED',
        },
      });

      // Deletar métricas antigas (manter apenas 1 ano)
      const oneYearAgo = new Date();
      oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

      const deletedMetrics = await prisma.campaignMetric.deleteMany({
        where: {
          date: {
            lt: oneYearAgo,
          },
        },
      });

      console.log(`Limpeza concluída: ${deletedExecutions.count} execuções e ${deletedMetrics.count} métricas removidas`);
    } catch (error) {
      console.error('Erro na limpeza:', error);
    }
  }

  // Processar campanhas de aniversário
  private async processBirthdayCampaigns() {
    console.log('🎂 Processando campanhas de aniversário...');

    const today = new Date();
    const todayMonth = today.getMonth() + 1;
    const todayDay = today.getDate();

    // Buscar usuários que fazem aniversário hoje
    // Nota: Isso requer um campo de data de nascimento no modelo User
    // Por enquanto, vamos simular com uma implementação básica

    const tenants = await prisma.tenant.findMany({
      where: { isActive: true },
    });

    for (const tenant of tenants) {
      try {
        // Verificar se já existe campanha de aniversário para hoje
        const existingCampaign = await prisma.campaign.findFirst({
          where: {
            tenantId: tenant.id,
            type: CampaignType.BIRTHDAY,
            createdAt: {
              gte: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
              lt: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1),
            },
          },
        });

        if (!existingCampaign) {
          // Criar campanha de aniversário
          const campaign = await campaignService.createCampaign({
            name: `Aniversários - ${today.toLocaleDateString()}`,
            description: 'Campanha automática para aniversariantes do dia',
            type: CampaignType.BIRTHDAY,
            tenantId: tenant.id,
            targetAudience: {
              criteria: {
                // Implementar critério de aniversário quando tivermos o campo
              },
            },
          });

          console.log(`Campanha de aniversário criada para tenant ${tenant.name}`);
        }
      } catch (error) {
        console.error(`Erro ao processar aniversários para tenant ${tenant.name}:`, error);
      }
    }
  }

  // Parar worker
  stop() {
    console.log('⏹️ Campaign Worker parado');
    // Implementar lógica de parada se necessário
  }
}

// Instância singleton do worker
export const campaignWorker = new CampaignWorker();