import { notificationService } from '../services/notification.service';

export class NotificationWorker {
  private isRunning = false;
  private intervalId: NodeJS.Timeout | null = null;
  private readonly POLL_INTERVAL = 5000; // 5 segundos
  private readonly MAX_CONCURRENT_JOBS = 5;
  private currentJobs = 0;

  // Iniciar worker
  start(): void {
    if (this.isRunning) {
      console.log('Notification worker já está rodando');
      return;
    }

    this.isRunning = true;
    console.log('Iniciando notification worker...');

    this.intervalId = setInterval(async () => {
      await this.processQueue();
    }, this.POLL_INTERVAL);

    // Processar imediatamente
    this.processQueue();
  }

  // Parar worker
  stop(): void {
    if (!this.isRunning) {
      console.log('Notification worker não está rodando');
      return;
    }

    this.isRunning = false;
    
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    console.log('Notification worker parado');
  }

  // Processar fila de notificações
  private async processQueue(): Promise<void> {
    if (!this.isRunning || this.currentJobs >= this.MAX_CONCURRENT_JOBS) {
      return;
    }

    try {
      const queueSize = await notificationService.getQueueSize();
      
      if (queueSize === 0) {
        return; // Fila vazia
      }

      // Processar múltiplas notificações em paralelo
      const promises: Promise<void>[] = [];
      const jobsToProcess = Math.min(
        this.MAX_CONCURRENT_JOBS - this.currentJobs,
        queueSize
      );

      for (let i = 0; i < jobsToProcess; i++) {
        promises.push(this.processNextJob());
      }

      await Promise.all(promises);
    } catch (error) {
      console.error('Erro ao processar fila de notificações:', error);
    }
  }

  // Processar próximo job
  private async processNextJob(): Promise<void> {
    this.currentJobs++;
    
    try {
      const processed = await notificationService.processNextNotification();
      
      if (processed) {
        console.log('Notificação processada com sucesso');
      }
    } catch (error) {
      console.error('Erro ao processar notificação:', error);
    } finally {
      this.currentJobs--;
    }
  }

  // Obter status do worker
  getStatus(): {
    isRunning: boolean;
    currentJobs: number;
    maxConcurrentJobs: number;
    pollInterval: number;
  } {
    return {
      isRunning: this.isRunning,
      currentJobs: this.currentJobs,
      maxConcurrentJobs: this.MAX_CONCURRENT_JOBS,
      pollInterval: this.POLL_INTERVAL
    };
  }

  // Processar notificações falhadas periodicamente
  async processFailedNotifications(): Promise<void> {
    try {
      const reprocessed = await notificationService.reprocessFailedNotifications();
      
      if (reprocessed > 0) {
        console.log(`${reprocessed} notificações falhadas foram reprocessadas`);
      }
    } catch (error) {
      console.error('Erro ao reprocessar notificações falhadas:', error);
    }
  }

  // Iniciar processamento de notificações falhadas em intervalo
  startFailedNotificationProcessor(): void {
    // Processar notificações falhadas a cada 30 minutos
    setInterval(async () => {
      await this.processFailedNotifications();
    }, 30 * 60 * 1000);

    console.log('Processador de notificações falhadas iniciado');
  }
}

// Instância singleton do worker
export const notificationWorker = new NotificationWorker();

// Iniciar worker automaticamente se não estiver em ambiente de teste e workers não estiverem desabilitados
if (process.env.NODE_ENV !== 'test' && process.env.DISABLE_WORKERS !== 'true') {
  // Aguardar um pouco para garantir que as conexões estejam estabelecidas
  setTimeout(() => {
    try {
      notificationWorker.start();
      notificationWorker.startFailedNotificationProcessor();
    } catch (error) {
      console.warn('Failed to start notification worker:', (error as Error).message);
    }
  }, 2000);
} else {
  console.log('Notification worker disabled');
}

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Recebido SIGTERM, parando notification worker...');
  notificationWorker.stop();
});

process.on('SIGINT', () => {
  console.log('Recebido SIGINT, parando notification worker...');
  notificationWorker.stop();
});