import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import path from 'path';
import { setupSwagger, addRequestId } from './config/swagger';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(helmet());
app.use(cors({
  origin: [
    process.env.FRONTEND_URL || "http://localhost:3000",
    "http://localhost:3002",
    "http://localhost:3001"
  ],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Request ID middleware
app.use(addRequestId);

// Setup Swagger documentation
setupSwagger(app);

// Health check endpoint
app.get('/health', (_req: express.Request, res: express.Response) => {
  res.status(200).json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    memory: process.memoryUsage(),
    version: '1.0.0'
  });
});

// API root endpoint
app.get('/api', (_req: express.Request, res: express.Response) => {
  res.json({
    message: 'Agenda Lotada 24h API - Working Version',
    version: '1.0.0',
    status: 'running'
  });
});

// Debug endpoint to check roles
app.get('/api/debug/roles', async (_req: express.Request, res: express.Response) => {
  try {
    const { PrismaClient } = await import('@prisma/client');
    const prisma = new PrismaClient();
    const roles = await prisma.role.findMany();
    await prisma.$disconnect();
    res.json({ roles });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch roles', details: error });
  }
});

// Simple test endpoint for user creation
app.post('/api/debug/test-user', async (req: express.Request, res: express.Response) => {
  try {
    const { PrismaClient } = await import('@prisma/client');
    const bcrypt = await import('bcryptjs');
    const prisma = new PrismaClient();
    
    const { name, email, password } = req.body;
    
    // Hash password
    const hashedPassword = await bcrypt.default.hash(password, 12);
    
    // Find CLIENT role
    const clientRole = await prisma.role.findUnique({
      where: { name: 'CLIENT' }
    });
    
    if (!clientRole) {
      return res.status(400).json({ error: 'CLIENT role not found' });
    }
    
    // Create user in transaction
    const result = await prisma.$transaction(async (tx) => {
      // Create user
      const user = await tx.user.create({
        data: {
          name,
          email,
          password: hashedPassword,
          isActive: true,
          emailVerified: false
        }
      });
      
      // Create user role
      await tx.userRole.create({
        data: {
          userId: user.id,
          roleId: clientRole.id
        }
      });
      
      return user;
    });
    
    await prisma.$disconnect();
    res.json({ success: true, user: { id: result.id, name: result.name, email: result.email } });
  } catch (error) {
    console.error('Debug user creation error:', error);
    res.status(500).json({ 
      error: 'Failed to create user', 
      details: error instanceof Error ? error.message : error,
      stack: error instanceof Error ? error.stack : undefined
    });
  }
});

// Import routes
import authRoutes from './routes/auth.routes';
import userRoutes from './routes/user.routes';
import tenantRoutes from './routes/tenant.routes';
import serviceRoutes from './routes/service.routes';
import scheduleRoutes from './routes/schedule.routes';
import { bookingRoutes } from './routes/booking.routes';

// Authentication routes
app.use('/api/auth', authRoutes);

// User management routes
app.use('/api/users', userRoutes);

// Tenant management routes
app.use('/api/tenants', tenantRoutes);

// Service management routes
app.use('/api/services', serviceRoutes);

// Schedule management routes
app.use('/api/schedules', scheduleRoutes);

// Booking management routes
app.use('/api/bookings', bookingRoutes);

// Error handling middleware
app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('Error:', err);
  
  res.status(500).json({
    error: 'Internal Server Error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong',
    requestId: req.requestId
  });
});

// 404 handler
app.use('*', (req: express.Request, res: express.Response) => {
  res.status(404).json({
    error: 'Not Found',
    message: `Route ${req.originalUrl} not found`,
    requestId: req.requestId
  });
});

// Start server
const startServer = async () => {
  try {
    console.log('🚀 Starting Agenda Lotada 24h API...');
    
    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📊 Health check: http://localhost:${PORT}/health`);
      console.log(`📚 API Docs: http://localhost:${PORT}/api-docs`);
      console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log('✅ Server ready to accept connections');
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();

export { app };