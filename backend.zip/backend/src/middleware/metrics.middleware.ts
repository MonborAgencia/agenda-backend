import { Request, Response, NextFunction } from 'express';
import MetricsService from '../services/metrics.service';
import LoggerUtils from '../utils/logger.utils';

// Estender o tipo Request para incluir métricas
declare global {
  namespace Express {
    interface Request {
      metricsStartTime?: number;
    }
  }
}

/**
 * Middleware para coletar métricas de requisições HTTP
 */
export const metricsMiddleware = (req: Request, res: Response, next: NextFunction) => {
  req.metricsStartTime = Date.now();

  // Interceptar o final da resposta
  const originalEnd = res.end;
  
  res.end = function(chunk?: any, encoding?: any) {
    const duration = req.metricsStartTime ? Date.now() - req.metricsStartTime : 0;
    const route = getRoutePattern(req);
    const tenantId = (req as any).user?.tenantId;

    // Registrar métricas
    MetricsService.recordHttpRequest(
      req.method,
      route,
      res.statusCode,
      duration,
      tenantId
    );

    // Log de performance para requisições lentas
    if (duration > 2000) {
      LoggerUtils.performance('Slow HTTP Request', duration, {
        method: req.method,
        route,
        statusCode: res.statusCode,
        tenantId,
        slow: true,
        threshold: '2000ms'
      });
    }

    return originalEnd.call(this, chunk, encoding);
  };

  next();
};

/**
 * Extrair padrão da rota para métricas
 */
function getRoutePattern(req: Request): string {
  // Tentar obter a rota original do Express
  if (req.route && req.route.path) {
    return req.route.path;
  }

  // Fallback para URL original com parâmetros normalizados
  let route = req.originalUrl || req.url;
  
  // Normalizar IDs numéricos
  route = route.replace(/\/\d+/g, '/:id');
  
  // Normalizar UUIDs
  route = route.replace(/\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, '/:uuid');
  
  // Remover query parameters
  route = route.split('?')[0];
  
  return route;
}

/**
 * Middleware para coletar métricas de erros
 */
export const errorMetricsMiddleware = (
  error: Error,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const tenantId = (req as any).user?.tenantId;
  const service = getServiceFromRoute(req.originalUrl);
  
  // Determinar tipo de erro
  let errorType = 'unknown_error';
  if (error.name === 'ValidationError') {
    errorType = 'validation_error';
  } else if (error.name === 'UnauthorizedError') {
    errorType = 'unauthorized_error';
  } else if (error.name === 'NotFoundError') {
    errorType = 'not_found_error';
  } else if (error.message.includes('database')) {
    errorType = 'database_error';
  } else if (error.message.includes('timeout')) {
    errorType = 'timeout_error';
  }

  MetricsService.recordError(errorType, service, tenantId);
  
  next(error);
};

/**
 * Extrair nome do serviço da rota
 */
function getServiceFromRoute(url: string): string {
  const parts = url.split('/');
  if (parts.length >= 3 && parts[1] === 'api') {
    return parts[2];
  }
  return 'unknown';
}

/**
 * Middleware para atualizar métricas de conexões ativas
 */
export const connectionMetricsMiddleware = (req: Request, res: Response, next: NextFunction) => {
  // Incrementar conexões ativas
  const currentConnections = parseInt(process.env.ACTIVE_CONNECTIONS || '0') + 1;
  process.env.ACTIVE_CONNECTIONS = currentConnections.toString();
  MetricsService.updateActiveConnections(currentConnections);

  // Decrementar quando a resposta terminar
  res.on('finish', () => {
    const newConnections = parseInt(process.env.ACTIVE_CONNECTIONS || '1') - 1;
    process.env.ACTIVE_CONNECTIONS = Math.max(0, newConnections).toString();
    MetricsService.updateActiveConnections(Math.max(0, newConnections));
  });

  next();
};

export default metricsMiddleware;