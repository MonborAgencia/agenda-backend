import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { Request } from 'express';

// Ensure uploads directory exists for tenant assets
const createUploadDir = (subDir: string) => {
  const dir = path.join(process.cwd(), 'uploads', 'tenants', subDir);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
};

// Configure multer for tenant logo uploads
const logoStorage = multer.diskStorage({
  destination: (req: Request, file: Express.Multer.File, cb: Function) => {
    const logoDir = createUploadDir('logos');
    cb(null, logoDir);
  },
  filename: (req: Request, file: Express.Multer.File, cb: Function) => {
    const tenantId = req.params.tenantId || 'unknown';
    const timestamp = Date.now();
    const extension = path.extname(file.originalname);
    const filename = `logo-${tenantId}-${timestamp}${extension}`;
    cb(null, filename);
  },
});

// Configure multer for tenant favicon uploads
const faviconStorage = multer.diskStorage({
  destination: (req: Request, file: Express.Multer.File, cb: Function) => {
    const faviconDir = createUploadDir('favicons');
    cb(null, faviconDir);
  },
  filename: (req: Request, file: Express.Multer.File, cb: Function) => {
    const tenantId = req.params.tenantId || 'unknown';
    const timestamp = Date.now();
    const extension = path.extname(file.originalname);
    const filename = `favicon-${tenantId}-${timestamp}${extension}`;
    cb(null, filename);
  },
});

// File filter for images only
const imageFilter = (req: Request, file: Express.Multer.File, cb: Function) => {
  if (file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error('Apenas arquivos de imagem são permitidos'), false);
  }
};

// File filter for favicon (ICO, PNG, SVG)
const faviconFilter = (req: Request, file: Express.Multer.File, cb: Function) => {
  const allowedTypes = ['image/x-icon', 'image/vnd.microsoft.icon', 'image/png', 'image/svg+xml'];
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Apenas arquivos ICO, PNG ou SVG são permitidos para favicon'), false);
  }
};

// Configure multer for logo uploads
export const uploadLogo = multer({
  storage: logoStorage,
  fileFilter: imageFilter,
  limits: {
    fileSize: 2 * 1024 * 1024, // 2MB limit for logos
    files: 1,
  },
});

// Configure multer for favicon uploads
export const uploadFavicon = multer({
  storage: faviconStorage,
  fileFilter: faviconFilter,
  limits: {
    fileSize: 512 * 1024, // 512KB limit for favicons
    files: 1,
  },
});

// Middleware to handle upload errors
export const handleTenantUploadError = (error: any, req: Request, res: any, next: Function) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        error: 'FILE_TOO_LARGE',
        message: 'Arquivo muito grande. Tamanho máximo: 2MB para logos, 512KB para favicons',
      });
    }
    if (error.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({
        error: 'TOO_MANY_FILES',
        message: 'Apenas um arquivo é permitido',
      });
    }
  }
  
  if (error.message.includes('Apenas arquivos')) {
    return res.status(400).json({
      error: 'INVALID_FILE_TYPE',
      message: error.message,
    });
  }

  next(error);
};

// Helper function to delete old tenant asset file
export const deleteOldTenantAsset = (assetPath: string) => {
  if (assetPath && fs.existsSync(assetPath)) {
    try {
      fs.unlinkSync(assetPath);
    } catch (error) {
      console.error('Error deleting old tenant asset:', error);
    }
  }
};

// Helper functions to get asset URLs
export const getLogoUrl = (filename: string): string => {
  return `/uploads/tenants/logos/${filename}`;
};

export const getFaviconUrl = (filename: string): string => {
  return `/uploads/tenants/favicons/${filename}`;
};

// Helper function to extract filename from URL
export const getFilenameFromUrl = (url: string): string => {
  return path.basename(url);
};

// Helper function to get full file path from URL
export const getFilePathFromUrl = (url: string): string => {
  const filename = getFilenameFromUrl(url);
  if (url.includes('/logos/')) {
    return path.join(process.cwd(), 'uploads', 'tenants', 'logos', filename);
  } else if (url.includes('/favicons/')) {
    return path.join(process.cwd(), 'uploads', 'tenants', 'favicons', filename);
  }
  return '';
};