import { Request, Response, NextFunction } from 'express';

export interface QueryMetrics {
  endpoint: string;
  method: string;
  duration: number;
  timestamp: Date;
  statusCode: number;
  userAgent?: string;
  tenantId?: string;
  userId?: string;
}

class QueryMonitorService {
  private metrics: QueryMetrics[] = [];
  private readonly maxMetrics = 1000; // Keep last 1000 requests

  addMetric(metric: QueryMetrics) {
    this.metrics.push(metric);
    
    // Keep only the last N metrics
    if (this.metrics.length > this.maxMetrics) {
      this.metrics = this.metrics.slice(-this.maxMetrics);
    }

    // Log slow requests
    if (metric.duration > 1000) {
      console.warn(`🐌 Slow request detected: ${metric.method} ${metric.endpoint} took ${metric.duration}ms`);
    }
  }

  getMetrics(limit?: number): QueryMetrics[] {
    return limit ? this.metrics.slice(-limit) : this.metrics;
  }

  getSlowQueries(threshold: number = 1000): QueryMetrics[] {
    return this.metrics.filter(m => m.duration > threshold);
  }

  getAverageResponseTime(endpoint?: string): number {
    const filteredMetrics = endpoint 
      ? this.metrics.filter(m => m.endpoint === endpoint)
      : this.metrics;

    if (filteredMetrics.length === 0) return 0;

    const total = filteredMetrics.reduce((sum, m) => sum + m.duration, 0);
    return Math.round(total / filteredMetrics.length);
  }

  getEndpointStats(): Record<string, {
    count: number;
    avgDuration: number;
    maxDuration: number;
    minDuration: number;
    slowQueries: number;
  }> {
    const stats: Record<string, any> = {};

    this.metrics.forEach(metric => {
      const key = `${metric.method} ${metric.endpoint}`;
      
      if (!stats[key]) {
        stats[key] = {
          count: 0,
          totalDuration: 0,
          maxDuration: 0,
          minDuration: Infinity,
          slowQueries: 0
        };
      }

      const stat = stats[key];
      stat.count++;
      stat.totalDuration += metric.duration;
      stat.maxDuration = Math.max(stat.maxDuration, metric.duration);
      stat.minDuration = Math.min(stat.minDuration, metric.duration);
      
      if (metric.duration > 1000) {
        stat.slowQueries++;
      }
    });

    // Calculate averages and clean up
    Object.keys(stats).forEach(key => {
      const stat = stats[key];
      stat.avgDuration = Math.round(stat.totalDuration / stat.count);
      delete stat.totalDuration;
      
      if (stat.minDuration === Infinity) {
        stat.minDuration = 0;
      }
    });

    return stats;
  }

  getTenantStats(): Record<string, {
    requestCount: number;
    avgDuration: number;
    slowQueries: number;
  }> {
    const stats: Record<string, any> = {};

    this.metrics.forEach(metric => {
      const tenantId = metric.tenantId || 'unknown';
      
      if (!stats[tenantId]) {
        stats[tenantId] = {
          requestCount: 0,
          totalDuration: 0,
          slowQueries: 0
        };
      }

      const stat = stats[tenantId];
      stat.requestCount++;
      stat.totalDuration += metric.duration;
      
      if (metric.duration > 1000) {
        stat.slowQueries++;
      }
    });

    // Calculate averages
    Object.keys(stats).forEach(tenantId => {
      const stat = stats[tenantId];
      stat.avgDuration = Math.round(stat.totalDuration / stat.requestCount);
      delete stat.totalDuration;
    });

    return stats;
  }

  clearMetrics() {
    this.metrics = [];
  }

  getHealthScore(): {
    score: number;
    status: 'excellent' | 'good' | 'fair' | 'poor';
    issues: string[];
  } {
    const issues: string[] = [];
    let score = 100;

    const avgResponseTime = this.getAverageResponseTime();
    const slowQueries = this.getSlowQueries();
    const slowQueryPercentage = (slowQueries.length / this.metrics.length) * 100;

    // Check average response time
    if (avgResponseTime > 2000) {
      issues.push('High average response time (> 2s)');
      score -= 30;
    } else if (avgResponseTime > 1000) {
      issues.push('Moderate average response time (> 1s)');
      score -= 15;
    }

    // Check slow query percentage
    if (slowQueryPercentage > 10) {
      issues.push('High percentage of slow queries (> 10%)');
      score -= 25;
    } else if (slowQueryPercentage > 5) {
      issues.push('Moderate percentage of slow queries (> 5%)');
      score -= 10;
    }

    // Check for error rates
    const errorCount = this.metrics.filter(m => m.statusCode >= 500).length;
    const errorPercentage = (errorCount / this.metrics.length) * 100;
    
    if (errorPercentage > 5) {
      issues.push('High error rate (> 5%)');
      score -= 20;
    } else if (errorPercentage > 1) {
      issues.push('Moderate error rate (> 1%)');
      score -= 10;
    }

    let status: 'excellent' | 'good' | 'fair' | 'poor';
    if (score >= 90) status = 'excellent';
    else if (score >= 75) status = 'good';
    else if (score >= 60) status = 'fair';
    else status = 'poor';

    return { score, status, issues };
  }
}

const queryMonitorService = new QueryMonitorService();

/**
 * Middleware to monitor query performance
 */
export const queryMonitorMiddleware = (req: Request, res: Response, next: NextFunction) => {
  const startTime = Date.now();

  // Store original end method
  const originalEnd = res.end;

  // Override end method to capture metrics
  res.end = function(chunk?: any, encoding?: any) {
    const duration = Date.now() - startTime;
    
    const metric: QueryMetrics = {
      endpoint: req.route?.path || req.path,
      method: req.method,
      duration,
      timestamp: new Date(),
      statusCode: res.statusCode,
      userAgent: req.get('User-Agent'),
      tenantId: req.headers['x-tenant-id'] as string,
      userId: (req as any).user?.id
    };

    queryMonitorService.addMetric(metric);

    // Call original end method
    return originalEnd.call(this, chunk, encoding);
  };

  next();
};

/**
 * Get query monitoring statistics
 */
export const getQueryStats = () => {
  return {
    metrics: queryMonitorService.getMetrics(100), // Last 100 requests
    slowQueries: queryMonitorService.getSlowQueries(),
    averageResponseTime: queryMonitorService.getAverageResponseTime(),
    endpointStats: queryMonitorService.getEndpointStats(),
    tenantStats: queryMonitorService.getTenantStats(),
    healthScore: queryMonitorService.getHealthScore()
  };
};

/**
 * Clear monitoring data
 */
export const clearQueryStats = () => {
  queryMonitorService.clearMetrics();
};

export { queryMonitorService };