import { Request, Response, NextFunction } from 'express';
import logger from '../config/logger';
import { v4 as uuidv4 } from 'uuid';

// Estender o tipo Request para incluir requestId
declare global {
  namespace Express {
    interface Request {
      requestId?: string;
      startTime?: number;
    }
  }
}

/**
 * Middleware para logging de requisições HTTP
 */
export const httpLoggingMiddleware = (req: Request, res: Response, next: NextFunction) => {
  // Gerar ID único para a requisição
  req.requestId = uuidv4();
  req.startTime = Date.now();

  // Extrair informações da requisição
  const requestInfo = {
    requestId: req.requestId,
    method: req.method,
    url: req.originalUrl,
    userAgent: req.get('User-Agent'),
    ip: req.ip || req.connection.remoteAddress,
    userId: (req as any).user?.id,
    tenantId: (req as any).user?.tenantId,
    contentLength: req.get('Content-Length'),
    referer: req.get('Referer')
  };

  // Log da requisição recebida
  logger.http('HTTP Request', {
    type: 'REQUEST',
    ...requestInfo,
    headers: filterSensitiveHeaders(req.headers),
    query: req.query,
    body: filterSensitiveBody(req.body)
  });

  // Interceptar a resposta
  const originalSend = res.send;
  const originalJson = res.json;

  res.send = function(body: any) {
    logResponse(req, res, body);
    return originalSend.call(this, body);
  };

  res.json = function(body: any) {
    logResponse(req, res, body);
    return originalJson.call(this, body);
  };

  next();
};

/**
 * Log da resposta HTTP
 */
function logResponse(req: Request, res: Response, body: any) {
  const duration = req.startTime ? Date.now() - req.startTime : 0;
  
  const responseInfo = {
    requestId: req.requestId,
    method: req.method,
    url: req.originalUrl,
    statusCode: res.statusCode,
    duration,
    userId: (req as any).user?.id,
    tenantId: (req as any).user?.tenantId,
    contentLength: res.get('Content-Length'),
    responseSize: Buffer.byteLength(JSON.stringify(body || ''), 'utf8')
  };

  // Determinar nível do log baseado no status code
  let logLevel = 'http';
  if (res.statusCode >= 400 && res.statusCode < 500) {
    logLevel = 'warn';
  } else if (res.statusCode >= 500) {
    logLevel = 'error';
  }

  logger.log(logLevel, 'HTTP Response', {
    type: 'RESPONSE',
    ...responseInfo,
    responseBody: filterSensitiveBody(body)
  });

  // Log de performance para requisições lentas
  if (duration > 1000) {
    logger.warn('Slow HTTP Request', {
      type: 'PERFORMANCE',
      ...responseInfo,
      threshold: '1000ms'
    });
  }
}

/**
 * Filtrar headers sensíveis
 */
function filterSensitiveHeaders(headers: any): any {
  const sensitiveHeaders = ['authorization', 'cookie', 'x-api-key', 'x-auth-token'];
  const filtered = { ...headers };
  
  sensitiveHeaders.forEach(header => {
    if (filtered[header]) {
      filtered[header] = '[REDACTED]';
    }
  });
  
  return filtered;
}

/**
 * Filtrar dados sensíveis do body
 */
function filterSensitiveBody(body: any): any {
  if (!body || typeof body !== 'object') {
    return body;
  }

  const sensitiveFields = [
    'password', 'token', 'secret', 'key', 'authorization',
    'creditCard', 'ssn', 'cpf', 'cnpj', 'bankAccount'
  ];

  const filtered = Array.isArray(body) ? [...body] : { ...body };

  function filterObject(obj: any): any {
    if (!obj || typeof obj !== 'object') {
      return obj;
    }

    const result = Array.isArray(obj) ? [] : {};
    
    for (const [key, value] of Object.entries(obj)) {
      const lowerKey = key.toLowerCase();
      
      if (sensitiveFields.some(field => lowerKey.includes(field))) {
        (result as any)[key] = '[REDACTED]';
      } else if (typeof value === 'object' && value !== null) {
        (result as any)[key] = filterObject(value);
      } else {
        (result as any)[key] = value;
      }
    }
    
    return result;
  }

  return filterObject(filtered);
}

/**
 * Middleware para capturar erros não tratados
 */
export const errorLoggingMiddleware = (
  error: Error,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const errorInfo = {
    requestId: req.requestId,
    method: req.method,
    url: req.originalUrl,
    userId: (req as any).user?.id,
    tenantId: (req as any).user?.tenantId,
    ip: req.ip || req.connection.remoteAddress,
    userAgent: req.get('User-Agent'),
    error: {
      name: error.name,
      message: error.message,
      stack: error.stack
    }
  };

  logger.error('Unhandled HTTP Error', errorInfo);
  
  next(error);
};

export default httpLoggingMiddleware;