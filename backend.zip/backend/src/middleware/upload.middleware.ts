import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { Request } from 'express';

// Ensure uploads directory exists
const uploadsDir = path.join(process.cwd(), 'uploads', 'avatars');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for avatar uploads
const storage = multer.diskStorage({
  destination: (req: Request, file: Express.Multer.File, cb: Function) => {
    cb(null, uploadsDir);
  },
  filename: (req: Request, file: Express.Multer.File, cb: Function) => {
    // Generate unique filename with timestamp and user ID
    const userId = req.params.id || req.user?.userId || 'unknown';
    const timestamp = Date.now();
    const extension = path.extname(file.originalname);
    const filename = `avatar-${userId}-${timestamp}${extension}`;
    cb(null, filename);
  },
});

// File filter for images only
const fileFilter = (req: Request, file: Express.Multer.File, cb: Function) => {
  // Check if file is an image
  if (file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error('Apenas arquivos de imagem são permitidos'), false);
  }
};

// Configure multer
export const uploadAvatar = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
    files: 1, // Only one file
  },
});

// Middleware to handle upload errors
export const handleUploadError = (error: any, req: Request, res: any, next: Function) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        error: 'FILE_TOO_LARGE',
        message: 'Arquivo muito grande. Tamanho máximo: 5MB',
      });
    }
    if (error.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({
        error: 'TOO_MANY_FILES',
        message: 'Apenas um arquivo é permitido',
      });
    }
  }
  
  if (error.message === 'Apenas arquivos de imagem são permitidos') {
    return res.status(400).json({
      error: 'INVALID_FILE_TYPE',
      message: error.message,
    });
  }

  next(error);
};

// Helper function to delete old avatar file
export const deleteOldAvatar = (avatarPath: string) => {
  if (avatarPath && fs.existsSync(avatarPath)) {
    try {
      fs.unlinkSync(avatarPath);
    } catch (error) {
      console.error('Error deleting old avatar:', error);
    }
  }
};

// Helper function to get avatar URL
export const getAvatarUrl = (filename: string): string => {
  return `/uploads/avatars/${filename}`;
};