import { Request, Response, NextFunction } from 'express';
import { verifyAccessToken, extractTokenFromHeader } from '../utils/jwt.utils';
import { JWTPayload } from '../types/user.types';

// Extend Express Request interface to include user
declare global {
  namespace Express {
    interface Request {
      user?: JWTPayload;
    }
  }
}

/**
 * Authentication middleware - verifies JWT token
 */
export function authenticateToken(req: Request, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    const token = extractTokenFromHeader(authHeader);

    if (!token) {
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'Token de acesso requerido',
      });
    }

    const decoded = verifyAccessToken(token);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({
      error: 'UNAUTHORIZED',
      message: error instanceof Error ? error.message : 'Token inválido',
    });
  }
}

/**
 * Optional authentication middleware - doesn't fail if no token
 */
export function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    const token = extractTokenFromHeader(authHeader);

    if (token) {
      const decoded = verifyAccessToken(token);
      req.user = decoded;
    }
    
    next();
  } catch (error) {
    // Continue without authentication if token is invalid
    next();
  }
}

/**
 * Role-based authorization middleware
 */
export function requireRoles(...roles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'Autenticação requerida',
      });
    }

    const userRoles = req.user.roles || [];
    const hasRequiredRole = roles.some(role => userRoles.includes(role));

    if (!hasRequiredRole) {
      return res.status(403).json({
        error: 'FORBIDDEN',
        message: `Acesso negado. Papéis requeridos: ${roles.join(', ')}`,
      });
    }

    next();
  };
}

/**
 * Permission-based authorization middleware
 */
export function requirePermissions(...permissions: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'Autenticação requerida',
      });
    }

    const userPermissions = req.user.permissions || [];
    const hasRequiredPermissions = permissions.every((permission: string) => 
      userPermissions.includes(permission)
    );

    if (!hasRequiredPermissions) {
      return res.status(403).json({
        error: 'FORBIDDEN',
        message: `Acesso negado. Permissões requeridas: ${permissions.join(', ')}`,
      });
    }

    next();
  };
}

/**
 * Resource-based authorization middleware
 */
export function requireResourcePermission(resource: string, action: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'Autenticação requerida',
      });
    }

    const userPermissions = req.user.permissions || [];
    const hasPermission = userPermissions.some(permission => 
      permission === `${resource}:${action}` || 
      permission === `${resource}:manage`
    );

    if (!hasPermission) {
      return res.status(403).json({
        error: 'FORBIDDEN',
        message: `Acesso negado. Permissão requerida: ${resource}:${action}`,
      });
    }

    next();
  };
}

/**
 * Tenant isolation middleware - ensures user can only access their tenant's data
 */
export function requireTenant(req: Request, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({
      error: 'UNAUTHORIZED',
      message: 'Autenticação requerida',
    });
  }

  // Admin users can access all tenants
  if (req.user.roles?.includes('ADMIN')) {
    return next();
  }

  const tenantId = req.params.tenantId || req.body.tenantId || req.query.tenantId;
  
  if (!tenantId) {
    return res.status(400).json({
      error: 'BAD_REQUEST',
      message: 'Tenant ID requerido',
    });
  }

  if (req.user.tenantId !== tenantId) {
    return res.status(403).json({
      error: 'FORBIDDEN',
      message: 'Acesso negado ao tenant especificado',
    });
  }

  next();
}

/**
 * Self or admin access middleware - allows users to access their own data or admins to access any
 */
export function requireSelfOrAdmin(userIdParam: string = 'userId') {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'Autenticação requerida',
      });
    }

    const targetUserId = req.params[userIdParam];
    const isAdmin = req.user.roles?.includes('ADMIN');
    const isSelf = req.user.userId === targetUserId;

    if (!isAdmin && !isSelf) {
      return res.status(403).json({
        error: 'FORBIDDEN',
        message: 'Acesso negado. Você só pode acessar seus próprios dados.',
      });
    }

    next();
  };
}