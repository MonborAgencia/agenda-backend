import { Request, Response, NextFunction } from 'express';
import { cacheService } from '../services/cache.service';
import { CACHE_TTL } from '../config/redis';

export interface CacheMiddlewareOptions {
  ttl?: number;
  keyGenerator?: (req: Request) => string;
  condition?: (req: Request) => boolean;
  prefix?: string;
}

/**
 * Cache middleware for GET requests
 */
export const cacheMiddleware = (options: CacheMiddlewareOptions = {}) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    // Only cache GET requests
    if (req.method !== 'GET') {
      return next();
    }

    // Check condition if provided
    if (options.condition && !options.condition(req)) {
      return next();
    }

    try {
      // Generate cache key
      const cacheKey = options.keyGenerator 
        ? options.keyGenerator(req)
        : generateDefaultCacheKey(req);

      // Try to get from cache
      const cachedData = await cacheService.get(cacheKey, {
        prefix: options.prefix,
        ttl: options.ttl
      });

      if (cachedData !== null) {
        // Return cached data
        res.json(cachedData);
        return;
      }

      // Store original json method
      const originalJson = res.json;

      // Override json method to cache the response
      res.json = function(data: any) {
        // Cache the response data
        cacheService.set(cacheKey, data, {
          prefix: options.prefix,
          ttl: options.ttl || CACHE_TTL.BOOKING_LIST
        }).catch(error => {
          console.error('Failed to cache response:', error);
        });

        // Call original json method
        return originalJson.call(this, data);
      };

      next();
    } catch (error) {
      console.error('Cache middleware error:', error);
      next();
    }
  };
};

/**
 * Generate default cache key from request
 */
function generateDefaultCacheKey(req: Request): string {
  const { originalUrl, query, params } = req;
  const tenantId = req.headers['x-tenant-id'] || 'default';
  const userId = (req as any).user?.id || 'anonymous';
  
  // Create a deterministic key from request data
  const queryString = Object.keys(query)
    .sort()
    .map(key => `${key}=${query[key]}`)
    .join('&');
  
  const paramsString = Object.keys(params)
    .sort()
    .map(key => `${key}=${params[key]}`)
    .join('&');

  return `${tenantId}:${userId}:${originalUrl}:${queryString}:${paramsString}`;
}

/**
 * Cache middleware for user-specific data
 */
export const userCacheMiddleware = (ttl: number = CACHE_TTL.USER_PROFILE) => {
  return cacheMiddleware({
    ttl,
    prefix: 'user',
    keyGenerator: (req) => {
      const userId = (req as any).user?.id || 'anonymous';
      const tenantId = req.headers['x-tenant-id'] || 'default';
      return `${tenantId}:${userId}:${req.originalUrl}:${JSON.stringify(req.query)}`;
    },
    condition: (req) => !!(req as any).user?.id
  });
};

/**
 * Cache middleware for tenant-specific data
 */
export const tenantCacheMiddleware = (ttl: number = CACHE_TTL.TENANT_CONFIG) => {
  return cacheMiddleware({
    ttl,
    prefix: 'tenant',
    keyGenerator: (req) => {
      const tenantId = req.headers['x-tenant-id'] || 'default';
      return `${tenantId}:${req.originalUrl}:${JSON.stringify(req.query)}`;
    }
  });
};

/**
 * Cache middleware for analytics data
 */
export const analyticsCacheMiddleware = (ttl: number = CACHE_TTL.ANALYTICS_DATA) => {
  return cacheMiddleware({
    ttl,
    prefix: 'analytics',
    keyGenerator: (req) => {
      const tenantId = req.headers['x-tenant-id'] || 'default';
      const { startDate, endDate, type, ...otherParams } = req.query;
      return `${tenantId}:${type}:${startDate}:${endDate}:${JSON.stringify(otherParams)}`;
    }
  });
};

/**
 * Cache middleware for schedule and availability data
 */
export const scheduleCacheMiddleware = (ttl: number = CACHE_TTL.DAY_AVAILABILITY) => {
  return cacheMiddleware({
    ttl,
    prefix: 'schedule',
    keyGenerator: (req) => {
      const tenantId = req.headers['x-tenant-id'] || 'default';
      const { professionalId, date, serviceId } = req.query;
      return `${tenantId}:${professionalId}:${date}:${serviceId}`;
    }
  });
};

/**
 * Invalidate cache after successful mutations
 */
export const invalidateCacheMiddleware = (patterns: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    // Store original json method
    const originalJson = res.json;

    // Override json method to invalidate cache after successful response
    res.json = function(data: any) {
      // Only invalidate on successful responses (2xx status codes)
      if (res.statusCode >= 200 && res.statusCode < 300) {
        const tenantId = req.headers['x-tenant-id'] as string || 'default';
        
        // Invalidate cache patterns
        patterns.forEach(pattern => {
          const fullPattern = `${tenantId}:${pattern}`;
          cacheService.delPattern(fullPattern).catch(error => {
            console.error(`Failed to invalidate cache pattern ${fullPattern}:`, error);
          });
        });
      }

      // Call original json method
      return originalJson.call(this, data);
    };

    next();
  };
};