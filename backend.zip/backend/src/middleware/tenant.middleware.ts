import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Extend Request interface to include tenant information
declare global {
  namespace Express {
    interface Request {
      tenant?: {
        id: string;
        name: string;
        slug: string;
        settings: any;
      };
    }
  }
}

/**
 * Middleware para extrair tenant do subdomínio ou header
 */
export const extractTenant = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let tenantSlug: string | null = null;

    // Método 1: Extrair do subdomínio
    const host = req.get('host') || '';
    const subdomain = host.split('.')[0];
    
    // Verificar se não é um subdomínio padrão (www, api, admin)
    if (subdomain && !['www', 'api', 'admin', 'localhost'].includes(subdomain)) {
      tenantSlug = subdomain;
    }

    // Método 2: Extrair do header X-Tenant-Slug (para desenvolvimento/API)
    if (!tenantSlug) {
      tenantSlug = req.get('X-Tenant-Slug') || null;
    }

    // Método 3: Extrair do parâmetro da URL (fallback)
    if (!tenantSlug && req.params.tenantSlug) {
      tenantSlug = req.params.tenantSlug;
    }

    // Se não encontrou tenant, continuar sem tenant (para rotas globais)
    if (!tenantSlug) {
      return next();
    }

    // Buscar tenant no banco de dados
    const tenant = await prisma.tenant.findUnique({
      where: { 
        slug: tenantSlug,
        isActive: true,
      },
    });

    if (!tenant) {
      return res.status(404).json({
        error: 'TENANT_NOT_FOUND',
        message: 'Tenant não encontrado ou inativo',
      });
    }

    // Adicionar tenant ao request
    req.tenant = {
      id: tenant.id,
      name: tenant.name,
      slug: tenant.slug,
      settings: tenant.settings ? JSON.parse(tenant.settings) : {},
    };

    next();
  } catch (error) {
    console.error('Extract tenant error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
};

/**
 * Middleware para garantir que um tenant seja obrigatório
 */
export const requireTenant = (req: Request, res: Response, next: NextFunction) => {
  if (!req.tenant) {
    return res.status(400).json({
      error: 'TENANT_REQUIRED',
      message: 'Tenant é obrigatório para esta operação',
    });
  }
  next();
};

/**
 * Middleware para validar se o usuário pertence ao tenant
 */
export const validateTenantAccess = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.tenant || !req.user) {
      return next();
    }

    // Verificar se o usuário pertence ao tenant
    const user = await prisma.user.findFirst({
      where: {
        id: req.user.userId,
        tenantId: req.tenant.id,
        isActive: true,
      },
    });

    if (!user) {
      return res.status(403).json({
        error: 'TENANT_ACCESS_DENIED',
        message: 'Usuário não tem acesso a este tenant',
      });
    }

    next();
  } catch (error) {
    console.error('Validate tenant access error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
};

/**
 * Middleware para adicionar filtro de tenant automaticamente nas queries
 */
export const addTenantFilter = (req: Request, res: Response, next: NextFunction) => {
  if (req.tenant) {
    // Adicionar tenantId aos parâmetros da query se não existir
    if (!req.query.tenantId) {
      req.query.tenantId = req.tenant.id;
    }
    
    // Adicionar tenantId ao body se for POST/PUT e não existir
    if (['POST', 'PUT', 'PATCH'].includes(req.method) && req.body && !req.body.tenantId) {
      req.body.tenantId = req.tenant.id;
    }
  }
  
  next();
};

/**
 * Helper function para criar filtro de tenant para queries Prisma
 */
export const createTenantFilter = (req: Request, additionalFilters: any = {}) => {
  const baseFilter = { ...additionalFilters };
  
  if (req.tenant) {
    baseFilter.tenantId = req.tenant.id;
  }
  
  return baseFilter;
};

/**
 * Middleware para logging de ações por tenant
 */
export const logTenantAction = (action: string) => {
  return (req: Request, res: Response, next: NextFunction) => {
    const originalSend = res.send;
    
    res.send = function(data) {
      // Log da ação apenas se foi bem-sucedida
      if (res.statusCode < 400 && req.tenant) {
        console.log(`[TENANT:${req.tenant.slug}] ${action} - User: ${req.user?.userId || 'anonymous'} - ${req.method} ${req.originalUrl}`);
      }
      
      return originalSend.call(this, data);
    };
    
    next();
  };
};