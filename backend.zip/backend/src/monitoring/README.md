# Sistema de Monitoramento e Logs - Agenda Lotada 24h

Este documento descreve o sistema completo de monitoramento, logging e alertas implementado na aplicação.

## Componentes Implementados

### 1. Sistema de Logging Estruturado

#### Configuração (src/config/logger.ts)
- **Winston** como biblioteca principal de logging
- **Rotação diária** de logs com compressão automática
- **Níveis de log customizados**: error, warn, info, http, debug, audit
- **Formato estruturado** em JSON para facilitar análise
- **Separação por tipo**: application, error, audit, http, exceptions, rejections

#### Características:
- Logs em desenvolvimento: console colorido + arquivos
- Logs em produção: apenas arquivos estruturados
- Retenção configurável por tipo de log
- Tratamento automático de exceções não capturadas

### 2. Sistema de Auditoria

#### Serviço de Auditoria (src/services/audit.service.ts)
- **Logs de autenticação**: login, logout, falhas
- **Logs de operações CRUD**: create, read, update, delete
- **Logs de agendamentos**: criação, cancelamento, reagendamento
- **Logs de pagamentos**: tentativas, sucessos, falhas
- **Logs de acesso a dados sensíveis**
- **Logs de configurações do sistema**
- **Logs de eventos de segurança**

#### Middleware de Logging (src/middleware/logging.middleware.ts)
- **Logging automático** de todas as requisições HTTP
- **Filtragem de dados sensíveis** (senhas, tokens, etc.)
- **Correlação de requisições** com IDs únicos
- **Medição de tempo de resposta**
- **Detecção de requisições lentas**

### 3. Sistema de Métricas

#### Serviço de Métricas (src/services/metrics.service.ts)
- **Métricas Prometheus** compatíveis
- **Métricas HTTP**: requests, duration, status codes
- **Métricas de banco de dados**: query duration, connections
- **Métricas de cache**: hits, misses, operations
- **Métricas de negócio**: bookings, auth events, notifications
- **Métricas de sistema**: memory, CPU, connections

#### Middleware de Métricas (src/middleware/metrics.middleware.ts)
- **Coleta automática** de métricas HTTP
- **Normalização de rotas** para agregação
- **Contagem de conexões ativas**
- **Detecção de erros** por tipo

### 4. Sistema de Health Check

#### Serviço de Health Check (src/services/health.service.ts)
- **Verificação de banco de dados**: conectividade e latência
- **Verificação de Redis**: conectividade e latência
- **Verificação de memória**: uso e limites
- **Verificação de disco**: espaço disponível
- **Verificação de serviços externos**: APIs terceiras
- **Status agregado**: healthy, degraded, unhealthy

### 5. Sistema de Alertas

#### Serviço de Alertas (src/services/alerting.service.ts)
- **Regras configuráveis** de alerta
- **Monitoramento contínuo** de métricas
- **Cooldown** para evitar spam de alertas
- **Severidade**: low, medium, high, critical
- **Resolução automática** de alertas
- **Limpeza de alertas antigos**

#### Regras Padrão:
- Alto uso de memória (>85%)
- Alta taxa de erro (>5%)
- Tempo de resposta lento (>2s)
- Falha de conexão com banco
- Falha de conexão com Redis
- Muitas conexões ativas (>1000)

### 6. Rotas de Monitoramento

#### Endpoints Disponíveis (src/routes/monitoring.routes.ts)

```
GET /api/monitoring/metrics          # Métricas Prometheus
GET /api/monitoring/health           # Health check completo
GET /api/monitoring/ping             # Health check simples
GET /api/monitoring/system           # Informações do sistema (auth)
POST /api/monitoring/metrics/clear   # Limpar métricas (admin)
GET /api/monitoring/metrics/:name    # Métrica específica (auth)
POST /api/monitoring/alerts          # Webhook para alertas
```

### 7. Limpeza Automática

#### Script de Limpeza (src/scripts/cleanup-logs.ts)
- **Remoção automática** de logs antigos
- **Configuração de retenção** por tipo
- **Estatísticas** de limpeza
- **Execução manual** ou automática

#### Job Cron (src/jobs/log-cleanup.job.ts)
- **Execução diária** às 2:00 AM
- **Limpeza de alertas** semanalmente
- **Monitoramento** de uso de disco
- **Alertas** para problemas de espaço

## Configuração

### Variáveis de Ambiente

```env
# Logging
LOG_LEVEL=info                    # Nível mínimo de log
NODE_ENV=production              # Ambiente (afeta formato dos logs)

# Métricas
METRICS_ENABLED=true             # Habilitar coleta de métricas
METRICS_INTERVAL=60000           # Intervalo de coleta (ms)

# Alertas
ALERTS_ENABLED=true              # Habilitar sistema de alertas
ALERT_CHECK_INTERVAL=60000       # Intervalo de verificação (ms)

# Health Check
HEALTH_CHECK_TIMEOUT=5000        # Timeout para checks (ms)

# Limpeza
LOG_RETENTION_DAYS=30            # Retenção de logs (dias)
ALERT_RETENTION_DAYS=7           # Retenção de alertas (dias)
```

### Estrutura de Diretórios

```
logs/
├── application-2024-01-01.log    # Logs gerais
├── error-2024-01-01.log          # Logs de erro
├── audit-2024-01-01.log          # Logs de auditoria
├── http-2024-01-01.log           # Logs HTTP
├── exceptions-2024-01-01.log     # Exceções não tratadas
└── rejections-2024-01-01.log     # Promises rejeitadas
```

## Uso

### Logging Manual

```typescript
import LoggerUtils from '../utils/logger.utils';

// Log básico
LoggerUtils.info('Operation completed', { userId: '123' });

// Log de erro
LoggerUtils.error('Operation failed', error, { userId: '123' });

// Log de performance
LoggerUtils.performance('database_query', 150, { table: 'users' });

// Log de segurança
LoggerUtils.security('unauthorized_access', { 
  severity: 'HIGH',
  ipAddress: '192.168.1.1' 
});
```

### Auditoria Manual

```typescript
import AuditService from '../services/audit.service';

// Log de autenticação
AuditService.logAuth({
  userId: '123',
  action: 'LOGIN',
  success: true,
  ipAddress: '192.168.1.1'
});

// Log de operação CRUD
AuditService.logCrud({
  userId: '123',
  action: 'UPDATE',
  resource: 'USER',
  resourceId: '456',
  oldValues: { name: 'Old Name' },
  newValues: { name: 'New Name' },
  success: true
});
```

### Métricas Manuais

```typescript
import MetricsService from '../services/metrics.service';

// Registrar requisição HTTP
MetricsService.recordHttpRequest('GET', '/api/users', 200, 150, 'tenant123');

// Registrar operação de banco
MetricsService.recordDatabaseQuery('SELECT', 'users', 50, 'tenant123');

// Registrar evento de negócio
MetricsService.recordBusinessEvent('booking_created', 'tenant123', 'CLIENT');
```

## Monitoramento Externo

### Prometheus

O endpoint `/api/monitoring/metrics` expõe métricas no formato Prometheus:

```
# HELP agenda_lotada_http_requests_total Total number of HTTP requests
# TYPE agenda_lotada_http_requests_total counter
agenda_lotada_http_requests_total{method="GET",route="/api/users",status_code="200",tenant_id="tenant123"} 42

# HELP agenda_lotada_http_request_duration_seconds Duration of HTTP requests in seconds
# TYPE agenda_lotada_http_request_duration_seconds histogram
agenda_lotada_http_request_duration_seconds_bucket{method="GET",route="/api/users",status_code="200",tenant_id="tenant123",le="0.1"} 30
```

### Grafana

Configure dashboards usando as métricas expostas:
- Taxa de requisições por minuto
- Tempo médio de resposta
- Taxa de erro
- Uso de memória e CPU
- Status de health checks

### Alertmanager

Configure alertas baseados nas métricas:
- Alta taxa de erro
- Tempo de resposta elevado
- Uso excessivo de recursos
- Falhas de health check

## Troubleshooting

### Logs Não Aparecem
1. Verificar permissões do diretório `logs/`
2. Verificar variável `LOG_LEVEL`
3. Verificar se o Winston está configurado corretamente

### Métricas Não Coletadas
1. Verificar se `METRICS_ENABLED=true`
2. Verificar se os middlewares estão registrados
3. Verificar endpoint `/api/monitoring/metrics`

### Alertas Não Funcionam
1. Verificar se `ALERTS_ENABLED=true`
2. Verificar se o serviço foi iniciado
3. Verificar logs de erro do sistema de alertas

### Performance Issues
1. Verificar retenção de logs
2. Executar limpeza manual
3. Verificar uso de disco
4. Ajustar intervalos de coleta

## Segurança

- **Filtragem automática** de dados sensíveis
- **Acesso restrito** a endpoints administrativos
- **Logs de auditoria** para compliance
- **Detecção de atividades suspeitas**
- **Alertas de segurança** automáticos

## Compliance

O sistema atende aos requisitos de:
- **LGPD**: logs de acesso a dados pessoais
- **SOX**: auditoria de operações financeiras
- **ISO 27001**: monitoramento de segurança
- **PCI DSS**: logs de transações (se aplicável)