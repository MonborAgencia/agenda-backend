# Test Suite - Authentication System

## Overview

This test suite covers the authentication and authorization system implemented for the Agenda Lotada 24h application.

## Test Structure

```
src/test/
├── setup.ts                           # Test configuration and mocks
├── utils/
│   ├── password.utils.test.ts         # Password hashing and validation tests
│   └── jwt.utils.test.ts              # JWT token generation and verification tests
├── services/
│   └── auth.service.test.ts           # Authentication service business logic tests
├── controllers/
│   └── auth.controller.test.ts        # Authentication controller endpoint tests
├── integration/
│   └── auth.integration.test.ts       # End-to-end integration tests
└── README.md                          # This file
```

## Test Coverage

### Unit Tests

#### Password Utils (`password.utils.test.ts`)
- ✅ Password hashing functionality
- ✅ Password comparison functionality
- ✅ Password strength validation
- ✅ Random password generation

#### JWT Utils (`jwt.utils.test.ts`)
- ✅ Access token generation and verification
- ✅ Refresh token generation and verification
- ✅ Token pair generation
- ✅ Token extraction from headers
- ✅ Token expiration checking

#### Auth Service (`auth.service.test.ts`)
- ✅ User login with valid/invalid credentials
- ✅ Token refresh functionality
- ✅ Current user retrieval
- ✅ Permission checking
- ✅ Role validation
- ✅ Password change functionality

### Integration Tests

#### Auth Controller (`auth.controller.test.ts`)
- ✅ Login endpoint with various scenarios
- ✅ Registration endpoint with validation
- ✅ Token refresh endpoint
- ✅ Current user endpoint
- ✅ Error handling and validation

#### Full Integration (`auth.integration.test.ts`)
- ✅ Health check endpoint
- ✅ API base route
- ✅ Authentication route availability
- ✅ Protected route access control
- ✅ 404 error handling

## Running Tests

### Prerequisites
- Node.js and npm installed
- All dependencies installed (`npm install`)
- Test database configured (if using real database)

### Commands

```bash
# Run all tests
npm test

# Run specific test file
npm test -- password.utils.test.ts

# Run tests with coverage
npm test -- --coverage

# Run tests in watch mode
npm test -- --watch

# Run integration tests only
npm test -- --testPathPattern="integration"

# Run unit tests only
npm test -- --testPathPattern="utils|services|controllers"
```

## Test Configuration

### Environment Variables
The following environment variables are set for testing:
- `JWT_SECRET`: Test JWT secret key
- `JWT_REFRESH_SECRET`: Test refresh token secret
- `JWT_EXPIRES_IN`: Token expiration time
- `JWT_REFRESH_EXPIRES_IN`: Refresh token expiration time

### Mocks
- **Prisma Client**: Mocked to avoid database dependencies
- **External Services**: Mocked for isolated testing
- **JWT Tokens**: Real tokens used for integration testing

## Test Data

### Mock Users
```typescript
const mockUser = {
  id: 'user-123',
  email: 'test@example.com',
  name: 'Test User',
  isActive: true,
  userRoles: [
    {
      role: {
        name: 'CLIENT',
        rolePermissions: [
          {
            permission: {
              name: 'booking:create',
              resource: 'booking',
              action: 'create'
            }
          }
        ]
      }
    }
  ]
}
```

### Test Credentials
- **Valid Password**: `TestPassword123!`
- **Weak Password**: `weak`
- **Test Email**: `test@example.com`

## Coverage Goals

- **Unit Tests**: 90%+ coverage for business logic
- **Integration Tests**: All API endpoints covered
- **Error Scenarios**: All error paths tested
- **Security**: Authentication and authorization flows validated

## Best Practices

1. **Isolation**: Each test is independent and doesn't rely on others
2. **Mocking**: External dependencies are mocked appropriately
3. **Real Data**: Integration tests use realistic data structures
4. **Error Testing**: Both success and failure scenarios are covered
5. **Security**: Authentication flows are thoroughly tested

## Continuous Integration

These tests should be run in CI/CD pipeline:
1. On every pull request
2. Before deployment to staging/production
3. Nightly for regression testing

## Troubleshooting

### Common Issues

1. **Mock not working**: Ensure mocks are properly configured in `setup.ts`
2. **JWT errors**: Check environment variables are set correctly
3. **Async issues**: Ensure all async operations use `await`
4. **Database errors**: Verify Prisma mocks are properly configured

### Debug Tips

1. Use `console.log` in tests for debugging
2. Run single test file to isolate issues
3. Check test setup and teardown
4. Verify mock implementations match real service interfaces