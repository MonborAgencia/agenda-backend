import request from 'supertest';
import express from 'express';
import authRoutes from '../../routes/auth.routes';
import { AuthService } from '../../services/auth.service';
import { UserService } from '../../services/user.service';

// Mock the services
jest.mock('../../services/auth.service');
jest.mock('../../services/user.service');

const app = express();
app.use(express.json());
app.use('/auth', authRoutes);

describe('Auth Controller', () => {
  let mockAuthService: jest.Mocked<AuthService>;
  let mockUserService: jest.Mocked<UserService>;

  beforeEach(() => {
    mockAuthService = new AuthService({} as any) as jest.Mocked<AuthService>;
    mockUserService = new UserService({} as any) as jest.Mocked<UserService>;
    jest.clearAllMocks();
  });

  describe('POST /auth/login', () => {
    it('should login successfully with valid credentials', async () => {
      const mockResult = {
        user: {
          id: 'user-123',
          email: 'test@example.com',
          name: 'Test User',
          isActive: true,
        },
        tokens: {
          accessToken: 'access-token',
          refreshToken: 'refresh-token',
        },
      };

      // Mock the login method
      jest.spyOn(mockAuthService, 'login').mockResolvedValue(mockResult);
      
      // Replace the actual service with mock
      const AuthServiceMock = AuthService as jest.MockedClass<typeof AuthService>;
      AuthServiceMock.prototype.login = mockAuthService.login;

      const response = await request(app)
        .post('/auth/login')
        .send({
          email: 'test@example.com',
          password: 'testPassword123!',
        });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Login realizado com sucesso');
      expect(response.body.data).toEqual(mockResult);
    });

    it('should return 401 for invalid credentials', async () => {
      jest.spyOn(mockAuthService, 'login').mockRejectedValue(new Error('Credenciais inválidas'));
      
      const AuthServiceMock = AuthService as jest.MockedClass<typeof AuthService>;
      AuthServiceMock.prototype.login = mockAuthService.login;

      const response = await request(app)
        .post('/auth/login')
        .send({
          email: 'test@example.com',
          password: 'wrongPassword',
        });

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('AUTHENTICATION_FAILED');
      expect(response.body.message).toBe('Credenciais inválidas');
    });

    it('should return 400 for invalid input format', async () => {
      const response = await request(app)
        .post('/auth/login')
        .send({
          email: 'invalid-email',
          password: 'short',
        });

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('AUTHENTICATION_FAILED');
    });

    it('should return 400 for missing fields', async () => {
      const response = await request(app)
        .post('/auth/login')
        .send({
          email: 'test@example.com',
          // password missing
        });

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('AUTHENTICATION_FAILED');
    });
  });

  describe('POST /auth/register', () => {
    it('should register successfully with valid data', async () => {
      const mockUser = {
        id: 'user-123',
        email: 'test@example.com',
        name: 'Test User',
        isActive: true,
        userRoles: [],
      };

      jest.spyOn(mockUserService, 'getUserByEmail').mockResolvedValue(null);
      jest.spyOn(mockUserService, 'createUser').mockResolvedValue(mockUser as any);
      
      const UserServiceMock = UserService as jest.MockedClass<typeof UserService>;
      UserServiceMock.prototype.getUserByEmail = mockUserService.getUserByEmail;
      UserServiceMock.prototype.createUser = mockUserService.createUser;

      const response = await request(app)
        .post('/auth/register')
        .send({
          email: 'test@example.com',
          name: 'Test User',
          password: 'TestPassword123!',
          roleIds: ['role-123'],
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Usuário criado com sucesso');
      expect(response.body.data.user.email).toBe('test@example.com');
    });

    it('should return 409 for existing user', async () => {
      const existingUser = {
        id: 'user-123',
        email: 'test@example.com',
        name: 'Existing User',
      };

      jest.spyOn(mockUserService, 'getUserByEmail').mockResolvedValue(existingUser as any);
      
      const UserServiceMock = UserService as jest.MockedClass<typeof UserService>;
      UserServiceMock.prototype.getUserByEmail = mockUserService.getUserByEmail;

      const response = await request(app)
        .post('/auth/register')
        .send({
          email: 'test@example.com',
          name: 'Test User',
          password: 'TestPassword123!',
          roleIds: ['role-123'],
        });

      expect(response.status).toBe(409);
      expect(response.body.error).toBe('USER_EXISTS');
      expect(response.body.message).toBe('Usuário já existe com este email');
    });

    it('should return 400 for weak password', async () => {
      jest.spyOn(mockUserService, 'getUserByEmail').mockResolvedValue(null);
      
      const UserServiceMock = UserService as jest.MockedClass<typeof UserService>;
      UserServiceMock.prototype.getUserByEmail = mockUserService.getUserByEmail;

      const response = await request(app)
        .post('/auth/register')
        .send({
          email: 'test@example.com',
          name: 'Test User',
          password: 'weak',
          roleIds: ['role-123'],
        });

      expect(response.status).toBe(400);
      expect(response.body.error).toBe('VALIDATION_ERROR');
      expect(response.body.message).toBe('Senha não atende aos critérios de segurança');
    });
  });

  describe('POST /auth/refresh', () => {
    it('should refresh token successfully', async () => {
      const mockTokens = {
        accessToken: 'new-access-token',
        refreshToken: 'new-refresh-token',
      };

      jest.spyOn(mockAuthService, 'refreshToken').mockResolvedValue(mockTokens);
      
      const AuthServiceMock = AuthService as jest.MockedClass<typeof AuthService>;
      AuthServiceMock.prototype.refreshToken = mockAuthService.refreshToken;

      const response = await request(app)
        .post('/auth/refresh')
        .send({
          refreshToken: 'valid-refresh-token',
        });

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Token renovado com sucesso');
      expect(response.body.data.tokens).toEqual(mockTokens);
    });

    it('should return 401 for invalid refresh token', async () => {
      jest.spyOn(mockAuthService, 'refreshToken').mockRejectedValue(new Error('Refresh token inválido'));
      
      const AuthServiceMock = AuthService as jest.MockedClass<typeof AuthService>;
      AuthServiceMock.prototype.refreshToken = mockAuthService.refreshToken;

      const response = await request(app)
        .post('/auth/refresh')
        .send({
          refreshToken: 'invalid-refresh-token',
        });

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('INVALID_REFRESH_TOKEN');
    });

    it('should return 400 for missing refresh token', async () => {
      const response = await request(app)
        .post('/auth/refresh')
        .send({});

      expect(response.status).toBe(400);
      expect(response.body.error).toBe('VALIDATION_ERROR');
      expect(response.body.message).toBe('Refresh token é obrigatório');
    });
  });

  describe('GET /auth/me', () => {
    it('should return current user when authenticated', async () => {
      const mockUser = {
        id: 'user-123',
        email: 'test@example.com',
        name: 'Test User',
        isActive: true,
      };

      jest.spyOn(mockAuthService, 'getCurrentUser').mockResolvedValue(mockUser);
      
      const AuthServiceMock = AuthService as jest.MockedClass<typeof AuthService>;
      AuthServiceMock.prototype.getCurrentUser = mockAuthService.getCurrentUser;

      // Mock JWT verification
      const jwt = require('jsonwebtoken');
      jest.spyOn(jwt, 'verify').mockReturnValue({
        userId: 'user-123',
        email: 'test@example.com',
        roles: ['CLIENT'],
        permissions: [],
      });

      const response = await request(app)
        .get('/auth/me')
        .set('Authorization', 'Bearer valid-token');

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.user).toEqual(mockUser);
    });

    it('should return 401 when not authenticated', async () => {
      const response = await request(app)
        .get('/auth/me');

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('UNAUTHORIZED');
    });
  });
});