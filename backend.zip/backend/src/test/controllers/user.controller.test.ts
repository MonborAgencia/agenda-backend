import request from 'supertest';
import { app } from '../../index';
import { PrismaClient } from '@prisma/client';
import { generateAccessToken } from '../../utils/jwt.utils';

// Mock the PrismaClient
jest.mock('@prisma/client');

describe('User Controller', () => {
  let authToken: string;

  beforeEach(() => {
    // Generate a valid JWT token for testing
    authToken = generateAccessToken({
      userId: 'user-123',
      email: 'test@example.com',
      tenantId: 'tenant-123',
      roles: ['ADMIN'],
      permissions: ['user:read', 'user:create', 'user:update', 'user:delete', 'user:manage'],
    });

    jest.clearAllMocks();
  });

  describe('GET /api/users', () => {
    it('should return paginated users', async () => {
      const mockUsers = [
        {
          id: 'user-1',
          email: 'user1@example.com',
          name: 'User 1',
          phone: null,
          tenantId: 'tenant-123',
          isActive: true,
          emailVerified: true,
          lastLoginAt: null,
          createdAt: new Date(),
          updatedAt: new Date(),
          profile: null,
          userRoles: [],
        },
      ];

      // Mock UserService.getUsers
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.getUsers = jest.fn().mockResolvedValue({
        users: mockUsers,
        pagination: {
          page: 1,
          limit: 10,
          total: 1,
          pages: 1,
        },
      });

      const response = await request(app)
        .get('/api/users')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.users).toHaveLength(1);
      expect(response.body.data.pagination.total).toBe(1);
    });

    it('should return 401 without authentication', async () => {
      await request(app)
        .get('/api/users')
        .expect(401);
    });

    it('should handle query parameters', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.getUsers = jest.fn().mockResolvedValue({
        users: [],
        pagination: {
          page: 2,
          limit: 5,
          total: 0,
          pages: 0,
        },
      });

      await request(app)
        .get('/api/users?page=2&limit=5&search=test&tenantId=tenant-123&isActive=true')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(mockUserService.prototype.getUsers).toHaveBeenCalledWith({
        page: 2,
        limit: 5,
        tenantId: 'tenant-123',
        isActive: true,
        search: 'test',
      });
    });
  });

  describe('GET /api/users/:id', () => {
    const mockUser = {
      id: 'user-123',
      email: 'test@example.com',
      name: 'Test User',
      phone: '+1234567890',
      tenantId: 'tenant-123',
      isActive: true,
      emailVerified: true,
      lastLoginAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      profile: null,
      userRoles: [],
    };

    it('should return user by ID', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.getUserById = jest.fn().mockResolvedValue(mockUser);

      const response = await request(app)
        .get('/api/users/user-123')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.user.id).toBe('user-123');
      expect(response.body.data.user.password).toBeUndefined(); // Password should be removed
    });

    it('should return 404 for non-existent user', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.getUserById = jest.fn().mockResolvedValue(null);

      const response = await request(app)
        .get('/api/users/non-existent')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(404);

      expect(response.body.error).toBe('USER_NOT_FOUND');
    });
  });

  describe('POST /api/users', () => {
    const mockCreateUserInput = {
      email: 'newuser@example.com',
      name: 'New User',
      phone: '+1234567890',
      password: 'testPassword123!',
      tenantId: 'tenant-123',
      roleIds: ['role-123'],
    };

    const mockCreatedUser = {
      id: 'user-new',
      email: 'newuser@example.com',
      name: 'New User',
      phone: '+1234567890',
      tenantId: 'tenant-123',
      isActive: true,
      emailVerified: false,
      lastLoginAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      profile: null,
      userRoles: [],
    };

    it('should create user successfully', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.getUserByEmail = jest.fn().mockResolvedValue(null);
      mockUserService.prototype.createUser = jest.fn().mockResolvedValue(mockCreatedUser);

      const response = await request(app)
        .post('/api/users')
        .set('Authorization', `Bearer ${authToken}`)
        .send(mockCreateUserInput)
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data.user.email).toBe(mockCreateUserInput.email);
      expect(response.body.data.user.password).toBeUndefined(); // Password should be removed
    });

    it('should return 409 for existing user', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.getUserByEmail = jest.fn().mockResolvedValue(mockCreatedUser);

      const response = await request(app)
        .post('/api/users')
        .set('Authorization', `Bearer ${authToken}`)
        .send(mockCreateUserInput)
        .expect(409);

      expect(response.body.error).toBe('USER_EXISTS');
    });

    it('should return 400 for invalid input', async () => {
      const invalidInput = {
        email: 'invalid-email',
        name: '',
        password: '123', // Too short
        roleIds: [], // Empty array
      };

      await request(app)
        .post('/api/users')
        .set('Authorization', `Bearer ${authToken}`)
        .send(invalidInput)
        .expect(400);
    });
  });

  describe('PUT /api/users/:id', () => {
    const mockUpdateInput = {
      name: 'Updated Name',
      email: 'updated@example.com',
    };

    const mockUpdatedUser = {
      id: 'user-123',
      email: 'updated@example.com',
      name: 'Updated Name',
      phone: '+1234567890',
      tenantId: 'tenant-123',
      isActive: true,
      emailVerified: true,
      lastLoginAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      profile: null,
      userRoles: [],
    };

    it('should update user successfully', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.updateUser = jest.fn().mockResolvedValue(mockUpdatedUser);

      const response = await request(app)
        .put('/api/users/user-123')
        .set('Authorization', `Bearer ${authToken}`)
        .send(mockUpdateInput)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.user.name).toBe(mockUpdateInput.name);
      expect(response.body.data.user.password).toBeUndefined(); // Password should be removed
    });

    it('should return 404 for non-existent user', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.updateUser = jest.fn().mockResolvedValue(null);

      const response = await request(app)
        .put('/api/users/non-existent')
        .set('Authorization', `Bearer ${authToken}`)
        .send(mockUpdateInput)
        .expect(404);

      expect(response.body.error).toBe('USER_NOT_FOUND');
    });
  });

  describe('PUT /api/users/:id/profile', () => {
    const mockProfileInput = {
      bio: 'Updated bio',
      avatar: 'https://example.com/avatar.jpg',
    };

    const mockUpdatedProfile = {
      id: 'profile-123',
      userId: 'user-123',
      bio: 'Updated bio',
      avatar: 'https://example.com/avatar.jpg',
      specialties: null,
      preferences: null,
      workingHours: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    it('should update user profile successfully', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.updateUserProfile = jest.fn().mockResolvedValue(mockUpdatedProfile);

      const response = await request(app)
        .put('/api/users/user-123/profile')
        .set('Authorization', `Bearer ${authToken}`)
        .send(mockProfileInput)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.profile.bio).toBe(mockProfileInput.bio);
    });
  });

  describe('PUT /api/users/:id/profile/professional', () => {
    const mockProfessionalProfileInput = {
      bio: 'Professional bio',
      specialties: ['Hair Cut', 'Hair Color'],
      workingHours: {
        monday: { start: '09:00', end: '18:00', enabled: true },
        tuesday: { start: '09:00', end: '18:00', enabled: true },
      },
    };

    const mockUpdatedProfile = {
      id: 'profile-123',
      userId: 'user-123',
      bio: 'Professional bio',
      specialties: JSON.stringify(['Hair Cut', 'Hair Color']),
      workingHours: JSON.stringify({
        monday: { start: '09:00', end: '18:00', enabled: true },
        tuesday: { start: '09:00', end: '18:00', enabled: true },
      }),
      preferences: null,
      avatar: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    it('should update professional profile successfully', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.updateProfessionalProfile = jest.fn().mockResolvedValue(mockUpdatedProfile);

      const response = await request(app)
        .put('/api/users/user-123/profile/professional')
        .set('Authorization', `Bearer ${authToken}`)
        .send(mockProfessionalProfileInput)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.profile.bio).toBe(mockProfessionalProfileInput.bio);
    });

    it('should return 400 for invalid professional profile', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.updateProfessionalProfile = jest.fn()
        .mockRejectedValue(new Error('Usuário não é um profissional'));

      const response = await request(app)
        .put('/api/users/user-123/profile/professional')
        .set('Authorization', `Bearer ${authToken}`)
        .send(mockProfessionalProfileInput)
        .expect(400);

      expect(response.body.error).toBe('VALIDATION_ERROR');
    });
  });

  describe('PUT /api/users/:id/profile/client', () => {
    const mockClientProfileInput = {
      bio: 'Client bio',
      preferences: {
        notifications: {
          email: true,
          whatsapp: true,
          push: false,
        },
        reminderTime: '24h',
        language: 'pt',
      },
    };

    const mockUpdatedProfile = {
      id: 'profile-123',
      userId: 'user-123',
      bio: 'Client bio',
      preferences: JSON.stringify(mockClientProfileInput.preferences),
      specialties: null,
      workingHours: null,
      avatar: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    it('should update client profile successfully', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.updateClientProfile = jest.fn().mockResolvedValue(mockUpdatedProfile);

      const response = await request(app)
        .put('/api/users/user-123/profile/client')
        .set('Authorization', `Bearer ${authToken}`)
        .send(mockClientProfileInput)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.profile.bio).toBe(mockClientProfileInput.bio);
    });
  });

  describe('POST /api/users/:id/avatar', () => {
    it('should return 400 when no file is uploaded', async () => {
      const response = await request(app)
        .post('/api/users/user-123/avatar')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(400);

      expect(response.body.error).toBe('NO_FILE');
    });
  });

  describe('DELETE /api/users/:id/avatar', () => {
    it('should delete avatar successfully', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.deleteAvatar = jest.fn().mockResolvedValue(undefined);

      const response = await request(app)
        .delete('/api/users/user-123/avatar')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Avatar removido com sucesso');
    });
  });

  describe('PUT /api/users/:id/deactivate', () => {
    it('should deactivate user successfully', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.deactivateUser = jest.fn().mockResolvedValue(undefined);

      const response = await request(app)
        .put('/api/users/user-123/deactivate')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Usuário desativado com sucesso');
    });
  });

  describe('PUT /api/users/:id/activate', () => {
    it('should activate user successfully', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.activateUser = jest.fn().mockResolvedValue(undefined);

      const response = await request(app)
        .put('/api/users/user-123/activate')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Usuário ativado com sucesso');
    });
  });

  describe('DELETE /api/users/:id', () => {
    it('should delete user successfully', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.deleteUser = jest.fn().mockResolvedValue(undefined);

      const response = await request(app)
        .delete('/api/users/user-123')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.message).toBe('Usuário removido com sucesso');
    });
  });

  describe('GET /api/users/:id/profile/custom-fields', () => {
    const mockProfileWithCustomFields = {
      id: 'profile-123',
      userId: 'user-123',
      bio: 'Test bio',
      avatar: null,
      specialties: ['Hair Cut'],
      workingHours: {},
      preferences: { customFields: { field1: 'value1' } },
      customFieldsDefinition: [
        {
          id: 'field1',
          name: 'customField1',
          type: 'text',
          label: 'Custom Field 1',
          required: false,
          order: 1,
        },
      ],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    it('should return user profile with custom fields', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.getUserProfileWithCustomFields = jest.fn()
        .mockResolvedValue(mockProfileWithCustomFields);

      const response = await request(app)
        .get('/api/users/user-123/profile/custom-fields')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.profile.customFieldsDefinition).toBeDefined();
      expect(response.body.data.profile.customFieldsDefinition).toHaveLength(1);
    });

    it('should return 404 for non-existent profile', async () => {
      const mockUserService = require('../../services/user.service').UserService;
      mockUserService.prototype.getUserProfileWithCustomFields = jest.fn().mockResolvedValue(null);

      const response = await request(app)
        .get('/api/users/user-123/profile/custom-fields')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(404);

      expect(response.body.error).toBe('PROFILE_NOT_FOUND');
    });
  });
});