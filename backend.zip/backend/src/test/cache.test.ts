import { cacheService } from '../services/cache.service';
import { cacheInvalidationService } from '../services/cache-invalidation.service';
import { cacheMetricsService } from '../services/cache-metrics.service';

describe('Cache System Tests', () => {
  beforeEach(() => {
    // Clear cache before each test
    cacheService.clearMetrics();
  });

  describe('CacheService', () => {
    test('should set and get cache values', async () => {
      const key = 'test-key';
      const value = { id: 1, name: 'Test' };

      // Set value
      const setResult = await cacheService.set(key, value, { ttl: 60 });
      expect(setResult).toBe(true);

      // Get value
      const cachedValue = await cacheService.get(key);
      expect(cachedValue).toEqual(value);
    });

    test('should return null for non-existent keys', async () => {
      const result = await cacheService.get('non-existent-key');
      expect(result).toBeNull();
    });

    test('should delete cache values', async () => {
      const key = 'test-delete';
      const value = { test: true };

      await cacheService.set(key, value);
      const deleteResult = await cacheService.del(key);
      expect(deleteResult).toBe(true);

      const cachedValue = await cacheService.get(key);
      expect(cachedValue).toBeNull();
    });

    test('should use getOrSet pattern', async () => {
      const key = 'test-get-or-set';
      const value = { computed: true };

      let callbackCalled = false;
      const callback = async () => {
        callbackCalled = true;
        return value;
      };

      // First call should execute callback
      const result1 = await cacheService.getOrSet(key, callback);
      expect(result1).toEqual(value);
      expect(callbackCalled).toBe(true);

      // Second call should use cache
      callbackCalled = false;
      const result2 = await cacheService.getOrSet(key, callback);
      expect(result2).toEqual(value);
      expect(callbackCalled).toBe(false);
    });

    test('should increment counters', async () => {
      const key = 'test-counter';

      const count1 = await cacheService.increment(key);
      expect(count1).toBe(1);

      const count2 = await cacheService.increment(key);
      expect(count2).toBe(2);
    });
  });

  describe('CacheInvalidationService', () => {
    test('should invalidate cache by entity', async () => {
      const tenantId = 'test-tenant';
      const entityId = 'test-entity';

      // Set some cache values
      await cacheService.set(`tenant:${tenantId}:user:${entityId}:profile`, { name: 'Test' });
      await cacheService.set(`tenant:${tenantId}:user:${entityId}:permissions`, ['read']);

      // Invalidate user entity
      await cacheInvalidationService.invalidate('user', entityId, tenantId);

      // Values should be invalidated (this is a simplified test)
      // In real implementation, we would check if the cache keys were deleted
    });

    test('should invalidate tenant cache', async () => {
      const tenantId = 'test-tenant';

      // Set tenant-specific cache
      await cacheService.set(`tenant:${tenantId}:config`, { theme: 'dark' });

      // Invalidate tenant
      await cacheInvalidationService.invalidateTenant(tenantId);

      // This would delete all tenant-specific cache in real implementation
    });
  });

  describe('CacheMetricsService', () => {
    test('should track cache metrics', async () => {
      // Simulate some cache operations
      await cacheService.get('test-key-1'); // Miss
      await cacheService.set('test-key-1', { value: 1 });
      await cacheService.get('test-key-1'); // Hit

      const metrics = cacheService.getMetrics();
      expect(metrics.totalRequests).toBeGreaterThan(0);
    });

    test('should get health status', async () => {
      const health = await cacheMetricsService.getHealthStatus();
      expect(health).toHaveProperty('status');
      expect(health).toHaveProperty('score');
      expect(health).toHaveProperty('issues');
      expect(['healthy', 'warning', 'critical']).toContain(health.status);
    });
  });
});

// Mock Redis client for testing
jest.mock('../config/redis', () => ({
  redisClient: {
    get: jest.fn(),
    set: jest.fn(),
    setex: jest.fn(),
    del: jest.fn(),
    keys: jest.fn(),
    exists: jest.fn(),
    incr: jest.fn(),
    expire: jest.fn(),
    info: jest.fn().mockResolvedValue('used_memory:1024\nexpired_keys:0\nevicted_keys:0\nuptime_in_seconds:3600'),
    status: 'ready'
  },
  CACHE_KEYS: {
    USER_PROFILE: (userId: string) => `user:${userId}:profile`,
    PROFESSIONAL_SCHEDULE: (professionalId: string) => `schedule:${professionalId}`
  },
  CACHE_TTL: {
    USER_PROFILE: 3600,
    PROFESSIONAL_SCHEDULE: 3600
  }
}));