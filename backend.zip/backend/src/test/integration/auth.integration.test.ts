import request from 'supertest';
import { app } from '../../index';

describe('Authentication Integration Tests', () => {
  describe('Health Check', () => {
    it('should return health status', async () => {
      const response = await request(app)
        .get('/health');

      expect(response.status).toBe(200);
      expect(response.body.status).toBe('OK');
      expect(response.body.timestamp).toBeDefined();
    });
  });

  describe('API Base Route', () => {
    it('should return API information', async () => {
      const response = await request(app)
        .get('/api');

      expect(response.status).toBe(200);
      expect(response.body.message).toBe('Agenda Lotada 24h API');
      expect(response.body.version).toBe('1.0.0');
      expect(response.body.status).toBe('running');
    });
  });

  describe('Authentication Routes', () => {
    it('should have auth routes available', async () => {
      // Test login endpoint exists
      const loginResponse = await request(app)
        .post('/api/auth/login')
        .send({});

      // Should not be 404 (route exists)
      expect(loginResponse.status).not.toBe(404);

      // Test register endpoint exists
      const registerResponse = await request(app)
        .post('/api/auth/register')
        .send({});

      // Should not be 404 (route exists)
      expect(registerResponse.status).not.toBe(404);

      // Test refresh endpoint exists
      const refreshResponse = await request(app)
        .post('/api/auth/refresh')
        .send({});

      // Should not be 404 (route exists)
      expect(refreshResponse.status).not.toBe(404);
    });

    it('should require authentication for protected routes', async () => {
      const response = await request(app)
        .get('/api/auth/me');

      expect(response.status).toBe(401);
      expect(response.body.error).toBe('UNAUTHORIZED');
    });
  });

  describe('User Routes', () => {
    it('should have user routes available', async () => {
      // Test users endpoint exists but requires auth
      const usersResponse = await request(app)
        .get('/api/users');

      // Should not be 404 (route exists) but should be 401 (unauthorized)
      expect(usersResponse.status).toBe(401);
      expect(usersResponse.body.error).toBe('UNAUTHORIZED');
    });
  });

  describe('404 Handler', () => {
    it('should return 404 for non-existent routes', async () => {
      const response = await request(app)
        .get('/api/non-existent-route');

      expect(response.status).toBe(404);
      expect(response.body.error).toBe('Not Found');
    });
  });
});