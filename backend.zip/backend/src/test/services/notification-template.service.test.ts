import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import { PrismaClient } from '@prisma/client';
import { notificationTemplateService } from '../../services/notification-template.service';
import {
  NotificationType,
  NotificationCategory,
  CreateNotificationTemplateData
} from '../../types/notification.types';

const prisma = new PrismaClient();

describe('NotificationTemplateService', () => {
  beforeEach(async () => {
    // Limpar dados de teste
    await prisma.notificationTemplate.deleteMany({
      where: {
        name: {
          startsWith: 'TEST_'
        }
      }
    });
  });

  afterEach(async () => {
    // Limpar dados de teste
    await prisma.notificationTemplate.deleteMany({
      where: {
        name: {
          startsWith: 'TEST_'
        }
      }
    });
  });

  describe('createTemplate', () => {
    it('deve criar um template com sucesso', async () => {
      const templateData: CreateNotificationTemplateData = {
        name: 'TEST_BOOKING_CONFIRMATION',
        type: NotificationType.EMAIL,
        subject: 'Agendamento Confirmado - {{serviceName}}',
        content: 'Olá {{clientName}}, seu agendamento foi confirmado!',
        category: NotificationCategory.CONFIRMATION,
        variables: [
          {
            name: 'clientName',
            description: 'Nome do cliente',
            type: 'string',
            required: true
          },
          {
            name: 'serviceName',
            description: 'Nome do serviço',
            type: 'string',
            required: true
          }
        ]
      };

      const template = await notificationTemplateService.createTemplate(templateData);

      expect(template).toBeDefined();
      expect(template.name).toBe(templateData.name);
      expect(template.type).toBe(templateData.type);
      expect(template.subject).toBe(templateData.subject);
      expect(template.content).toBe(templateData.content);
      expect(template.category).toBe(templateData.category);
      expect(template.language).toBe('pt-BR');
      expect(template.variables).toHaveLength(2);
      expect(template.isActive).toBe(true);
    });

    it('deve criar template com idioma personalizado', async () => {
      const templateData: CreateNotificationTemplateData = {
        name: 'TEST_BOOKING_CONFIRMATION_EN',
        type: NotificationType.EMAIL,
        subject: 'Booking Confirmed - {{serviceName}}',
        content: 'Hello {{clientName}}, your booking has been confirmed!',
        category: NotificationCategory.CONFIRMATION,
        language: 'en-US'
      };

      const template = await notificationTemplateService.createTemplate(templateData);

      expect(template.language).toBe('en-US');
    });
  });

  describe('getTemplateById', () => {
    it('deve buscar template por ID', async () => {
      const templateData: CreateNotificationTemplateData = {
        name: 'TEST_TEMPLATE_BY_ID',
        type: NotificationType.WHATSAPP,
        content: 'Mensagem de teste {{name}}',
        category: NotificationCategory.REMINDER
      };

      const createdTemplate = await notificationTemplateService.createTemplate(templateData);
      const foundTemplate = await notificationTemplateService.getTemplateById(createdTemplate.id);

      expect(foundTemplate).toBeDefined();
      expect(foundTemplate?.id).toBe(createdTemplate.id);
      expect(foundTemplate?.name).toBe(templateData.name);
    });

    it('deve retornar null para ID inexistente', async () => {
      const template = await notificationTemplateService.getTemplateById('invalid-id');
      expect(template).toBeNull();
    });
  });

  describe('getTemplates', () => {
    beforeEach(async () => {
      // Criar templates de teste
      await notificationTemplateService.createTemplate({
        name: 'TEST_EMAIL_TEMPLATE',
        type: NotificationType.EMAIL,
        content: 'Email template',
        category: NotificationCategory.CONFIRMATION
      });

      await notificationTemplateService.createTemplate({
        name: 'TEST_WHATSAPP_TEMPLATE',
        type: NotificationType.WHATSAPP,
        content: 'WhatsApp template',
        category: NotificationCategory.REMINDER
      });
    });

    it('deve buscar todos os templates', async () => {
      const templates = await notificationTemplateService.getTemplates();
      
      const testTemplates = templates.filter(t => t.name.startsWith('TEST_'));
      expect(testTemplates.length).toBeGreaterThanOrEqual(2);
    });

    it('deve filtrar templates por tipo', async () => {
      const emailTemplates = await notificationTemplateService.getTemplates({
        type: NotificationType.EMAIL
      });

      const testEmailTemplates = emailTemplates.filter(t => t.name.startsWith('TEST_'));
      expect(testEmailTemplates.length).toBeGreaterThanOrEqual(1);
      expect(testEmailTemplates.every(t => t.type === NotificationType.EMAIL)).toBe(true);
    });

    it('deve filtrar templates por categoria', async () => {
      const confirmationTemplates = await notificationTemplateService.getTemplates({
        category: NotificationCategory.CONFIRMATION
      });

      const testConfirmationTemplates = confirmationTemplates.filter(t => t.name.startsWith('TEST_'));
      expect(testConfirmationTemplates.length).toBeGreaterThanOrEqual(1);
      expect(testConfirmationTemplates.every(t => t.category === NotificationCategory.CONFIRMATION)).toBe(true);
    });
  });

  describe('renderTemplate', () => {
    it('deve renderizar template com variáveis', async () => {
      const templateData: CreateNotificationTemplateData = {
        name: 'TEST_RENDER_TEMPLATE',
        type: NotificationType.EMAIL,
        subject: 'Olá {{name}}',
        content: 'Seu agendamento é em {{date}} às {{time}}',
        category: NotificationCategory.REMINDER
      };

      const template = await notificationTemplateService.createTemplate(templateData);
      
      const variables = {
        name: 'João Silva',
        date: '15/12/2024',
        time: '14:30'
      };

      const result = await notificationTemplateService.renderTemplate(template.id, { variables });

      expect(result).toBeDefined();
      expect(result?.subject).toBe('Olá João Silva');
      expect(result?.content).toBe('Seu agendamento é em 15/12/2024 às 14:30');
    });

    it('deve remover variáveis não substituídas', async () => {
      const templateData: CreateNotificationTemplateData = {
        name: 'TEST_RENDER_INCOMPLETE',
        type: NotificationType.EMAIL,
        content: 'Olá {{name}}, seu agendamento {{missing}} está confirmado',
        category: NotificationCategory.CONFIRMATION
      };

      const template = await notificationTemplateService.createTemplate(templateData);
      
      const variables = {
        name: 'Maria'
      };

      const result = await notificationTemplateService.renderTemplate(template.id, { variables });

      expect(result?.content).toBe('Olá Maria, seu agendamento  está confirmado');
    });
  });

  describe('validateTemplate', () => {
    it('deve validar template corretamente', async () => {
      const content = 'Olá {{name}}, seu agendamento é {{date}}';
      const variables = [
        {
          name: 'name',
          description: 'Nome do cliente',
          type: 'string' as const,
          required: true
        },
        {
          name: 'date',
          description: 'Data do agendamento',
          type: 'string' as const,
          required: true
        }
      ];

      const validation = await notificationTemplateService.validateTemplate(content, variables);

      expect(validation.isValid).toBe(true);
      expect(validation.errors).toHaveLength(0);
      expect(validation.unusedVariables).toHaveLength(0);
    });

    it('deve detectar variáveis obrigatórias ausentes', async () => {
      const content = 'Olá {{name}}';
      const variables = [
        {
          name: 'name',
          description: 'Nome do cliente',
          type: 'string' as const,
          required: true
        },
        {
          name: 'date',
          description: 'Data do agendamento',
          type: 'string' as const,
          required: true
        }
      ];

      const validation = await notificationTemplateService.validateTemplate(content, variables);

      expect(validation.isValid).toBe(false);
      expect(validation.errors).toContain("Variável obrigatória 'date' não encontrada no template");
    });

    it('deve detectar variáveis não utilizadas', async () => {
      const content = 'Olá {{name}}';
      const variables = [
        {
          name: 'name',
          description: 'Nome do cliente',
          type: 'string' as const,
          required: true
        },
        {
          name: 'unused',
          description: 'Variável não usada',
          type: 'string' as const,
          required: false
        }
      ];

      const validation = await notificationTemplateService.validateTemplate(content, variables);

      expect(validation.isValid).toBe(true);
      expect(validation.unusedVariables).toContain('unused');
    });
  });

  describe('createDefaultTemplates', () => {
    it('deve criar templates padrão', async () => {
      await notificationTemplateService.createDefaultTemplates();

      const templates = await notificationTemplateService.getTemplates();
      const defaultTemplateNames = [
        'BOOKING_CONFIRMATION',
        'BOOKING_REMINDER',
        'BOOKING_CANCELLATION',
        'BOOKING_RESCHEDULED'
      ];

      defaultTemplateNames.forEach(name => {
        const template = templates.find(t => t.name === name);
        expect(template).toBeDefined();
      });
    });

    it('não deve duplicar templates padrão existentes', async () => {
      // Criar templates padrão duas vezes
      await notificationTemplateService.createDefaultTemplates();
      await notificationTemplateService.createDefaultTemplates();

      const templates = await notificationTemplateService.getTemplates();
      const confirmationTemplates = templates.filter(t => t.name === 'BOOKING_CONFIRMATION');
      
      expect(confirmationTemplates).toHaveLength(1);
    });
  });
});