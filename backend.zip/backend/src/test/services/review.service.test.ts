import { PrismaClient } from '@prisma/client';
import { reviewService } from '../../services/review.service';
import { CreateReviewRequest, UpdateReviewRequest, ModerateReviewRequest } from '../../types/review.types';

// Mock do Prisma
jest.mock('@prisma/client');
const mockPrisma = {
  booking: {
    findFirst: jest.fn(),
  },
  review: {
    findUnique: jest.fn(),
    findFirst: jest.fn(),
    findMany: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
    count: jest.fn(),
    groupBy: jest.fn(),
  },
  reviewResponse: {
    findUnique: jest.fn(),
    findFirst: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
    count: jest.fn(),
  },
};

// Mock do PrismaClient
(PrismaClient as jest.Mock).mockImplementation(() => mockPrisma);

describe('ReviewService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('createReview', () => {
    const mockBooking = {
      id: 'booking-1',
      clientId: 'client-1',
      professionalId: 'prof-1',
      status: 'COMPLETED',
      service: { name: 'Corte de Cabelo' },
      professional: { id: 'prof-1' }
    };

    const mockReviewData: CreateReviewRequest = {
      bookingId: 'booking-1',
      rating: 5,
      comment: 'Excelente serviço!'
    };

    it('deve criar uma avaliação com sucesso', async () => {
      mockPrisma.booking.findFirst.mockResolvedValue(mockBooking);
      mockPrisma.review.findUnique.mockResolvedValue(null);
      mockPrisma.review.create.mockResolvedValue({
        id: 'review-1',
        bookingId: 'booking-1',
        clientId: 'client-1',
        professionalId: 'prof-1',
        rating: 5,
        comment: 'Excelente serviço!',
        isModerated: false,
        moderationStatus: 'APPROVED',
        isVisible: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        client: {
          id: 'client-1',
          name: 'João Silva',
          profile: { avatar: null }
        },
        professional: {
          id: 'prof-1',
          user: {
            name: 'Maria Santos',
            profile: { avatar: null }
          }
        },
        booking: {
          service: { name: 'Corte de Cabelo' },
          startTime: new Date()
        },
        response: null
      });

      const result = await reviewService.createReview('client-1', mockReviewData);

      expect(result).toBeDefined();
      expect(result.rating).toBe(5);
      expect(result.comment).toBe('Excelente serviço!');
      expect(mockPrisma.booking.findFirst).toHaveBeenCalledWith({
        where: {
          id: 'booking-1',
          clientId: 'client-1',
          status: 'COMPLETED'
        },
        include: {
          service: true,
          professional: true
        }
      });
    });

    it('deve falhar se o booking não existir', async () => {
      mockPrisma.booking.findFirst.mockResolvedValue(null);

      await expect(
        reviewService.createReview('client-1', mockReviewData)
      ).rejects.toThrow('Agendamento não encontrado ou não pode ser avaliado');
    });

    it('deve falhar se já existir uma avaliação para o booking', async () => {
      mockPrisma.booking.findFirst.mockResolvedValue(mockBooking);
      mockPrisma.review.findUnique.mockResolvedValue({ id: 'existing-review' });

      await expect(
        reviewService.createReview('client-1', mockReviewData)
      ).rejects.toThrow('Este agendamento já foi avaliado');
    });

    it('deve falhar se o rating for inválido', async () => {
      const invalidRatingData = { ...mockReviewData, rating: 6 };

      await expect(
        reviewService.createReview('client-1', invalidRatingData)
      ).rejects.toThrow('A avaliação deve ser entre 1 e 5 estrelas');
    });
  });

  describe('getReviews', () => {
    it('deve buscar avaliações com filtros', async () => {
      const mockReviews = [
        {
          id: 'review-1',
          rating: 5,
          comment: 'Ótimo!',
          createdAt: new Date(),
          client: { id: 'client-1', name: 'João' },
          professional: { id: 'prof-1', user: { name: 'Maria' } }
        }
      ];

      mockPrisma.review.findMany.mockResolvedValue(mockReviews);
      mockPrisma.review.count.mockResolvedValue(1);

      const result = await reviewService.getReviews({
        professionalId: 'prof-1',
        page: 1,
        limit: 10
      });

      expect(result.reviews).toHaveLength(1);
      expect(result.total).toBe(1);
      expect(mockPrisma.review.findMany).toHaveBeenCalled();
    });
  });

  describe('updateReview', () => {
    const mockExistingReview = {
      id: 'review-1',
      clientId: 'client-1',
      rating: 4,
      comment: 'Bom serviço'
    };

    it('deve atualizar uma avaliação com sucesso', async () => {
      mockPrisma.review.findFirst.mockResolvedValue(mockExistingReview);
      mockPrisma.review.update.mockResolvedValue({
        ...mockExistingReview,
        rating: 5,
        comment: 'Excelente serviço!',
        moderationStatus: 'PENDING'
      });

      const updateData: UpdateReviewRequest = {
        rating: 5,
        comment: 'Excelente serviço!'
      };

      const result = await reviewService.updateReview('review-1', 'client-1', updateData);

      expect(mockPrisma.review.update).toHaveBeenCalledWith({
        where: { id: 'review-1' },
        data: {
          rating: 5,
          comment: 'Excelente serviço!',
          moderationStatus: 'PENDING',
          updatedAt: expect.any(Date)
        },
        include: expect.any(Object)
      });
    });

    it('deve falhar se a avaliação não pertencer ao cliente', async () => {
      mockPrisma.review.findFirst.mockResolvedValue(null);

      await expect(
        reviewService.updateReview('review-1', 'wrong-client', { rating: 5 })
      ).rejects.toThrow('Avaliação não encontrada');
    });
  });

  describe('moderateReview', () => {
    it('deve moderar uma avaliação com sucesso', async () => {
      const mockReview = {
        id: 'review-1',
        rating: 5,
        comment: 'Ótimo!',
        moderationStatus: 'APPROVED',
        isVisible: true,
        isModerated: true,
        moderatedAt: new Date(),
        moderatedBy: 'admin-1'
      };

      mockPrisma.review.update.mockResolvedValue(mockReview);

      const moderationData: ModerateReviewRequest = {
        moderationStatus: 'APPROVED',
        moderationReason: 'Conteúdo apropriado'
      };

      const result = await reviewService.moderateReview('review-1', 'admin-1', moderationData);

      expect(mockPrisma.review.update).toHaveBeenCalledWith({
        where: { id: 'review-1' },
        data: {
          moderationStatus: 'APPROVED',
          moderationReason: 'Conteúdo apropriado',
          moderatedAt: expect.any(Date),
          moderatedBy: 'admin-1',
          isVisible: true,
          isModerated: true
        },
        include: expect.any(Object)
      });
    });
  });

  describe('createReviewResponse', () => {
    const mockReview = {
      id: 'review-1',
      professionalId: 'prof-1'
    };

    it('deve criar uma resposta com sucesso', async () => {
      mockPrisma.review.findFirst.mockResolvedValue(mockReview);
      mockPrisma.reviewResponse.findUnique.mockResolvedValue(null);
      mockPrisma.reviewResponse.create.mockResolvedValue({
        id: 'response-1',
        reviewId: 'review-1',
        professionalId: 'prof-1',
        response: 'Obrigado pelo feedback!'
      });

      // Mock para getReviewById
      mockPrisma.review.findUnique.mockResolvedValue({
        ...mockReview,
        response: {
          id: 'response-1',
          response: 'Obrigado pelo feedback!'
        }
      });

      const result = await reviewService.createReviewResponse(
        'review-1',
        'prof-1',
        { response: 'Obrigado pelo feedback!' }
      );

      expect(mockPrisma.reviewResponse.create).toHaveBeenCalledWith({
        data: {
          reviewId: 'review-1',
          professionalId: 'prof-1',
          response: 'Obrigado pelo feedback!'
        }
      });
    });

    it('deve falhar se a avaliação não pertencer ao profissional', async () => {
      mockPrisma.review.findFirst.mockResolvedValue(null);

      await expect(
        reviewService.createReviewResponse('review-1', 'wrong-prof', { response: 'Teste' })
      ).rejects.toThrow('Avaliação não encontrada');
    });

    it('deve falhar se já existir uma resposta', async () => {
      mockPrisma.review.findFirst.mockResolvedValue(mockReview);
      mockPrisma.reviewResponse.findUnique.mockResolvedValue({ id: 'existing-response' });

      await expect(
        reviewService.createReviewResponse('review-1', 'prof-1', { response: 'Teste' })
      ).rejects.toThrow('Esta avaliação já possui uma resposta');
    });
  });

  describe('getReviewStats', () => {
    it('deve calcular estatísticas corretamente', async () => {
      const mockReviews = [
        { id: '1', rating: 5, createdAt: new Date() },
        { id: '2', rating: 4, createdAt: new Date() },
        { id: '3', rating: 5, createdAt: new Date() }
      ];

      const mockRatingStats = [
        { rating: 4, _count: { rating: 1 } },
        { rating: 5, _count: { rating: 2 } }
      ];

      mockPrisma.review.findMany.mockResolvedValue(mockReviews);
      mockPrisma.review.groupBy.mockResolvedValue(mockRatingStats);

      const result = await reviewService.getReviewStats();

      expect(result.totalReviews).toBe(3);
      expect(result.averageRating).toBe(4.7); // (5+4+5)/3 = 4.67 arredondado para 4.7
      expect(result.ratingDistribution[4]).toBe(1);
      expect(result.ratingDistribution[5]).toBe(2);
    });
  });

  describe('getProfessionalReviewStats', () => {
    it('deve calcular estatísticas do profissional corretamente', async () => {
      const mockReviews = [
        { id: '1', rating: 5, createdAt: new Date() },
        { id: '2', rating: 4, createdAt: new Date() }
      ];

      const mockRatingStats = [
        { rating: 4, _count: { rating: 1 } },
        { rating: 5, _count: { rating: 1 } }
      ];

      mockPrisma.review.findMany.mockResolvedValue(mockReviews);
      mockPrisma.review.groupBy.mockResolvedValue(mockRatingStats);
      mockPrisma.reviewResponse.count.mockResolvedValue(1); // 1 resposta de 2 avaliações = 50%

      const result = await reviewService.getProfessionalReviewStats('prof-1');

      expect(result.professionalId).toBe('prof-1');
      expect(result.totalReviews).toBe(2);
      expect(result.averageRating).toBe(4.5);
      expect(result.responseRate).toBe(50);
      expect(result.ratingDistribution[4]).toBe(1);
      expect(result.ratingDistribution[5]).toBe(1);
    });
  });
});