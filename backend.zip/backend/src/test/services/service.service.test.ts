import { ServiceService } from '../../services/service.service';

// Simple mock for testing core functionality
const mockPrisma = {
  service: {
    findFirst: jest.fn(),
    findMany: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
    groupBy: jest.fn(),
  },
  professional: {
    findFirst: jest.fn(),
  },
  booking: {
    findFirst: jest.fn(),
  },
} as any;

describe('ServiceService - Core Functionality', () => {
  let serviceService: ServiceService;

  beforeEach(() => {
    serviceService = new ServiceService(mockPrisma);
    jest.clearAllMocks();
  });

  describe('createService', () => {
    it('should create service successfully', async () => {
      const serviceData = {
        name: 'Corte de Cabelo',
        description: 'Corte masculino',
        duration: 30,
        price: 25.00,
        professionalId: 'prof-123'
      };

      const mockProfessional = {
        id: 'prof-123',
        tenantId: 'tenant-123',
        user: { id: 'user-123', name: 'João', email: 'joao@test.com' }
      };

      const mockService = {
        id: 'service-123',
        ...serviceData,
        tenantId: 'tenant-123',
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        professional: mockProfessional
      };

      mockPrisma.professional.findFirst.mockResolvedValue(mockProfessional);
      mockPrisma.service.findFirst.mockResolvedValue(null); // No existing service
      mockPrisma.service.create.mockResolvedValue(mockService);

      const result = await serviceService.createService(serviceData, 'tenant-123');

      expect(result).toBeDefined();
      expect(result.name).toBe(serviceData.name);
      expect(result.duration).toBe(serviceData.duration);
      expect(result.price).toBe(serviceData.price);
    });

    it('should throw error when professional not found', async () => {
      const serviceData = {
        name: 'Corte de Cabelo',
        description: 'Corte masculino',
        duration: 30,
        price: 25.00,
        professionalId: 'prof-123'
      };

      mockPrisma.professional.findFirst.mockResolvedValue(null);

      await expect(serviceService.createService(serviceData, 'tenant-123'))
        .rejects.toThrow('Profissional não encontrado ou não pertence ao tenant');
    });

    it('should throw error when service name already exists', async () => {
      const serviceData = {
        name: 'Corte de Cabelo',
        description: 'Corte masculino',
        duration: 30,
        price: 25.00,
        professionalId: 'prof-123'
      };

      const mockProfessional = {
        id: 'prof-123',
        tenantId: 'tenant-123',
        user: { id: 'user-123', name: 'João', email: 'joao@test.com' }
      };

      const existingService = {
        id: 'existing-123',
        name: 'Corte de Cabelo',
        professionalId: 'prof-123'
      };

      mockPrisma.professional.findFirst.mockResolvedValue(mockProfessional);
      mockPrisma.service.findFirst.mockResolvedValue(existingService);

      await expect(serviceService.createService(serviceData, 'tenant-123'))
        .rejects.toThrow('Já existe um serviço com este nome para este profissional');
    });
  });

  describe('getServices', () => {
    it('should return services with filters', async () => {
      const mockServices = [
        {
          id: 'service-1',
          name: 'Corte de Cabelo',
          duration: 30,
          price: 25.00,
          category: 'Cabelo',
          professional: {
            id: 'prof-123',
            user: { id: 'user-123', name: 'João', email: 'joao@test.com' }
          }
        }
      ];

      mockPrisma.service.findMany.mockResolvedValue(mockServices);

      const result = await serviceService.getServices('tenant-123', { category: 'Cabelo' });

      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('Corte de Cabelo');
      expect(result[0].category).toBe('Cabelo');
    });
  });

  describe('getServiceById', () => {
    it('should return service when found', async () => {
      const mockService = {
        id: 'service-123',
        name: 'Corte de Cabelo',
        duration: 30,
        price: 25.00,
        professional: {
          id: 'prof-123',
          user: { id: 'user-123', name: 'João', email: 'joao@test.com' }
        }
      };

      mockPrisma.service.findFirst.mockResolvedValue(mockService);

      const result = await serviceService.getServiceById('service-123', 'tenant-123');

      expect(result).toBeDefined();
      expect(result?.id).toBe('service-123');
      expect(result?.name).toBe('Corte de Cabelo');
    });

    it('should return null when service not found', async () => {
      mockPrisma.service.findFirst.mockResolvedValue(null);

      const result = await serviceService.getServiceById('non-existent', 'tenant-123');

      expect(result).toBeNull();
    });
  });

  describe('deleteService', () => {
    it('should throw error when service has active bookings', async () => {
      const mockService = {
        id: 'service-123',
        tenantId: 'tenant-123'
      };

      const activeBooking = {
        id: 'booking-123',
        serviceId: 'service-123',
        status: 'SCHEDULED'
      };

      mockPrisma.service.findFirst.mockResolvedValue(mockService);
      mockPrisma.booking.findFirst.mockResolvedValue(activeBooking);

      await expect(serviceService.deleteService('service-123', 'tenant-123'))
        .rejects.toThrow('Não é possível deletar um serviço com agendamentos ativos');
    });

    it('should delete service successfully when no active bookings', async () => {
      const mockService = {
        id: 'service-123',
        tenantId: 'tenant-123'
      };

      mockPrisma.service.findFirst.mockResolvedValue(mockService);
      mockPrisma.booking.findFirst.mockResolvedValue(null);
      mockPrisma.service.delete.mockResolvedValue({});

      await expect(serviceService.deleteService('service-123', 'tenant-123'))
        .resolves.not.toThrow();

      expect(mockPrisma.service.delete).toHaveBeenCalledWith({
        where: { id: 'service-123' }
      });
    });
  });
});