import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';
import { PrismaClient } from '@prisma/client';
import { reportService } from '../../services/report.service';
import { AnalyticsFilters } from '../../types/analytics.types';

const prisma = new PrismaClient();

// Mock do puppeteer para evitar problemas nos testes
jest.mock('puppeteer', () => ({
  launch: jest.fn().mockResolvedValue({
    newPage: jest.fn().mockResolvedValue({
      setContent: jest.fn(),
      pdf: jest.fn().mockResolvedValue(Buffer.from('fake-pdf-content'))
    }),
    close: jest.fn()
  })
}));

describe('ReportService', () => {
  let testTenantId: string;
  let testClientId: string;
  let testProfessionalId: string;
  let testServiceId: string;

  beforeEach(async () => {
    // Criar dados de teste
    const tenant = await prisma.tenant.create({
      data: {
        name: 'Test Tenant Reports',
        slug: 'test-tenant-reports'
      }
    });
    testTenantId = tenant.id;

    const user = await prisma.user.create({
      data: {
        email: 'professional-reports@test.com',
        name: 'Test Professional Reports',
        password: 'hashedpassword',
        tenantId: testTenantId
      }
    });

    const professional = await prisma.professional.create({
      data: {
        userId: user.id,
        tenantId: testTenantId
      }
    });
    testProfessionalId = professional.id;

    const client = await prisma.user.create({
      data: {
        email: 'client-reports@test.com',
        name: 'Test Client Reports',
        password: 'hashedpassword',
        tenantId: testTenantId
      }
    });
    testClientId = client.id;

    const service = await prisma.service.create({
      data: {
        name: 'Test Service Reports',
        duration: 60,
        price: 100.0,
        tenantId: testTenantId,
        professionalId: testProfessionalId
      }
    });
    testServiceId = service.id;

    // Criar alguns agendamentos de teste
    const baseDate = new Date();
    baseDate.setDate(baseDate.getDate() - 7);
    baseDate.setHours(10, 0, 0, 0);

    for (let i = 0; i < 3; i++) {
      const bookingDate = new Date(baseDate);
      bookingDate.setDate(baseDate.getDate() + i);
      bookingDate.setHours(10 + i, 0, 0, 0);

      await prisma.booking.create({
        data: {
          clientId: testClientId,
          professionalId: testProfessionalId,
          serviceId: testServiceId,
          tenantId: testTenantId,
          startTime: bookingDate,
          endTime: new Date(bookingDate.getTime() + 60 * 60 * 1000),
          status: 'COMPLETED',
          price: 100.0,
          paymentStatus: 'PAID'
        }
      });
    }
  });

  afterEach(async () => {
    // Limpar dados de teste
    await prisma.booking.deleteMany({});
    await prisma.service.deleteMany({});
    await prisma.professional.deleteMany({});
    await prisma.user.deleteMany({});
    await prisma.tenant.deleteMany({});
  });

  describe('generatePDFReport', () => {
    it('deve gerar relatório PDF com dados válidos', async () => {
      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const title = 'Relatório de Teste PDF';
      const pdfBuffer = await reportService.generatePDFReport(filters, title);

      expect(pdfBuffer).toBeDefined();
      expect(Buffer.isBuffer(pdfBuffer)).toBe(true);
      expect(pdfBuffer.length).toBeGreaterThan(0);
    });

    it('deve gerar PDF mesmo com dados vazios', async () => {
      const filters: AnalyticsFilters = {
        tenantId: 'tenant-inexistente',
        dateRange: {
          startDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // Futuro
          endDate: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000)
        }
      };

      const title = 'Relatório Vazio';
      const pdfBuffer = await reportService.generatePDFReport(filters, title);

      expect(pdfBuffer).toBeDefined();
      expect(Buffer.isBuffer(pdfBuffer)).toBe(true);
    });
  });

  describe('generateExcelReport', () => {
    it('deve gerar relatório Excel com dados válidos', async () => {
      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const title = 'Relatório de Teste Excel';
      const excelBuffer = await reportService.generateExcelReport(filters, title);

      expect(excelBuffer).toBeDefined();
      expect(Buffer.isBuffer(excelBuffer)).toBe(true);
      expect(excelBuffer.length).toBeGreaterThan(0);
    });

    it('deve gerar Excel com filtros específicos', async () => {
      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        professionalId: testProfessionalId,
        serviceId: testServiceId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const title = 'Relatório Filtrado';
      const excelBuffer = await reportService.generateExcelReport(filters, title);

      expect(excelBuffer).toBeDefined();
      expect(Buffer.isBuffer(excelBuffer)).toBe(true);
    });
  });

  describe('createReportConfig', () => {
    it('deve criar configuração de relatório válida', async () => {
      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const config = await reportService.createReportConfig({
        name: 'Relatório Mensal',
        type: 'PDF',
        frequency: 'MONTHLY',
        filters,
        recipients: ['admin@test.com'],
        isActive: true
      });

      expect(config).toBeDefined();
      expect(config.id).toBeDefined();
      expect(config.name).toBe('Relatório Mensal');
      expect(config.type).toBe('PDF');
      expect(config.frequency).toBe('MONTHLY');
      expect(config.isActive).toBe(true);
      expect(config.recipients).toContain('admin@test.com');
      expect(config.createdAt).toBeDefined();
      expect(config.updatedAt).toBeDefined();
    });

    it('deve criar configuração para relatório Excel', async () => {
      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const config = await reportService.createReportConfig({
        name: 'Relatório Semanal Excel',
        type: 'EXCEL',
        frequency: 'WEEKLY',
        filters,
        recipients: ['manager@test.com', 'admin@test.com'],
        isActive: true
      });

      expect(config.type).toBe('EXCEL');
      expect(config.frequency).toBe('WEEKLY');
      expect(config.recipients).toHaveLength(2);
    });

    it('deve criar configuração inativa', async () => {
      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const config = await reportService.createReportConfig({
        name: 'Relatório Diário Inativo',
        type: 'PDF',
        frequency: 'DAILY',
        filters,
        recipients: [],
        isActive: false
      });

      expect(config.isActive).toBe(false);
    });
  });

  describe('stopScheduledReport', () => {
    it('deve parar relatório agendado existente', async () => {
      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const config = await reportService.createReportConfig({
        name: 'Relatório para Parar',
        type: 'PDF',
        frequency: 'DAILY',
        filters,
        recipients: [],
        isActive: true
      });

      // Não deve lançar erro
      expect(() => {
        reportService.stopScheduledReport(config.id);
      }).not.toThrow();
    });

    it('deve lidar com ID inexistente sem erro', async () => {
      expect(() => {
        reportService.stopScheduledReport('id-inexistente');
      }).not.toThrow();
    });
  });

  describe('Report Content Validation', () => {
    it('deve incluir todas as métricas no relatório', async () => {
      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      // Testar geração de Excel para validar estrutura
      const excelBuffer = await reportService.generateExcelReport(filters, 'Teste Completo');
      
      expect(excelBuffer).toBeDefined();
      expect(excelBuffer.length).toBeGreaterThan(1000); // Excel deve ter tamanho razoável
    });

    it('deve gerar relatório com período personalizado', async () => {
      const startDate = new Date('2024-01-01');
      const endDate = new Date('2024-01-31');

      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: { startDate, endDate }
      };

      const pdfBuffer = await reportService.generatePDFReport(filters, 'Janeiro 2024');
      
      expect(pdfBuffer).toBeDefined();
      expect(Buffer.isBuffer(pdfBuffer)).toBe(true);
    });
  });

  describe('Error Handling', () => {
    it('deve lidar com erro na geração de PDF', async () => {
      // Mock para simular erro no puppeteer
      const puppeteer = require('puppeteer');
      puppeteer.launch.mockRejectedValueOnce(new Error('Puppeteer error'));

      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      await expect(reportService.generatePDFReport(filters, 'Teste Erro'))
        .rejects.toThrow('Puppeteer error');
    });

    it('deve validar filtros obrigatórios', async () => {
      const invalidFilters = {
        tenantId: '',
        dateRange: {
          startDate: new Date(),
          endDate: new Date()
        }
      } as AnalyticsFilters;

      // O serviço deve lidar com filtros inválidos graciosamente
      const excelBuffer = await reportService.generateExcelReport(invalidFilters, 'Teste Inválido');
      expect(excelBuffer).toBeDefined();
    });
  });

  describe('Performance Tests', () => {
    it('deve gerar relatório em tempo razoável', async () => {
      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const startTime = Date.now();
      await reportService.generateExcelReport(filters, 'Teste Performance');
      const endTime = Date.now();

      const executionTime = endTime - startTime;
      expect(executionTime).toBeLessThan(10000); // Menos de 10 segundos
    });
  });
});