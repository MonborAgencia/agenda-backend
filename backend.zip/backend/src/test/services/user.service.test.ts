import { PrismaClient } from '@prisma/client';
import { UserService } from '../../services/user.service';
import { hashPassword } from '../../utils/password.utils';

// Mock the PrismaClient
const mockPrisma = {
  user: {
    findUnique: jest.fn(),
    findMany: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
    count: jest.fn(),
  },
  userProfile: {
    findUnique: jest.fn(),
    upsert: jest.fn(),
    update: jest.fn(),
  },
  userRole: {
    createMany: jest.fn(),
    deleteMany: jest.fn(),
  },
  $transaction: jest.fn(),
  $disconnect: jest.fn(),
} as any;

describe('UserService', () => {
  let userService: UserService;

  beforeEach(() => {
    userService = new UserService(mockPrisma as any);
    jest.clearAllMocks();
  });

  describe('createUser', () => {
    const mockCreateUserInput = {
      email: 'test@example.com',
      name: 'Test User',
      phone: '+1234567890',
      password: 'testPassword123!',
      tenantId: 'tenant-123',
      roleIds: ['role-123'],
    };

    const mockCreatedUser = {
      id: 'user-123',
      email: 'test@example.com',
      name: 'Test User',
      phone: '+1234567890',
      password: 'hashed-password',
      tenantId: 'tenant-123',
      isActive: true,
      emailVerified: false,
      lastLoginAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      profile: null,
      userRoles: [
        {
          role: {
            id: 'role-123',
            name: 'CLIENT',
            description: 'Client role',
            rolePermissions: [],
          },
        },
      ],
    };

    it('should create user successfully', async () => {
      // Mock transaction
      mockPrisma.$transaction.mockImplementation(async (callback: any) => {
        // Mock user creation
        mockPrisma.user.create.mockResolvedValue(mockCreatedUser as any);
        
        // Mock role assignment
        mockPrisma.userRole.createMany.mockResolvedValue({ count: 1 });

        return callback(mockPrisma);
      });

      // Mock getUserById for returning created user
      jest.spyOn(userService, 'getUserById').mockResolvedValue(mockCreatedUser as any);

      const result = await userService.createUser(mockCreateUserInput);

      expect(result).toBeDefined();
      expect(result.email).toBe(mockCreateUserInput.email);
      expect(result.name).toBe(mockCreateUserInput.name);
      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should hash password before creating user', async () => {
      const hashPasswordSpy = jest.spyOn(require('../../utils/password.utils'), 'hashPassword');
      
      mockPrisma.$transaction.mockImplementation(async (callback: any) => {
        mockPrisma.user.create.mockResolvedValue(mockCreatedUser as any);
        mockPrisma.userRole.createMany.mockResolvedValue({ count: 1 });
        return callback(mockPrisma);
      });

      jest.spyOn(userService, 'getUserById').mockResolvedValue(mockCreatedUser as any);

      await userService.createUser(mockCreateUserInput);

      expect(hashPasswordSpy).toHaveBeenCalledWith(mockCreateUserInput.password);
    });
  });

  describe('getUserById', () => {
    const mockUser = {
      id: 'user-123',
      email: 'test@example.com',
      name: 'Test User',
      phone: '+1234567890',
      password: 'hashed-password',
      tenantId: 'tenant-123',
      isActive: true,
      emailVerified: false,
      lastLoginAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      profile: {
        id: 'profile-123',
        userId: 'user-123',
        avatar: null,
        bio: null,
        specialties: null,
        preferences: null,
        workingHours: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      userRoles: [
        {
          role: {
            id: 'role-123',
            name: 'CLIENT',
            description: 'Client role',
            rolePermissions: [
              {
                permission: {
                  id: 'perm-123',
                  name: 'booking:create',
                  resource: 'booking',
                  action: 'create',
                },
              },
            ],
          },
        },
      ],
    };

    it('should return user with relations', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(mockUser as any);

      const result = await userService.getUserById('user-123');

      expect(result).toBeDefined();
      expect(result?.id).toBe('user-123');
      expect(result?.profile).toBeDefined();
      expect(result?.userRoles).toBeDefined();
      expect(mockPrisma.user.findUnique).toHaveBeenCalledWith({
        where: { id: 'user-123' },
        include: {
          profile: true,
          userRoles: {
            include: {
              role: {
                include: {
                  rolePermissions: {
                    include: {
                      permission: true,
                    },
                  },
                },
              },
            },
          },
        },
      });
    });

    it('should return null for non-existent user', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(null);

      const result = await userService.getUserById('non-existent');

      expect(result).toBeNull();
    });
  });

  describe('updateUser', () => {
    const mockUpdateInput = {
      name: 'Updated Name',
      email: 'updated@example.com',
      roleIds: ['role-456'],
    };

    const mockUpdatedUser = {
      id: 'user-123',
      email: 'updated@example.com',
      name: 'Updated Name',
      phone: '+1234567890',
      tenantId: 'tenant-123',
      isActive: true,
      emailVerified: false,
      lastLoginAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      profile: null,
      userRoles: [],
    };

    it('should update user successfully', async () => {
      mockPrisma.$transaction.mockImplementation(async (callback: any) => {
        mockPrisma.user.update.mockResolvedValue(mockUpdatedUser as any);
        mockPrisma.userRole.deleteMany.mockResolvedValue({ count: 1 });
        mockPrisma.userRole.createMany.mockResolvedValue({ count: 1 });
        return callback(mockPrisma);
      });

      jest.spyOn(userService, 'getUserById').mockResolvedValue(mockUpdatedUser as any);

      const result = await userService.updateUser('user-123', mockUpdateInput);

      expect(result).toBeDefined();
      expect(result?.name).toBe(mockUpdateInput.name);
      expect(result?.email).toBe(mockUpdateInput.email);
      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });

    it('should update roles when roleIds provided', async () => {
      mockPrisma.$transaction.mockImplementation(async (callback: any) => {
        mockPrisma.user.update.mockResolvedValue(mockUpdatedUser as any);
        mockPrisma.userRole.deleteMany.mockResolvedValue({ count: 1 });
        mockPrisma.userRole.createMany.mockResolvedValue({ count: 1 });
        return callback(mockPrisma);
      });

      jest.spyOn(userService, 'getUserById').mockResolvedValue(mockUpdatedUser as any);

      await userService.updateUser('user-123', mockUpdateInput);

      expect(mockPrisma.$transaction).toHaveBeenCalled();
    });
  });

  describe('updateUserProfile', () => {
    const mockProfileInput = {
      bio: 'Updated bio',
      avatar: 'https://example.com/avatar.jpg',
    };

    const mockUpdatedProfile = {
      id: 'profile-123',
      userId: 'user-123',
      bio: 'Updated bio',
      avatar: 'https://example.com/avatar.jpg',
      specialties: null,
      preferences: null,
      workingHours: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    it('should update user profile successfully', async () => {
      mockPrisma.userProfile.upsert.mockResolvedValue(mockUpdatedProfile as any);

      const result = await userService.updateUserProfile('user-123', mockProfileInput);

      expect(result).toBeDefined();
      expect(result.bio).toBe(mockProfileInput.bio);
      expect(result.avatar).toBe(mockProfileInput.avatar);
      expect(mockPrisma.userProfile.upsert).toHaveBeenCalledWith({
        where: { userId: 'user-123' },
        update: mockProfileInput,
        create: {
          userId: 'user-123',
          ...mockProfileInput,
        },
      });
    });
  });

  describe('changePassword', () => {
    const mockUser = {
      id: 'user-123',
      password: 'hashed-current-password',
    };

    beforeEach(async () => {
      // Mock current password hash
      mockUser.password = await hashPassword('currentPassword123!');
    });

    it('should change password successfully', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(mockUser as any);
      mockPrisma.user.update.mockResolvedValue({} as any);

      const result = await userService.changePassword('user-123', 'currentPassword123!', 'newPassword123!');

      expect(result).toBe(true);
      expect(mockPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-123' },
        data: { password: expect.any(String) },
      });
    });

    it('should throw error for non-existent user', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(null);

      await expect(
        userService.changePassword('non-existent', 'currentPassword123!', 'newPassword123!')
      ).rejects.toThrow('Usuário não encontrado');
    });

    it('should throw error for incorrect current password', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(mockUser as any);

      await expect(
        userService.changePassword('user-123', 'wrongPassword', 'newPassword123!')
      ).rejects.toThrow('Senha atual incorreta');
    });
  });

  describe('deactivateUser', () => {
    it('should deactivate user successfully', async () => {
      mockPrisma.user.update.mockResolvedValue({} as any);

      await userService.deactivateUser('user-123');

      expect(mockPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-123' },
        data: { isActive: false },
      });
    });
  });

  describe('activateUser', () => {
    it('should activate user successfully', async () => {
      mockPrisma.user.update.mockResolvedValue({} as any);

      await userService.activateUser('user-123');

      expect(mockPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-123' },
        data: { isActive: true },
      });
    });
  });

  describe('getUsers', () => {
    const mockUsers = [
      {
        id: 'user-1',
        email: 'user1@example.com',
        name: 'User 1',
        phone: null,
        tenantId: 'tenant-123',
        isActive: true,
        emailVerified: true,
        lastLoginAt: null,
        createdAt: new Date(),
        updatedAt: new Date(),
        profile: null,
        userRoles: [],
      },
      {
        id: 'user-2',
        email: 'user2@example.com',
        name: 'User 2',
        phone: null,
        tenantId: 'tenant-123',
        isActive: true,
        emailVerified: false,
        lastLoginAt: null,
        createdAt: new Date(),
        updatedAt: new Date(),
        profile: null,
        userRoles: [],
      },
    ];

    it('should return paginated users', async () => {
      mockPrisma.user.findMany.mockResolvedValue(mockUsers as any);
      mockPrisma.user.count.mockResolvedValue(2);

      const result = await userService.getUsers({ page: 1, limit: 10 });

      expect(result.users).toHaveLength(2);
      expect(result.pagination.total).toBe(2);
      expect(result.pagination.page).toBe(1);
      expect(result.pagination.limit).toBe(10);
      expect(result.pagination.pages).toBe(1);
    });

    it('should filter by tenant', async () => {
      mockPrisma.user.findMany.mockResolvedValue([mockUsers[0]] as any);
      mockPrisma.user.count.mockResolvedValue(1);

      await userService.getUsers({ tenantId: 'tenant-123' });

      expect(mockPrisma.user.findMany).toHaveBeenCalledWith({
        where: { tenantId: 'tenant-123' },
        skip: 0,
        take: 10,
        include: {
          profile: true,
          userRoles: {
            include: {
              role: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      });
    });

    it('should filter by search term', async () => {
      mockPrisma.user.findMany.mockResolvedValue([mockUsers[0]] as any);
      mockPrisma.user.count.mockResolvedValue(1);

      await userService.getUsers({ search: 'User 1' });

      expect(mockPrisma.user.findMany).toHaveBeenCalledWith({
        where: {
          OR: [
            { name: { contains: 'User 1', mode: 'insensitive' } },
            { email: { contains: 'User 1', mode: 'insensitive' } },
          ],
        },
        skip: 0,
        take: 10,
        include: {
          profile: true,
          userRoles: {
            include: {
              role: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      });
    });
  });

  describe('hasPermission', () => {
    const mockUserWithPermissions = {
      id: 'user-123',
      isActive: true,
      userRoles: [
        {
          role: {
            rolePermissions: [
              {
                permission: {
                  resource: 'booking',
                  action: 'create',
                  name: 'booking:create',
                },
              },
              {
                permission: {
                  resource: 'user',
                  action: 'manage',
                  name: 'user:manage',
                },
              },
            ],
          },
        },
      ],
    };

    it('should return true for exact permission match', async () => {
      jest.spyOn(userService, 'getUserById').mockResolvedValue(mockUserWithPermissions as any);

      const result = await userService.hasPermission('user-123', 'booking', 'create');

      expect(result).toBe(true);
    });

    it('should return true for manage permission', async () => {
      jest.spyOn(userService, 'getUserById').mockResolvedValue(mockUserWithPermissions as any);

      const result = await userService.hasPermission('user-123', 'user', 'update');

      expect(result).toBe(true);
    });

    it('should return false for non-existent permission', async () => {
      jest.spyOn(userService, 'getUserById').mockResolvedValue(mockUserWithPermissions as any);

      const result = await userService.hasPermission('user-123', 'admin', 'delete');

      expect(result).toBe(false);
    });

    it('should return false for inactive user', async () => {
      const inactiveUser = { ...mockUserWithPermissions, isActive: false };
      jest.spyOn(userService, 'getUserById').mockResolvedValue(inactiveUser as any);

      const result = await userService.hasPermission('user-123', 'booking', 'create');

      expect(result).toBe(false);
    });

    it('should return false for non-existent user', async () => {
      jest.spyOn(userService, 'getUserById').mockResolvedValue(null);

      const result = await userService.hasPermission('non-existent', 'booking', 'create');

      expect(result).toBe(false);
    });
  });

  describe('uploadAvatar', () => {
    const mockProfile = {
      id: 'profile-123',
      userId: 'user-123',
      avatar: '/uploads/avatars/old-avatar.jpg',
      bio: null,
      specialties: null,
      preferences: null,
      workingHours: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    it('should upload avatar successfully', async () => {
      mockPrisma.userProfile.findUnique.mockResolvedValue(mockProfile as any);
      mockPrisma.userProfile.upsert.mockResolvedValue({
        ...mockProfile,
        avatar: '/uploads/avatars/new-avatar.jpg',
      } as any);

      const result = await userService.uploadAvatar('user-123', 'new-avatar.jpg');

      expect(result).toBe('/uploads/avatars/new-avatar.jpg');
      expect(mockPrisma.userProfile.upsert).toHaveBeenCalledWith({
        where: { userId: 'user-123' },
        update: { avatar: '/uploads/avatars/new-avatar.jpg' },
        create: {
          userId: 'user-123',
          avatar: '/uploads/avatars/new-avatar.jpg',
        },
      });
    });
  });

  describe('deleteAvatar', () => {
    const mockProfile = {
      id: 'profile-123',
      userId: 'user-123',
      avatar: '/uploads/avatars/avatar.jpg',
      bio: null,
      specialties: null,
      preferences: null,
      workingHours: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    it('should delete avatar successfully', async () => {
      mockPrisma.userProfile.findUnique.mockResolvedValue(mockProfile as any);
      mockPrisma.userProfile.update.mockResolvedValue({
        ...mockProfile,
        avatar: null,
      } as any);

      await userService.deleteAvatar('user-123');

      expect(mockPrisma.userProfile.update).toHaveBeenCalledWith({
        where: { userId: 'user-123' },
        data: { avatar: null },
      });
    });

    it('should handle user without avatar', async () => {
      mockPrisma.userProfile.findUnique.mockResolvedValue(null);

      await expect(userService.deleteAvatar('user-123')).resolves.not.toThrow();
    });
  });

  describe('updateLastLogin', () => {
    it('should update last login timestamp', async () => {
      mockPrisma.user.update.mockResolvedValue({} as any);

      await userService.updateLastLogin('user-123');

      expect(mockPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-123' },
        data: { lastLoginAt: expect.any(Date) },
      });
    });
  });

  describe('verifyEmail', () => {
    it('should verify user email', async () => {
      mockPrisma.user.update.mockResolvedValue({} as any);

      await userService.verifyEmail('user-123');

      expect(mockPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-123' },
        data: { emailVerified: true },
      });
    });
  });
});