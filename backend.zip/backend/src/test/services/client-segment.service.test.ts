import { ClientSegmentService } from '../../services/client-segment.service';

// Mock do Prisma
jest.mock('@prisma/client', () => ({
  PrismaClient: jest.fn().mockImplementation(() => ({
    clientSegment: {
      create: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    user: {
      findMany: jest.fn(),
    },
  })),
}));

describe('ClientSegmentService', () => {
  let segmentService: ClientSegmentService;

  beforeEach(() => {
    segmentService = new ClientSegmentService();
    jest.clearAllMocks();
  });

  describe('createSegment', () => {
    it('deve criar um novo segmento', async () => {
      const mockSegment = {
        id: '1',
        name: 'Clientes VIP',
        description: 'Clientes com alto valor',
        tenantId: 'tenant1',
        criteria: JSON.stringify({ totalSpent: { min: 1000 } }),
        isActive: true,
        lastUpdated: new Date(),
        clientCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.clientSegment.create.mockResolvedValue(mockSegment);
      prismaInstance.clientSegment.update.mockResolvedValue({ ...mockSegment, clientCount: 5 });
      prismaInstance.user.findMany.mockResolvedValue([
        { id: '1' }, { id: '2' }, { id: '3' }, { id: '4' }, { id: '5' }
      ]);

      const segmentData = {
        name: 'Clientes VIP',
        description: 'Clientes com alto valor',
        tenantId: 'tenant1',
        criteria: { totalSpent: { min: 1000 } },
      };

      const result = await segmentService.createSegment(segmentData);

      expect(result.name).toBe('Clientes VIP');
      expect(result.tenantId).toBe('tenant1');
      expect(result.criteria).toEqual({ totalSpent: { min: 1000 } });
    });
  });

  describe('getSegmentsByTenant', () => {
    it('deve retornar segmentos do tenant', async () => {
      const mockSegments = [
        {
          id: '1',
          name: 'Clientes VIP',
          tenantId: 'tenant1',
          criteria: JSON.stringify({ totalSpent: { min: 1000 } }),
          isActive: true,
          lastUpdated: new Date(),
          clientCount: 5,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.clientSegment.findMany.mockResolvedValue(mockSegments);

      const result = await segmentService.getSegmentsByTenant('tenant1');

      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('Clientes VIP');
      expect(result[0].tenantId).toBe('tenant1');
    });
  });

  describe('updateSegment', () => {
    it('deve atualizar um segmento', async () => {
      const mockUpdatedSegment = {
        id: '1',
        name: 'Clientes Premium',
        description: 'Clientes premium atualizados',
        tenantId: 'tenant1',
        criteria: JSON.stringify({ totalSpent: { min: 1500 } }),
        isActive: true,
        lastUpdated: new Date(),
        clientCount: 3,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.clientSegment.update.mockResolvedValue(mockUpdatedSegment);
      prismaInstance.user.findMany.mockResolvedValue([
        { id: '1' }, { id: '2' }, { id: '3' }
      ]);

      const result = await segmentService.updateSegment('1', {
        name: 'Clientes Premium',
        description: 'Clientes premium atualizados',
        criteria: { totalSpent: { min: 1500 } },
      });

      expect(result.name).toBe('Clientes Premium');
      expect(result.criteria).toEqual({ totalSpent: { min: 1500 } });
    });
  });

  describe('deleteSegment', () => {
    it('deve deletar um segmento', async () => {
      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.clientSegment.delete.mockResolvedValue({});

      await expect(segmentService.deleteSegment('1')).resolves.not.toThrow();
    });
  });

  describe('calculateSegmentSize', () => {
    it('deve calcular o tamanho do segmento', async () => {
      const mockSegment = {
        id: '1',
        name: 'Clientes Ativos',
        tenantId: 'tenant1',
        criteria: { isActive: true },
        isActive: true,
        lastUpdated: new Date(),
        clientCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.clientSegment.findUnique.mockResolvedValue({
        ...mockSegment,
        criteria: JSON.stringify(mockSegment.criteria),
      });
      prismaInstance.user.findMany.mockResolvedValue([
        { id: '1' }, { id: '2' }, { id: '3' }, { id: '4' }
      ]);

      const result = await segmentService.calculateSegmentSize('1');

      expect(result).toBe(4);
    });
  });

  describe('getSuggestedSegments', () => {
    it('deve retornar segmentos sugeridos', async () => {
      const suggestions = await segmentService.getSuggestedSegments('tenant1');

      expect(suggestions).toHaveLength(4);
      expect(suggestions[0].name).toBe('Clientes Inativos');
      expect(suggestions[1].name).toBe('Clientes VIP');
      expect(suggestions[2].name).toBe('Novos Clientes');
      expect(suggestions[3].name).toBe('Clientes com Faltas');
    });
  });

  describe('getUsersInSegment', () => {
    it('deve retornar usuários que fazem parte do segmento', async () => {
      const mockSegment = {
        id: '1',
        name: 'Clientes Ativos',
        tenantId: 'tenant1',
        criteria: { isActive: true },
        isActive: true,
        lastUpdated: new Date(),
        clientCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.user.findMany.mockResolvedValue([
        { id: '1' }, { id: '2' }, { id: '3' }
      ]);

      const result = await segmentService.getUsersInSegment(mockSegment);

      expect(result).toHaveLength(3);
      expect(result).toEqual(['1', '2', '3']);
    });
  });
});