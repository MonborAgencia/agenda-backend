import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';
import { PrismaClient } from '@prisma/client';
import { analyticsService } from '../../services/analytics.service';
import { AnalyticsFilters } from '../../types/analytics.types';

// Mock do PrismaClient
const mockPrisma = {
  booking: {
    findMany: jest.fn(),
  },
  professional: {
    findMany: jest.fn(),
  },
} as any;

// Mock do analytics service para usar o mock do prisma
jest.mock('@prisma/client');
const prisma = new PrismaClient();

describe('AnalyticsService', () => {
  let testTenantId: string;
  let testClientId: string;
  let testProfessionalId: string;
  let testServiceId: string;

  beforeEach(() => {
    // Definir IDs de teste
    testTenantId = 'test-tenant-id';
    testClientId = 'test-client-id';
    testProfessionalId = 'test-professional-id';
    testServiceId = 'test-service-id';

    // Reset mocks
    jest.clearAllMocks();
  });

  describe('calculateOccupancyMetrics', () => {
    it('deve calcular métricas de ocupação corretamente', async () => {
      // Mock dos dados de agendamentos
      const mockBookings = [
        { id: '1', status: 'COMPLETED' },
        { id: '2', status: 'SCHEDULED' },
        { id: '3', status: 'CONFIRMED' }
      ];

      (prisma.booking.findMany as jest.Mock).mockResolvedValue(mockBookings);

      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const occupancy = await analyticsService.calculateOccupancyMetrics(filters);

      expect(occupancy).toBeDefined();
      expect(occupancy.bookedSlots).toBe(3);
      expect(occupancy.totalSlots).toBeGreaterThan(0);
      expect(occupancy.occupancyRate).toBeGreaterThanOrEqual(0);
      expect(occupancy.occupancyRate).toBeLessThanOrEqual(100);
      expect(occupancy.availableSlots).toBe(occupancy.totalSlots - occupancy.bookedSlots);
    });

    it('deve retornar zero para período sem agendamentos', async () => {
      (prisma.booking.findMany as jest.Mock).mockResolvedValue([]);

      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const occupancy = await analyticsService.calculateOccupancyMetrics(filters);

      expect(occupancy.bookedSlots).toBe(0);
      expect(occupancy.occupancyRate).toBe(0);
    });
  });

  describe('calculateRevenueMetrics', () => {
    it('deve calcular métricas de faturamento corretamente', async () => {
      const mockBookings = [
        { price: 150, status: 'COMPLETED', paymentStatus: 'PAID' },
        { price: 150, status: 'COMPLETED', paymentStatus: 'PAID' },
        { price: 150, status: 'COMPLETED', paymentStatus: 'PAID' },
        { price: 150, status: 'SCHEDULED', paymentStatus: 'PENDING' },
        { price: 150, status: 'CONFIRMED', paymentStatus: 'PENDING' }
      ];

      (prisma.booking.findMany as jest.Mock).mockResolvedValue(mockBookings);

      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const revenue = await analyticsService.calculateRevenueMetrics(filters);

      expect(revenue).toBeDefined();
      expect(revenue.totalBookings).toBe(5);
      expect(revenue.totalRevenue).toBe(750.0);
      expect(revenue.confirmedRevenue).toBe(450.0); // 3 * 150 (COMPLETED)
      expect(revenue.pendingRevenue).toBe(300.0); // 2 * 150 (SCHEDULED + CONFIRMED)
      expect(revenue.averageBookingValue).toBe(150.0);
    });

    it('deve retornar zero para período sem receita', async () => {
      (prisma.booking.findMany as jest.Mock).mockResolvedValue([]);

      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const revenue = await analyticsService.calculateRevenueMetrics(filters);

      expect(revenue.totalBookings).toBe(0);
      expect(revenue.totalRevenue).toBe(0);
      expect(revenue.averageBookingValue).toBe(0);
    });
  });

  describe('analyzeProfitableHours', () => {
    it('deve analisar horários rentáveis corretamente', async () => {
      const mockBookings = [
        { startTime: new Date('2024-01-01T10:00:00'), price: 150, status: 'COMPLETED' },
        { startTime: new Date('2024-01-01T14:00:00'), price: 200, status: 'COMPLETED' },
        { startTime: new Date('2024-01-01T10:00:00'), price: 150, status: 'SCHEDULED' }
      ];

      (prisma.booking.findMany as jest.Mock).mockResolvedValue(mockBookings);

      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const profitableHours = await analyticsService.analyzeProfitableHours(filters);

      expect(profitableHours).toBeDefined();
      expect(Array.isArray(profitableHours)).toBe(true);
      expect(profitableHours.length).toBe(24);

      // Verificar estrutura dos dados
      const firstHour = profitableHours[0];
      expect(firstHour).toHaveProperty('hour');
      expect(firstHour).toHaveProperty('totalBookings');
      expect(firstHour).toHaveProperty('totalRevenue');
      expect(firstHour).toHaveProperty('averageRevenue');
      expect(firstHour).toHaveProperty('occupancyRate');
    });
  });

  describe('generateDashboardMetrics', () => {
    it('deve gerar métricas completas do dashboard', async () => {
      const mockBookings = [
        { price: 150, status: 'COMPLETED', paymentStatus: 'PAID' },
        { price: 150, status: 'SCHEDULED', paymentStatus: 'PENDING' }
      ];

      (prisma.booking.findMany as jest.Mock).mockResolvedValue(mockBookings);
      (prisma.professional.findMany as jest.Mock).mockResolvedValue([
        {
          id: testProfessionalId,
          user: { name: 'Test Professional' },
          bookings: mockBookings
        }
      ]);

      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          endDate: new Date()
        }
      };

      const dashboard = await analyticsService.generateDashboardMetrics(filters);

      expect(dashboard).toBeDefined();
      expect(dashboard).toHaveProperty('occupancy');
      expect(dashboard).toHaveProperty('revenue');
      expect(dashboard).toHaveProperty('profitableHours');
      expect(dashboard).toHaveProperty('topServices');
      expect(dashboard).toHaveProperty('professionalPerformance');
      expect(dashboard).toHaveProperty('periodComparison');
    });
  });

  describe('Edge Cases', () => {
    it('deve lidar com período sem agendamentos', async () => {
      (prisma.booking.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.professional.findMany as jest.Mock).mockResolvedValue([]);

      const filters: AnalyticsFilters = {
        tenantId: testTenantId,
        dateRange: {
          startDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          endDate: new Date(Date.now() + 40 * 24 * 60 * 60 * 1000)
        }
      };

      const dashboard = await analyticsService.generateDashboardMetrics(filters);

      expect(dashboard.occupancy.bookedSlots).toBe(0);
      expect(dashboard.revenue.totalRevenue).toBe(0);
      expect(dashboard.revenue.totalBookings).toBe(0);
    });
  });
});