import { CampaignService } from '../../services/campaign.service';
import { CampaignType, CampaignStatus } from '../../types/campaign.types';

// Mock do Prisma
jest.mock('@prisma/client', () => ({
  PrismaClient: jest.fn().mockImplementation(() => ({
    campaign: {
      create: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    campaignExecution: {
      create: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
    },
    campaignTarget: {
      create: jest.fn(),
      update: jest.fn(),
    },
    campaignMetric: {
      findMany: jest.fn(),
      upsert: jest.fn(),
    },
    user: {
      findMany: jest.fn(),
    },
  })),
}));

describe('CampaignService', () => {
  let campaignService: CampaignService;

  beforeEach(() => {
    campaignService = new CampaignService();
    jest.clearAllMocks();
  });

  describe('createCampaign', () => {
    it('deve criar uma nova campanha', async () => {
      const mockCampaign = {
        id: '1',
        name: 'Teste Campanha',
        type: CampaignType.PROMOTIONAL,
        tenantId: 'tenant1',
        status: CampaignStatus.DRAFT,
        totalSent: 0,
        totalOpened: 0,
        totalClicked: 0,
        totalConverted: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.campaign.create.mockResolvedValue(mockCampaign);

      const campaignData = {
        name: 'Teste Campanha',
        type: CampaignType.PROMOTIONAL,
        tenantId: 'tenant1',
      };

      const result = await campaignService.createCampaign(campaignData);

      expect(result.name).toBe('Teste Campanha');
      expect(result.type).toBe(CampaignType.PROMOTIONAL);
      expect(result.tenantId).toBe('tenant1');
    });
  });

  describe('getCampaignsByTenant', () => {
    it('deve retornar campanhas do tenant', async () => {
      const mockCampaigns = [
        {
          id: '1',
          name: 'Campanha 1',
          type: CampaignType.PROMOTIONAL,
          tenantId: 'tenant1',
          status: CampaignStatus.ACTIVE,
          totalSent: 100,
          totalOpened: 25,
          totalClicked: 5,
          totalConverted: 2,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.campaign.findMany.mockResolvedValue(mockCampaigns);

      const result = await campaignService.getCampaignsByTenant('tenant1');

      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('Campanha 1');
      expect(result[0].tenantId).toBe('tenant1');
    });
  });

  describe('updateCampaign', () => {
    it('deve atualizar uma campanha', async () => {
      const mockUpdatedCampaign = {
        id: '1',
        name: 'Campanha Atualizada',
        type: CampaignType.PROMOTIONAL,
        tenantId: 'tenant1',
        status: CampaignStatus.ACTIVE,
        totalSent: 0,
        totalOpened: 0,
        totalClicked: 0,
        totalConverted: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.campaign.update.mockResolvedValue(mockUpdatedCampaign);

      const result = await campaignService.updateCampaign('1', {
        name: 'Campanha Atualizada',
        status: CampaignStatus.ACTIVE,
      });

      expect(result.name).toBe('Campanha Atualizada');
      expect(result.status).toBe(CampaignStatus.ACTIVE);
    });
  });

  describe('deleteCampaign', () => {
    it('deve deletar uma campanha', async () => {
      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.campaign.delete.mockResolvedValue({});

      await expect(campaignService.deleteCampaign('1')).resolves.not.toThrow();
    });
  });

  describe('pauseCampaign', () => {
    it('deve pausar uma campanha', async () => {
      const mockPausedCampaign = {
        id: '1',
        name: 'Campanha Pausada',
        type: CampaignType.PROMOTIONAL,
        tenantId: 'tenant1',
        status: CampaignStatus.PAUSED,
        totalSent: 50,
        totalOpened: 10,
        totalClicked: 2,
        totalConverted: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.campaign.update.mockResolvedValue(mockPausedCampaign);

      const result = await campaignService.pauseCampaign('1');

      expect(result.status).toBe(CampaignStatus.PAUSED);
    });
  });

  describe('activateCampaign', () => {
    it('deve ativar uma campanha', async () => {
      const mockActiveCampaign = {
        id: '1',
        name: 'Campanha Ativa',
        type: CampaignType.PROMOTIONAL,
        tenantId: 'tenant1',
        status: CampaignStatus.ACTIVE,
        totalSent: 0,
        totalOpened: 0,
        totalClicked: 0,
        totalConverted: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.campaign.update.mockResolvedValue(mockActiveCampaign);

      const result = await campaignService.activateCampaign('1');

      expect(result.status).toBe(CampaignStatus.ACTIVE);
    });
  });

  describe('cancelCampaign', () => {
    it('deve cancelar uma campanha', async () => {
      const mockCancelledCampaign = {
        id: '1',
        name: 'Campanha Cancelada',
        type: CampaignType.PROMOTIONAL,
        tenantId: 'tenant1',
        status: CampaignStatus.CANCELLED,
        totalSent: 25,
        totalOpened: 5,
        totalClicked: 1,
        totalConverted: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const mockPrisma = require('@prisma/client').PrismaClient;
      const prismaInstance = new mockPrisma();
      prismaInstance.campaign.update.mockResolvedValue(mockCancelledCampaign);

      const result = await campaignService.cancelCampaign('1');

      expect(result.status).toBe(CampaignStatus.CANCELLED);
    });
  });
});