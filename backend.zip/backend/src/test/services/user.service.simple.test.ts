import { UserService } from '../../services/user.service';
import { hashPassword } from '../../utils/password.utils';

// Simple mock for testing core functionality
const mockPrisma = {
  user: {
    findUnique: jest.fn(),
    findMany: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    count: jest.fn(),
  },
  userProfile: {
    findUnique: jest.fn(),
    upsert: jest.fn(),
    update: jest.fn(),
  },
  userRole: {
    createMany: jest.fn(),
    deleteMany: jest.fn(),
  },
  $transaction: jest.fn(),
} as any;

describe('UserService - Core Functionality', () => {
  let userService: UserService;

  beforeEach(() => {
    userService = new UserService(mockPrisma);
    jest.clearAllMocks();
  });

  describe('getUserById', () => {
    it('should return user when found', async () => {
      const mockUser = {
        id: 'user-123',
        email: 'test@example.com',
        name: 'Test User',
        isActive: true,
        profile: null,
        userRoles: [],
      };

      mockPrisma.user.findUnique.mockResolvedValue(mockUser);

      const result = await userService.getUserById('user-123');

      expect(result).toBeDefined();
      expect(result?.id).toBe('user-123');
      expect(result?.email).toBe('test@example.com');
    });

    it('should return null when user not found', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(null);

      const result = await userService.getUserById('non-existent');

      expect(result).toBeNull();
    });
  });

  describe('updateUserProfile', () => {
    it('should update user profile successfully', async () => {
      const profileData = {
        bio: 'Test bio',
        avatar: 'test-avatar.jpg',
      };

      const mockProfile = {
        id: 'profile-123',
        userId: 'user-123',
        ...profileData,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      mockPrisma.userProfile.upsert.mockResolvedValue(mockProfile);

      const result = await userService.updateUserProfile('user-123', profileData);

      expect(result).toBeDefined();
      expect(result.bio).toBe(profileData.bio);
      expect(result.avatar).toBe(profileData.avatar);
      expect(mockPrisma.userProfile.upsert).toHaveBeenCalledWith({
        where: { userId: 'user-123' },
        update: profileData,
        create: {
          userId: 'user-123',
          ...profileData,
        },
      });
    });
  });

  describe('deactivateUser', () => {
    it('should deactivate user successfully', async () => {
      mockPrisma.user.update.mockResolvedValue({});

      await userService.deactivateUser('user-123');

      expect(mockPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-123' },
        data: { isActive: false },
      });
    });
  });

  describe('activateUser', () => {
    it('should activate user successfully', async () => {
      mockPrisma.user.update.mockResolvedValue({});

      await userService.activateUser('user-123');

      expect(mockPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-123' },
        data: { isActive: true },
      });
    });
  });

  describe('uploadAvatar', () => {
    it('should upload avatar successfully', async () => {
      const filename = 'new-avatar.jpg';
      const expectedUrl = '/uploads/avatars/new-avatar.jpg';

      mockPrisma.userProfile.findUnique.mockResolvedValue(null);
      mockPrisma.userProfile.upsert.mockResolvedValue({
        id: 'profile-123',
        userId: 'user-123',
        avatar: expectedUrl,
      });

      const result = await userService.uploadAvatar('user-123', filename);

      expect(result).toBe(expectedUrl);
      expect(mockPrisma.userProfile.upsert).toHaveBeenCalledWith({
        where: { userId: 'user-123' },
        update: { avatar: expectedUrl },
        create: {
          userId: 'user-123',
          avatar: expectedUrl,
        },
      });
    });
  });

  describe('deleteAvatar', () => {
    it('should delete avatar successfully', async () => {
      const mockProfile = {
        id: 'profile-123',
        userId: 'user-123',
        avatar: '/uploads/avatars/old-avatar.jpg',
      };

      mockPrisma.userProfile.findUnique.mockResolvedValue(mockProfile);
      mockPrisma.userProfile.update.mockResolvedValue({
        ...mockProfile,
        avatar: null,
      });

      await userService.deleteAvatar('user-123');

      expect(mockPrisma.userProfile.update).toHaveBeenCalledWith({
        where: { userId: 'user-123' },
        data: { avatar: null },
      });
    });

    it('should handle user without avatar gracefully', async () => {
      mockPrisma.userProfile.findUnique.mockResolvedValue(null);

      await expect(userService.deleteAvatar('user-123')).resolves.not.toThrow();
    });
  });

  describe('getUsers', () => {
    it('should return paginated users', async () => {
      const mockUsers = [
        {
          id: 'user-1',
          email: 'user1@example.com',
          name: 'User 1',
          isActive: true,
          profile: null,
          userRoles: [],
        },
        {
          id: 'user-2',
          email: 'user2@example.com',
          name: 'User 2',
          isActive: true,
          profile: null,
          userRoles: [],
        },
      ];

      mockPrisma.user.findMany.mockResolvedValue(mockUsers);
      mockPrisma.user.count.mockResolvedValue(2);

      const result = await userService.getUsers({ page: 1, limit: 10 });

      expect(result.users).toHaveLength(2);
      expect(result.pagination.total).toBe(2);
      expect(result.pagination.page).toBe(1);
      expect(result.pagination.limit).toBe(10);
      expect(result.pagination.pages).toBe(1);
    });

    it('should filter by tenant', async () => {
      mockPrisma.user.findMany.mockResolvedValue([]);
      mockPrisma.user.count.mockResolvedValue(0);

      await userService.getUsers({ tenantId: 'tenant-123' });

      expect(mockPrisma.user.findMany).toHaveBeenCalledWith({
        where: { tenantId: 'tenant-123' },
        skip: 0,
        take: 10,
        include: {
          profile: true,
          userRoles: {
            include: {
              role: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      });
    });

    it('should filter by search term', async () => {
      mockPrisma.user.findMany.mockResolvedValue([]);
      mockPrisma.user.count.mockResolvedValue(0);

      await userService.getUsers({ search: 'test' });

      expect(mockPrisma.user.findMany).toHaveBeenCalledWith({
        where: {
          OR: [
            { name: { contains: 'test', mode: 'insensitive' } },
            { email: { contains: 'test', mode: 'insensitive' } },
          ],
        },
        skip: 0,
        take: 10,
        include: {
          profile: true,
          userRoles: {
            include: {
              role: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      });
    });
  });

  describe('updateLastLogin', () => {
    it('should update last login timestamp', async () => {
      mockPrisma.user.update.mockResolvedValue({});

      await userService.updateLastLogin('user-123');

      expect(mockPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-123' },
        data: { lastLoginAt: expect.any(Date) },
      });
    });
  });

  describe('verifyEmail', () => {
    it('should verify user email', async () => {
      mockPrisma.user.update.mockResolvedValue({});

      await userService.verifyEmail('user-123');

      expect(mockPrisma.user.update).toHaveBeenCalledWith({
        where: { id: 'user-123' },
        data: { emailVerified: true },
      });
    });
  });
});