import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import { PrismaClient } from '@prisma/client';
import { bookingService } from '../../services/booking.service';
import { CreateBookingRequest } from '../../types/booking.types';

const prisma = new PrismaClient();

describe('BookingService', () => {
  let testTenantId: string;
  let testClientId: string;
  let testProfessionalId: string;
  let testServiceId: string;
  let testUserId: string;

  beforeEach(async () => {
    // Criar dados de teste
    const tenant = await prisma.tenant.create({
      data: {
        name: 'Test Tenant',
        slug: 'test-tenant-booking'
      }
    });
    testTenantId = tenant.id;

    const user = await prisma.user.create({
      data: {
        email: 'professional@test.com',
        name: 'Test Professional',
        password: 'hashedpassword',
        tenantId: testTenantId
      }
    });
    testUserId = user.id;

    const professional = await prisma.professional.create({
      data: {
        userId: user.id,
        tenantId: testTenantId
      }
    });
    testProfessionalId = professional.id;

    const client = await prisma.user.create({
      data: {
        email: 'client@test.com',
        name: 'Test Client',
        password: 'hashedpassword',
        tenantId: testTenantId
      }
    });
    testClientId = client.id;

    const service = await prisma.service.create({
      data: {
        name: 'Test Service',
        duration: 60,
        price: 100.0,
        tenantId: testTenantId,
        professionalId: testProfessionalId
      }
    });
    testServiceId = service.id;

    // Criar horário de funcionamento
    await prisma.schedule.create({
      data: {
        professionalId: testProfessionalId,
        dayOfWeek: 1, // Segunda-feira
        startTime: '09:00',
        endTime: '18:00'
      }
    });
  });

  afterEach(async () => {
    // Limpar dados de teste
    await prisma.bookingHistory.deleteMany({});
    await prisma.booking.deleteMany({});
    await prisma.schedule.deleteMany({});
    await prisma.service.deleteMany({});
    await prisma.professional.deleteMany({});
    await prisma.user.deleteMany({});
    await prisma.tenant.deleteMany({});
  });

  describe('createBooking', () => {
    it('deve criar um agendamento válido', async () => {
      const nextMonday = new Date();
      nextMonday.setDate(nextMonday.getDate() + (1 + 7 - nextMonday.getDay()) % 7);
      nextMonday.setHours(10, 0, 0, 0);

      const bookingData: CreateBookingRequest = {
        clientId: testClientId,
        professionalId: testProfessionalId,
        serviceId: testServiceId,
        startTime: nextMonday,
        notes: 'Teste de agendamento'
      };

      const booking = await bookingService.createBooking(bookingData, testTenantId);

      expect(booking).toBeDefined();
      expect(booking.clientId).toBe(testClientId);
      expect(booking.professionalId).toBe(testProfessionalId);
      expect(booking.serviceId).toBe(testServiceId);
      expect(booking.status).toBe('SCHEDULED');
      expect(booking.price).toBe(100.0);
    });

    it('deve falhar ao criar agendamento com dados inválidos', async () => {
      const bookingData: CreateBookingRequest = {
        clientId: 'invalid-client-id',
        professionalId: testProfessionalId,
        serviceId: testServiceId,
        startTime: new Date(),
        notes: 'Teste inválido'
      };

      await expect(bookingService.createBooking(bookingData, testTenantId))
        .rejects.toThrow();
    });

    it('deve falhar ao criar agendamento em horário ocupado', async () => {
      const nextMonday = new Date();
      nextMonday.setDate(nextMonday.getDate() + (1 + 7 - nextMonday.getDay()) % 7);
      nextMonday.setHours(10, 0, 0, 0);

      const bookingData: CreateBookingRequest = {
        clientId: testClientId,
        professionalId: testProfessionalId,
        serviceId: testServiceId,
        startTime: nextMonday
      };

      // Criar primeiro agendamento
      await bookingService.createBooking(bookingData, testTenantId);

      // Tentar criar segundo agendamento no mesmo horário
      await expect(bookingService.createBooking(bookingData, testTenantId))
        .rejects.toThrow('Horário não disponível');
    });
  });

  describe('validateBookingAvailability', () => {
    it('deve validar disponibilidade corretamente', async () => {
      const nextMonday = new Date();
      nextMonday.setDate(nextMonday.getDate() + (1 + 7 - nextMonday.getDay()) % 7);
      nextMonday.setHours(10, 0, 0, 0);

      const validationData = {
        clientId: testClientId,
        professionalId: testProfessionalId,
        serviceId: testServiceId,
        startTime: nextMonday
      };

      const result = await bookingService.validateBookingAvailability(validationData);

      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('deve detectar horário fora do expediente', async () => {
      const nextMonday = new Date();
      nextMonday.setDate(nextMonday.getDate() + (1 + 7 - nextMonday.getDay()) % 7);
      nextMonday.setHours(20, 0, 0, 0); // Fora do horário de funcionamento

      const validationData = {
        clientId: testClientId,
        professionalId: testProfessionalId,
        serviceId: testServiceId,
        startTime: nextMonday
      };

      const result = await bookingService.validateBookingAvailability(validationData);

      expect(result.isValid).toBe(false);
      expect(result.errors).toContain('Horário fora do expediente do profissional');
    });
  });

  describe('rescheduleBooking', () => {
    it('deve reagendar um agendamento válido', async () => {
      const nextMonday = new Date();
      nextMonday.setDate(nextMonday.getDate() + (1 + 7 - nextMonday.getDay()) % 7);
      nextMonday.setHours(10, 0, 0, 0);

      const bookingData: CreateBookingRequest = {
        clientId: testClientId,
        professionalId: testProfessionalId,
        serviceId: testServiceId,
        startTime: nextMonday
      };

      const booking = await bookingService.createBooking(bookingData, testTenantId);

      const newStartTime = new Date(nextMonday);
      newStartTime.setHours(14, 0, 0, 0);

      const rescheduledBooking = await bookingService.rescheduleBooking(
        booking.id,
        { newStartTime, reason: 'Teste de reagendamento' },
        testClientId
      );

      expect(rescheduledBooking.startTime).toEqual(newStartTime);
      expect(rescheduledBooking.status).toBe('RESCHEDULED');
    });
  });

  describe('cancelBooking', () => {
    it('deve cancelar um agendamento válido', async () => {
      const nextMonday = new Date();
      nextMonday.setDate(nextMonday.getDate() + (1 + 7 - nextMonday.getDay()) % 7);
      nextMonday.setHours(10, 0, 0, 0);

      const bookingData: CreateBookingRequest = {
        clientId: testClientId,
        professionalId: testProfessionalId,
        serviceId: testServiceId,
        startTime: nextMonday
      };

      const booking = await bookingService.createBooking(bookingData, testTenantId);

      const cancelledBooking = await bookingService.cancelBooking(
        booking.id,
        testClientId,
        'Teste de cancelamento'
      );

      expect(cancelledBooking.status).toBe('CANCELLED');
    });
  });

  describe('getBookings', () => {
    it('deve listar agendamentos com filtros', async () => {
      const nextMonday = new Date();
      nextMonday.setDate(nextMonday.getDate() + (1 + 7 - nextMonday.getDay()) % 7);
      nextMonday.setHours(10, 0, 0, 0);

      const bookingData: CreateBookingRequest = {
        clientId: testClientId,
        professionalId: testProfessionalId,
        serviceId: testServiceId,
        startTime: nextMonday
      };

      await bookingService.createBooking(bookingData, testTenantId);

      const bookings = await bookingService.getBookings({
        tenantId: testTenantId,
        clientId: testClientId
      });

      expect(bookings).toHaveLength(1);
      expect(bookings[0].clientId).toBe(testClientId);
    });
  });

  describe('getBookingMetrics', () => {
    it('deve calcular métricas básicas', async () => {
      const nextMonday = new Date();
      nextMonday.setDate(nextMonday.getDate() + (1 + 7 - nextMonday.getDay()) % 7);
      nextMonday.setHours(10, 0, 0, 0);

      const bookingData: CreateBookingRequest = {
        clientId: testClientId,
        professionalId: testProfessionalId,
        serviceId: testServiceId,
        startTime: nextMonday
      };

      const booking = await bookingService.createBooking(bookingData, testTenantId);
      await bookingService.completeBooking(booking.id, testUserId);

      const metrics = await bookingService.getBookingMetrics({
        tenantId: testTenantId
      });

      expect(metrics.totalBookings).toBe(1);
      expect(metrics.completedBookings).toBe(1);
      expect(metrics.completionRate).toBe(100);
      expect(metrics.totalRevenue).toBe(100);
    });
  });
});