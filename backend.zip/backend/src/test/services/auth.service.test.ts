import { PrismaClient } from '@prisma/client';
import { AuthService } from '../../services/auth.service';
import { hashPassword } from '../../utils/password.utils';

// Mock the PrismaClient
const mockPrisma = new PrismaClient() as jest.Mocked<PrismaClient>;

describe('AuthService', () => {
  let authService: AuthService;

  beforeEach(() => {
    authService = new AuthService(mockPrisma);
    jest.clearAllMocks();
  });

  describe('login', () => {
    const mockUser = {
      id: 'user-123',
      email: 'test@example.com',
      name: 'Test User',
      phone: null,
      password: 'hashed-password',
      tenantId: 'tenant-123',
      isActive: true,
      emailVerified: true,
      lastLoginAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      userRoles: [
        {
          role: {
            id: 'role-123',
            name: 'CLIENT',
            description: 'Client role',
            rolePermissions: [
              {
                permission: {
                  id: 'perm-123',
                  name: 'booking:create',
                  resource: 'booking',
                  action: 'create',
                },
              },
            ],
          },
        },
      ],
    };

    beforeEach(async () => {
      // Mock password hash
      mockUser.password = await hashPassword('testPassword123!');
    });

    it('should login successfully with valid credentials', async () => {
      // Mock UserService.getUserByEmail
      jest.spyOn(authService['userService'], 'getUserByEmail').mockResolvedValue(mockUser as any);
      jest.spyOn(authService['userService'], 'updateLastLogin').mockResolvedValue();

      const result = await authService.login({
        email: 'test@example.com',
        password: 'testPassword123!',
      });

      expect(result).toBeDefined();
      expect(result.user).toBeDefined();
      expect(result.tokens).toBeDefined();
      expect(result.tokens.accessToken).toBeDefined();
      expect(result.tokens.refreshToken).toBeDefined();
      expect(result.user.email).toBe('test@example.com');
      expect(result.user.password).toBeUndefined(); // Password should be removed
    });

    it('should throw error for non-existent user', async () => {
      jest.spyOn(authService['userService'], 'getUserByEmail').mockResolvedValue(null);

      await expect(
        authService.login({
          email: 'nonexistent@example.com',
          password: 'testPassword123!',
        })
      ).rejects.toThrow('Credenciais inválidas');
    });

    it('should throw error for inactive user', async () => {
      const inactiveUser = { ...mockUser, isActive: false };
      jest.spyOn(authService['userService'], 'getUserByEmail').mockResolvedValue(inactiveUser as any);

      await expect(
        authService.login({
          email: 'test@example.com',
          password: 'testPassword123!',
        })
      ).rejects.toThrow('Conta desativada. Entre em contato com o suporte.');
    });

    it('should throw error for invalid password', async () => {
      jest.spyOn(authService['userService'], 'getUserByEmail').mockResolvedValue(mockUser as any);

      await expect(
        authService.login({
          email: 'test@example.com',
          password: 'wrongPassword',
        })
      ).rejects.toThrow('Credenciais inválidas');
    });
  });

  describe('refreshToken', () => {
    const mockUser = {
      id: 'user-123',
      email: 'test@example.com',
      name: 'Test User',
      phone: null,
      tenantId: 'tenant-123',
      isActive: true,
      emailVerified: true,
      lastLoginAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      userRoles: [
        {
          role: {
            id: 'role-123',
            name: 'CLIENT',
            description: 'Client role',
            rolePermissions: [
              {
                permission: {
                  id: 'perm-123',
                  name: 'booking:create',
                  resource: 'booking',
                  action: 'create',
                },
              },
            ],
          },
        },
      ],
    };

    it('should refresh token successfully with valid refresh token', async () => {
      // Generate a valid refresh token
      const { generateRefreshToken } = require('../../utils/jwt.utils');
      const validRefreshToken = generateRefreshToken('user-123');

      jest.spyOn(authService['userService'], 'getUserById').mockResolvedValue(mockUser as any);

      const result = await authService.refreshToken(validRefreshToken);

      expect(result).toBeDefined();
      expect(result.accessToken).toBeDefined();
      expect(result.refreshToken).toBeDefined();
    });

    it('should throw error for invalid refresh token', async () => {
      await expect(
        authService.refreshToken('invalid-refresh-token')
      ).rejects.toThrow('Refresh token inválido ou expirado');
    });

    it('should throw error for inactive user', async () => {
      const { generateRefreshToken } = require('../../utils/jwt.utils');
      const validRefreshToken = generateRefreshToken('user-123');

      const inactiveUser = { ...mockUser, isActive: false };
      jest.spyOn(authService['userService'], 'getUserById').mockResolvedValue(inactiveUser as any);

      await expect(
        authService.refreshToken(validRefreshToken)
      ).rejects.toThrow('Refresh token inválido ou expirado');
    });
  });

  describe('getCurrentUser', () => {
    const mockUser = {
      id: 'user-123',
      email: 'test@example.com',
      name: 'Test User',
      phone: null,
      password: 'hashed-password',
      tenantId: 'tenant-123',
      isActive: true,
      emailVerified: true,
      lastLoginAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      userRoles: [],
    };

    it('should return current user successfully', async () => {
      jest.spyOn(authService['userService'], 'getUserById').mockResolvedValue(mockUser as any);

      const result = await authService.getCurrentUser('user-123');

      expect(result).toBeDefined();
      expect(result.id).toBe('user-123');
      expect(result.email).toBe('test@example.com');
      expect(result.password).toBeUndefined(); // Password should be removed
    });

    it('should throw error for non-existent user', async () => {
      jest.spyOn(authService['userService'], 'getUserById').mockResolvedValue(null);

      await expect(
        authService.getCurrentUser('non-existent-user')
      ).rejects.toThrow('Sessão inválida');
    });

    it('should throw error for inactive user', async () => {
      const inactiveUser = { ...mockUser, isActive: false };
      jest.spyOn(authService['userService'], 'getUserById').mockResolvedValue(inactiveUser as any);

      await expect(
        authService.getCurrentUser('user-123')
      ).rejects.toThrow('Sessão inválida');
    });
  });

  describe('checkPermission', () => {
    it('should check user permission successfully', async () => {
      jest.spyOn(authService['userService'], 'hasPermission').mockResolvedValue(true);

      const result = await authService.checkPermission('user-123', 'booking', 'create');

      expect(result).toBe(true);
      expect(authService['userService'].hasPermission).toHaveBeenCalledWith('user-123', 'booking', 'create');
    });

    it('should return false for user without permission', async () => {
      jest.spyOn(authService['userService'], 'hasPermission').mockResolvedValue(false);

      const result = await authService.checkPermission('user-123', 'booking', 'delete');

      expect(result).toBe(false);
    });
  });

  describe('hasRole', () => {
    it('should return true when user has required role', async () => {
      jest.spyOn(authService['userService'], 'getUserRoles').mockResolvedValue(['CLIENT', 'PROFESSIONAL']);

      const result = await authService.hasRole('user-123', ['CLIENT']);

      expect(result).toBe(true);
    });

    it('should return false when user does not have required role', async () => {
      jest.spyOn(authService['userService'], 'getUserRoles').mockResolvedValue(['CLIENT']);

      const result = await authService.hasRole('user-123', ['ADMIN']);

      expect(result).toBe(false);
    });

    it('should return true when user has any of the required roles', async () => {
      jest.spyOn(authService['userService'], 'getUserRoles').mockResolvedValue(['CLIENT']);

      const result = await authService.hasRole('user-123', ['ADMIN', 'CLIENT']);

      expect(result).toBe(true);
    });
  });

  describe('hasAllRoles', () => {
    it('should return true when user has all required roles', async () => {
      jest.spyOn(authService['userService'], 'getUserRoles').mockResolvedValue(['CLIENT', 'PROFESSIONAL']);

      const result = await authService.hasAllRoles('user-123', ['CLIENT', 'PROFESSIONAL']);

      expect(result).toBe(true);
    });

    it('should return false when user does not have all required roles', async () => {
      jest.spyOn(authService['userService'], 'getUserRoles').mockResolvedValue(['CLIENT']);

      const result = await authService.hasAllRoles('user-123', ['CLIENT', 'ADMIN']);

      expect(result).toBe(false);
    });
  });

  describe('changePassword', () => {
    it('should change password successfully', async () => {
      jest.spyOn(authService['userService'], 'changePassword').mockResolvedValue(true);

      await expect(
        authService.changePassword('user-123', 'currentPassword', 'newPassword123!')
      ).resolves.not.toThrow();

      expect(authService['userService'].changePassword).toHaveBeenCalledWith(
        'user-123',
        'currentPassword',
        'newPassword123!'
      );
    });

    it('should throw error when change password fails', async () => {
      jest.spyOn(authService['userService'], 'changePassword').mockRejectedValue(new Error('Senha atual incorreta'));

      await expect(
        authService.changePassword('user-123', 'wrongPassword', 'newPassword123!')
      ).rejects.toThrow('Senha atual incorreta');
    });
  });
});