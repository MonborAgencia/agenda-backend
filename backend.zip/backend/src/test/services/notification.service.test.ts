import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import { PrismaClient } from '@prisma/client';
import { notificationService } from '../../services/notification.service';
import { notificationTemplateService } from '../../services/notification-template.service';
import {
  NotificationType,
  NotificationCategory,
  NotificationStatus,
  NotificationPriority,
  CreateNotificationData
} from '../../types/notification.types';

const prisma = new PrismaClient();

describe('NotificationService', () => {
  let testUserId: string;
  let testTemplateId: string;

  beforeEach(async () => {
    // Criar usuário de teste
    const testUser = await prisma.user.create({
      data: {
        email: 'test-notification@example.com',
        name: 'Test User',
        password: 'hashedpassword',
        phone: '+5511999999999'
      }
    });
    testUserId = testUser.id;

    // Criar template de teste
    const testTemplate = await notificationTemplateService.createTemplate({
      name: 'TEST_NOTIFICATION_TEMPLATE',
      type: NotificationType.EMAIL,
      subject: 'Teste - {{name}}',
      content: 'Olá {{name}}, esta é uma notificação de teste.',
      category: NotificationCategory.SYSTEM,
      variables: [
        {
          name: 'name',
          description: 'Nome do usuário',
          type: 'string',
          required: true
        }
      ]
    });
    testTemplateId = testTemplate.id;

    // Limpar fila de testes
    await notificationService.clearQueue();
  });

  afterEach(async () => {
    // Limpar dados de teste
    await prisma.notification.deleteMany({
      where: {
        recipientId: testUserId
      }
    });

    await prisma.notificationTemplate.deleteMany({
      where: {
        name: 'TEST_NOTIFICATION_TEMPLATE'
      }
    });

    await prisma.user.deleteMany({
      where: {
        email: 'test-notification@example.com'
      }
    });

    // Limpar fila
    await notificationService.clearQueue();
  });

  describe('createNotification', () => {
    it('deve criar notificação com template', async () => {
      const notificationData: CreateNotificationData = {
        templateId: testTemplateId,
        recipientId: testUserId,
        type: NotificationType.EMAIL,
        variables: {
          name: 'João Silva'
        }
      };

      const notification = await notificationService.createNotification(notificationData);

      expect(notification).toBeDefined();
      expect(notification.templateId).toBe(testTemplateId);
      expect(notification.recipientId).toBe(testUserId);
      expect(notification.type).toBe(NotificationType.EMAIL);
      expect(notification.status).toBe(NotificationStatus.PENDING);
      expect(notification.subject).toBe('Teste - João Silva');
      expect(notification.content).toBe('Olá João Silva, esta é uma notificação de teste.');
    });

    it('deve criar notificação sem template', async () => {
      const notificationData: CreateNotificationData = {
        recipientId: testUserId,
        type: NotificationType.WHATSAPP,
        subject: 'Assunto personalizado',
        content: 'Conteúdo personalizado da mensagem',
        metadata: {
          customField: 'valor personalizado'
        }
      };

      const notification = await notificationService.createNotification(notificationData);

      expect(notification).toBeDefined();
      expect(notification.templateId).toBeNull();
      expect(notification.recipientId).toBe(testUserId);
      expect(notification.type).toBe(NotificationType.WHATSAPP);
      expect(notification.subject).toBe('Assunto personalizado');
      expect(notification.content).toBe('Conteúdo personalizado da mensagem');
      expect(notification.metadata).toEqual({
        customField: 'valor personalizado'
      });
    });

    it('deve criar notificação agendada', async () => {
      const scheduledFor = new Date(Date.now() + 3600000); // 1 hora no futuro
      
      const notificationData: CreateNotificationData = {
        recipientId: testUserId,
        type: NotificationType.EMAIL,
        content: 'Notificação agendada',
        scheduledFor
      };

      const notification = await notificationService.createNotification(notificationData);

      expect(notification.scheduledFor).toEqual(scheduledFor);
    });
  });

  describe('enqueueNotification', () => {
    it('deve adicionar notificação à fila', async () => {
      const notification = await notificationService.createNotification({
        recipientId: testUserId,
        type: NotificationType.EMAIL,
        content: 'Teste de fila'
      });

      await notificationService.enqueueNotification({
        notificationId: notification.id,
        priority: NotificationPriority.HIGH
      });

      const queueSize = await notificationService.getQueueSize();
      expect(queueSize).toBe(1);

      const queueItems = await notificationService.getQueueItems(1);
      expect(queueItems).toHaveLength(1);
      expect(queueItems[0].notificationId).toBe(notification.id);
    });

    it('deve respeitar prioridade na fila', async () => {
      // Criar duas notificações
      const notification1 = await notificationService.createNotification({
        recipientId: testUserId,
        type: NotificationType.EMAIL,
        content: 'Notificação normal'
      });

      const notification2 = await notificationService.createNotification({
        recipientId: testUserId,
        type: NotificationType.EMAIL,
        content: 'Notificação urgente'
      });

      // Adicionar à fila com prioridades diferentes
      await notificationService.enqueueNotification({
        notificationId: notification1.id,
        priority: NotificationPriority.NORMAL
      });

      await notificationService.enqueueNotification({
        notificationId: notification2.id,
        priority: NotificationPriority.URGENT
      });

      const queueItems = await notificationService.getQueueItems(2);
      expect(queueItems).toHaveLength(2);
      
      // A notificação urgente deve vir primeiro
      expect(queueItems[0].notificationId).toBe(notification2.id);
      expect(queueItems[1].notificationId).toBe(notification1.id);
    });

    it('deve adicionar delay à notificação', async () => {
      const notification = await notificationService.createNotification({
        recipientId: testUserId,
        type: NotificationType.EMAIL,
        content: 'Notificação com delay'
      });

      const delay = 60; // 60 segundos
      await notificationService.enqueueNotification({
        notificationId: notification.id,
        delay
      });

      const queueItems = await notificationService.getQueueItems(1);
      expect(queueItems).toHaveLength(1);
      
      const scheduledTime = queueItems[0].scheduledFor.getTime();
      const expectedTime = Date.now() + (delay * 1000);
      
      // Permitir diferença de até 5 segundos
      expect(Math.abs(scheduledTime - expectedTime)).toBeLessThan(5000);
    });
  });

  describe('getNotifications', () => {
    beforeEach(async () => {
      // Criar notificações de teste
      await notificationService.createNotification({
        recipientId: testUserId,
        type: NotificationType.EMAIL,
        content: 'Email de teste'
      });

      await notificationService.createNotification({
        recipientId: testUserId,
        type: NotificationType.WHATSAPP,
        content: 'WhatsApp de teste'
      });
    });

    it('deve buscar todas as notificações', async () => {
      const result = await notificationService.getNotifications();
      
      const testNotifications = result.notifications.filter(
        n => n.recipientId === testUserId
      );
      
      expect(testNotifications.length).toBeGreaterThanOrEqual(2);
    });

    it('deve filtrar notificações por tipo', async () => {
      const result = await notificationService.getNotifications({
        type: NotificationType.EMAIL,
        recipientId: testUserId
      });

      expect(result.notifications.length).toBeGreaterThanOrEqual(1);
      expect(result.notifications.every(n => n.type === NotificationType.EMAIL)).toBe(true);
    });

    it('deve paginar resultados', async () => {
      const result = await notificationService.getNotifications({}, 1, 1);
      
      expect(result.notifications).toHaveLength(1);
      expect(result.page).toBe(1);
      expect(result.totalPages).toBeGreaterThanOrEqual(1);
    });
  });

  describe('cancelNotification', () => {
    it('deve cancelar notificação na fila', async () => {
      const notification = await notificationService.createNotification({
        recipientId: testUserId,
        type: NotificationType.EMAIL,
        content: 'Notificação para cancelar'
      });

      await notificationService.enqueueNotification({
        notificationId: notification.id
      });

      const success = await notificationService.cancelNotification(notification.id);
      expect(success).toBe(true);

      const queueSize = await notificationService.getQueueSize();
      expect(queueSize).toBe(0);

      const updatedNotification = await notificationService.getNotificationById(notification.id);
      expect(updatedNotification?.status).toBe(NotificationStatus.CANCELLED);
    });
  });

  describe('getNotificationStats', () => {
    beforeEach(async () => {
      // Criar notificações com diferentes status
      const notification1 = await notificationService.createNotification({
        recipientId: testUserId,
        type: NotificationType.EMAIL,
        content: 'Notificação 1'
      });

      const notification2 = await notificationService.createNotification({
        recipientId: testUserId,
        type: NotificationType.EMAIL,
        content: 'Notificação 2'
      });

      // Simular diferentes status
      await prisma.notification.update({
        where: { id: notification1.id },
        data: { status: NotificationStatus.DELIVERED }
      });

      await prisma.notification.update({
        where: { id: notification2.id },
        data: { status: NotificationStatus.FAILED }
      });
    });

    it('deve calcular estatísticas corretamente', async () => {
      const stats = await notificationService.getNotificationStats({
        recipientId: testUserId
      });

      expect(stats.total).toBeGreaterThanOrEqual(2);
      expect(stats.delivered).toBeGreaterThanOrEqual(1);
      expect(stats.failed).toBeGreaterThanOrEqual(1);
      expect(stats.deliveryRate).toBeGreaterThan(0);
    });
  });

  describe('createAndEnqueueNotification', () => {
    it('deve criar e enfileirar notificação em uma operação', async () => {
      const notificationData: CreateNotificationData = {
        recipientId: testUserId,
        type: NotificationType.EMAIL,
        content: 'Notificação criada e enfileirada'
      };

      const notification = await notificationService.createAndEnqueueNotification(
        notificationData,
        { priority: NotificationPriority.HIGH }
      );

      expect(notification).toBeDefined();
      expect(notification.status).toBe(NotificationStatus.PENDING);

      const queueSize = await notificationService.getQueueSize();
      expect(queueSize).toBe(1);
    });
  });
});