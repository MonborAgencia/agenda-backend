import { ScheduleService } from '../../services/schedule.service';

// Mock Redis client
jest.mock('../../config/redis', () => ({
  redisClient: {
    isReady: false,
    get: jest.fn(),
    setEx: jest.fn(),
    del: jest.fn(),
    keys: jest.fn()
  },
  CACHE_KEYS: {
    AVAILABLE_SLOTS: (professionalId: string, date: string) => 
      `slots:available:${professionalId}:${date}`,
    SLOT_RESERVATION: (slotId: string) => 
      `slots:reserved:${slotId}`,
    PROFESSIONAL_SCHEDULE: (professionalId: string) => 
      `schedule:${professionalId}`,
    DAY_AVAILABILITY: (professionalId: string, date: string, duration: number) => 
      `availability:${professionalId}:${date}:${duration}`
  },
  CACHE_TTL: {
    AVAILABLE_SLOTS: 300,
    SLOT_RESERVATION: 900,
    PROFESSIONAL_SCHEDULE: 3600,
    DAY_AVAILABILITY: 300
  }
}));

// Simple mock for testing core functionality
const mockPrisma = {
  schedule: {
    findFirst: jest.fn(),
    findMany: jest.fn(),
    findUnique: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
    deleteMany: jest.fn(),
  },
  scheduleException: {
    findFirst: jest.fn(),
    findUnique: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
  },
  professional: {
    findFirst: jest.fn(),
  },
  booking: {
    findFirst: jest.fn(),
    findMany: jest.fn(),
  },
  service: {
    findFirst: jest.fn(),
  },
} as any;

describe('ScheduleService - Core Functionality', () => {
  let scheduleService: ScheduleService;

  beforeEach(() => {
    scheduleService = new ScheduleService(mockPrisma);
    jest.clearAllMocks();
  });

  describe('createSchedule', () => {
    it('should create schedule successfully', async () => {
      const scheduleData = {
        professionalId: 'prof-123',
        dayOfWeek: 1, // Segunda-feira
        startTime: '09:00',
        endTime: '18:00'
      };

      const mockProfessional = {
        id: 'prof-123',
        tenantId: 'tenant-123',
        user: { id: 'user-123', name: 'João', email: 'joao@test.com' }
      };

      const mockSchedule = {
        id: 'schedule-123',
        ...scheduleData,
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        professional: mockProfessional,
        exceptions: []
      };

      mockPrisma.professional.findFirst.mockResolvedValue(mockProfessional);
      mockPrisma.schedule.findMany.mockResolvedValue([]); // No conflicting schedules
      mockPrisma.schedule.findFirst.mockResolvedValue(null); // No existing schedule for this day
      mockPrisma.schedule.create.mockResolvedValue(mockSchedule);

      const result = await scheduleService.createSchedule(scheduleData, 'tenant-123');

      expect(result).toBeDefined();
      expect(result.dayOfWeek).toBe(1);
      expect(result.startTime).toBe('09:00');
      expect(result.endTime).toBe('18:00');
    });

    it('should throw error when professional not found', async () => {
      const scheduleData = {
        professionalId: 'prof-123',
        dayOfWeek: 1,
        startTime: '09:00',
        endTime: '18:00'
      };

      mockPrisma.professional.findFirst.mockResolvedValue(null);

      await expect(scheduleService.createSchedule(scheduleData, 'tenant-123'))
        .rejects.toThrow('Profissional não encontrado ou não pertence ao tenant');
    });

    it('should throw error when schedule already exists for day', async () => {
      const scheduleData = {
        professionalId: 'prof-123',
        dayOfWeek: 1,
        startTime: '09:00',
        endTime: '18:00'
      };

      const mockProfessional = {
        id: 'prof-123',
        tenantId: 'tenant-123'
      };

      const existingSchedule = {
        id: 'existing-123',
        professionalId: 'prof-123',
        dayOfWeek: 1
      };

      mockPrisma.professional.findFirst.mockResolvedValue(mockProfessional);
      mockPrisma.schedule.findMany.mockResolvedValue([]);
      mockPrisma.schedule.findFirst.mockResolvedValue(existingSchedule);

      await expect(scheduleService.createSchedule(scheduleData, 'tenant-123'))
        .rejects.toThrow('Já existe um horário configurado para este dia da semana');
    });

    it('should throw error for invalid time range', async () => {
      const scheduleData = {
        professionalId: 'prof-123',
        dayOfWeek: 1,
        startTime: '18:00',
        endTime: '09:00' // End before start
      };

      const mockProfessional = {
        id: 'prof-123',
        tenantId: 'tenant-123'
      };

      mockPrisma.professional.findFirst.mockResolvedValue(mockProfessional);

      await expect(scheduleService.createSchedule(scheduleData, 'tenant-123'))
        .rejects.toThrow('Horário de início deve ser anterior ao horário de fim');
    });
  });

  describe('getSchedulesByProfessional', () => {
    it('should return schedules for professional', async () => {
      const mockProfessional = {
        id: 'prof-123',
        tenantId: 'tenant-123'
      };

      const mockSchedules = [
        {
          id: 'schedule-1',
          professionalId: 'prof-123',
          dayOfWeek: 1,
          startTime: '09:00',
          endTime: '18:00',
          professional: {
            id: 'prof-123',
            user: { id: 'user-123', name: 'João', email: 'joao@test.com' }
          },
          exceptions: []
        }
      ];

      mockPrisma.professional.findFirst.mockResolvedValue(mockProfessional);
      mockPrisma.schedule.findMany.mockResolvedValue(mockSchedules);

      const result = await scheduleService.getSchedulesByProfessional('prof-123', 'tenant-123');

      expect(result).toHaveLength(1);
      expect(result[0].dayOfWeek).toBe(1);
      expect(result[0].startTime).toBe('09:00');
    });

    it('should throw error when professional not found', async () => {
      mockPrisma.professional.findFirst.mockResolvedValue(null);

      await expect(scheduleService.getSchedulesByProfessional('prof-123', 'tenant-123'))
        .rejects.toThrow('Profissional não encontrado ou não pertence ao tenant');
    });
  });

  describe('getDayAvailability', () => {
    it('should return empty availability when no schedule', async () => {
      const mockProfessional = {
        id: 'prof-123',
        tenantId: 'tenant-123'
      };

      mockPrisma.professional.findFirst.mockResolvedValue(mockProfessional);
      mockPrisma.schedule.findFirst.mockResolvedValue(null);

      const result = await scheduleService.getDayAvailability(
        'prof-123', 
        '2024-12-23',
        60,
        'tenant-123'
      );

      expect(result.slots).toHaveLength(0);
      expect(result.totalSlots).toBe(0);
      expect(result.availableSlots).toBe(0);
    });

    it('should calculate availability with existing bookings', async () => {
      const mockProfessional = {
        id: 'prof-123',
        tenantId: 'tenant-123'
      };

      const mockSchedule = {
        id: 'schedule-123',
        professionalId: 'prof-123',
        dayOfWeek: 1, // Monday
        startTime: '09:00',
        endTime: '17:00',
        isActive: true,
        exceptions: []
      };

      const mockBookings = [
        {
          id: 'booking-1',
          startTime: new Date('2024-12-23T10:00:00'),
          endTime: new Date('2024-12-23T11:00:00'),
          status: 'SCHEDULED'
        }
      ];

      mockPrisma.professional.findFirst.mockResolvedValue(mockProfessional);
      mockPrisma.schedule.findFirst.mockResolvedValue(mockSchedule);
      mockPrisma.booking.findMany.mockResolvedValue(mockBookings);

      const result = await scheduleService.getDayAvailability(
        'prof-123', 
        '2024-12-23', // Monday
        60,
        'tenant-123'
      );

      expect(result.slots.length).toBeGreaterThan(0);
      expect(result.availableSlots).toBeLessThan(result.totalSlots);
      
      // Check that 10:00-11:00 slot is not available
      const unavailableSlot = result.slots.find(slot => 
        slot.startTime === '10:00' && slot.endTime === '11:00'
      );
      expect(unavailableSlot?.isAvailable).toBe(false);
    });
  });

  describe('Agenda Visualization', () => {
    describe('getDailyAgenda', () => {
      it('should return daily agenda with bookings', async () => {
        const mockBookings = [
          {
            id: 'booking-1',
            startTime: new Date('2024-12-23T10:00:00'),
            endTime: new Date('2024-12-23T11:00:00'),
            status: 'SCHEDULED',
            price: 50.0,
            notes: 'Test booking',
            client: {
              name: 'João Silva',
              phone: '11999999999'
            },
            service: {
              name: 'Corte de Cabelo'
            }
          }
        ];

        mockPrisma.booking.findMany.mockResolvedValue(mockBookings);

        const result = await scheduleService.getDailyAgenda(
          '2024-12-23',
          'prof-123',
          undefined,
          'tenant-123'
        );

        expect(result.date).toBe('2024-12-23');
        expect(result.dayOfWeek).toBe(0); // Sunday (December 23, 2024 is actually Sunday)
        expect(result.bookings).toHaveLength(1);
        expect(result.totalBookings).toBe(1);
        expect(result.totalRevenue).toBe(50.0);
        expect(result.occupancyRate).toBeGreaterThan(0);
        
        const booking = result.bookings[0];
        expect(booking.clientName).toBe('João Silva');
        expect(booking.serviceName).toBe('Corte de Cabelo');
        expect(booking.price).toBe(50.0);
      });

      it('should return empty agenda when no bookings', async () => {
        mockPrisma.booking.findMany.mockResolvedValue([]);

        const result = await scheduleService.getDailyAgenda(
          '2024-12-23',
          'prof-123',
          undefined,
          'tenant-123'
        );

        expect(result.bookings).toHaveLength(0);
        expect(result.totalBookings).toBe(0);
        expect(result.totalRevenue).toBe(0);
        expect(result.occupancyRate).toBe(0);
      });
    });

    describe('getWeeklyAgenda', () => {
      it('should return weekly agenda with 7 days', async () => {
        // Mock getDailyAgenda calls
        const mockDailyAgenda = {
          date: '2024-12-23',
          dayOfWeek: 1,
          bookings: [],
          totalBookings: 0,
          totalRevenue: 0,
          occupancyRate: 0
        };

        // Mock the getDailyAgenda method
        jest.spyOn(scheduleService, 'getDailyAgenda').mockResolvedValue(mockDailyAgenda);

        const result = await scheduleService.getWeeklyAgenda(
          '2024-12-23', // Monday
          'prof-123',
          undefined,
          'tenant-123'
        );

        expect(result.startDate).toBe('2024-12-23');
        expect(result.days).toHaveLength(7);
        expect(result.totalBookings).toBe(0);
        expect(result.totalRevenue).toBe(0);
        expect(result.averageOccupancyRate).toBe(0);
      });
    });

    describe('getMonthlyAgenda', () => {
      it('should return monthly agenda with weeks', async () => {
        // Mock getWeeklyAgenda calls
        const mockWeeklyAgenda = {
          startDate: '2024-12-23',
          endDate: '2024-12-29',
          days: [],
          totalBookings: 0,
          totalRevenue: 0,
          averageOccupancyRate: 0
        };

        jest.spyOn(scheduleService, 'getWeeklyAgenda').mockResolvedValue(mockWeeklyAgenda);

        const result = await scheduleService.getMonthlyAgenda(
          2024,
          12,
          'prof-123',
          undefined,
          'tenant-123'
        );

        expect(result.year).toBe(2024);
        expect(result.month).toBe(12);
        expect(result.weeks.length).toBeGreaterThan(0);
        expect(result.totalBookings).toBe(0);
        expect(result.totalRevenue).toBe(0);
      });
    });
  });

  describe('Available Slots System', () => {
    describe('generateAvailableSlots', () => {
      it('should generate available slots for valid request', async () => {
        const mockProfessional = {
          id: 'prof-123',
          tenantId: 'tenant-123'
        };

        const mockService = {
          id: 'service-123',
          name: 'Corte de Cabelo',
          duration: 60,
          price: 50.0,
          tenantId: 'tenant-123',
          professionalId: 'prof-123'
        };

        const mockSchedule = {
          id: 'schedule-123',
          professionalId: 'prof-123',
          dayOfWeek: 1, // Monday
          startTime: '09:00',
          endTime: '17:00',
          isActive: true,
          exceptions: []
        };

        mockPrisma.professional.findFirst.mockResolvedValue(mockProfessional);
        mockPrisma.service.findFirst.mockResolvedValue(mockService);
        mockPrisma.schedule.findFirst.mockResolvedValue(mockSchedule);
        mockPrisma.booking.findMany.mockResolvedValue([]);

        const request = {
          professionalId: 'prof-123',
          serviceId: 'service-123',
          startDate: '2024-12-23',
          endDate: '2024-12-23'
        };

        const result = await scheduleService.generateAvailableSlots(request, 'tenant-123');

        expect(result.length).toBeGreaterThan(0);
        expect(result[0].professionalId).toBe('prof-123');
        expect(result[0].serviceId).toBe('service-123');
        expect(result[0].duration).toBe(60);
        expect(result[0].price).toBe(50.0);
      });

      it('should throw error when professional not found', async () => {
        mockPrisma.professional.findFirst.mockResolvedValue(null);

        const request = {
          professionalId: 'prof-123',
          serviceId: 'service-123',
          startDate: '2024-12-23',
          endDate: '2024-12-23'
        };

        await expect(scheduleService.generateAvailableSlots(request, 'tenant-123'))
          .rejects.toThrow('Profissional não encontrado ou não pertence ao tenant');
      });

      it('should throw error when service not found', async () => {
        const mockProfessional = {
          id: 'prof-123',
          tenantId: 'tenant-123'
        };

        mockPrisma.professional.findFirst.mockResolvedValue(mockProfessional);
        mockPrisma.service.findFirst.mockResolvedValue(null);

        const request = {
          professionalId: 'prof-123',
          serviceId: 'service-123',
          startDate: '2024-12-23',
          endDate: '2024-12-23'
        };

        await expect(scheduleService.generateAvailableSlots(request, 'tenant-123'))
          .rejects.toThrow('Serviço não encontrado ou não pertence ao profissional');
      });
    });

    describe('reserveSlotTemporarily', () => {
      it('should reserve slot successfully', async () => {
        const { redisClient } = require('../../config/redis');
        redisClient.isReady = true;
        redisClient.get.mockResolvedValue(null); // No existing reservation
        redisClient.setEx.mockResolvedValue('OK');

        const request = {
          slotId: 'slot-123',
          clientId: 'client-123',
          reservationMinutes: 15
        };

        const result = await scheduleService.reserveSlotTemporarily(request);

        expect(result.slotId).toBe('slot-123');
        expect(result.clientId).toBe('client-123');
        expect(result.reservedAt).toBeInstanceOf(Date);
        expect(result.expiresAt).toBeInstanceOf(Date);
        expect(redisClient.setEx).toHaveBeenCalled();
      });

      it('should throw error when slot already reserved', async () => {
        const { redisClient } = require('../../config/redis');
        redisClient.isReady = true;
        
        const existingReservation = {
          slotId: 'slot-123',
          clientId: 'other-client',
          reservedAt: new Date(),
          expiresAt: new Date(Date.now() + 15 * 60 * 1000)
        };
        
        redisClient.get.mockResolvedValue(JSON.stringify(existingReservation));

        const request = {
          slotId: 'slot-123',
          clientId: 'client-123'
        };

        await expect(scheduleService.reserveSlotTemporarily(request))
          .rejects.toThrow('Slot já está reservado temporariamente');
      });
    });

    describe('releaseSlotReservation', () => {
      it('should release reservation successfully', async () => {
        const { redisClient } = require('../../config/redis');
        redisClient.isReady = true;
        redisClient.del.mockResolvedValue(1);

        await scheduleService.releaseSlotReservation('slot-123');

        expect(redisClient.del).toHaveBeenCalledWith('slots:reserved:slot-123');
      });
    });

    describe('getSlotReservation', () => {
      it('should return reservation when exists and not expired', async () => {
        const { redisClient } = require('../../config/redis');
        redisClient.isReady = true;
        
        const reservation = {
          slotId: 'slot-123',
          clientId: 'client-123',
          reservedAt: new Date(),
          expiresAt: new Date(Date.now() + 15 * 60 * 1000) // 15 minutes from now
        };
        
        redisClient.get.mockResolvedValue(JSON.stringify(reservation));

        const result = await scheduleService.getSlotReservation('slot-123');

        expect(result).toBeDefined();
        expect(result?.slotId).toBe('slot-123');
        expect(result?.clientId).toBe('client-123');
      });

      it('should return null when reservation expired', async () => {
        const { redisClient } = require('../../config/redis');
        redisClient.isReady = true;
        
        const expiredReservation = {
          slotId: 'slot-123',
          clientId: 'client-123',
          reservedAt: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
          expiresAt: new Date(Date.now() - 15 * 60 * 1000) // 15 minutes ago (expired)
        };
        
        redisClient.get.mockResolvedValue(JSON.stringify(expiredReservation));
        redisClient.del.mockResolvedValue(1);

        const result = await scheduleService.getSlotReservation('slot-123');

        expect(result).toBeNull();
        expect(redisClient.del).toHaveBeenCalled(); // Should clean up expired reservation
      });

      it('should return null when no reservation exists', async () => {
        const { redisClient } = require('../../config/redis');
        redisClient.isReady = true;
        redisClient.get.mockResolvedValue(null);

        const result = await scheduleService.getSlotReservation('slot-123');

        expect(result).toBeNull();
      });
    });
  });

  describe('Performance and Cache', () => {
    describe('invalidateAvailableSlotsCache', () => {
      it('should invalidate cache for professional', async () => {
        const { redisClient } = require('../../config/redis');
        redisClient.isReady = true;
        redisClient.keys.mockResolvedValue(['slots:available:prof-123:2024-12-23']);
        redisClient.del.mockResolvedValue(1);

        await scheduleService.invalidateAvailableSlotsCache('prof-123');

        expect(redisClient.keys).toHaveBeenCalledWith('slots:available:prof-123:*');
        expect(redisClient.del).toHaveBeenCalledWith(['slots:available:prof-123:2024-12-23']);
      });

      it('should handle Redis errors gracefully', async () => {
        const { redisClient } = require('../../config/redis');
        redisClient.isReady = true;
        redisClient.keys.mockRejectedValue(new Error('Redis error'));

        // Should not throw error
        await expect(scheduleService.invalidateAvailableSlotsCache('prof-123'))
          .resolves.not.toThrow();
      });
    });
  });
});