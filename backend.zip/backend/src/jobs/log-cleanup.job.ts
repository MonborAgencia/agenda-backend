import cron from 'node-cron';
import LogCleanup from '../scripts/cleanup-logs';
import LoggerUtils from '../utils/logger.utils';
import AlertingService from '../services/alerting.service';

/**
 * Job para limpeza automática de logs
 */
export class LogCleanupJob {
  private cleanup: LogCleanup;
  private alertingService: AlertingService;
  private isRunning: boolean = false;

  constructor() {
    this.cleanup = new LogCleanup();
    this.alertingService = AlertingService.getInstance();
  }

  /**
   * Iniciar job de limpeza de logs
   * Executa diariamente às 2:00 AM
   */
  start(): void {
    // Executar diariamente às 2:00 AM
    cron.schedule('0 2 * * *', async () => {
      await this.runCleanup();
    }, {
      scheduled: true,
      timezone: 'America/Sao_Paulo'
    });

    // Executar limpeza de alertas antigos semanalmente (domingo às 3:00 AM)
    cron.schedule('0 3 * * 0', async () => {
      await this.cleanupOldAlerts();
    }, {
      scheduled: true,
      timezone: 'America/Sao_Paulo'
    });

    LoggerUtils.info('Log cleanup job scheduled', {
      category: 'CRON_JOB',
      job: 'LOG_CLEANUP',
      schedule: 'Daily at 2:00 AM'
    });
  }

  /**
   * Executar limpeza de logs
   */
  private async runCleanup(): Promise<void> {
    if (this.isRunning) {
      LoggerUtils.warn('Log cleanup job already running, skipping', {
        category: 'CRON_JOB',
        job: 'LOG_CLEANUP'
      });
      return;
    }

    this.isRunning = true;

    try {
      LoggerUtils.info('Starting scheduled log cleanup', {
        category: 'CRON_JOB',
        job: 'LOG_CLEANUP'
      });

      const statsBefore = this.cleanup.getLogStats();
      await this.cleanup.cleanup();
      const statsAfter = this.cleanup.getLogStats();

      const deletedFiles = statsBefore.totalFiles - statsAfter.totalFiles;
      const freedSpace = statsBefore.totalSize - statsAfter.totalSize;

      LoggerUtils.info('Scheduled log cleanup completed', {
        category: 'CRON_JOB',
        job: 'LOG_CLEANUP',
        deletedFiles,
        freedSpace,
        remainingFiles: statsAfter.totalFiles,
        remainingSize: statsAfter.totalSize
      });

      // Verificar se há muitos arquivos de log (possível problema)
      if (statsAfter.totalFiles > 1000) {
        LoggerUtils.warn('High number of log files detected', {
          category: 'CRON_JOB',
          job: 'LOG_CLEANUP',
          fileCount: statsAfter.totalFiles,
          threshold: 1000
        });
      }

      // Verificar se os logs estão ocupando muito espaço
      const sizeMB = statsAfter.totalSize / (1024 * 1024);
      if (sizeMB > 1000) { // 1GB
        LoggerUtils.warn('Log files using excessive disk space', {
          category: 'CRON_JOB',
          job: 'LOG_CLEANUP',
          sizeMB: Math.round(sizeMB),
          threshold: 1000
        });
      }

    } catch (error) {
      LoggerUtils.error('Scheduled log cleanup failed', error as Error, {
        category: 'CRON_JOB',
        job: 'LOG_CLEANUP'
      });
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * Limpar alertas antigos
   */
  private async cleanupOldAlerts(): Promise<void> {
    try {
      LoggerUtils.info('Starting scheduled alert cleanup', {
        category: 'CRON_JOB',
        job: 'ALERT_CLEANUP'
      });

      // Limpar alertas com mais de 7 dias
      this.alertingService.cleanupOldAlerts(7 * 24 * 60 * 60 * 1000);

      LoggerUtils.info('Scheduled alert cleanup completed', {
        category: 'CRON_JOB',
        job: 'ALERT_CLEANUP'
      });

    } catch (error) {
      LoggerUtils.error('Scheduled alert cleanup failed', error as Error, {
        category: 'CRON_JOB',
        job: 'ALERT_CLEANUP'
      });
    }
  }

  /**
   * Executar limpeza manual
   */
  async runManualCleanup(): Promise<void> {
    LoggerUtils.info('Manual log cleanup requested', {
      category: 'MANUAL_CLEANUP'
    });

    await this.runCleanup();
  }

  /**
   * Obter estatísticas dos logs
   */
  getLogStats() {
    return this.cleanup.getLogStats();
  }
}

export default LogCleanupJob;