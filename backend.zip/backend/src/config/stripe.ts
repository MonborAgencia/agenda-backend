import Stripe from 'stripe';
import { config } from 'dotenv';

config();

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('STRIPE_SECRET_KEY é obrigatório nas variáveis de ambiente');
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16',
  typescript: true,
});

export const stripeConfig = {
  secretKey: process.env.STRIPE_SECRET_KEY,
  publishableKey: process.env.STRIPE_PUBLISHABLE_KEY,
  webhookSecret: process.env.STRIPE_WEBHOOK_SECRET,
  currency: process.env.STRIPE_CURRENCY || 'brl',
  paymentMethodTypes: ['card', 'pix'] as const,
};

// Configurações específicas para o Brasil
export const brazilConfig = {
  currency: 'brl',
  paymentMethodTypes: ['card', 'pix', 'boleto'] as const,
  locale: 'pt-BR',
  country: 'BR',
};