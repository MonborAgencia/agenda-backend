import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import { Express } from 'express';
import path from 'path';
import fs from 'fs';
import yaml from 'js-yaml';

const swaggerOptions = {
  definition: {
    openapi: '3.0.3',
    info: {
      title: 'Agenda Lotada 24h API',
      version: '1.0.0',
      description: `
        API completa para o sistema de agendamento inteligente Agenda Lotada 24h.
        
        Esta API oferece funcionalidades para:
        - Autenticação e autorização
        - Gestão de usuários (Admin, Profissional, Cliente)
        - Agendamento e gestão de horários
        - Notificações automáticas
        - Integração com IA para chatbot e analytics
        - Sistema de avaliações
        - Campanhas automáticas
        - Relatórios e métricas
        
        ## Autenticação
        A API utiliza JWT (JSON Web Tokens) para autenticação. Inclua o token no header:
        \`\`\`
        Authorization: Bearer <seu-jwt-token>
        \`\`\`
        
        ## Códigos de Status
        - 200: Sucesso
        - 201: Criado com sucesso
        - 400: Erro de validação
        - 401: Não autorizado
        - 403: Acesso negado
        - 404: Não encontrado
        - 409: Conflito
        - 429: Muitas requisições
        - 500: Erro interno do servidor
      `,
      contact: {
        name: 'Equipe Agenda Lotada 24h',
        email: 'suporte@agendalotada24h.com'
      },
      license: {
        name: 'MIT',
        url: 'https://opensource.org/licenses/MIT'
      }
    },
    servers: [
      {
        url: process.env.API_URL || 'http://localhost:3001/api',
        description: process.env.NODE_ENV === 'production' ? 'Servidor de produção' : 'Servidor de desenvolvimento'
      }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT'
        }
      },
      schemas: {
        Error: {
          type: 'object',
          properties: {
            code: {
              type: 'string',
              example: 'VALIDATION_ERROR'
            },
            message: {
              type: 'string',
              example: 'Dados inválidos fornecidos'
            },
            details: {
              type: 'object'
            },
            timestamp: {
              type: 'string',
              format: 'date-time'
            },
            requestId: {
              type: 'string'
            }
          }
        },
        User: {
          type: 'object',
          properties: {
            id: {
              type: 'string',
              format: 'uuid'
            },
            email: {
              type: 'string',
              format: 'email'
            },
            name: {
              type: 'string'
            },
            phone: {
              type: 'string'
            },
            role: {
              type: 'string',
              enum: ['ADMIN', 'PROFESSIONAL', 'CLIENT']
            },
            tenantId: {
              type: 'string',
              format: 'uuid'
            },
            profile: {
              $ref: '#/components/schemas/UserProfile'
            },
            createdAt: {
              type: 'string',
              format: 'date-time'
            },
            updatedAt: {
              type: 'string',
              format: 'date-time'
            }
          }
        },
        UserProfile: {
          type: 'object',
          properties: {
            avatar: {
              type: 'string',
              format: 'uri'
            },
            bio: {
              type: 'string'
            },
            specialties: {
              type: 'array',
              items: {
                type: 'string'
              }
            },
            workingHours: {
              $ref: '#/components/schemas/WorkingHours'
            },
            preferences: {
              type: 'object'
            }
          }
        },
        WorkingHours: {
          type: 'object',
          properties: {
            monday: { $ref: '#/components/schemas/DaySchedule' },
            tuesday: { $ref: '#/components/schemas/DaySchedule' },
            wednesday: { $ref: '#/components/schemas/DaySchedule' },
            thursday: { $ref: '#/components/schemas/DaySchedule' },
            friday: { $ref: '#/components/schemas/DaySchedule' },
            saturday: { $ref: '#/components/schemas/DaySchedule' },
            sunday: { $ref: '#/components/schemas/DaySchedule' }
          }
        },
        DaySchedule: {
          type: 'object',
          properties: {
            isActive: {
              type: 'boolean'
            },
            startTime: {
              type: 'string',
              pattern: '^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$',
              example: '09:00'
            },
            endTime: {
              type: 'string',
              pattern: '^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$',
              example: '18:00'
            },
            breakStart: {
              type: 'string',
              pattern: '^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$',
              example: '12:00'
            },
            breakEnd: {
              type: 'string',
              pattern: '^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$',
              example: '13:00'
            }
          }
        },
        Service: {
          type: 'object',
          properties: {
            id: {
              type: 'string',
              format: 'uuid'
            },
            name: {
              type: 'string'
            },
            description: {
              type: 'string'
            },
            duration: {
              type: 'integer',
              description: 'Duração em minutos'
            },
            price: {
              type: 'number',
              format: 'decimal'
            },
            category: {
              type: 'string'
            },
            isActive: {
              type: 'boolean'
            },
            professionalIds: {
              type: 'array',
              items: {
                type: 'string',
                format: 'uuid'
              }
            },
            tenantId: {
              type: 'string',
              format: 'uuid'
            },
            createdAt: {
              type: 'string',
              format: 'date-time'
            },
            updatedAt: {
              type: 'string',
              format: 'date-time'
            }
          }
        },
        Booking: {
          type: 'object',
          properties: {
            id: {
              type: 'string',
              format: 'uuid'
            },
            clientId: {
              type: 'string',
              format: 'uuid'
            },
            professionalId: {
              type: 'string',
              format: 'uuid'
            },
            serviceId: {
              type: 'string',
              format: 'uuid'
            },
            startTime: {
              type: 'string',
              format: 'date-time'
            },
            endTime: {
              type: 'string',
              format: 'date-time'
            },
            status: {
              type: 'string',
              enum: ['SCHEDULED', 'CONFIRMED', 'COMPLETED', 'CANCELLED', 'NO_SHOW']
            },
            notes: {
              type: 'string'
            },
            price: {
              type: 'number',
              format: 'decimal'
            },
            paymentStatus: {
              type: 'string',
              enum: ['PENDING', 'PAID', 'REFUNDED']
            },
            createdAt: {
              type: 'string',
              format: 'date-time'
            },
            updatedAt: {
              type: 'string',
              format: 'date-time'
            },
            client: {
              $ref: '#/components/schemas/User'
            },
            professional: {
              $ref: '#/components/schemas/User'
            },
            service: {
              $ref: '#/components/schemas/Service'
            }
          }
        },
        Notification: {
          type: 'object',
          properties: {
            id: {
              type: 'string',
              format: 'uuid'
            },
            userId: {
              type: 'string',
              format: 'uuid'
            },
            type: {
              type: 'string',
              enum: ['REMINDER', 'CONFIRMATION', 'CANCELLATION', 'PROMOTIONAL']
            },
            channel: {
              type: 'string',
              enum: ['EMAIL', 'WHATSAPP', 'PUSH', 'SMS']
            },
            title: {
              type: 'string'
            },
            message: {
              type: 'string'
            },
            status: {
              type: 'string',
              enum: ['PENDING', 'SENT', 'DELIVERED', 'FAILED']
            },
            scheduledFor: {
              type: 'string',
              format: 'date-time'
            },
            sentAt: {
              type: 'string',
              format: 'date-time'
            },
            createdAt: {
              type: 'string',
              format: 'date-time'
            }
          }
        },
        Review: {
          type: 'object',
          properties: {
            id: {
              type: 'string',
              format: 'uuid'
            },
            bookingId: {
              type: 'string',
              format: 'uuid'
            },
            clientId: {
              type: 'string',
              format: 'uuid'
            },
            professionalId: {
              type: 'string',
              format: 'uuid'
            },
            rating: {
              type: 'integer',
              minimum: 1,
              maximum: 5
            },
            comment: {
              type: 'string'
            },
            response: {
              type: 'string'
            },
            createdAt: {
              type: 'string',
              format: 'date-time'
            },
            updatedAt: {
              type: 'string',
              format: 'date-time'
            }
          }
        }
      }
    },
    security: [
      {
        bearerAuth: []
      }
    ],
    tags: [
      {
        name: 'Autenticação',
        description: 'Endpoints para login, registro e gestão de tokens'
      },
      {
        name: 'Usuários',
        description: 'Gestão de usuários (Admin, Profissional, Cliente)'
      },
      {
        name: 'Serviços',
        description: 'Gestão de serviços oferecidos'
      },
      {
        name: 'Agendamentos',
        description: 'Criação e gestão de agendamentos'
      },
      {
        name: 'Horários',
        description: 'Consulta de disponibilidade e horários'
      },
      {
        name: 'Notificações',
        description: 'Sistema de notificações automáticas'
      },
      {
        name: 'IA e Chatbot',
        description: 'Integração com IA para chatbot e recomendações'
      },
      {
        name: 'Analytics',
        description: 'Métricas e dados de performance'
      },
      {
        name: 'Relatórios',
        description: 'Geração de relatórios em PDF e Excel'
      },
      {
        name: 'Avaliações',
        description: 'Sistema de avaliações e feedback'
      }
    ]
  },
  apis: [
    path.join(__dirname, '../routes/*.ts'),
    path.join(__dirname, '../controllers/*.ts')
  ]
};

// Função para carregar especificação YAML externa se existir
const loadExternalSpec = (): any => {
  try {
    const yamlPath = path.join(__dirname, '../../../../docs/api/swagger.yaml');
    if (fs.existsSync(yamlPath)) {
      const yamlContent = fs.readFileSync(yamlPath, 'utf8');
      return yaml.load(yamlContent);
    }
  } catch (error) {
    console.warn('Não foi possível carregar especificação YAML externa:', error);
  }
  return null;
};

// Configurar Swagger
export const setupSwagger = (app: Express): void => {
  // Tentar carregar especificação externa primeiro
  const externalSpec = loadExternalSpec();
  
  let specs;
  if (externalSpec) {
    // Usar especificação YAML externa
    specs = externalSpec;
    console.log('✅ Usando especificação Swagger externa (YAML)');
  } else {
    // Usar especificação inline
    specs = swaggerJsdoc(swaggerOptions);
    console.log('✅ Usando especificação Swagger inline');
  }

  // Configurar Swagger UI
  const swaggerUiOptions = {
    explorer: true,
    swaggerOptions: {
      persistAuthorization: true,
      displayRequestDuration: true,
      filter: true,
      showExtensions: true,
      showCommonExtensions: true,
      docExpansion: 'none',
      defaultModelsExpandDepth: 2,
      defaultModelExpandDepth: 2
    },
    customCss: `
      .swagger-ui .topbar { display: none }
      .swagger-ui .info { margin: 20px 0 }
      .swagger-ui .info .title { color: #3b82f6 }
      .swagger-ui .scheme-container { background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0 }
    `,
    customSiteTitle: 'Agenda Lotada 24h - API Documentation',
    customfavIcon: '/favicon.ico'
  };

  // Servir documentação Swagger
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs, swaggerUiOptions));

  // Endpoint para especificação JSON
  app.get('/api-docs.json', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.send(specs);
  });

  // Endpoint para especificação YAML
  app.get('/api-docs.yaml', (req, res) => {
    res.setHeader('Content-Type', 'text/yaml');
    res.send(yaml.dump(specs));
  });

  console.log('📚 Swagger UI disponível em: /api-docs');
  console.log('📄 Especificação JSON: /api-docs.json');
  console.log('📄 Especificação YAML: /api-docs.yaml');
};

// Middleware para adicionar informações de request ID nos logs
export const addRequestId = (req: any, res: any, next: any) => {
  req.requestId = Math.random().toString(36).substring(2, 15);
  res.setHeader('X-Request-ID', req.requestId);
  next();
};

// Função para gerar documentação automaticamente dos controllers
export const generateApiDocs = () => {
  // Esta função pode ser expandida para gerar documentação automaticamente
  // baseada nos decorators dos controllers ou comentários JSDoc
  console.log('🔄 Gerando documentação da API...');
  
  // Implementação futura: scan dos controllers e geração automática
  // de documentação baseada em decorators ou comentários
};

export default { setupSwagger, addRequestId, generateApiDocs };