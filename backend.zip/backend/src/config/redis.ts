import Redis from 'ioredis';

const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379';

let redisClient: Redis | null = null;

// Initialize Redis connection
export const initRedis = async (): Promise<boolean> => {
  try {
    redisClient = new Redis(redisUrl, {
      retryDelayOnFailover: 100,
      enableReadyCheck: false,
      maxRetriesPerRequest: 1,
      lazyConnect: true,
      connectTimeout: 5000,
      commandTimeout: 5000
    });

    redisClient.on('error', (err: Error) => {
      console.warn('Redis Client Error (continuing without Redis):', err.message);
      redisClient = null;
    });

    redisClient.on('connect', () => {
      console.log('✅ Redis Client Connected');
    });

    redisClient.on('ready', () => {
      console.log('✅ Redis Client Ready');
    });

    // Test connection
    await redisClient.ping();
    console.log('✅ Redis connected successfully');
    return true;
  } catch (error) {
    console.warn('⚠️  Redis not available, continuing without cache:', (error as Error).message);
    redisClient = null;
    return false;
  }
};

// Export redisClient with null check
export { redisClient };

// Cache keys
export const CACHE_KEYS = {
  // Schedule and availability
  AVAILABLE_SLOTS: (professionalId: string, date: string) => 
    `slots:available:${professionalId}:${date}`,
  SLOT_RESERVATION: (slotId: string) => 
    `slots:reserved:${slotId}`,
  PROFESSIONAL_SCHEDULE: (professionalId: string) => 
    `schedule:${professionalId}`,
  DAY_AVAILABILITY: (professionalId: string, date: string, duration: number) => 
    `availability:${professionalId}:${date}:${duration}`,
  
  // User and profile
  USER_PROFILE: (userId: string) => `user:${userId}:profile`,
  USER_PERMISSIONS: (userId: string) => `user:${userId}:permissions`,
  PROFESSIONAL_SERVICES: (professionalId: string) => `professional:${professionalId}:services`,
  
  // Booking and metrics
  BOOKING_LIST: (userId: string, page: number, filters: string) => 
    `booking:${userId}:list:${page}:${filters}`,
  BOOKING_METRICS: (tenantId: string, period: string) => 
    `metrics:${tenantId}:${period}`,
  DASHBOARD_DATA: (tenantId: string, userId: string) => 
    `dashboard:${tenantId}:${userId}`,
  
  // Analytics and reports
  ANALYTICS_DATA: (tenantId: string, type: string, period: string) => 
    `analytics:${tenantId}:${type}:${period}`,
  REPORT_DATA: (tenantId: string, reportType: string, params: string) => 
    `report:${tenantId}:${reportType}:${params}`,
  
  // Services and configuration
  SERVICE_LIST: (tenantId: string) => `service:${tenantId}:list`,
  TENANT_CONFIG: (tenantId: string) => `tenant:${tenantId}:config`,
  
  // Notifications
  NOTIFICATION_TEMPLATES: (tenantId: string) => `template:${tenantId}:list`,
  NOTIFICATION_QUEUE: (tenantId: string) => `notification:${tenantId}:queue`,
  
  // AI and recommendations
  AI_RECOMMENDATIONS: (userId: string, type: string) => `ai:${userId}:recommendations:${type}`,
  CHAT_CONTEXT: (sessionId: string) => `chat:${sessionId}:context`
};

// Cache TTL (Time To Live) in seconds
export const CACHE_TTL = {
  // Short-term cache (5 minutes)
  AVAILABLE_SLOTS: 300,
  DAY_AVAILABILITY: 300,
  DASHBOARD_DATA: 300,
  
  // Medium-term cache (15 minutes)
  SLOT_RESERVATION: 900,
  BOOKING_LIST: 900,
  SERVICE_LIST: 900,
  
  // Long-term cache (1 hour)
  PROFESSIONAL_SCHEDULE: 3600,
  USER_PROFILE: 3600,
  USER_PERMISSIONS: 3600,
  PROFESSIONAL_SERVICES: 3600,
  TENANT_CONFIG: 3600,
  NOTIFICATION_TEMPLATES: 3600,
  
  // Analytics cache (4 hours)
  BOOKING_METRICS: 14400,
  ANALYTICS_DATA: 14400,
  REPORT_DATA: 14400,
  
  // AI cache (30 minutes)
  AI_RECOMMENDATIONS: 1800,
  CHAT_CONTEXT: 1800
};