import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed do banco de dados...');

  // Criar permissões básicas
  const permissions = [
    // User permissions
    { name: 'user:create', resource: 'user', action: 'create', description: 'Criar usuários' },
    { name: 'user:read', resource: 'user', action: 'read', description: 'Visualizar usuários' },
    { name: 'user:update', resource: 'user', action: 'update', description: 'Atualizar usuários' },
    { name: 'user:delete', resource: 'user', action: 'delete', description: 'Deletar usuários' },
    { name: 'user:manage', resource: 'user', action: 'manage', description: 'Gerenciar todos os usuários' },

    // Booking permissions
    { name: 'booking:create', resource: 'booking', action: 'create', description: 'Criar agendamentos' },
    { name: 'booking:read', resource: 'booking', action: 'read', description: 'Visualizar agendamentos' },
    { name: 'booking:update', resource: 'booking', action: 'update', description: 'Atualizar agendamentos' },
    { name: 'booking:delete', resource: 'booking', action: 'delete', description: 'Cancelar agendamentos' },
    { name: 'booking:manage', resource: 'booking', action: 'manage', description: 'Gerenciar todos os agendamentos' },

    // Schedule permissions
    { name: 'schedule:create', resource: 'schedule', action: 'create', description: 'Criar horários' },
    { name: 'schedule:read', resource: 'schedule', action: 'read', description: 'Visualizar horários' },
    { name: 'schedule:update', resource: 'schedule', action: 'update', description: 'Atualizar horários' },
    { name: 'schedule:delete', resource: 'schedule', action: 'delete', description: 'Deletar horários' },
    { name: 'schedule:manage', resource: 'schedule', action: 'manage', description: 'Gerenciar todos os horários' },

    // Service permissions
    { name: 'service:create', resource: 'service', action: 'create', description: 'Criar serviços' },
    { name: 'service:read', resource: 'service', action: 'read', description: 'Visualizar serviços' },
    { name: 'service:update', resource: 'service', action: 'update', description: 'Atualizar serviços' },
    { name: 'service:delete', resource: 'service', action: 'delete', description: 'Deletar serviços' },
    { name: 'service:manage', resource: 'service', action: 'manage', description: 'Gerenciar todos os serviços' },

    // Tenant permissions
    { name: 'tenant:create', resource: 'tenant', action: 'create', description: 'Criar tenants' },
    { name: 'tenant:read', resource: 'tenant', action: 'read', description: 'Visualizar tenants' },
    { name: 'tenant:update', resource: 'tenant', action: 'update', description: 'Atualizar tenants' },
    { name: 'tenant:delete', resource: 'tenant', action: 'delete', description: 'Deletar tenants' },
    { name: 'tenant:manage', resource: 'tenant', action: 'manage', description: 'Gerenciar todos os tenants' },

    // Analytics permissions
    { name: 'analytics:read', resource: 'analytics', action: 'read', description: 'Visualizar relatórios e métricas' },
    { name: 'analytics:manage', resource: 'analytics', action: 'manage', description: 'Gerenciar analytics' },
  ];

  console.log('📝 Criando permissões...');
  for (const permission of permissions) {
    await prisma.permission.upsert({
      where: { name: permission.name },
      update: {},
      create: permission,
    });
  }

  // Criar papéis básicos
  const adminRole = await prisma.role.upsert({
    where: { name: 'ADMIN' },
    update: {},
    create: {
      name: 'ADMIN',
      description: 'Administrador do sistema com acesso completo',
    },
  });

  const professionalRole = await prisma.role.upsert({
    where: { name: 'PROFESSIONAL' },
    update: {},
    create: {
      name: 'PROFESSIONAL',
      description: 'Profissional que oferece serviços',
    },
  });

  const clientRole = await prisma.role.upsert({
    where: { name: 'CLIENT' },
    update: {},
    create: {
      name: 'CLIENT',
      description: 'Cliente que agenda serviços',
    },
  });

  console.log('🔐 Associando permissões aos papéis...');

  // Permissões do ADMIN (todas)
  const allPermissions = await prisma.permission.findMany();
  for (const permission of allPermissions) {
    await prisma.rolePermission.upsert({
      where: {
        roleId_permissionId: {
          roleId: adminRole.id,
          permissionId: permission.id,
        },
      },
      update: {},
      create: {
        roleId: adminRole.id,
        permissionId: permission.id,
      },
    });
  }

  // Permissões do PROFESSIONAL
  const professionalPermissions = await prisma.permission.findMany({
    where: {
      OR: [
        { resource: 'booking', action: { in: ['create', 'read', 'update'] } },
        { resource: 'schedule', action: { in: ['create', 'read', 'update', 'delete'] } },
        { resource: 'service', action: { in: ['read', 'update'] } },
        { resource: 'user', action: 'read' },
        { resource: 'analytics', action: 'read' },
      ],
    },
  });

  for (const permission of professionalPermissions) {
    await prisma.rolePermission.upsert({
      where: {
        roleId_permissionId: {
          roleId: professionalRole.id,
          permissionId: permission.id,
        },
      },
      update: {},
      create: {
        roleId: professionalRole.id,
        permissionId: permission.id,
      },
    });
  }

  // Permissões do CLIENT
  const clientPermissions = await prisma.permission.findMany({
    where: {
      OR: [
        { resource: 'booking', action: { in: ['create', 'read', 'update'] } },
        { resource: 'service', action: 'read' },
        { resource: 'schedule', action: 'read' },
      ],
    },
  });

  for (const permission of clientPermissions) {
    await prisma.rolePermission.upsert({
      where: {
        roleId_permissionId: {
          roleId: clientRole.id,
          permissionId: permission.id,
        },
      },
      update: {},
      create: {
        roleId: clientRole.id,
        permissionId: permission.id,
      },
    });
  }

  // Criar usuário admin padrão
  const hashedPassword = await bcrypt.hash('admin123', 12);
  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@agenda-lotada.com' },
    update: {},
    create: {
      email: 'admin@agenda-lotada.com',
      name: 'Administrador',
      password: hashedPassword,
      emailVerified: true,
      isActive: true,
    },
  });

  // Associar papel de admin ao usuário
  await prisma.userRole.upsert({
    where: {
      userId_roleId: {
        userId: adminUser.id,
        roleId: adminRole.id,
      },
    },
    update: {},
    create: {
      userId: adminUser.id,
      roleId: adminRole.id,
    },
  });

  console.log('✅ Seed concluído com sucesso!');
  console.log(`👤 Usuário admin criado: admin@agenda-lotada.com / admin123`);
}

main()
  .catch((e) => {
    console.error('❌ Erro durante o seed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });