export interface LocalizedContent {
  [language: string]: {
    [key: string]: string;
  };
}

export class I18nUtils {
  private static readonly DEFAULT_LANGUAGE = 'pt-BR';
  
  private static readonly SUPPORTED_LANGUAGES = [
    'pt-BR',
    'en-US',
    'es-ES'
  ];

  private static readonly TRANSLATIONS: LocalizedContent = {
    'pt-BR': {
      // Mensagens de sistema
      'system.booking.confirmed': 'Agendamento confirmado',
      'system.booking.cancelled': 'Agendamento cancelado',
      'system.booking.rescheduled': 'Agendamento reagendado',
      'system.booking.reminder': 'Lembrete de agendamento',
      
      // Saudações
      'greeting.hello': 'Olá',
      'greeting.good_morning': 'Bom dia',
      'greeting.good_afternoon': 'Boa tarde',
      'greeting.good_evening': 'Boa noite',
      
      // Dias da semana
      'day.sunday': 'Domingo',
      'day.monday': 'Segunda-feira',
      'day.tuesday': 'Terça-feira',
      'day.wednesday': 'Quarta-feira',
      'day.thursday': 'Quinta-feira',
      'day.friday': 'Sexta-feira',
      'day.saturday': 'Sábado',
      
      // Meses
      'month.january': 'Janeiro',
      'month.february': 'Fevereiro',
      'month.march': 'Março',
      'month.april': 'Abril',
      'month.may': 'Maio',
      'month.june': 'Junho',
      'month.july': 'Julho',
      'month.august': 'Agosto',
      'month.september': 'Setembro',
      'month.october': 'Outubro',
      'month.november': 'Novembro',
      'month.december': 'Dezembro',
      
      // Frases comuns
      'common.thank_you': 'Obrigado',
      'common.see_you_soon': 'Nos vemos em breve',
      'common.contact_us': 'Entre em contato conosco',
      'common.questions': 'Em caso de dúvidas',
      'common.location': 'Local',
      'common.date': 'Data',
      'common.time': 'Horário',
      'common.service': 'Serviço',
      'common.professional': 'Profissional',
      'common.price': 'Valor',
      'common.total': 'Total',
      'common.duration': 'Duração',
      'common.status': 'Status',
      'common.reason': 'Motivo'
    },
    
    'en-US': {
      // System messages
      'system.booking.confirmed': 'Booking confirmed',
      'system.booking.cancelled': 'Booking cancelled',
      'system.booking.rescheduled': 'Booking rescheduled',
      'system.booking.reminder': 'Booking reminder',
      
      // Greetings
      'greeting.hello': 'Hello',
      'greeting.good_morning': 'Good morning',
      'greeting.good_afternoon': 'Good afternoon',
      'greeting.good_evening': 'Good evening',
      
      // Days of the week
      'day.sunday': 'Sunday',
      'day.monday': 'Monday',
      'day.tuesday': 'Tuesday',
      'day.wednesday': 'Wednesday',
      'day.thursday': 'Thursday',
      'day.friday': 'Friday',
      'day.saturday': 'Saturday',
      
      // Months
      'month.january': 'January',
      'month.february': 'February',
      'month.march': 'March',
      'month.april': 'April',
      'month.may': 'May',
      'month.june': 'June',
      'month.july': 'July',
      'month.august': 'August',
      'month.september': 'September',
      'month.october': 'October',
      'month.november': 'November',
      'month.december': 'December',
      
      // Common phrases
      'common.thank_you': 'Thank you',
      'common.see_you_soon': 'See you soon',
      'common.contact_us': 'Contact us',
      'common.questions': 'If you have any questions',
      'common.location': 'Location',
      'common.date': 'Date',
      'common.time': 'Time',
      'common.service': 'Service',
      'common.professional': 'Professional',
      'common.price': 'Price',
      'common.total': 'Total',
      'common.duration': 'Duration',
      'common.status': 'Status',
      'common.reason': 'Reason'
    },
    
    'es-ES': {
      // Mensajes del sistema
      'system.booking.confirmed': 'Cita confirmada',
      'system.booking.cancelled': 'Cita cancelada',
      'system.booking.rescheduled': 'Cita reprogramada',
      'system.booking.reminder': 'Recordatorio de cita',
      
      // Saludos
      'greeting.hello': 'Hola',
      'greeting.good_morning': 'Buenos días',
      'greeting.good_afternoon': 'Buenas tardes',
      'greeting.good_evening': 'Buenas noches',
      
      // Días de la semana
      'day.sunday': 'Domingo',
      'day.monday': 'Lunes',
      'day.tuesday': 'Martes',
      'day.wednesday': 'Miércoles',
      'day.thursday': 'Jueves',
      'day.friday': 'Viernes',
      'day.saturday': 'Sábado',
      
      // Meses
      'month.january': 'Enero',
      'month.february': 'Febrero',
      'month.march': 'Marzo',
      'month.april': 'Abril',
      'month.may': 'Mayo',
      'month.june': 'Junio',
      'month.july': 'Julio',
      'month.august': 'Agosto',
      'month.september': 'Septiembre',
      'month.october': 'Octubre',
      'month.november': 'Noviembre',
      'month.december': 'Diciembre',
      
      // Frases comunes
      'common.thank_you': 'Gracias',
      'common.see_you_soon': 'Nos vemos pronto',
      'common.contact_us': 'Contáctanos',
      'common.questions': 'Si tienes dudas',
      'common.location': 'Ubicación',
      'common.date': 'Fecha',
      'common.time': 'Hora',
      'common.service': 'Servicio',
      'common.professional': 'Profesional',
      'common.price': 'Precio',
      'common.total': 'Total',
      'common.duration': 'Duración',
      'common.status': 'Estado',
      'common.reason': 'Motivo'
    }
  };

  // Obter texto traduzido
  static translate(key: string, language: string = this.DEFAULT_LANGUAGE): string {
    const lang = this.getSupportedLanguage(language);
    const translation = this.TRANSLATIONS[lang]?.[key];
    
    // Se não encontrar na linguagem solicitada, tenta no idioma padrão
    if (!translation && lang !== this.DEFAULT_LANGUAGE) {
      return this.TRANSLATIONS[this.DEFAULT_LANGUAGE]?.[key] || key;
    }
    
    return translation || key;
  }

  // Obter múltiplas traduções
  static translateMultiple(
    keys: string[], 
    language: string = this.DEFAULT_LANGUAGE
  ): Record<string, string> {
    const translations: Record<string, string> = {};
    
    keys.forEach(key => {
      translations[key] = this.translate(key, language);
    });
    
    return translations;
  }

  // Verificar se idioma é suportado
  static isSupportedLanguage(language: string): boolean {
    return this.SUPPORTED_LANGUAGES.includes(language);
  }

  // Obter idioma suportado mais próximo
  static getSupportedLanguage(language: string): string {
    if (this.isSupportedLanguage(language)) {
      return language;
    }
    
    // Tentar encontrar por código de idioma (ex: 'pt' para 'pt-BR')
    const languageCode = language.split('-')[0];
    const matchingLanguage = this.SUPPORTED_LANGUAGES.find(
      lang => lang.startsWith(languageCode)
    );
    
    return matchingLanguage || this.DEFAULT_LANGUAGE;
  }

  // Obter lista de idiomas suportados
  static getSupportedLanguages(): string[] {
    return [...this.SUPPORTED_LANGUAGES];
  }

  // Obter idioma padrão
  static getDefaultLanguage(): string {
    return this.DEFAULT_LANGUAGE;
  }

  // Formatar data por idioma
  static formatDate(date: Date, language: string = this.DEFAULT_LANGUAGE): string {
    const lang = this.getSupportedLanguage(language);
    
    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    };
    
    return date.toLocaleDateString(lang, options);
  }

  // Formatar hora por idioma
  static formatTime(date: Date, language: string = this.DEFAULT_LANGUAGE): string {
    const lang = this.getSupportedLanguage(language);
    
    const options: Intl.DateTimeFormatOptions = {
      hour: '2-digit',
      minute: '2-digit'
    };
    
    return date.toLocaleTimeString(lang, options);
  }

  // Formatar data e hora por idioma
  static formatDateTime(date: Date, language: string = this.DEFAULT_LANGUAGE): string {
    const lang = this.getSupportedLanguage(language);
    
    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    };
    
    return date.toLocaleDateString(lang, options);
  }

  // Formatar moeda por idioma
  static formatCurrency(
    amount: number, 
    currency: string = 'BRL',
    language: string = this.DEFAULT_LANGUAGE
  ): string {
    const lang = this.getSupportedLanguage(language);
    
    return new Intl.NumberFormat(lang, {
      style: 'currency',
      currency: currency
    }).format(amount);
  }

  // Obter saudação baseada no horário
  static getGreeting(language: string = this.DEFAULT_LANGUAGE): string {
    const hour = new Date().getHours();
    
    if (hour < 12) {
      return this.translate('greeting.good_morning', language);
    } else if (hour < 18) {
      return this.translate('greeting.good_afternoon', language);
    } else {
      return this.translate('greeting.good_evening', language);
    }
  }

  // Pluralizar texto (implementação básica)
  static pluralize(
    count: number,
    singular: string,
    plural: string,
    language: string = this.DEFAULT_LANGUAGE
  ): string {
    const lang = this.getSupportedLanguage(language);
    
    // Regras básicas de pluralização por idioma
    switch (lang) {
      case 'pt-BR':
      case 'es-ES':
        return count === 1 ? singular : plural;
      case 'en-US':
        return count === 1 ? singular : plural;
      default:
        return count === 1 ? singular : plural;
    }
  }

  // Adicionar tradução dinamicamente
  static addTranslation(
    language: string,
    key: string,
    value: string
  ): void {
    if (!this.TRANSLATIONS[language]) {
      this.TRANSLATIONS[language] = {};
    }
    
    this.TRANSLATIONS[language][key] = value;
  }

  // Adicionar múltiplas traduções
  static addTranslations(
    language: string,
    translations: Record<string, string>
  ): void {
    if (!this.TRANSLATIONS[language]) {
      this.TRANSLATIONS[language] = {};
    }
    
    Object.assign(this.TRANSLATIONS[language], translations);
  }
}

export const i18n = I18nUtils;