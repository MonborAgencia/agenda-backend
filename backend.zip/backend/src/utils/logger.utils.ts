import logger from '../config/logger';

export interface LogContext {
  userId?: string;
  tenantId?: string;
  requestId?: string;
  sessionId?: string;
  correlationId?: string;
  service?: string;
  method?: string;
  [key: string]: any;
}

/**
 * Utilitários para logging estruturado
 */
export class LoggerUtils {
  /**
   * Log de informação com contexto
   */
  static info(message: string, context?: LogContext): void {
    logger.info(message, context);
  }

  /**
   * Log de erro com contexto
   */
  static error(message: string, error?: Error, context?: LogContext): void {
    logger.error(message, {
      ...context,
      error: error ? {
        name: error.name,
        message: error.message,
        stack: error.stack
      } : undefined
    });
  }

  /**
   * Log de warning com contexto
   */
  static warn(message: string, context?: LogContext): void {
    logger.warn(message, context);
  }

  /**
   * Log de debug com contexto
   */
  static debug(message: string, context?: LogContext): void {
    logger.debug(message, context);
  }

  /**
   * Log de operação de banco de dados
   */
  static database(operation: string, table: string, context?: LogContext & {
    query?: string;
    duration?: number;
    rowsAffected?: number;
  }): void {
    logger.info(`Database ${operation}`, {
      ...context,
      category: 'DATABASE',
      table,
      operation
    });
  }

  /**
   * Log de operação de cache
   */
  static cache(operation: 'HIT' | 'MISS' | 'SET' | 'DELETE' | 'CLEAR', key: string, context?: LogContext & {
    ttl?: number;
    size?: number;
  }): void {
    logger.info(`Cache ${operation}`, {
      ...context,
      category: 'CACHE',
      operation,
      key
    });
  }

  /**
   * Log de integração externa
   */
  static integration(service: string, operation: string, context?: LogContext & {
    endpoint?: string;
    duration?: number;
    statusCode?: number;
    success?: boolean;
  }): void {
    const level = context?.success === false ? 'error' : 'info';
    logger.log(level, `Integration ${service}`, {
      ...context,
      category: 'INTEGRATION',
      service,
      operation
    });
  }

  /**
   * Log de performance
   */
  static performance(operation: string, duration: number, context?: LogContext & {
    threshold?: number;
    slow?: boolean;
  }): void {
    const level = context?.slow ? 'warn' : 'info';
    logger.log(level, `Performance ${operation}`, {
      ...context,
      category: 'PERFORMANCE',
      operation,
      duration,
      unit: 'ms'
    });
  }

  /**
   * Log de segurança
   */
  static security(event: string, context?: LogContext & {
    severity?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    ipAddress?: string;
    userAgent?: string;
    blocked?: boolean;
  }): void {
    logger.warn(`Security Event: ${event}`, {
      ...context,
      category: 'SECURITY',
      event
    });
  }

  /**
   * Log de business logic
   */
  static business(event: string, context?: LogContext & {
    entity?: string;
    entityId?: string;
    action?: string;
    result?: 'SUCCESS' | 'FAILURE' | 'PARTIAL';
  }): void {
    logger.info(`Business Event: ${event}`, {
      ...context,
      category: 'BUSINESS',
      event
    });
  }

  /**
   * Log de métricas customizadas
   */
  static metric(name: string, value: number, context?: LogContext & {
    unit?: string;
    tags?: Record<string, string>;
  }): void {
    logger.info(`Metric: ${name}`, {
      ...context,
      category: 'METRIC',
      metricName: name,
      metricValue: value
    });
  }

  /**
   * Criar contexto de log a partir de request
   */
  static createRequestContext(req: any): LogContext {
    return {
      requestId: req.requestId,
      userId: req.user?.id,
      tenantId: req.user?.tenantId,
      method: req.method,
      url: req.originalUrl,
      userAgent: req.get('User-Agent'),
      ip: req.ip || req.connection.remoteAddress
    };
  }

  /**
   * Medir tempo de execução e logar
   */
  static async measureTime<T>(
    operation: string,
    fn: () => Promise<T>,
    context?: LogContext
  ): Promise<T> {
    const startTime = Date.now();
    
    try {
      const result = await fn();
      const duration = Date.now() - startTime;
      
      this.performance(operation, duration, {
        ...context,
        success: true
      });
      
      return result;
    } catch (error) {
      const duration = Date.now() - startTime;
      
      this.performance(operation, duration, {
        ...context,
        success: false
      });
      
      this.error(`Operation failed: ${operation}`, error as Error, context);
      throw error;
    }
  }

  /**
   * Log estruturado para início de operação
   */
  static operationStart(operation: string, context?: LogContext): void {
    this.info(`Starting operation: ${operation}`, {
      ...context,
      phase: 'START',
      operation
    });
  }

  /**
   * Log estruturado para fim de operação
   */
  static operationEnd(operation: string, success: boolean, context?: LogContext): void {
    const level = success ? 'info' : 'error';
    logger.log(level, `Completed operation: ${operation}`, {
      ...context,
      phase: 'END',
      operation,
      success
    });
  }
}

export default LoggerUtils;