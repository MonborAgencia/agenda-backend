export interface Campaign {
  id: string;
  name: string;
  description?: string;
  type: CampaignType;
  status: CampaignStatus;
  tenantId: string;
  templateId?: string;
  targetAudience?: TargetAudience;
  startDate?: Date;
  endDate?: Date;
  frequency?: CampaignFrequency;
  totalSent: number;
  totalOpened: number;
  totalClicked: number;
  totalConverted: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface CampaignExecution {
  id: string;
  campaignId: string;
  status: ExecutionStatus;
  startedAt?: Date;
  completedAt?: Date;
  totalTargets: number;
  successCount: number;
  failureCount: number;
  errorMessage?: string;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface CampaignTarget {
  id: string;
  executionId: string;
  userId: string;
  status: TargetStatus;
  sentAt?: Date;
  deliveredAt?: Date;
  openedAt?: Date;
  clickedAt?: Date;
  convertedAt?: Date;
  failureReason?: string;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface CampaignMetric {
  id: string;
  campaignId: string;
  date: Date;
  sent: number;
  delivered: number;
  opened: number;
  clicked: number;
  converted: number;
  revenue: number;
  createdAt: Date;
}

export interface ClientSegment {
  id: string;
  name: string;
  description?: string;
  tenantId: string;
  criteria: SegmentationCriteria;
  isActive: boolean;
  lastUpdated: Date;
  clientCount: number;
  createdAt: Date;
  updatedAt: Date;
}

// Enums e tipos auxiliares
export enum CampaignType {
  PROMOTIONAL = 'PROMOTIONAL',
  REACTIVATION = 'REACTIVATION',
  BIRTHDAY = 'BIRTHDAY',
  CUSTOM = 'CUSTOM'
}

export enum CampaignStatus {
  DRAFT = 'DRAFT',
  ACTIVE = 'ACTIVE',
  PAUSED = 'PAUSED',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED'
}

export enum CampaignFrequency {
  ONCE = 'ONCE',
  DAILY = 'DAILY',
  WEEKLY = 'WEEKLY',
  MONTHLY = 'MONTHLY'
}

export enum ExecutionStatus {
  PENDING = 'PENDING',
  RUNNING = 'RUNNING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED'
}

export enum TargetStatus {
  PENDING = 'PENDING',
  SENT = 'SENT',
  DELIVERED = 'DELIVERED',
  FAILED = 'FAILED',
  OPENED = 'OPENED',
  CLICKED = 'CLICKED',
  CONVERTED = 'CONVERTED'
}

// Interfaces para segmentação
export interface TargetAudience {
  segments?: string[]; // IDs dos segmentos
  criteria?: SegmentationCriteria;
  excludeSegments?: string[];
}

export interface SegmentationCriteria {
  // Critérios demográficos
  ageRange?: {
    min?: number;
    max?: number;
  };
  gender?: string[];
  location?: string[];

  // Critérios comportamentais
  lastBookingDays?: number; // Últimos X dias desde o último agendamento
  totalBookings?: {
    min?: number;
    max?: number;
  };
  totalSpent?: {
    min?: number;
    max?: number;
  };
  
  // Critérios de engajamento
  openRate?: {
    min?: number; // Porcentagem mínima de abertura de emails/mensagens
  };
  clickRate?: {
    min?: number; // Porcentagem mínima de cliques
  };
  
  // Critérios de serviços
  preferredServices?: string[]; // IDs dos serviços
  preferredProfessionals?: string[]; // IDs dos profissionais
  
  // Critérios temporais
  registrationDate?: {
    from?: Date;
    to?: Date;
  };
  lastLoginDays?: number; // Últimos X dias desde o último login
  
  // Status do cliente
  isActive?: boolean;
  hasNoShow?: boolean; // Cliente que já faltou em agendamentos
}

// DTOs para criação e atualização
export interface CreateCampaignDto {
  name: string;
  description?: string;
  type: CampaignType;
  tenantId: string;
  templateId?: string;
  targetAudience?: TargetAudience;
  startDate?: Date;
  endDate?: Date;
  frequency?: CampaignFrequency;
}

export interface UpdateCampaignDto {
  name?: string;
  description?: string;
  status?: CampaignStatus;
  templateId?: string;
  targetAudience?: TargetAudience;
  startDate?: Date;
  endDate?: Date;
  frequency?: CampaignFrequency;
}

export interface CreateClientSegmentDto {
  name: string;
  description?: string;
  tenantId: string;
  criteria: SegmentationCriteria;
}

export interface UpdateClientSegmentDto {
  name?: string;
  description?: string;
  criteria?: SegmentationCriteria;
  isActive?: boolean;
}

// Interfaces para relatórios e métricas
export interface CampaignReport {
  campaign: Campaign;
  metrics: {
    totalSent: number;
    totalDelivered: number;
    totalOpened: number;
    totalClicked: number;
    totalConverted: number;
    deliveryRate: number;
    openRate: number;
    clickRate: number;
    conversionRate: number;
    revenue: number;
    roi: number; // Return on Investment
  };
  timeline: CampaignMetric[];
  topPerformingSegments?: {
    segmentName: string;
    openRate: number;
    clickRate: number;
    conversionRate: number;
  }[];
}

export interface CampaignAnalytics {
  totalCampaigns: number;
  activeCampaigns: number;
  averageOpenRate: number;
  averageClickRate: number;
  averageConversionRate: number;
  totalRevenue: number;
  bestPerformingCampaign?: {
    id: string;
    name: string;
    conversionRate: number;
  };
  recentExecutions: CampaignExecution[];
}

// Interface para automação de campanhas
export interface AutomationRule {
  id: string;
  name: string;
  description?: string;
  tenantId: string;
  trigger: AutomationTrigger;
  conditions: AutomationCondition[];
  actions: AutomationAction[];
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface AutomationTrigger {
  type: 'CLIENT_INACTIVE' | 'BIRTHDAY' | 'BOOKING_COMPLETED' | 'CUSTOM_DATE';
  config: Record<string, any>;
}

export interface AutomationCondition {
  field: string;
  operator: 'equals' | 'not_equals' | 'greater_than' | 'less_than' | 'contains' | 'not_contains';
  value: any;
}

export interface AutomationAction {
  type: 'SEND_CAMPAIGN' | 'ADD_TO_SEGMENT' | 'REMOVE_FROM_SEGMENT' | 'UPDATE_PROFILE';
  config: Record<string, any>;
}