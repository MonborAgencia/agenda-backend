// Module type declarations

declare module 'express' {
  export interface Request {
    user?: import('./user.types').JWTPayload;
  }
}

declare module 'cors';
declare module 'helmet';
declare module 'dotenv';
declare module 'socket.io';
declare module 'bcryptjs';
declare module 'jsonwebtoken';
declare module 'winston';
declare module 'redis';

// Extend global namespace
declare global {
  var console: Console;
  var process: NodeJS.Process;
}

export {};