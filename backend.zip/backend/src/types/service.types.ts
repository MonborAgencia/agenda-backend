export interface CreateServiceRequest {
  name: string;
  description?: string;
  duration: number; // em minutos
  price: number;
  category?: string;
  professionalId: string;
}

export interface UpdateServiceRequest {
  name?: string;
  description?: string;
  duration?: number;
  price?: number;
  category?: string;
  isActive?: boolean;
}

export interface ServiceResponse {
  id: string;
  name: string;
  description?: string;
  duration: number;
  price: number;
  category?: string;
  isActive: boolean;
  tenantId: string;
  professionalId: string;
  createdAt: Date;
  updatedAt: Date;
  professional?: {
    id: string;
    user: {
      id: string;
      name: string;
      email: string;
    };
  };
}

export interface ServiceFilters {
  category?: string;
  professionalId?: string;
  isActive?: boolean;
  minPrice?: number;
  maxPrice?: number;
  minDuration?: number;
  maxDuration?: number;
}

export interface ServiceCategory {
  name: string;
  count: number;
}