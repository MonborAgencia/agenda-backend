export interface CreateScheduleRequest {
  professionalId: string;
  dayOfWeek: number; // 0-6 (domingo-sábado)
  startTime: string; // HH:mm
  endTime: string; // HH:mm
}

export interface UpdateScheduleRequest {
  dayOfWeek?: number;
  startTime?: string;
  endTime?: string;
  isActive?: boolean;
}

export interface ScheduleResponse {
  id: string;
  professionalId: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  professional?: {
    id: string;
    user: {
      id: string;
      name: string;
      email: string;
    };
  };
  exceptions?: ScheduleExceptionResponse[];
}

export interface CreateScheduleExceptionRequest {
  scheduleId: string;
  date: string; // YYYY-MM-DD
  isBlocked: boolean;
  startTime?: string; // HH:mm para horário customizado
  endTime?: string; // HH:mm para horário customizado
  reason?: string;
}

export interface UpdateScheduleExceptionRequest {
  isBlocked?: boolean;
  startTime?: string;
  endTime?: string;
  reason?: string;
}

export interface ScheduleExceptionResponse {
  id: string;
  scheduleId: string;
  date: Date;
  isBlocked: boolean;
  startTime?: string;
  endTime?: string;
  reason?: string;
  createdAt: Date;
}

export interface WeeklyScheduleRequest {
  professionalId: string;
  schedules: {
    dayOfWeek: number;
    startTime: string;
    endTime: string;
    isActive: boolean;
  }[];
}

export interface ScheduleConflict {
  type: 'OVERLAP' | 'INVALID_TIME' | 'EXISTING_BOOKING';
  message: string;
  conflictingSchedule?: ScheduleResponse;
  conflictingBooking?: any;
}

export interface AvailabilitySlot {
  startTime: string;
  endTime: string;
  duration: number; // em minutos
  isAvailable: boolean;
  reason?: string; // motivo se não disponível
}

export interface DayAvailability {
  date: string;
  dayOfWeek: number;
  slots: AvailabilitySlot[];
  totalSlots: number;
  availableSlots: number;
}

// Agenda visualization types
export interface AgendaViewRequest {
  professionalId?: string;
  serviceId?: string;
  startDate: string;
  endDate: string;
}

export interface AgendaBooking {
  id: string;
  clientName: string;
  clientPhone?: string;
  serviceName: string;
  startTime: Date;
  endTime: Date;
  status: string;
  price: number;
  notes?: string;
}

export interface AgendaDay {
  date: string;
  dayOfWeek: number;
  bookings: AgendaBooking[];
  totalBookings: number;
  totalRevenue: number;
  occupancyRate: number; // percentage of occupied time
}

export interface AgendaWeek {
  startDate: string;
  endDate: string;
  days: AgendaDay[];
  totalBookings: number;
  totalRevenue: number;
  averageOccupancyRate: number;
}

export interface AgendaMonth {
  year: number;
  month: number;
  weeks: AgendaWeek[];
  totalBookings: number;
  totalRevenue: number;
  averageOccupancyRate: number;
}

// Available slots system types
export interface SlotGenerationRequest {
  professionalId: string;
  serviceId: string;
  startDate: string;
  endDate: string;
}

export interface AvailableSlot {
  id: string;
  professionalId: string;
  serviceId: string;
  startTime: Date;
  endTime: Date;
  duration: number;
  isAvailable: boolean;
  isTemporarilyReserved: boolean;
  reservedUntil?: Date;
  price: number;
}

export interface SlotReservationRequest {
  slotId: string;
  clientId: string;
  reservationMinutes?: number; // default 15 minutes
}

export interface SlotReservation {
  slotId: string;
  clientId: string;
  reservedAt: Date;
  expiresAt: Date;
}