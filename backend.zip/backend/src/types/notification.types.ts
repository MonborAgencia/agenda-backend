export interface NotificationTemplate {
  id: string;
  name: string;
  type: NotificationType;
  subject?: string;
  content: string;
  language: string;
  category: NotificationCategory;
  tenantId?: string;
  isActive: boolean;
  variables?: TemplateVariable[];
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateNotificationTemplateData {
  name: string;
  type: NotificationType;
  subject?: string;
  content: string;
  language?: string;
  category: NotificationCategory;
  tenantId?: string;
  variables?: TemplateVariable[];
}

export interface UpdateNotificationTemplateData {
  name?: string;
  type?: NotificationType;
  subject?: string;
  content?: string;
  language?: string;
  category?: NotificationCategory;
  isActive?: boolean;
  variables?: TemplateVariable[];
}

export interface TemplateVariable {
  name: string;
  description: string;
  type: 'string' | 'number' | 'date' | 'boolean';
  required: boolean;
  defaultValue?: any;
}

export interface Notification {
  id: string;
  templateId?: string;
  recipientId: string;
  type: NotificationType;
  subject?: string;
  content: string;
  status: NotificationStatus;
  scheduledFor?: Date;
  sentAt?: Date;
  deliveredAt?: Date;
  failureReason?: string;
  retryCount: number;
  maxRetries: number;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateNotificationData {
  templateId?: string;
  recipientId: string;
  type: NotificationType;
  subject?: string;
  content?: string;
  scheduledFor?: Date;
  metadata?: Record<string, any>;
  variables?: Record<string, any>;
}

export interface NotificationQueue {
  id: string;
  notificationId: string;
  priority: NotificationPriority;
  attempts: number;
  nextAttempt: Date;
  data: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface ProcessNotificationData {
  notificationId: string;
  priority?: NotificationPriority;
  delay?: number; // em segundos
}

export interface NotificationResult {
  success: boolean;
  messageId?: string;
  error?: string;
  deliveredAt?: Date;
}

export interface TemplateRenderData {
  variables: Record<string, any>;
  language?: string;
}

export interface NotificationStats {
  total: number;
  sent: number;
  delivered: number;
  failed: number;
  pending: number;
  deliveryRate: number;
}

export interface NotificationFilter {
  type?: NotificationType;
  status?: NotificationStatus;
  recipientId?: string;
  templateId?: string;
  dateFrom?: Date;
  dateTo?: Date;
  category?: NotificationCategory;
}

export enum NotificationType {
  EMAIL = 'EMAIL',
  WHATSAPP = 'WHATSAPP',
  PUSH = 'PUSH',
  SMS = 'SMS'
}

export enum NotificationStatus {
  PENDING = 'PENDING',
  SENT = 'SENT',
  DELIVERED = 'DELIVERED',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED'
}

export enum NotificationCategory {
  REMINDER = 'REMINDER',
  CONFIRMATION = 'CONFIRMATION',
  CANCELLATION = 'CANCELLATION',
  MARKETING = 'MARKETING',
  SYSTEM = 'SYSTEM'
}

export enum NotificationPriority {
  NORMAL = 0,
  HIGH = 1,
  URGENT = 2
}

// Templates padrão do sistema
export interface DefaultTemplates {
  BOOKING_CONFIRMATION: {
    subject: string;
    content: string;
    variables: string[];
  };
  BOOKING_REMINDER: {
    subject: string;
    content: string;
    variables: string[];
  };
  BOOKING_CANCELLATION: {
    subject: string;
    content: string;
    variables: string[];
  };
  BOOKING_RESCHEDULED: {
    subject: string;
    content: string;
    variables: string[];
  };
}

export interface NotificationProvider {
  type: NotificationType;
  send(notification: Notification): Promise<NotificationResult>;
  isConfigured(): boolean;
}

export interface EmailConfig {
  host: string;
  port: number;
  secure: boolean;
  auth: {
    user: string;
    pass: string;
  };
  from: string;
}

export interface WhatsAppConfig {
  apiUrl: string;
  token: string;
  phoneNumberId: string;
}

export interface PushConfig {
  serverKey: string;
  vapidKeys: {
    publicKey: string;
    privateKey: string;
  };
}