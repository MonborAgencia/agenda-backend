export interface CreateBookingRequest {
  clientId: string;
  professionalId: string;
  serviceId: string;
  startTime: Date;
  notes?: string;
}

export interface UpdateBookingRequest {
  startTime?: Date;
  notes?: string;
  status?: BookingStatus;
}

export interface RescheduleBookingRequest {
  newStartTime: Date;
  reason?: string;
}

export interface BookingFilters {
  clientId?: string;
  professionalId?: string;
  serviceId?: string;
  status?: BookingStatus;
  startDate?: Date;
  endDate?: Date;
  tenantId?: string;
}

export interface BookingResponse {
  id: string;
  clientId: string;
  professionalId: string;
  serviceId: string;
  tenantId: string;
  startTime: Date;
  endTime: Date;
  status: BookingStatus;
  notes?: string;
  price: number;
  paymentStatus: PaymentStatus;
  createdAt: Date;
  updatedAt: Date;
  client?: {
    id: string;
    name: string;
    email: string;
    phone?: string;
  };
  professional?: {
    id: string;
    user: {
      name: string;
      email: string;
    };
  };
  service?: {
    id: string;
    name: string;
    duration: number;
    price: number;
  };
}

export interface BookingHistory {
  id: string;
  bookingId: string;
  action: BookingAction;
  previousStatus?: BookingStatus;
  newStatus?: BookingStatus;
  previousStartTime?: Date;
  newStartTime?: Date;
  reason?: string;
  performedBy: string;
  performedAt: Date;
}

export interface BookingMetrics {
  totalBookings: number;
  completedBookings: number;
  cancelledBookings: number;
  noShowBookings: number;
  completionRate: number;
  cancellationRate: number;
  noShowRate: number;
  averageBookingValue: number;
  totalRevenue: number;
}

export interface AvailabilitySlot {
  startTime: Date;
  endTime: Date;
  isAvailable: boolean;
  professionalId: string;
  serviceId?: string;
}

export interface BookingValidationResult {
  isValid: boolean;
  errors: string[];
  warnings?: string[];
}

export interface CancellationPolicy {
  minimumHours: number;
  allowCancellation: boolean;
  chargePercentage: number;
  reason?: string;
}

export type BookingStatus = 
  | 'SCHEDULED' 
  | 'CONFIRMED' 
  | 'COMPLETED' 
  | 'CANCELLED' 
  | 'NO_SHOW'
  | 'RESCHEDULED';

export type PaymentStatus = 
  | 'PENDING' 
  | 'PAID' 
  | 'REFUNDED' 
  | 'CANCELLED';

export type BookingAction = 
  | 'CREATED' 
  | 'UPDATED' 
  | 'CONFIRMED' 
  | 'COMPLETED' 
  | 'CANCELLED' 
  | 'RESCHEDULED' 
  | 'NO_SHOW';

export interface BookingNotification {
  type: 'CONFIRMATION' | 'REMINDER' | 'CANCELLATION' | 'RESCHEDULE';
  bookingId: string;
  recipientId: string;
  message: string;
  scheduledFor?: Date;
}