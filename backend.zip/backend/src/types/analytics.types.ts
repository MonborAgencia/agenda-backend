export interface DateRange {
  startDate: Date;
  endDate: Date;
}

export interface OccupancyMetrics {
  totalSlots: number;
  bookedSlots: number;
  occupancyRate: number; // percentage
  availableSlots: number;
}

export interface RevenueMetrics {
  totalRevenue: number;
  confirmedRevenue: number;
  pendingRevenue: number;
  averageBookingValue: number;
  totalBookings: number;
}

export interface ProfitableHoursAnalysis {
  hour: number; // 0-23
  totalBookings: number;
  totalRevenue: number;
  averageRevenue: number;
  occupancyRate: number;
}

export interface ServiceMetrics {
  serviceId: string;
  serviceName: string;
  totalBookings: number;
  totalRevenue: number;
  averagePrice: number;
  popularityRank: number;
}

export interface ProfessionalMetrics {
  professionalId: string;
  professionalName: string;
  totalBookings: number;
  totalRevenue: number;
  occupancyRate: number;
  averageRating?: number;
  noShowRate: number;
  cancellationRate: number;
}

export interface DashboardMetrics {
  occupancy: OccupancyMetrics;
  revenue: RevenueMetrics;
  profitableHours: ProfitableHoursAnalysis[];
  topServices: ServiceMetrics[];
  professionalPerformance: ProfessionalMetrics[];
  periodComparison?: {
    current: RevenueMetrics;
    previous: RevenueMetrics;
    growthRate: number;
  };
}

export interface AnalyticsFilters {
  tenantId: string;
  dateRange: DateRange;
  professionalId?: string;
  serviceId?: string;
  status?: string[];
}

export interface ReportConfig {
  id: string;
  name: string;
  type: 'PDF' | 'EXCEL';
  frequency: 'DAILY' | 'WEEKLY' | 'MONTHLY';
  filters: AnalyticsFilters;
  recipients: string[];
  isActive: boolean;
  nextRun?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface ReportData {
  title: string;
  generatedAt: Date;
  period: DateRange;
  metrics: DashboardMetrics;
  charts?: {
    occupancyTrend: Array<{ date: string; occupancy: number }>;
    revenueTrend: Array<{ date: string; revenue: number }>;
    serviceDistribution: Array<{ service: string; bookings: number }>;
  };
}