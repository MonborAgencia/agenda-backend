export interface Payment {
  id: string;
  bookingId: string;
  stripePaymentId?: string;
  stripeCustomerId?: string;
  amount: number; // em centavos
  currency: string;
  status: PaymentStatus;
  paymentMethod?: string;
  description?: string;
  metadata?: Record<string, any>;
  failureReason?: string;
  refundAmount?: number;
  refundReason?: string;
  refundedAt?: Date;
  paidAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export enum PaymentStatus {
  PENDING = 'PENDING',
  PROCESSING = 'PROCESSING',
  SUCCEEDED = 'SUCCEEDED',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED',
  REFUNDED = 'REFUNDED'
}

export interface PaymentIntent {
  id: string;
  paymentId: string;
  stripePaymentIntentId: string;
  amount: number;
  currency: string;
  status: string;
  clientSecret?: string;
  paymentMethodTypes: string[];
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface PaymentMethod {
  id: string;
  userId: string;
  stripeMethodId: string;
  type: string;
  brand?: string;
  last4?: string;
  expiryMonth?: number;
  expiryYear?: number;
  isDefault: boolean;
  isActive: boolean;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface WebhookEvent {
  id: string;
  paymentId?: string;
  stripeEventId: string;
  eventType: string;
  processed: boolean;
  processingError?: string;
  data: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreatePaymentRequest {
  bookingId: string;
  amount: number;
  currency?: string;
  paymentMethodTypes?: string[];
  description?: string;
  metadata?: Record<string, any>;
}

export interface CreatePaymentResponse {
  payment: Payment;
  paymentIntent: PaymentIntent;
  clientSecret: string;
}

export interface RefundPaymentRequest {
  paymentId: string;
  amount?: number; // se não especificado, reembolsa o valor total
  reason?: string;
}

export interface RefundPaymentResponse {
  payment: Payment;
  refundId: string;
  status: string;
}

export interface PaymentWebhookData {
  id: string;
  object: string;
  type: string;
  data: {
    object: any;
  };
  created: number;
}

export interface StripeCustomer {
  id: string;
  email: string;
  name?: string;
  phone?: string;
  metadata?: Record<string, any>;
}

export interface PaymentStats {
  totalRevenue: number;
  totalTransactions: number;
  successfulPayments: number;
  failedPayments: number;
  refundedAmount: number;
  averageTransactionValue: number;
  paymentMethodBreakdown: Record<string, number>;
  monthlyRevenue: Array<{
    month: string;
    revenue: number;
    transactions: number;
  }>;
}