export interface CreateReviewRequest {
  bookingId: string;
  rating: number;
  comment?: string;
}

export interface UpdateReviewRequest {
  rating?: number;
  comment?: string;
}

export interface ReviewResponse {
  id: string;
  bookingId: string;
  clientId: string;
  professionalId: string;
  rating: number;
  comment?: string;
  isModerated: boolean;
  moderationStatus: 'PENDING' | 'APPROVED' | 'REJECTED';
  moderationReason?: string;
  moderatedAt?: Date;
  moderatedBy?: string;
  isVisible: boolean;
  createdAt: Date;
  updatedAt: Date;
  client?: {
    id: string;
    name: string;
    avatar?: string;
  };
  professional?: {
    id: string;
    user: {
      name: string;
      avatar?: string;
    };
  };
  booking?: {
    service: {
      name: string;
    };
    startTime: Date;
  };
  response?: ReviewResponseData;
}

export interface ReviewResponseData {
  id: string;
  reviewId: string;
  professionalId: string;
  response: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateReviewResponseRequest {
  response: string;
}

export interface ReviewStats {
  totalReviews: number;
  averageRating: number;
  ratingDistribution: {
    1: number;
    2: number;
    3: number;
    4: number;
    5: number;
  };
  recentReviews: ReviewResponse[];
}

export interface ReviewFilters {
  professionalId?: string;
  rating?: number;
  moderationStatus?: 'PENDING' | 'APPROVED' | 'REJECTED';
  isVisible?: boolean;
  startDate?: Date;
  endDate?: Date;
  page?: number;
  limit?: number;
}

export interface ModerateReviewRequest {
  moderationStatus: 'APPROVED' | 'REJECTED';
  moderationReason?: string;
  isVisible?: boolean;
}

export interface ProfessionalReviewStats {
  professionalId: string;
  totalReviews: number;
  averageRating: number;
  ratingDistribution: {
    1: number;
    2: number;
    3: number;
    4: number;
    5: number;
  };
  responseRate: number; // Porcentagem de avaliações com resposta
  lastReviewDate?: Date;
}