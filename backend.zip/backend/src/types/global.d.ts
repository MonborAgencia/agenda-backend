// Global type declarations

declare global {
  namespace NodeJS {
    interface ProcessEnv {
      NODE_ENV: 'development' | 'production' | 'test';
      PORT?: string;
      DATABASE_URL: string;
      JWT_SECRET?: string;
      JWT_REFRESH_SECRET?: string;
      JWT_EXPIRES_IN?: string;
      JWT_REFRESH_EXPIRES_IN?: string;
      FRONTEND_URL?: string;
    }
  }
}

// Module declarations for packages without types
declare module 'express' {
  interface Request {
    user?: import('./user.types').JWTPayload;
  }
}

export {};