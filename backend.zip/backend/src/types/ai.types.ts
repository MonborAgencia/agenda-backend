export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}

export interface ChatContext {
  userId: string;
  sessionId: string;
  conversationHistory: ChatMessage[];
  userProfile?: {
    name?: string;
    role: 'CLIENT' | 'PROFESSIONAL' | 'ADMIN';
    preferences?: Record<string, any>;
  };
  tenantId: string;
}

export interface ChatResponse {
  message: string;
  intent?: Intent;
  actions?: ChatAction[];
  suggestions?: string[];
  metadata?: Record<string, any>;
}

export interface Intent {
  name: string;
  confidence: number;
  entities?: Record<string, any>;
}

export interface ChatAction {
  type: 'BOOK_APPOINTMENT' | 'SHOW_AVAILABILITY' | 'CANCEL_BOOKING' | 'SHOW_SERVICES' | 'TRANSFER_TO_HUMAN';
  data?: Record<string, any>;
}

export interface Recommendation {
  id: string;
  type: 'SERVICE' | 'PROFESSIONAL' | 'TIME_SLOT' | 'PROMOTION';
  title: string;
  description: string;
  confidence: number;
  data: Record<string, any>;
  reason?: string;
}

export interface ServiceRecommendation extends Recommendation {
  type: 'SERVICE';
  data: {
    serviceId: string;
    serviceName: string;
    price: number;
    duration: number;
    category: string;
  };
}

export interface ProfessionalRecommendation extends Recommendation {
  type: 'PROFESSIONAL';
  data: {
    professionalId: string;
    professionalName: string;
    rating: number;
    specialties: string[];
    availability: string[];
  };
}

export interface TimeSlotRecommendation extends Recommendation {
  type: 'TIME_SLOT';
  data: {
    date: string;
    time: string;
    professionalId: string;
    serviceId: string;
    isOptimal: boolean;
  };
}

export interface PromotionRecommendation extends Recommendation {
  type: 'PROMOTION';
  data: {
    promotionId: string;
    discount: number;
    validUntil: Date;
    applicableServices: string[];
  };
}

export interface ChatSession {
  id: string;
  userId: string;
  tenantId: string;
  startedAt: Date;
  lastActivity: Date;
  isActive: boolean;
  messages: ChatMessage[];
  context?: Record<string, any>;
}

export interface AIInsight {
  id: string;
  type: 'IDLE_PERIOD' | 'DEMAND_PREDICTION' | 'CHURN_RISK' | 'PRICING_OPTIMIZATION';
  title: string;
  description: string;
  confidence: number;
  data: Record<string, any>;
  actionable: boolean;
  createdAt: Date;
}

export interface IdlePeriodInsight extends AIInsight {
  type: 'IDLE_PERIOD';
  data: {
    professionalId: string;
    date: string;
    timeSlots: string[];
    suggestedActions: string[];
  };
}

export interface DemandPrediction extends AIInsight {
  type: 'DEMAND_PREDICTION';
  data: {
    date: string;
    serviceId?: string;
    professionalId?: string;
    predictedDemand: number;
    factors: string[];
  };
}

export interface ChurnRisk extends AIInsight {
  type: 'CHURN_RISK';
  data: {
    clientId: string;
    riskScore: number;
    factors: string[];
    suggestedActions: string[];
  };
}

export interface PricingOptimization extends AIInsight {
  type: 'PRICING_OPTIMIZATION';
  data: {
    serviceId: string;
    currentPrice: number;
    suggestedPrice: number;
    expectedImpact: number;
    reasoning: string[];
  };
}

export interface CampaignSuggestion {
  id: string;
  type: 'REACTIVATION' | 'PROMOTION' | 'RETENTION' | 'ACQUISITION';
  title: string;
  description: string;
  targetAudience: {
    criteria: Record<string, any>;
    estimatedSize: number;
  };
  content: {
    subject: string;
    message: string;
    callToAction: string;
  };
  timing: {
    bestTime: string;
    frequency: string;
  };
  expectedResults: {
    openRate: number;
    clickRate: number;
    conversionRate: number;
  };
  createdAt: Date;
}

export interface AIConfig {
  openaiApiKey: string;
  model: string;
  temperature: number;
  maxTokens: number;
  systemPrompt: string;
  enableRecommendations: boolean;
  enableInsights: boolean;
  cacheEnabled: boolean;
  cacheTtl: number;
}