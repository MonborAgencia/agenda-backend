import { z } from 'zod';

// User validation schemas
export const createUserSchema = z.object({
  email: z.string().email('Email inválido'),
  name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres').max(100, 'Nome muito longo'),
  phone: z.string().regex(/^\+?[\d\s\-\(\)]+$/, 'Formato de telefone inválido').optional(),
  password: z.string()
    .min(8, 'Senha deve ter pelo menos 8 caracteres')
    .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, 'Senha deve conter pelo menos uma letra minúscula, uma maiúscula e um número'),
  tenantId: z.string().optional(),
  roleIds: z.array(z.string()).min(1, 'Pelo menos um papel deve ser atribuído'),
}).refine((data) => {
  // Additional validation based on user type can be added here
  return true;
}, {
  message: 'Dados de usuário inválidos',
});

export const updateUserSchema = z.object({
  email: z.string().email('Email inválido').optional(),
  name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres').max(100, 'Nome muito longo').optional(),
  phone: z.string().regex(/^\+?[\d\s\-\(\)]+$/, 'Formato de telefone inválido').optional(),
  isActive: z.boolean().optional(),
  roleIds: z.array(z.string()).optional(),
});

export const loginSchema = z.object({
  email: z.string().email('Email inválido'),
  password: z.string().min(1, 'Senha é obrigatória'),
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Senha atual é obrigatória'),
  newPassword: z.string().min(8, 'Nova senha deve ter pelo menos 8 caracteres'),
});

// User profile validation schemas
export const updateUserProfileSchema = z.object({
  avatar: z.string().optional(), // Can be URL or file path
  bio: z.string().max(500, 'Bio muito longa').optional(),
  specialties: z.array(z.string()).optional(),
  preferences: z.record(z.any()).optional(),
  workingHours: z.record(z.any()).optional(),
});

// Professional-specific profile schema
export const updateProfessionalProfileSchema = updateUserProfileSchema.extend({
  specialties: z.array(z.string()).min(1, 'Profissional deve ter pelo menos uma especialidade'),
  workingHours: z.object({
    monday: z.object({ start: z.string(), end: z.string(), enabled: z.boolean() }).optional(),
    tuesday: z.object({ start: z.string(), end: z.string(), enabled: z.boolean() }).optional(),
    wednesday: z.object({ start: z.string(), end: z.string(), enabled: z.boolean() }).optional(),
    thursday: z.object({ start: z.string(), end: z.string(), enabled: z.boolean() }).optional(),
    friday: z.object({ start: z.string(), end: z.string(), enabled: z.boolean() }).optional(),
    saturday: z.object({ start: z.string(), end: z.string(), enabled: z.boolean() }).optional(),
    sunday: z.object({ start: z.string(), end: z.string(), enabled: z.boolean() }).optional(),
  }).optional(),
});

// Client-specific profile schema
export const updateClientProfileSchema = updateUserProfileSchema.extend({
  preferences: z.object({
    notifications: z.object({
      email: z.boolean().default(true),
      whatsapp: z.boolean().default(true),
      push: z.boolean().default(true),
    }).optional(),
    reminderTime: z.enum(['1h', '2h', '24h', '48h']).default('24h').optional(),
    language: z.enum(['pt', 'en', 'es']).default('pt').optional(),
  }).optional(),
});

// Role validation schemas
export const createRoleSchema = z.object({
  name: z.string().min(2, 'Nome do papel deve ter pelo menos 2 caracteres').max(50, 'Nome muito longo'),
  description: z.string().max(200, 'Descrição muito longa').optional(),
  permissionIds: z.array(z.string()).optional(),
});

export const updateRoleSchema = z.object({
  name: z.string().min(2, 'Nome do papel deve ter pelo menos 2 caracteres').max(50, 'Nome muito longo').optional(),
  description: z.string().max(200, 'Descrição muito longa').optional(),
  isActive: z.boolean().optional(),
  permissionIds: z.array(z.string()).optional(),
});

// Permission validation schemas
export const createPermissionSchema = z.object({
  name: z.string().min(2, 'Nome da permissão deve ter pelo menos 2 caracteres').max(100, 'Nome muito longo'),
  resource: z.string().min(2, 'Recurso deve ter pelo menos 2 caracteres').max(50, 'Recurso muito longo'),
  action: z.enum(['create', 'read', 'update', 'delete', 'manage']),
  description: z.string().max(200, 'Descrição muito longa').optional(),
});

// Type exports
export type CreateUserInput = {
  email: string;
  name: string;
  phone?: string;
  password: string;
  tenantId?: string;
  roleIds: string[];
};

export type UpdateUserInput = {
  email?: string;
  name?: string;
  phone?: string;
  isActive?: boolean;
  roleIds?: string[];
};

export type LoginInput = {
  email: string;
  password: string;
};

export type ChangePasswordInput = {
  currentPassword: string;
  newPassword: string;
};

export type UpdateUserProfileInput = {
  avatar?: string;
  bio?: string;
  specialties?: string[];
  preferences?: Record<string, any>;
  workingHours?: Record<string, any>;
};

export type UpdateProfessionalProfileInput = UpdateUserProfileInput & {
  specialties: string[];
  workingHours: {
    monday?: { start: string; end: string; enabled: boolean };
    tuesday?: { start: string; end: string; enabled: boolean };
    wednesday?: { start: string; end: string; enabled: boolean };
    thursday?: { start: string; end: string; enabled: boolean };
    friday?: { start: string; end: string; enabled: boolean };
    saturday?: { start: string; end: string; enabled: boolean };
    sunday?: { start: string; end: string; enabled: boolean };
  };
};

export type UpdateClientProfileInput = UpdateUserProfileInput & {
  preferences: {
    notifications: {
      email: boolean;
      whatsapp: boolean;
      push: boolean;
    };
    reminderTime?: '1h' | '2h' | '24h' | '48h';
    language?: 'pt' | 'en' | 'es';
  };
};

export type CreateRoleInput = {
  name: string;
  description?: string;
  permissionIds?: string[];
};

export type UpdateRoleInput = {
  name?: string;
  description?: string;
  isActive?: boolean;
  permissionIds?: string[];
};

export type CreatePermissionInput = {
  name: string;
  resource: string;
  action: 'create' | 'read' | 'update' | 'delete' | 'manage';
  description?: string;
};

// User with relations type
export interface UserWithRoles {
  id: string;
  email: string;
  name: string;
  phone: string | null;
  password?: string; // Optional for responses
  tenantId: string | null;
  isActive: boolean;
  emailVerified: boolean;
  lastLoginAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
  userRoles: {
    role: {
      id: string;
      name: string;
      description: string | null;
      rolePermissions: {
        permission: {
          id: string;
          name: string;
          resource: string;
          action: string;
        };
      }[];
    };
  }[];
  profile?: {
    id: string;
    avatar: string | null;
    bio: string | null;
    specialties: string[];
    preferences: any;
    workingHours: any;
  } | null;
}

// JWT payload type
export interface JWTPayload {
  userId: string;
  email: string;
  tenantId: string | null;
  roles: string[];
  permissions: string[];
}