import { Router } from 'express';
import { ClientReactivationController } from '../controllers/client-reactivation.controller';
import { authMiddleware } from '../middleware/auth.middleware';

const router = Router();
const reactivationController = new ClientReactivationController();

// Aplicar middleware de autenticação em todas as rotas
router.use(authMiddleware);

// Rotas de reativação de clientes
router.get('/inactive-clients', reactivationController.getInactiveClients.bind(reactivationController));
router.post('/campaigns', reactivationController.createReactivationCampaign.bind(reactivationController));
router.post('/campaigns/:campaignId/execute', reactivationController.executePersonalizedReactivation.bind(reactivationController));
router.get('/metrics', reactivationController.getReactivationMetrics.bind(reactivationController));
router.get('/suggestions', reactivationController.getReactivationSuggestions.bind(reactivationController));
router.post('/setup-automatic', reactivationController.setupAutomaticReactivation.bind(reactivationController));
router.get('/templates', reactivationController.getReactivationTemplates.bind(reactivationController));
router.post('/simulate', reactivationController.simulateReactivationCampaign.bind(reactivationController));

export default router;