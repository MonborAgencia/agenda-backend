import { Router } from 'express';
import { serviceController } from '../controllers/service.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

// Aplicar middleware de autenticação em todas as rotas
router.use(authenticateToken);

// Rotas de serviços
router.post('/', serviceController.createService);
router.get('/', serviceController.getServices);
router.get('/categories', serviceController.getServiceCategories);
router.get('/professional/:professionalId', serviceController.getServicesByProfessional);
router.get('/:id', serviceController.getServiceById);
router.put('/:id', serviceController.updateService);
router.delete('/:id', serviceController.deleteService);
router.put('/:id/transfer', serviceController.transferService);

export default router;