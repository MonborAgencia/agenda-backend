import { Router } from 'express';
import { bookingController } from '../controllers/booking.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

// Aplicar middleware de autenticação em todas as rotas
router.use(authenticateToken);

// Rotas para agendamentos
router.post('/', bookingController.createBooking.bind(bookingController));
router.get('/', bookingController.getBookings.bind(bookingController));
router.get('/:id', bookingController.getBookingById.bind(bookingController));
router.put('/:id', bookingController.updateBooking.bind(bookingController));

// Rotas para ações específicas
router.post('/:id/confirm', bookingController.confirmBooking.bind(bookingController));
router.post('/:id/reschedule', bookingController.rescheduleBooking.bind(bookingController));
router.post('/:id/cancel', bookingController.cancelBooking.bind(bookingController));
router.post('/:id/complete', bookingController.completeBooking.bind(bookingController));
router.post('/:id/no-show', bookingController.markAsNoShow.bind(bookingController));

// Rotas para validações
router.post('/validate-availability', bookingController.validateAvailability.bind(bookingController));
router.get('/:id/validate-cancellation', bookingController.validateCancellation.bind(bookingController));
router.post('/:id/validate-reschedule', bookingController.validateReschedule.bind(bookingController));
router.get('/:id/cancellation-fee', bookingController.calculateCancellationFee.bind(bookingController));

// Rotas para histórico e métricas
router.get('/:id/history', bookingController.getBookingHistory.bind(bookingController));
router.get('/metrics/basic', bookingController.getBookingMetrics.bind(bookingController));
router.get('/metrics/detailed', bookingController.getDetailedMetrics.bind(bookingController));
router.get('/metrics/trends', bookingController.getBookingTrends.bind(bookingController));
router.get('/metrics/cancellation-patterns', bookingController.getCancellationPatterns.bind(bookingController));
router.get('/metrics/high-cancellation-clients', bookingController.getHighCancellationClients.bind(bookingController));

export { router as bookingRoutes };