import { Router } from 'express';
import {
  getUsers,
  getUserById,
  createUser,
  updateUser,
  updateUserProfile,
  updateProfessionalProfile,
  updateClientProfile,
  uploadAvatar,
  deleteAvatar,
  getUserProfileWithCustomFields,
  getTenantCustomFields,
  deactivateUser,
  activateUser,
  deleteUser,
  getRoles,
  createRole,
  getPermissions,
} from '../controllers/user.controller';
import {
  authenticateToken,
  requirePermissions,
  requireSelfOrAdmin,
} from '../middleware/auth.middleware';
import { uploadAvatar as uploadAvatarMiddleware, handleUploadError } from '../middleware/upload.middleware';

const router = Router();

// User routes
/**
 * @route GET /users
 * @desc Get all users
 * @access Private (requires user:read permission)
 */
router.get('/', authenticateToken, requirePermissions('user:read'), getUsers);

/**
 * @route GET /users/:id
 * @desc Get user by ID
 * @access Private (self or admin)
 */
router.get('/:id', authenticateToken, requireSelfOrAdmin('id'), getUserById);

/**
 * @route POST /users
 * @desc Create new user
 * @access Private (requires user:create permission)
 */
router.post('/', authenticateToken, requirePermissions('user:create'), createUser);

/**
 * @route PUT /users/:id
 * @desc Update user
 * @access Private (requires user:update permission)
 */
router.put('/:id', authenticateToken, requirePermissions('user:update'), updateUser);

/**
 * @route PUT /users/:id/profile
 * @desc Update user profile
 * @access Private (self or admin)
 */
router.put('/:id/profile', authenticateToken, requireSelfOrAdmin('id'), updateUserProfile);

/**
 * @route PUT /users/:id/profile/professional
 * @desc Update professional profile
 * @access Private (self or admin)
 */
router.put('/:id/profile/professional', authenticateToken, requireSelfOrAdmin('id'), updateProfessionalProfile);

/**
 * @route PUT /users/:id/profile/client
 * @desc Update client profile
 * @access Private (self or admin)
 */
router.put('/:id/profile/client', authenticateToken, requireSelfOrAdmin('id'), updateClientProfile);

/**
 * @route POST /users/:id/avatar
 * @desc Upload user avatar
 * @access Private (self or admin)
 */
router.post('/:id/avatar', 
  authenticateToken, 
  requireSelfOrAdmin('id'), 
  uploadAvatarMiddleware.single('avatar'),
  handleUploadError,
  uploadAvatar
);

/**
 * @route DELETE /users/:id/avatar
 * @desc Delete user avatar
 * @access Private (self or admin)
 */
router.delete('/:id/avatar', authenticateToken, requireSelfOrAdmin('id'), deleteAvatar);

/**
 * @route GET /users/:id/profile/custom-fields
 * @desc Get user profile with custom fields
 * @access Private (self or admin)
 */
router.get('/:id/profile/custom-fields', authenticateToken, requireSelfOrAdmin('id'), getUserProfileWithCustomFields);

/**
 * @route GET /users/tenants/:tenantId/custom-fields/:userType
 * @desc Get tenant custom fields for user type
 * @access Private (requires user:read permission)
 */
router.get('/tenants/:tenantId/custom-fields/:userType', authenticateToken, requirePermissions('user:read'), getTenantCustomFields);

/**
 * @route PUT /users/:id/deactivate
 * @desc Deactivate user
 * @access Private (requires user:update permission)
 */
router.put('/:id/deactivate', authenticateToken, requirePermissions('user:update'), deactivateUser);

/**
 * @route PUT /users/:id/activate
 * @desc Activate user
 * @access Private (requires user:update permission)
 */
router.put('/:id/activate', authenticateToken, requirePermissions('user:update'), activateUser);

/**
 * @route DELETE /users/:id
 * @desc Delete user
 * @access Private (requires user:delete permission)
 */
router.delete('/:id', authenticateToken, requirePermissions('user:delete'), deleteUser);

// Role routes
/**
 * @route GET /users/roles
 * @desc Get all roles
 * @access Private (requires user:read permission)
 */
router.get('/roles', authenticateToken, requirePermissions('user:read'), getRoles);

/**
 * @route POST /users/roles
 * @desc Create new role
 * @access Private (requires user:manage permission)
 */
router.post('/roles', authenticateToken, requirePermissions('user:manage'), createRole);

/**
 * @route GET /users/permissions
 * @desc Get all permissions
 * @access Private (requires user:read permission)
 */
router.get('/permissions', authenticateToken, requirePermissions('user:read'), getPermissions);

export default router;