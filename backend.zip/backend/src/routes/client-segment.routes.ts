import { Router } from 'express';
import { ClientSegmentController } from '../controllers/client-segment.controller';
import { authMiddleware } from '../middleware/auth.middleware';

const router = Router();
const clientSegmentController = new ClientSegmentController();

// Aplicar middleware de autenticação em todas as rotas
router.use(authMiddleware);

// Rotas de segmentos
router.post('/', clientSegmentController.createSegment.bind(clientSegmentController));
router.get('/', clientSegmentController.getSegments.bind(clientSegmentController));
router.get('/suggested', clientSegmentController.getSuggestedSegments.bind(clientSegmentController));
router.get('/criteria', clientSegmentController.getSegmentationCriteria.bind(clientSegmentController));
router.post('/preview', clientSegmentController.previewSegment.bind(clientSegmentController));
router.post('/update-counts', clientSegmentController.updateAllSegmentCounts.bind(clientSegmentController));

router.get('/:id', clientSegmentController.getSegmentById.bind(clientSegmentController));
router.put('/:id', clientSegmentController.updateSegment.bind(clientSegmentController));
router.delete('/:id', clientSegmentController.deleteSegment.bind(clientSegmentController));

// Clientes do segmento
router.get('/:id/clients', clientSegmentController.getSegmentClients.bind(clientSegmentController));
router.get('/:id/size', clientSegmentController.calculateSegmentSize.bind(clientSegmentController));

export default router;