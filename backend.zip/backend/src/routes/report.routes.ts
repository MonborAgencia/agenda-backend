import { Router } from 'express';
import { reportController } from '../controllers/report.controller';
import { authMiddleware } from '../middleware/auth.middleware';

const router = Router();

// Aplicar middleware de autenticação em todas as rotas
router.use(authMiddleware);

/**
 * @route POST /reports/generate/pdf
 * @desc Gerar relatório em PDF
 * @access Private
 * @body {string} tenantId - ID do tenant
 * @body {string} startDate - Data de início (ISO string)
 * @body {string} endDate - Data de fim (ISO string)
 * @body {string} [professionalId] - ID do profissional (opcional)
 * @body {string} [serviceId] - ID do serviço (opcional)
 * @body {string} [title] - Título do relatório (opcional)
 */
router.post('/generate/pdf', reportController.generatePDFReport);

/**
 * @route POST /reports/generate/excel
 * @desc Gerar relatório em Excel
 * @access Private
 * @body {string} tenantId - ID do tenant
 * @body {string} startDate - Data de início (ISO string)
 * @body {string} endDate - Data de fim (ISO string)
 * @body {string} [professionalId] - ID do profissional (opcional)
 * @body {string} [serviceId] - ID do serviço (opcional)
 * @body {string} [title] - Título do relatório (opcional)
 */
router.post('/generate/excel', reportController.generateExcelReport);

/**
 * @route GET /reports/preview
 * @desc Obter preview dos dados do relatório em JSON
 * @access Private
 * @query {string} tenantId - ID do tenant
 * @query {string} startDate - Data de início (ISO string)
 * @query {string} endDate - Data de fim (ISO string)
 * @query {string} [professionalId] - ID do profissional (opcional)
 * @query {string} [serviceId] - ID do serviço (opcional)
 */
router.get('/preview', reportController.previewReport);

/**
 * @route POST /reports/schedule
 * @desc Criar agendamento de relatório automático
 * @access Private
 * @body {string} name - Nome do relatório
 * @body {string} type - Tipo do relatório (PDF ou EXCEL)
 * @body {string} frequency - Frequência (DAILY, WEEKLY, MONTHLY)
 * @body {object} filters - Filtros para o relatório
 * @body {string[]} [recipients] - Lista de emails para envio (opcional)
 * @body {boolean} [isActive] - Se o agendamento está ativo (padrão: true)
 */
router.post('/schedule', reportController.scheduleReport);

/**
 * @route DELETE /reports/schedule/:id
 * @desc Parar agendamento de relatório automático
 * @access Private
 * @param {string} id - ID do agendamento
 */
router.delete('/schedule/:id', reportController.stopScheduledReport);

export default router;