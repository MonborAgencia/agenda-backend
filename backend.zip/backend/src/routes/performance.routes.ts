import { Router } from 'express';
import { getQueryStats, clearQueryStats } from '../middleware/query-monitor.middleware';
import { queryOptimizationService } from '../services/query-optimization.service';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

// Apply authentication requirement
router.use(authenticateToken);

/**
 * Get query performance statistics
 */
router.get('/query-stats', async (req, res) => {
  try {
    const stats = getQueryStats();
    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Error getting query stats:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter estatísticas de performance'
    });
  }
});

/**
 * Get slow queries report
 */
router.get('/slow-queries', async (req, res) => {
  try {
    const threshold = parseInt(req.query.threshold as string) || 1000;
    const stats = getQueryStats();
    
    const slowQueries = stats.slowQueries.filter(q => q.duration > threshold);
    
    res.json({
      success: true,
      data: {
        threshold,
        count: slowQueries.length,
        queries: slowQueries
      }
    });
  } catch (error) {
    console.error('Error getting slow queries:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter consultas lentas'
    });
  }
});

/**
 * Get endpoint performance analysis
 */
router.get('/endpoint-analysis', async (req, res) => {
  try {
    const stats = getQueryStats();
    const endpointStats = stats.endpointStats;
    
    // Sort by average duration (slowest first)
    const sortedEndpoints = Object.entries(endpointStats)
      .map(([endpoint, stats]) => ({ endpoint, ...stats }))
      .sort((a, b) => b.avgDuration - a.avgDuration);

    res.json({
      success: true,
      data: {
        totalEndpoints: sortedEndpoints.length,
        endpoints: sortedEndpoints
      }
    });
  } catch (error) {
    console.error('Error getting endpoint analysis:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter análise de endpoints'
    });
  }
});

/**
 * Get tenant performance comparison
 */
router.get('/tenant-performance', async (req, res) => {
  try {
    const stats = getQueryStats();
    const tenantStats = stats.tenantStats;
    
    // Sort by average duration (slowest first)
    const sortedTenants = Object.entries(tenantStats)
      .map(([tenantId, stats]) => ({ tenantId, ...stats }))
      .sort((a, b) => b.avgDuration - a.avgDuration);

    res.json({
      success: true,
      data: {
        totalTenants: sortedTenants.length,
        tenants: sortedTenants
      }
    });
  } catch (error) {
    console.error('Error getting tenant performance:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter performance por tenant'
    });
  }
});

/**
 * Get system health score
 */
router.get('/health-score', async (req, res) => {
  try {
    const stats = getQueryStats();
    const healthScore = stats.healthScore;
    
    res.json({
      success: true,
      data: healthScore
    });
  } catch (error) {
    console.error('Error getting health score:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter score de saúde do sistema'
    });
  }
});

/**
 * Clear performance statistics
 */
router.delete('/clear-stats', async (req, res) => {
  try {
    clearQueryStats();
    
    res.json({
      success: true,
      message: 'Estatísticas de performance limpas com sucesso'
    });
  } catch (error) {
    console.error('Error clearing stats:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao limpar estatísticas'
    });
  }
});

/**
 * Run database optimization
 */
router.post('/optimize-database', async (req, res) => {
  try {
    // Import the optimization function
    const { optimizeDatabase } = await import('../scripts/optimize-database');
    
    // Run optimization in background
    optimizeDatabase()
      .then(() => {
        console.log('Database optimization completed successfully');
      })
      .catch((error) => {
        console.error('Database optimization failed:', error);
      });
    
    res.json({
      success: true,
      message: 'Otimização do banco de dados iniciada em segundo plano'
    });
  } catch (error) {
    console.error('Error starting database optimization:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao iniciar otimização do banco de dados'
    });
  }
});

/**
 * Test query performance
 */
router.post('/test-query', async (req, res) => {
  try {
    const { queryType, params } = req.body;
    const tenantId = req.headers['x-tenant-id'] as string;
    
    if (!tenantId) {
      return res.status(400).json({
        success: false,
        message: 'Tenant ID é obrigatório'
      });
    }

    let result: any;
    const startTime = Date.now();

    switch (queryType) {
      case 'bookings':
        result = await queryOptimizationService.getBookingsOptimized(tenantId, params || {});
        break;
      
      case 'dashboard':
        const startDate = params?.startDate ? new Date(params.startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        const endDate = params?.endDate ? new Date(params.endDate) : new Date();
        result = await queryOptimizationService.getDashboardMetricsOptimized(tenantId, startDate, endDate);
        break;
      
      case 'search':
        result = await queryOptimizationService.searchUsersOptimized(tenantId, params?.searchTerm || 'test', params);
        break;
      
      case 'analytics':
        const analyticsStartDate = params?.startDate ? new Date(params.startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        const analyticsEndDate = params?.endDate ? new Date(params.endDate) : new Date();
        result = await queryOptimizationService.getAnalyticsOptimized(
          tenantId, 
          params?.type || 'daily', 
          analyticsStartDate, 
          analyticsEndDate
        );
        break;
      
      default:
        return res.status(400).json({
          success: false,
          message: 'Tipo de consulta não suportado'
        });
    }

    const duration = Date.now() - startTime;

    res.json({
      success: true,
      data: {
        queryType,
        duration,
        result: Array.isArray(result) ? { count: result.length, sample: result.slice(0, 5) } : result
      }
    });
  } catch (error) {
    console.error('Error testing query:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao testar consulta'
    });
  }
});

/**
 * Get performance recommendations
 */
router.get('/recommendations', async (req, res) => {
  try {
    const stats = getQueryStats();
    const recommendations: string[] = [];

    // Analyze performance and generate recommendations
    const healthScore = stats.healthScore;
    const endpointStats = stats.endpointStats;
    const slowQueries = stats.slowQueries;

    // General recommendations based on health score
    if (healthScore.score < 70) {
      recommendations.push('Sistema com performance abaixo do ideal - considere otimizações urgentes');
    }

    // Slow query recommendations
    if (slowQueries.length > 0) {
      const slowEndpoints = Object.entries(endpointStats)
        .filter(([_, stats]) => stats.avgDuration > 1000)
        .map(([endpoint]) => endpoint);
      
      if (slowEndpoints.length > 0) {
        recommendations.push(`Endpoints lentos detectados: ${slowEndpoints.join(', ')}`);
        recommendations.push('Considere adicionar cache ou otimizar queries destes endpoints');
      }
    }

    // Cache recommendations
    recommendations.push('Implemente cache Redis para consultas frequentes');
    recommendations.push('Use paginação em listagens grandes');
    recommendations.push('Otimize queries com índices apropriados');

    // Database recommendations
    recommendations.push('Execute ANALYZE nas tabelas principais regularmente');
    recommendations.push('Monitore o crescimento do banco de dados');
    recommendations.push('Considere arquivamento de dados antigos');

    res.json({
      success: true,
      data: {
        healthScore: healthScore.score,
        status: healthScore.status,
        issues: healthScore.issues,
        recommendations
      }
    });
  } catch (error) {
    console.error('Error getting recommendations:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter recomendações'
    });
  }
});

export default router;