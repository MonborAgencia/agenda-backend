import { Router } from 'express';
import { reviewController } from '../controllers/review.controller';
import { authenticateToken, requireRoles } from '../middleware/auth.middleware';

const router = Router();

// Aplicar middleware de autenticação em todas as rotas
router.use(authenticateToken);

// Rotas para avaliações
router.post('/', reviewController.createReview);
router.get('/', reviewController.getReviews);
router.get('/stats', reviewController.getReviewStats);
router.get('/:id', reviewController.getReviewById);
router.put('/:id', reviewController.updateReview);
router.delete('/:id', reviewController.deleteReview);

// Rotas para moderação (admin)
router.put('/:id/moderate', requireRoles('ADMIN'), reviewController.moderateReview);

// Rotas para respostas dos profissionais
router.post('/:id/response', reviewController.createReviewResponse);
router.put('/:id/response', reviewController.updateReviewResponse);
router.delete('/:id/response', reviewController.deleteReviewResponse);

// Rotas para estatísticas por profissional
router.get('/professional/:professionalId/stats', reviewController.getProfessionalReviewStats);

export { router as reviewRoutes };