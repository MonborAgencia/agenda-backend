import { Router } from 'express';
import { CampaignController } from '../controllers/campaign.controller';
import { authMiddleware } from '../middleware/auth.middleware';

const router = Router();
const campaignController = new CampaignController();

// Aplicar middleware de autenticação em todas as rotas
router.use(authMiddleware);

// Rotas de campanhas
router.post('/', campaignController.createCampaign.bind(campaignController));
router.get('/', campaignController.getCampaigns.bind(campaignController));
router.get('/analytics', campaignController.getCampaignAnalytics.bind(campaignController));
router.get('/templates', campaignController.getCampaignTemplates.bind(campaignController));
router.get('/:id', campaignController.getCampaignById.bind(campaignController));
router.put('/:id', campaignController.updateCampaign.bind(campaignController));
router.delete('/:id', campaignController.deleteCampaign.bind(campaignController));

// Ações de campanha
router.post('/:id/execute', campaignController.executeCampaign.bind(campaignController));
router.post('/:id/pause', campaignController.pauseCampaign.bind(campaignController));
router.post('/:id/activate', campaignController.activateCampaign.bind(campaignController));
router.post('/:id/cancel', campaignController.cancelCampaign.bind(campaignController));

// Execuções e relatórios
router.get('/:id/executions', campaignController.getCampaignExecutions.bind(campaignController));
router.get('/:id/report', campaignController.getCampaignReport.bind(campaignController));

export default router;