import { Router } from 'express';
import {
  login,
  register,
  refreshToken,
  logout,
  getCurrentUser,
  changePassword,
  requestPasswordReset,
  verifyEmail,
} from '../controllers/auth.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

/**
 * @route POST /auth/login
 * @desc Login user
 * @access Public
 */
router.post('/login', login);

/**
 * @route POST /auth/register
 * @desc Register new user
 * @access Public
 */
router.post('/register', register);

/**
 * @route POST /auth/refresh
 * @desc Refresh access token
 * @access Public
 */
router.post('/refresh', refreshToken);

/**
 * @route POST /auth/logout
 * @desc Logout user
 * @access Private
 */
router.post('/logout', authenticateToken, logout);

/**
 * @route GET /auth/me
 * @desc Get current user
 * @access Private
 */
router.get('/me', authenticateToken, getCurrentUser);

/**
 * @route PUT /auth/change-password
 * @desc Change user password
 * @access Private
 */
router.put('/change-password', authenticateToken, changePassword);

/**
 * @route POST /auth/request-password-reset
 * @desc Request password reset
 * @access Public
 */
router.post('/request-password-reset', requestPasswordReset);

/**
 * @route GET /auth/verify-email/:token
 * @desc Verify user email
 * @access Public
 */
router.get('/verify-email/:token', verifyEmail);

export default router;