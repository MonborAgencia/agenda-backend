import { Router } from 'express';
import { analyticsController } from '../controllers/analytics.controller';
import { authMiddleware } from '../middleware/auth.middleware';

const router = Router();

// Aplicar middleware de autenticação em todas as rotas
router.use(authMiddleware);

/**
 * @route GET /analytics/dashboard
 * @desc Obter métricas completas do dashboard
 * @access Private
 * @query {string} tenantId - ID do tenant
 * @query {string} startDate - Data de início (ISO string)
 * @query {string} endDate - Data de fim (ISO string)
 * @query {string} [professionalId] - ID do profissional (opcional)
 * @query {string} [serviceId] - ID do serviço (opcional)
 * @query {string} [status] - Status dos agendamentos, separados por vírgula (opcional)
 */
router.get('/dashboard', analyticsController.getDashboardMetrics);

/**
 * @route GET /analytics/occupancy
 * @desc Obter métricas de ocupação da agenda
 * @access Private
 * @query {string} tenantId - ID do tenant
 * @query {string} startDate - Data de início (ISO string)
 * @query {string} endDate - Data de fim (ISO string)
 * @query {string} [professionalId] - ID do profissional (opcional)
 */
router.get('/occupancy', analyticsController.getOccupancyMetrics);

/**
 * @route GET /analytics/revenue
 * @desc Obter métricas de faturamento
 * @access Private
 * @query {string} tenantId - ID do tenant
 * @query {string} startDate - Data de início (ISO string)
 * @query {string} endDate - Data de fim (ISO string)
 * @query {string} [professionalId] - ID do profissional (opcional)
 * @query {string} [serviceId] - ID do serviço (opcional)
 */
router.get('/revenue', analyticsController.getRevenueMetrics);

/**
 * @route GET /analytics/profitable-hours
 * @desc Obter análise de horários mais rentáveis
 * @access Private
 * @query {string} tenantId - ID do tenant
 * @query {string} startDate - Data de início (ISO string)
 * @query {string} endDate - Data de fim (ISO string)
 * @query {string} [professionalId] - ID do profissional (opcional)
 */
router.get('/profitable-hours', analyticsController.getProfitableHours);

/**
 * @route GET /analytics/services
 * @desc Obter métricas por serviço
 * @access Private
 * @query {string} tenantId - ID do tenant
 * @query {string} startDate - Data de início (ISO string)
 * @query {string} endDate - Data de fim (ISO string)
 * @query {string} [professionalId] - ID do profissional (opcional)
 */
router.get('/services', analyticsController.getServiceMetrics);

/**
 * @route GET /analytics/professionals
 * @desc Obter métricas por profissional
 * @access Private
 * @query {string} tenantId - ID do tenant
 * @query {string} startDate - Data de início (ISO string)
 * @query {string} endDate - Data de fim (ISO string)
 */
router.get('/professionals', analyticsController.getProfessionalMetrics);

export default router;