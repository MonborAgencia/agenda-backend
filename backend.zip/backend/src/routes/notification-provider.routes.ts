import { Router } from 'express';
import { notificationProviderController } from '../controllers/notification-provider.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

// Rotas públicas (webhooks)
router.get('/whatsapp/webhook', notificationProviderController.whatsappWebhook);
router.post('/whatsapp/webhook', notificationProviderController.whatsappWebhook);

// Aplicar middleware de autenticação nas demais rotas
router.use(authenticateToken);

// Rotas para gerenciamento de providers
router.get('/status', notificationProviderController.getProvidersStatus);
router.get('/test/:type', notificationProviderController.testProvider);
router.post('/reconfigure/:type', notificationProviderController.reconfigureProvider);

// Rotas para estatísticas
router.get('/stats/delivery', notificationProviderController.getDeliveryStats);

// Rotas para preferências de usuário
router.get('/users/:userId/preferred', notificationProviderController.getPreferredProvider);
router.post('/users/:userId/preferred', notificationProviderController.setPreferredProvider);

// Rotas para push tokens
router.post('/users/:userId/push-token', notificationProviderController.addPushToken);
router.delete('/users/:userId/push-token', notificationProviderController.removePushToken);

// Rotas para push notifications
router.post('/push/topic', notificationProviderController.sendToTopic);

export { router as notificationProviderRoutes };