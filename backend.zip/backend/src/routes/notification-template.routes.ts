import { Router } from 'express';
import { notificationTemplateController } from '../controllers/notification-template.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

// Aplicar middleware de autenticação em todas as rotas
router.use(authenticateToken);

// Rotas para templates de notificação
router.post('/', notificationTemplateController.createTemplate);
router.get('/', notificationTemplateController.getTemplates);
router.get('/:id', notificationTemplateController.getTemplateById);
router.put('/:id', notificationTemplateController.updateTemplate);
router.delete('/:id', notificationTemplateController.deleteTemplate);

// Rotas para renderização de templates
router.post('/:id/render', notificationTemplateController.renderTemplate);
router.post('/render/:name', notificationTemplateController.renderTemplateByName);

// Rotas para validação e utilitários
router.post('/validate', notificationTemplateController.validateTemplate);
router.post('/default', notificationTemplateController.createDefaultTemplates);
router.post('/:id/duplicate', notificationTemplateController.duplicateTemplate);

// Rotas para estatísticas
router.get('/:id/stats', notificationTemplateController.getTemplateStats);

export { router as notificationTemplateRoutes };