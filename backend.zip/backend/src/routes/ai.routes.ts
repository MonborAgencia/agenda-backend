import { Router } from 'express';
import { AIController } from '../controllers/ai.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();
const aiController = new AIController();

// Todas as rotas requerem autenticação
router.use(authenticateToken);

// Rotas do chatbot
router.post('/chat', aiController.chat);
router.post('/sessions', aiController.createSession);
router.get('/sessions/:sessionId/history', aiController.getChatHistory);

// Rotas de recomendações
router.get('/recommendations', aiController.getRecommendations);

// Rotas de insights (apenas para admins e profissionais)
router.get('/insights', aiController.getInsights);

// Rotas de sugestões de campanha (apenas para admins)
router.get('/campaign-suggestions', aiController.getCampaignSuggestions);

export { router as aiRoutes };