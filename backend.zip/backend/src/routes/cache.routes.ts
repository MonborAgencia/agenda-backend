import { Router } from 'express';
import { cacheMetricsService } from '../services/cache-metrics.service';
import { cacheService } from '../services/cache.service';
import { cacheInvalidationService } from '../services/cache-invalidation.service';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

// Apply authentication requirement
router.use(authenticateToken);

/**
 * Get cache metrics
 */
router.get('/metrics', async (req, res) => {
  try {
    const metrics = await cacheMetricsService.getDetailedMetrics();
    res.json({
      success: true,
      data: metrics
    });
  } catch (error) {
    console.error('Error getting cache metrics:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter métricas do cache'
    });
  }
});

/**
 * Get cache performance report
 */
router.get('/performance-report', async (req, res) => {
  try {
    const report = await cacheMetricsService.getPerformanceReport();
    res.json({
      success: true,
      data: report
    });
  } catch (error) {
    console.error('Error getting cache performance report:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter relatório de performance do cache'
    });
  }
});

/**
 * Get cache health status
 */
router.get('/health', async (req, res) => {
  try {
    const health = await cacheMetricsService.getHealthStatus();
    res.json({
      success: true,
      data: health
    });
  } catch (error) {
    console.error('Error getting cache health:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter status de saúde do cache'
    });
  }
});

/**
 * Get cache hit rate trend
 */
router.get('/hit-rate-trend', async (req, res) => {
  try {
    const minutes = parseInt(req.query.minutes as string) || 60;
    const trend = cacheMetricsService.getHitRateTrend(minutes);
    res.json({
      success: true,
      data: trend
    });
  } catch (error) {
    console.error('Error getting hit rate trend:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter tendência de hit rate'
    });
  }
});

/**
 * Get memory usage trend
 */
router.get('/memory-trend', async (req, res) => {
  try {
    const minutes = parseInt(req.query.minutes as string) || 60;
    const trend = cacheMetricsService.getMemoryUsageTrend(minutes);
    res.json({
      success: true,
      data: trend
    });
  } catch (error) {
    console.error('Error getting memory trend:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter tendência de uso de memória'
    });
  }
});

/**
 * Clear cache by pattern
 */
router.delete('/clear', async (req, res) => {
  try {
    const { pattern, tenantId } = req.body;
    
    if (!pattern) {
      return res.status(400).json({
        success: false,
        message: 'Pattern é obrigatório'
      });
    }

    const deletedCount = await cacheInvalidationService.invalidatePattern(pattern, tenantId);
    
    res.json({
      success: true,
      message: `Cache limpo com sucesso. ${deletedCount} chaves removidas.`,
      data: { deletedCount }
    });
  } catch (error) {
    console.error('Error clearing cache:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao limpar cache'
    });
  }
});

/**
 * Clear all tenant cache
 */
router.delete('/clear-tenant/:tenantId', async (req, res) => {
  try {
    const { tenantId } = req.params;
    await cacheInvalidationService.invalidateTenant(tenantId);
    
    res.json({
      success: true,
      message: 'Cache do tenant limpo com sucesso'
    });
  } catch (error) {
    console.error('Error clearing tenant cache:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao limpar cache do tenant'
    });
  }
});

/**
 * Clear user-specific cache
 */
router.delete('/clear-user/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const tenantId = req.headers['x-tenant-id'] as string;
    
    await cacheInvalidationService.invalidateUser(userId, tenantId);
    
    res.json({
      success: true,
      message: 'Cache do usuário limpo com sucesso'
    });
  } catch (error) {
    console.error('Error clearing user cache:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao limpar cache do usuário'
    });
  }
});

/**
 * Clear date-specific cache
 */
router.delete('/clear-date/:date', async (req, res) => {
  try {
    const { date } = req.params;
    const tenantId = req.headers['x-tenant-id'] as string;
    
    await cacheInvalidationService.invalidateDate(date, tenantId);
    
    res.json({
      success: true,
      message: 'Cache da data limpo com sucesso'
    });
  } catch (error) {
    console.error('Error clearing date cache:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao limpar cache da data'
    });
  }
});

/**
 * Get invalidation rules
 */
router.get('/invalidation-rules', async (req, res) => {
  try {
    const rules = cacheInvalidationService.getInvalidationRules();
    const rulesObject = Object.fromEntries(rules);
    
    res.json({
      success: true,
      data: rulesObject
    });
  } catch (error) {
    console.error('Error getting invalidation rules:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao obter regras de invalidação'
    });
  }
});

/**
 * Clear metrics history
 */
router.delete('/metrics-history', async (req, res) => {
  try {
    cacheMetricsService.clearHistory();
    cacheService.clearMetrics();
    
    res.json({
      success: true,
      message: 'Histórico de métricas limpo com sucesso'
    });
  } catch (error) {
    console.error('Error clearing metrics history:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao limpar histórico de métricas'
    });
  }
});

export default router;