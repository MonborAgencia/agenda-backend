import { Router } from 'express';
import path from 'path';
import fs from 'fs';
import { Request, Response } from 'express';

const router = Router();

/**
 * Serve tenant logos
 */
router.get('/tenants/logos/:filename', (req: Request, res: Response) => {
  const { filename } = req.params;
  const filePath = path.join(process.cwd(), 'uploads', 'tenants', 'logos', filename);
  
  // Verificar se arquivo existe
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({
      error: 'FILE_NOT_FOUND',
      message: 'Arquivo não encontrado',
    });
  }

  // Definir headers apropriados
  const ext = path.extname(filename).toLowerCase();
  const mimeTypes: { [key: string]: string } = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.webp': 'image/webp',
  };

  const mimeType = mimeTypes[ext] || 'application/octet-stream';
  
  res.setHeader('Content-Type', mimeType);
  res.setHeader('Cache-Control', 'public, max-age=31536000'); // Cache por 1 ano
  
  res.sendFile(filePath);
});

/**
 * Serve tenant favicons
 */
router.get('/tenants/favicons/:filename', (req: Request, res: Response) => {
  const { filename } = req.params;
  const filePath = path.join(process.cwd(), 'uploads', 'tenants', 'favicons', filename);
  
  // Verificar se arquivo existe
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({
      error: 'FILE_NOT_FOUND',
      message: 'Arquivo não encontrado',
    });
  }

  // Definir headers apropriados
  const ext = path.extname(filename).toLowerCase();
  const mimeTypes: { [key: string]: string } = {
    '.ico': 'image/x-icon',
    '.png': 'image/png',
    '.svg': 'image/svg+xml',
  };

  const mimeType = mimeTypes[ext] || 'application/octet-stream';
  
  res.setHeader('Content-Type', mimeType);
  res.setHeader('Cache-Control', 'public, max-age=31536000'); // Cache por 1 ano
  
  res.sendFile(filePath);
});

/**
 * Serve user avatars (existing functionality)
 */
router.get('/avatars/:filename', (req: Request, res: Response) => {
  const { filename } = req.params;
  const filePath = path.join(process.cwd(), 'uploads', 'avatars', filename);
  
  // Verificar se arquivo existe
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({
      error: 'FILE_NOT_FOUND',
      message: 'Arquivo não encontrado',
    });
  }

  // Definir headers apropriados
  const ext = path.extname(filename).toLowerCase();
  const mimeTypes: { [key: string]: string } = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.webp': 'image/webp',
  };

  const mimeType = mimeTypes[ext] || 'application/octet-stream';
  
  res.setHeader('Content-Type', mimeType);
  res.setHeader('Cache-Control', 'public, max-age=31536000'); // Cache por 1 ano
  
  res.sendFile(filePath);
});

export default router;