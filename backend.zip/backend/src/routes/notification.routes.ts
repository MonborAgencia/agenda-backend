import { Router } from 'express';
import { notificationController } from '../controllers/notification.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

// Aplicar middleware de autenticação em todas as rotas
router.use(authenticateToken);

// Rotas para notificações
router.post('/', notificationController.createNotification);
router.post('/enqueue', notificationController.createAndEnqueueNotification);
router.get('/', notificationController.getNotifications);
router.get('/stats', notificationController.getNotificationStats);
router.get('/:id', notificationController.getNotificationById);

// Rotas para gerenciamento da fila
router.post('/:id/enqueue', notificationController.enqueueNotification);
router.post('/:id/cancel', notificationController.cancelNotification);
router.get('/queue/info', notificationController.getQueueInfo);
router.post('/queue/clear', notificationController.clearQueue);

// Rotas para reprocessamento
router.post('/failed/reprocess', notificationController.reprocessFailedNotifications);

// Rotas para controle do worker
router.post('/worker/control', notificationController.controlWorker);

export { router as notificationRoutes };