import { Router } from 'express';
import {
  getTenants,
  createTenant,
  updateTenant,
  deleteTenant,
  getTenantSettings,
  updateTenantSettings,
  uploadTenantLogo,
  uploadTenantFavicon,
  getTenantStats,
  getCustomFields,
  addCustomField,
  updateCustomField,
  removeCustomField,
} from '../controllers/tenant.controller';
import {
  authenticateToken,
  requirePermissions,
} from '../middleware/auth.middleware';
import {
  uploadLogo,
  uploadFavicon,
  handleTenantUploadError,
} from '../middleware/tenant-upload.middleware';
import {
  extractTenant,
  requireTenant,
  validateTenantAccess,
  addTenantFilter,
  logTenantAction,
} from '../middleware/tenant.middleware';

const router = Router();

// Apply tenant extraction middleware to all routes
router.use(extractTenant);

/**
 * @route GET /tenants
 * @desc Get all tenants
 * @access Private (requires tenant:read permission)
 */
router.get('/', authenticateToken, requirePermissions('tenant:read'), getTenants);

/**
 * @route POST /tenants
 * @desc Create new tenant
 * @access Private (requires tenant:create permission)
 */
router.post('/', 
  authenticateToken, 
  requirePermissions('tenant:create'), 
  logTenantAction('CREATE_TENANT'),
  createTenant
);

/**
 * @route GET /tenants/:tenantId/settings
 * @desc Get tenant settings
 * @access Private (requires tenant:read permission)
 */
router.get('/:tenantId/settings', 
  authenticateToken, 
  requirePermissions('tenant:read'), 
  validateTenantAccess,
  getTenantSettings
);

/**
 * @route PUT /tenants/:tenantId
 * @desc Update tenant basic info
 * @access Private (requires tenant:update permission)
 */
router.put('/:tenantId', 
  authenticateToken, 
  requirePermissions('tenant:update'), 
  validateTenantAccess,
  logTenantAction('UPDATE_TENANT'),
  updateTenant
);

/**
 * @route DELETE /tenants/:tenantId
 * @desc Delete tenant
 * @access Private (requires tenant:delete permission)
 */
router.delete('/:tenantId', 
  authenticateToken, 
  requirePermissions('tenant:delete'), 
  validateTenantAccess,
  logTenantAction('DELETE_TENANT'),
  deleteTenant
);

/**
 * @route PUT /tenants/:tenantId/settings
 * @desc Update tenant settings
 * @access Private (requires tenant:update permission)
 */
router.put('/:tenantId/settings', 
  authenticateToken, 
  requirePermissions('tenant:update'), 
  validateTenantAccess,
  addTenantFilter,
  logTenantAction('UPDATE_TENANT_SETTINGS'),
  updateTenantSettings
);

/**
 * @route POST /tenants/:tenantId/logo
 * @desc Upload tenant logo
 * @access Private (requires tenant:update permission)
 */
router.post('/:tenantId/logo', 
  authenticateToken, 
  requirePermissions('tenant:update'), 
  validateTenantAccess,
  uploadLogo.single('logo'),
  handleTenantUploadError,
  logTenantAction('UPLOAD_LOGO'),
  uploadTenantLogo
);

/**
 * @route POST /tenants/:tenantId/favicon
 * @desc Upload tenant favicon
 * @access Private (requires tenant:update permission)
 */
router.post('/:tenantId/favicon', 
  authenticateToken, 
  requirePermissions('tenant:update'), 
  validateTenantAccess,
  uploadFavicon.single('favicon'),
  handleTenantUploadError,
  logTenantAction('UPLOAD_FAVICON'),
  uploadTenantFavicon
);

/**
 * @route GET /tenants/:tenantId/stats
 * @desc Get tenant statistics
 * @access Private (requires tenant:read permission)
 */
router.get('/:tenantId/stats', 
  authenticateToken, 
  requirePermissions('tenant:read'), 
  validateTenantAccess,
  getTenantStats
);

/**
 * @route GET /tenants/:tenantId/custom-fields/:userType
 * @desc Get custom fields for user type
 * @access Private (requires tenant:read permission)
 */
router.get('/:tenantId/custom-fields/:userType', 
  authenticateToken, 
  requirePermissions('tenant:read'), 
  validateTenantAccess,
  getCustomFields
);

/**
 * @route POST /tenants/:tenantId/custom-fields/:userType
 * @desc Add custom field for user type
 * @access Private (requires tenant:update permission)
 */
router.post('/:tenantId/custom-fields/:userType', 
  authenticateToken, 
  requirePermissions('tenant:update'), 
  validateTenantAccess,
  addTenantFilter,
  logTenantAction('ADD_CUSTOM_FIELD'),
  addCustomField
);

/**
 * @route PUT /tenants/:tenantId/custom-fields/:userType/:fieldId
 * @desc Update custom field
 * @access Private (requires tenant:update permission)
 */
router.put('/:tenantId/custom-fields/:userType/:fieldId', 
  authenticateToken, 
  requirePermissions('tenant:update'), 
  validateTenantAccess,
  logTenantAction('UPDATE_CUSTOM_FIELD'),
  updateCustomField
);

/**
 * @route DELETE /tenants/:tenantId/custom-fields/:userType/:fieldId
 * @desc Remove custom field
 * @access Private (requires tenant:update permission)
 */
router.delete('/:tenantId/custom-fields/:userType/:fieldId', 
  authenticateToken, 
  requirePermissions('tenant:update'), 
  validateTenantAccess,
  logTenantAction('REMOVE_CUSTOM_FIELD'),
  removeCustomField
);

export default router;