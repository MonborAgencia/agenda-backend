import { Router } from 'express';
import { scheduleController } from '../controllers/schedule.controller';
import { authenticateToken } from '../middleware/auth.middleware';

const router = Router();

// Aplicar middleware de autenticação em todas as rotas
router.use(authenticateToken);

// Rotas de horários
router.post('/', scheduleController.createSchedule);
router.get('/professional/:professionalId', scheduleController.getSchedulesByProfessional);
router.get('/professional/:professionalId/availability', scheduleController.getDayAvailability);
router.put('/weekly', scheduleController.setWeeklySchedule);
router.put('/:id', scheduleController.updateSchedule);
router.delete('/:id', scheduleController.deleteSchedule);

// Rotas de visualização de agenda
router.get('/agenda/daily/:date', scheduleController.getDailyAgenda);
router.get('/agenda/weekly/:startDate', scheduleController.getWeeklyAgenda);
router.get('/agenda/monthly/:year/:month', scheduleController.getMonthlyAgenda);

// Rotas de slots disponíveis
router.post('/slots/generate', scheduleController.generateAvailableSlots);
router.post('/slots/reserve', scheduleController.reserveSlotTemporarily);
router.delete('/slots/reserve/:slotId', scheduleController.releaseSlotReservation);
router.get('/slots/reserve/:slotId', scheduleController.getSlotReservation);

// Rotas de exceções
router.post('/exceptions', scheduleController.createScheduleException);
router.put('/exceptions/:id', scheduleController.updateScheduleException);
router.delete('/exceptions/:id', scheduleController.deleteScheduleException);

export default router;