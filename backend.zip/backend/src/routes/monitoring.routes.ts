import { Router, Request, Response } from 'express';
import MetricsService from '../services/metrics.service';
import HealthService from '../services/health.service';
import LoggerUtils from '../utils/logger.utils';
import { authenticateToken, requireRoles } from '../middleware/auth.middleware';

const router = Router();
const healthService = new HealthService();

/**
 * Endpoint para métricas Prometheus
 * GET /api/monitoring/metrics
 */
router.get('/metrics', async (req: Request, res: Response) => {
  try {
    const metrics = await MetricsService.getMetrics();
    
    res.set('Content-Type', 'text/plain; version=0.0.4; charset=utf-8');
    res.send(metrics);
    
    LoggerUtils.info('Metrics endpoint accessed', {
      category: 'MONITORING',
      endpoint: 'METRICS',
      userAgent: req.get('User-Agent')
    });
  } catch (error) {
    LoggerUtils.error('Failed to get metrics', error as Error, {
      category: 'MONITORING',
      endpoint: 'METRICS'
    });
    
    res.status(500).json({
      error: 'METRICS_ERROR',
      message: 'Failed to retrieve metrics'
    });
  }
});

/**
 * Endpoint para health check básico
 * GET /api/monitoring/health
 */
router.get('/health', async (req: Request, res: Response) => {
  try {
    const healthResult = await healthService.performHealthCheck();
    
    const statusCode = healthResult.status === 'healthy' ? 200 : 
                      healthResult.status === 'degraded' ? 200 : 503;
    
    res.status(statusCode).json(healthResult);
    
    LoggerUtils.info('Health check endpoint accessed', {
      category: 'MONITORING',
      endpoint: 'HEALTH',
      status: healthResult.status,
      userAgent: req.get('User-Agent')
    });
  } catch (error) {
    LoggerUtils.error('Health check failed', error as Error, {
      category: 'MONITORING',
      endpoint: 'HEALTH'
    });
    
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: 'Health check failed',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

/**
 * Endpoint para health check simples (para load balancers)
 * GET /api/monitoring/ping
 */
router.get('/ping', (req: Request, res: Response) => {
  res.status(200).json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

/**
 * Endpoint para informações do sistema (requer autenticação)
 * GET /api/monitoring/system
 */
router.get('/system', authenticateToken, async (req: Request, res: Response) => {
  try {
    const memUsage = process.memoryUsage();
    const cpuUsage = process.cpuUsage();
    
    const systemInfo = {
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || 'development',
      version: process.env.APP_VERSION || '1.0.0',
      node_version: process.version,
      platform: process.platform,
      arch: process.arch,
      memory: {
        rss: Math.round(memUsage.rss / 1024 / 1024),
        heap_used: Math.round(memUsage.heapUsed / 1024 / 1024),
        heap_total: Math.round(memUsage.heapTotal / 1024 / 1024),
        external: Math.round(memUsage.external / 1024 / 1024)
      },
      cpu: {
        user: cpuUsage.user,
        system: cpuUsage.system
      },
      active_connections: parseInt(process.env.ACTIVE_CONNECTIONS || '0')
    };
    
    res.json(systemInfo);
    
    LoggerUtils.info('System info endpoint accessed', {
      category: 'MONITORING',
      endpoint: 'SYSTEM',
      userId: (req as any).user?.userId
    });
  } catch (error) {
    LoggerUtils.error('Failed to get system info', error as Error, {
      category: 'MONITORING',
      endpoint: 'SYSTEM'
    });
    
    res.status(500).json({
      error: 'SYSTEM_INFO_ERROR',
      message: 'Failed to retrieve system information'
    });
  }
});

/**
 * Endpoint para limpar métricas (requer autenticação de admin)
 * POST /api/monitoring/metrics/clear
 */
router.post('/metrics/clear', authenticateToken, requireRoles('ADMIN'), async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    
    // O middleware requireRoles('ADMIN') já verifica se é admin
    
    MetricsService.clearMetrics();
    
    res.json({
      success: true,
      message: 'Metrics cleared successfully',
      timestamp: new Date().toISOString()
    });
    
    LoggerUtils.info('Metrics cleared', {
      category: 'MONITORING',
      endpoint: 'METRICS_CLEAR',
      userId: user.userId,
      action: 'CLEAR_METRICS'
    });
  } catch (error) {
    LoggerUtils.error('Failed to clear metrics', error as Error, {
      category: 'MONITORING',
      endpoint: 'METRICS_CLEAR'
    });
    
    res.status(500).json({
      error: 'CLEAR_METRICS_ERROR',
      message: 'Failed to clear metrics'
    });
  }
});

/**
 * Endpoint para obter métricas específicas (requer autenticação)
 * GET /api/monitoring/metrics/:name
 */
router.get('/metrics/:name', authenticateToken, async (req: Request, res: Response) => {
  try {
    const { name } = req.params;
    const metric = MetricsService.getMetric(name);
    
    if (!metric) {
      return res.status(404).json({
        error: 'METRIC_NOT_FOUND',
        message: `Metric '${name}' not found`
      });
    }
    
    res.json({
      name,
      metric: metric.get(),
      timestamp: new Date().toISOString()
    });
    
    LoggerUtils.info('Specific metric accessed', {
      category: 'MONITORING',
      endpoint: 'SPECIFIC_METRIC',
      metricName: name,
      userId: (req as any).user?.userId
    });
  } catch (error) {
    LoggerUtils.error('Failed to get specific metric', error as Error, {
      category: 'MONITORING',
      endpoint: 'SPECIFIC_METRIC',
      metricName: req.params.name
    });
    
    res.status(500).json({
      error: 'METRIC_ERROR',
      message: 'Failed to retrieve metric'
    });
  }
});

/**
 * Endpoint para alertas de saúde (webhook para sistemas de monitoramento)
 * POST /api/monitoring/alerts
 */
router.post('/alerts', async (req: Request, res: Response) => {
  try {
    const { alert_type, severity, message, details } = req.body;
    
    if (!alert_type || !severity || !message) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: 'alert_type, severity, and message are required'
      });
    }
    
    // Log do alerta
    LoggerUtils.warn(`Alert received: ${alert_type}`, {
      category: 'MONITORING',
      endpoint: 'ALERTS',
      alertType: alert_type,
      severity,
      message,
      details
    });
    
    // Registrar métrica de alerta
    MetricsService.recordError(alert_type, 'monitoring', undefined);
    
    res.json({
      success: true,
      message: 'Alert received and logged',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    LoggerUtils.error('Failed to process alert', error as Error, {
      category: 'MONITORING',
      endpoint: 'ALERTS'
    });
    
    res.status(500).json({
      error: 'ALERT_PROCESSING_ERROR',
      message: 'Failed to process alert'
    });
  }
});

export default router;