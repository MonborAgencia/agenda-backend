#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import LoggerUtils from '../utils/logger.utils';

/**
 * Script para limpeza automática de logs antigos
 */
class LogCleanup {
  private logsDir: string;
  private maxAgeInDays: number;

  constructor(logsDir: string = 'logs', maxAgeInDays: number = 30) {
    this.logsDir = path.resolve(logsDir);
    this.maxAgeInDays = maxAgeInDays;
  }

  /**
   * Executar limpeza de logs
   */
  async cleanup(): Promise<void> {
    try {
      LoggerUtils.info('Starting log cleanup', {
        category: 'LOG_CLEANUP',
        logsDir: this.logsDir,
        maxAgeInDays: this.maxAgeInDays
      });

      if (!fs.existsSync(this.logsDir)) {
        LoggerUtils.warn('Logs directory does not exist', {
          category: 'LOG_CLEANUP',
          logsDir: this.logsDir
        });
        return;
      }

      const files = fs.readdirSync(this.logsDir);
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - this.maxAgeInDays);

      let deletedCount = 0;
      let totalSize = 0;

      for (const file of files) {
        const filePath = path.join(this.logsDir, file);
        const stats = fs.statSync(filePath);

        if (stats.isFile() && stats.mtime < cutoffDate) {
          try {
            totalSize += stats.size;
            fs.unlinkSync(filePath);
            deletedCount++;
            
            LoggerUtils.debug('Deleted old log file', {
              category: 'LOG_CLEANUP',
              file,
              size: stats.size,
              lastModified: stats.mtime
            });
          } catch (error) {
            LoggerUtils.error(`Failed to delete log file: ${file}`, error as Error, {
              category: 'LOG_CLEANUP'
            });
          }
        }
      }

      LoggerUtils.info('Log cleanup completed', {
        category: 'LOG_CLEANUP',
        deletedFiles: deletedCount,
        totalSizeDeleted: totalSize,
        cutoffDate: cutoffDate.toISOString()
      });

    } catch (error) {
      LoggerUtils.error('Log cleanup failed', error as Error, {
        category: 'LOG_CLEANUP'
      });
      throw error;
    }
  }

  /**
   * Obter estatísticas dos logs
   */
  getLogStats(): { totalFiles: number; totalSize: number; oldestFile: Date | null; newestFile: Date | null } {
    if (!fs.existsSync(this.logsDir)) {
      return { totalFiles: 0, totalSize: 0, oldestFile: null, newestFile: null };
    }

    const files = fs.readdirSync(this.logsDir);
    let totalFiles = 0;
    let totalSize = 0;
    let oldestFile: Date | null = null;
    let newestFile: Date | null = null;

    for (const file of files) {
      const filePath = path.join(this.logsDir, file);
      const stats = fs.statSync(filePath);

      if (stats.isFile()) {
        totalFiles++;
        totalSize += stats.size;

        if (!oldestFile || stats.mtime < oldestFile) {
          oldestFile = stats.mtime;
        }

        if (!newestFile || stats.mtime > newestFile) {
          newestFile = stats.mtime;
        }
      }
    }

    return { totalFiles, totalSize, oldestFile, newestFile };
  }
}

// Executar se chamado diretamente
if (require.main === module) {
  const cleanup = new LogCleanup();
  
  // Mostrar estatísticas antes da limpeza
  const statsBefore = cleanup.getLogStats();
  console.log('Log statistics before cleanup:', statsBefore);
  
  cleanup.cleanup()
    .then(() => {
      // Mostrar estatísticas após a limpeza
      const statsAfter = cleanup.getLogStats();
      console.log('Log statistics after cleanup:', statsAfter);
      console.log('Log cleanup completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Log cleanup failed:', error);
      process.exit(1);
    });
}

export default LogCleanup;