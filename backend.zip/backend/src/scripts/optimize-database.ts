import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

/**
 * Script to optimize database with proper indexes
 * Run this script to apply performance optimizations
 */
async function optimizeDatabase() {
  console.log('Starting database optimization...');

  try {
    // For SQLite, we need to create indexes manually
    // In production with PostgreSQL, these would be in migration files
    
    const optimizationQueries = [
      // User table indexes
      'CREATE INDEX IF NOT EXISTS idx_users_tenant_id ON users(tenantId);',
      'CREATE INDEX IF NOT EXISTS idx_users_email_tenant ON users(email, tenantId);',
      'CREATE INDEX IF NOT EXISTS idx_users_active_tenant ON users(isActive, tenantId);',
      'CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(createdAt);',

      // Professional table indexes
      'CREATE INDEX IF NOT EXISTS idx_professionals_tenant_id ON professionals(tenantId);',
      'CREATE INDEX IF NOT EXISTS idx_professionals_user_tenant ON professionals(userId, tenantId);',

      // Service table indexes
      'CREATE INDEX IF NOT EXISTS idx_services_tenant_active ON services(tenantId, isActive);',
      'CREATE INDEX IF NOT EXISTS idx_services_professional_active ON services(professionalId, isActive);',
      'CREATE INDEX IF NOT EXISTS idx_services_category_tenant ON services(category, tenantId);',
      'CREATE INDEX IF NOT EXISTS idx_services_price ON services(price);',

      // Schedule table indexes
      'CREATE INDEX IF NOT EXISTS idx_schedules_professional_day ON schedules(professionalId, dayOfWeek);',
      'CREATE INDEX IF NOT EXISTS idx_schedules_professional_active ON schedules(professionalId, isActive);',
      'CREATE INDEX IF NOT EXISTS idx_schedules_day_of_week ON schedules(dayOfWeek);',

      // Schedule exceptions indexes
      'CREATE INDEX IF NOT EXISTS idx_schedule_exceptions_schedule_date ON schedule_exceptions(scheduleId, date);',
      'CREATE INDEX IF NOT EXISTS idx_schedule_exceptions_date ON schedule_exceptions(date);',
      'CREATE INDEX IF NOT EXISTS idx_schedule_exceptions_blocked ON schedule_exceptions(isBlocked);',

      // Booking table indexes (most critical for performance)
      'CREATE INDEX IF NOT EXISTS idx_bookings_tenant_start_time ON bookings(tenantId, startTime);',
      'CREATE INDEX IF NOT EXISTS idx_bookings_professional_start_time ON bookings(professionalId, startTime);',
      'CREATE INDEX IF NOT EXISTS idx_bookings_client_start_time ON bookings(clientId, startTime);',
      'CREATE INDEX IF NOT EXISTS idx_bookings_status_tenant ON bookings(status, tenantId);',
      'CREATE INDEX IF NOT EXISTS idx_bookings_start_end_time ON bookings(startTime, endTime);',
      'CREATE INDEX IF NOT EXISTS idx_bookings_payment_status ON bookings(paymentStatus);',
      'CREATE INDEX IF NOT EXISTS idx_bookings_created_at ON bookings(createdAt);',
      'CREATE INDEX IF NOT EXISTS idx_bookings_professional_status_start ON bookings(professionalId, status, startTime);',
      'CREATE INDEX IF NOT EXISTS idx_bookings_tenant_status_start ON bookings(tenantId, status, startTime);',

      // Role and permission indexes
      'CREATE INDEX IF NOT EXISTS idx_roles_active ON roles(isActive);',
      'CREATE INDEX IF NOT EXISTS idx_permissions_resource_action ON permissions(resource, action);',
      'CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(userId);',
      'CREATE INDEX IF NOT EXISTS idx_user_roles_role_id ON user_roles(roleId);',
      'CREATE INDEX IF NOT EXISTS idx_role_permissions_role_id ON role_permissions(roleId);',
      'CREATE INDEX IF NOT EXISTS idx_role_permissions_permission_id ON role_permissions(permissionId);',

      // Booking history indexes
      'CREATE INDEX IF NOT EXISTS idx_booking_history_booking_performed ON booking_history(bookingId, performedAt);',
      'CREATE INDEX IF NOT EXISTS idx_booking_history_performed_by ON booking_history(performedBy);',
      'CREATE INDEX IF NOT EXISTS idx_booking_history_action ON booking_history(action);',
      'CREATE INDEX IF NOT EXISTS idx_booking_history_performed_at ON booking_history(performedAt);',

      // Notification indexes
      'CREATE INDEX IF NOT EXISTS idx_notification_templates_tenant_type_active ON notification_templates(tenantId, type, isActive);',
      'CREATE INDEX IF NOT EXISTS idx_notification_templates_category_tenant ON notification_templates(category, tenantId);',
      'CREATE INDEX IF NOT EXISTS idx_notification_templates_language ON notification_templates(language);',
      'CREATE INDEX IF NOT EXISTS idx_notifications_recipient_status ON notifications(recipientId, status);',
      'CREATE INDEX IF NOT EXISTS idx_notifications_status_scheduled ON notifications(status, scheduledFor);',
      'CREATE INDEX IF NOT EXISTS idx_notifications_type_status ON notifications(type, status);',
      'CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(createdAt);',
      'CREATE INDEX IF NOT EXISTS idx_notifications_sent_at ON notifications(sentAt);',

      // Notification queue indexes
      'CREATE INDEX IF NOT EXISTS idx_notification_queue_priority_next_attempt ON notification_queue(priority, nextAttempt);',
      'CREATE INDEX IF NOT EXISTS idx_notification_queue_attempts ON notification_queue(attempts);',

      // Campaign indexes
      'CREATE INDEX IF NOT EXISTS idx_campaigns_tenant_status ON campaigns(tenantId, status);',
      'CREATE INDEX IF NOT EXISTS idx_campaigns_type_tenant ON campaigns(type, tenantId);',
      'CREATE INDEX IF NOT EXISTS idx_campaigns_start_end_date ON campaigns(startDate, endDate);',
      'CREATE INDEX IF NOT EXISTS idx_campaigns_status ON campaigns(status);',

      // Campaign execution indexes
      'CREATE INDEX IF NOT EXISTS idx_campaign_executions_campaign_status ON campaign_executions(campaignId, status);',
      'CREATE INDEX IF NOT EXISTS idx_campaign_executions_status_started ON campaign_executions(status, startedAt);',

      // Campaign target indexes
      'CREATE INDEX IF NOT EXISTS idx_campaign_targets_execution_status ON campaign_targets(executionId, status);',
      'CREATE INDEX IF NOT EXISTS idx_campaign_targets_user_id ON campaign_targets(userId);',
      'CREATE INDEX IF NOT EXISTS idx_campaign_targets_status ON campaign_targets(status);',

      // Campaign metrics indexes
      'CREATE INDEX IF NOT EXISTS idx_campaign_metrics_campaign_date ON campaign_metrics(campaignId, date);',
      'CREATE INDEX IF NOT EXISTS idx_campaign_metrics_date ON campaign_metrics(date);',

      // Client segment indexes
      'CREATE INDEX IF NOT EXISTS idx_client_segments_tenant_active ON client_segments(tenantId, isActive);',
      'CREATE INDEX IF NOT EXISTS idx_client_segments_last_updated ON client_segments(lastUpdated);',

      // Review indexes
      'CREATE INDEX IF NOT EXISTS idx_reviews_professional_visible ON reviews(professionalId, isVisible);',
      'CREATE INDEX IF NOT EXISTS idx_reviews_client_id ON reviews(clientId);',
      'CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews(rating);',
      'CREATE INDEX IF NOT EXISTS idx_reviews_moderation_status ON reviews(moderationStatus);',
      'CREATE INDEX IF NOT EXISTS idx_reviews_created_at ON reviews(createdAt);',

      // Review response indexes
      'CREATE INDEX IF NOT EXISTS idx_review_responses_professional ON review_responses(professionalId);',

      // Payment indexes
      'CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);',
      'CREATE INDEX IF NOT EXISTS idx_payments_stripe_customer ON payments(stripeCustomerId);',
      'CREATE INDEX IF NOT EXISTS idx_payments_created_at ON payments(createdAt);',
      'CREATE INDEX IF NOT EXISTS idx_payments_paid_at ON payments(paidAt);',

      // Payment intent indexes
      'CREATE INDEX IF NOT EXISTS idx_payment_intents_payment_id ON payment_intents(paymentId);',
      'CREATE INDEX IF NOT EXISTS idx_payment_intents_status ON payment_intents(status);',

      // Webhook event indexes
      'CREATE INDEX IF NOT EXISTS idx_webhook_events_processed ON webhook_events(processed);',
      'CREATE INDEX IF NOT EXISTS idx_webhook_events_event_type ON webhook_events(eventType);',
      'CREATE INDEX IF NOT EXISTS idx_webhook_events_created_at ON webhook_events(createdAt);',

      // Payment method indexes
      'CREATE INDEX IF NOT EXISTS idx_payment_methods_user_active ON payment_methods(userId, isActive);',
      'CREATE INDEX IF NOT EXISTS idx_payment_methods_default ON payment_methods(isDefault);'
    ];

    console.log(`Applying ${optimizationQueries.length} optimization queries...`);

    // Execute all optimization queries
    for (const query of optimizationQueries) {
      try {
        await prisma.$executeRawUnsafe(query);
        console.log(`✓ Applied: ${query.substring(0, 50)}...`);
      } catch (error) {
        console.warn(`⚠ Warning applying query: ${query.substring(0, 50)}...`, error);
      }
    }

    // Analyze tables for better query planning (SQLite specific)
    const tables = [
      'users', 'professionals', 'services', 'schedules', 'schedule_exceptions',
      'bookings', 'booking_history', 'notifications', 'notification_templates',
      'campaigns', 'reviews', 'payments'
    ];

    console.log('Analyzing tables for better query planning...');
    for (const table of tables) {
      try {
        await prisma.$executeRawUnsafe(`ANALYZE ${table};`);
        console.log(`✓ Analyzed table: ${table}`);
      } catch (error) {
        console.warn(`⚠ Warning analyzing table ${table}:`, error);
      }
    }

    console.log('✅ Database optimization completed successfully!');

    // Display optimization summary
    console.log('\n📊 Optimization Summary:');
    console.log('- Added indexes for frequently queried columns');
    console.log('- Optimized booking queries (most critical for performance)');
    console.log('- Added composite indexes for complex queries');
    console.log('- Optimized notification and campaign queries');
    console.log('- Added indexes for analytics and reporting queries');
    console.log('- Analyzed tables for better query planning');

  } catch (error) {
    console.error('❌ Error during database optimization:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

// Run optimization if called directly
if (require.main === module) {
  optimizeDatabase()
    .then(() => {
      console.log('Database optimization completed!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Database optimization failed:', error);
      process.exit(1);
    });
}

export { optimizeDatabase };