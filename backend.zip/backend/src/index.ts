import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import path from 'path';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { initRedis } from './config/redis';
import { campaignWorker } from './workers/campaign.worker';
import { setupSwagger, addRequestId } from './config/swagger';
import { httpLoggingMiddleware, errorLoggingMiddleware } from './middleware/logging.middleware';
import { metricsMiddleware, errorMetricsMiddleware, connectionMetricsMiddleware } from './middleware/metrics.middleware';
import { queryMonitorMiddleware } from './middleware/query-monitor.middleware';
import LoggerUtils from './utils/logger.utils';
import AlertingService from './services/alerting.service';
import LogCleanupJob from './jobs/log-cleanup.job';

// Load environment variables
dotenv.config();

// Ensure logs directory exists
import fs from 'fs';
const logsDir = path.join(process.cwd(), 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || "http://localhost:3000",
    methods: ["GET", "POST"]
  }
});

const PORT = process.env.PORT || 3001;

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || "http://localhost:3000",
  credentials: true
}));
app.use((express as any).json({ limit: '10mb' }));
app.use((express as any).urlencoded({ extended: true }));

// Request ID middleware (deve vir primeiro)
app.use(addRequestId);

// Connection metrics middleware
app.use(connectionMetricsMiddleware);

// HTTP Logging middleware (deve vir antes das rotas)
app.use(httpLoggingMiddleware);

// Metrics middleware (deve vir antes das rotas)
app.use(metricsMiddleware);

// Query monitoring middleware
app.use(queryMonitorMiddleware);

// Setup Swagger documentation
setupSwagger(app);

// Serve static files for uploads
app.use('/uploads', (express as any).static(path.join(process.cwd(), 'uploads')));

// Health check endpoint
app.get('/health', (_req: express.Request, res: express.Response) => {
  const healthData = {
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    memory: process.memoryUsage(),
    version: '1.0.0'
  };
  
  LoggerUtils.info('Health check requested', {
    category: 'HEALTH_CHECK',
    uptime: process.uptime()
  });
  
  res.status(200).json(healthData);
});

// Import routes
import authRoutes from './routes/auth.routes';
import userRoutes from './routes/user.routes';
import tenantRoutes from './routes/tenant.routes';
import serviceRoutes from './routes/service.routes';
import scheduleRoutes from './routes/schedule.routes';
import { bookingRoutes } from './routes/booking.routes';
import { notificationRoutes } from './routes/notification.routes';
import { notificationTemplateRoutes } from './routes/notification-template.routes';
import { notificationProviderRoutes } from './routes/notification-provider.routes';
import analyticsRoutes from './routes/analytics.routes';
import reportRoutes from './routes/report.routes';
import { aiRoutes } from './routes/ai.routes';
import campaignRoutes from './routes/campaign.routes';
import clientSegmentRoutes from './routes/client-segment.routes';
import clientReactivationRoutes from './routes/client-reactivation.routes';
import { reviewRoutes } from './routes/review.routes';
import uploadsRoutes from './routes/uploads.routes';
import cacheRoutes from './routes/cache.routes';
import performanceRoutes from './routes/performance.routes';
import monitoringRoutes from './routes/monitoring.routes';

// API routes
app.get('/api', (_req: express.Request, res: express.Response) => {
  res.json({
    message: 'Agenda Lotada 24h API',
    version: '1.0.0',
    status: 'running'
  });
});

// Authentication routes
app.use('/api/auth', authRoutes);

// User management routes
app.use('/api/users', userRoutes);

// Tenant management routes
app.use('/api/tenants', tenantRoutes);

// Service management routes
app.use('/api/services', serviceRoutes);

// Schedule management routes
app.use('/api/schedules', scheduleRoutes);

// Booking management routes
app.use('/api/bookings', bookingRoutes);

// Notification management routes
app.use('/api/notifications', notificationRoutes);
app.use('/api/notification-templates', notificationTemplateRoutes);
app.use('/api/notification-providers', notificationProviderRoutes);

// Analytics routes
app.use('/api/analytics', analyticsRoutes);

// Cache management routes
app.use('/api/cache', cacheRoutes);

// Performance monitoring routes
app.use('/api/performance', performanceRoutes);

// Monitoring routes (métricas, health check, alertas)
app.use('/api/monitoring', monitoringRoutes);

// Report routes
app.use('/api/reports', reportRoutes);

// AI routes
app.use('/api/ai', aiRoutes);

// Campaign routes
app.use('/api/campaigns', campaignRoutes);

// Client segment routes
app.use('/api/client-segments', clientSegmentRoutes);

// Client reactivation routes
app.use('/api/client-reactivation', clientReactivationRoutes);

// Review routes
app.use('/api/reviews', reviewRoutes);

// Upload routes (serve static files)
app.use('/uploads', uploadsRoutes);

// Socket.io connection handling
io.on('connection', (socket: any) => {
  LoggerUtils.info('Socket.io client connected', {
    category: 'WEBSOCKET',
    socketId: socket.id,
    event: 'CONNECTION'
  });
  
  socket.on('disconnect', () => {
    LoggerUtils.info('Socket.io client disconnected', {
      category: 'WEBSOCKET',
      socketId: socket.id,
      event: 'DISCONNECTION'
    });
  });
});

// Error logging middleware (deve vir antes do error handler)
app.use(errorLoggingMiddleware);

// Error metrics middleware (deve vir antes do error handler)
app.use(errorMetricsMiddleware);

// Error handling middleware
app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const context = LoggerUtils.createRequestContext(req);
  LoggerUtils.error('Unhandled application error', err, {
    ...context,
    category: 'APPLICATION_ERROR'
  });
  
  res.status(500).json({
    error: 'Internal Server Error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong',
    requestId: req.requestId
  });
});

// 404 handler
app.use('*', (req: express.Request, res: express.Response) => {
  const context = LoggerUtils.createRequestContext(req);
  LoggerUtils.warn('Route not found', {
    ...context,
    category: 'NOT_FOUND'
  });
  
  res.status(404).json({
    error: 'Not Found',
    message: `Route ${req.originalUrl} not found`,
    requestId: req.requestId
  });
});

// Initialize Redis and start server
const startServer = async () => {
  try {
    LoggerUtils.info('Starting application initialization', {
      category: 'STARTUP',
      phase: 'INIT'
    });
    
    const redisAvailable = await initRedis();
    LoggerUtils.info('Redis initialization completed', {
      category: 'STARTUP',
      component: 'REDIS',
      available: redisAvailable
    });
    
    // Só iniciar workers se Redis estiver disponível ou se não for obrigatório
    if (redisAvailable || process.env.DISABLE_WORKERS !== 'true') {
      try {
        // Iniciar worker de campanhas
        campaignWorker.start();
        LoggerUtils.info('Campaign worker started', {
          category: 'STARTUP',
          component: 'WORKER'
        });
        
        // Iniciar sistema de alertas
        const alertingService = AlertingService.getInstance();
        alertingService.startMonitoring(60000); // Verificar alertas a cada minuto
        LoggerUtils.info('Alerting service started', {
          category: 'STARTUP',
          component: 'ALERTING'
        });
      } catch (error) {
        LoggerUtils.warn('Workers failed to start, continuing without them', {
          category: 'STARTUP',
          component: 'WORKER',
          error: (error as Error).message
        });
      }
    } else {
      LoggerUtils.info('Workers disabled due to Redis unavailability', {
        category: 'STARTUP',
        component: 'WORKER'
      });
    }
    
    // Iniciar job de limpeza de logs (não depende do Redis)
    try {
      const logCleanupJob = new LogCleanupJob();
      logCleanupJob.start();
      LoggerUtils.info('Log cleanup job started', {
        category: 'STARTUP',
        component: 'LOG_CLEANUP'
      });
    } catch (error) {
      LoggerUtils.warn('Log cleanup job failed to start', {
        category: 'STARTUP',
        component: 'LOG_CLEANUP',
        error: (error as Error).message
      });
    }
    
    server.listen(PORT, () => {
      LoggerUtils.info('Server started successfully', {
        category: 'STARTUP',
        port: PORT,
        environment: process.env.NODE_ENV || 'development',
        healthCheck: `http://localhost:${PORT}/health`
      });
      
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📊 Health check: http://localhost:${PORT}/health`);
      console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
    });
    
  } catch (error) {
    LoggerUtils.error('Failed to start server', error as Error, {
      category: 'STARTUP',
      phase: 'ERROR'
    });
    process.exit(1);
  }
};

// Handle uncaught exceptions and unhandled rejections
process.on('uncaughtException', (error: Error) => {
  LoggerUtils.error('Uncaught Exception', error, {
    category: 'PROCESS',
    event: 'UNCAUGHT_EXCEPTION'
  });
  process.exit(1);
});

process.on('unhandledRejection', (reason: any, promise: Promise<any>) => {
  LoggerUtils.error('Unhandled Rejection', new Error(reason), {
    category: 'PROCESS',
    event: 'UNHANDLED_REJECTION',
    promise: promise.toString()
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  LoggerUtils.info('SIGTERM received, shutting down gracefully', {
    category: 'SHUTDOWN',
    signal: 'SIGTERM'
  });
  server.close(() => {
    LoggerUtils.info('Server closed successfully', {
      category: 'SHUTDOWN'
    });
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  LoggerUtils.info('SIGINT received, shutting down gracefully', {
    category: 'SHUTDOWN',
    signal: 'SIGINT'
  });
  server.close(() => {
    LoggerUtils.info('Server closed successfully', {
      category: 'SHUTDOWN'
    });
    process.exit(0);
  });
});

startServer();

export { app, io };