import { Request, Response } from 'express';
import { bookingService } from '../services/booking.service';
import { cancellationPolicyService } from '../services/cancellation-policy.service';
import { CreateBookingRequest, UpdateBookingRequest, RescheduleBookingRequest, BookingFilters } from '../types/booking.types';

export class BookingController {

  /**
   * Cria um novo agendamento
   */
  async createBooking(req: Request, res: Response): Promise<void> {
    try {
      const data: CreateBookingRequest = req.body;
      const tenantId = req.user?.tenantId;

      if (!tenantId) {
        res.status(400).json({ 
          error: 'Tenant ID é obrigatório' 
        });
        return;
      }

      // Validar dados obrigatórios
      if (!data.clientId || !data.professionalId || !data.serviceId || !data.startTime) {
        res.status(400).json({ 
          error: 'Dados obrigatórios: clientId, professionalId, serviceId, startTime' 
        });
        return;
      }

      const booking = await bookingService.createBooking(data, tenantId);

      res.status(201).json({
        success: true,
        data: booking,
        message: 'Agendamento criado com sucesso'
      });
    } catch (error) {
      console.error('Erro ao criar agendamento:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Lista agendamentos com filtros
   */
  async getBookings(req: Request, res: Response): Promise<void> {
    try {
      const filters: BookingFilters = {
        clientId: req.query.clientId as string,
        professionalId: req.query.professionalId as string,
        serviceId: req.query.serviceId as string,
        status: req.query.status as any,
        tenantId: req.user?.tenantId,
        startDate: req.query.startDate ? new Date(req.query.startDate as string) : undefined,
        endDate: req.query.endDate ? new Date(req.query.endDate as string) : undefined
      };

      // Remover filtros undefined
      Object.keys(filters).forEach(key => {
        if (filters[key as keyof BookingFilters] === undefined) {
          delete filters[key as keyof BookingFilters];
        }
      });

      const bookings = await bookingService.getBookings(filters);

      res.json({
        success: true,
        data: bookings,
        count: bookings.length
      });
    } catch (error) {
      console.error('Erro ao buscar agendamentos:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Busca um agendamento por ID
   */
  async getBookingById(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;

      const booking = await bookingService.getBookingById(id);

      if (!booking) {
        res.status(404).json({ 
          error: 'Agendamento não encontrado' 
        });
        return;
      }

      res.json({
        success: true,
        data: booking
      });
    } catch (error) {
      console.error('Erro ao buscar agendamento:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Atualiza um agendamento
   */
  async updateBooking(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const data: UpdateBookingRequest = req.body;
      const performedBy = req.user?.id;

      if (!performedBy) {
        res.status(401).json({ 
          error: 'Usuário não autenticado' 
        });
        return;
      }

      const booking = await bookingService.updateBooking(id, data, performedBy);

      res.json({
        success: true,
        data: booking,
        message: 'Agendamento atualizado com sucesso'
      });
    } catch (error) {
      console.error('Erro ao atualizar agendamento:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Confirma um agendamento
   */
  async confirmBooking(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const performedBy = req.user?.id;

      if (!performedBy) {
        res.status(401).json({ 
          error: 'Usuário não autenticado' 
        });
        return;
      }

      const booking = await bookingService.confirmBooking(id, performedBy);

      res.json({
        success: true,
        data: booking,
        message: 'Agendamento confirmado com sucesso'
      });
    } catch (error) {
      console.error('Erro ao confirmar agendamento:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Reagenda um agendamento
   */
  async rescheduleBooking(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const data: RescheduleBookingRequest = req.body;
      const performedBy = req.user?.id;

      if (!performedBy) {
        res.status(401).json({ 
          error: 'Usuário não autenticado' 
        });
        return;
      }

      if (!data.newStartTime) {
        res.status(400).json({ 
          error: 'newStartTime é obrigatório' 
        });
        return;
      }

      const booking = await bookingService.rescheduleBooking(id, data, performedBy);

      res.json({
        success: true,
        data: booking,
        message: 'Agendamento reagendado com sucesso'
      });
    } catch (error) {
      console.error('Erro ao reagendar agendamento:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Cancela um agendamento
   */
  async cancelBooking(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const { reason } = req.body;
      const performedBy = req.user?.id;

      if (!performedBy) {
        res.status(401).json({ 
          error: 'Usuário não autenticado' 
        });
        return;
      }

      const booking = await bookingService.cancelBooking(id, performedBy, reason);

      res.json({
        success: true,
        data: booking,
        message: 'Agendamento cancelado com sucesso'
      });
    } catch (error) {
      console.error('Erro ao cancelar agendamento:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Marca agendamento como concluído
   */
  async completeBooking(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const performedBy = req.user?.id;

      if (!performedBy) {
        res.status(401).json({ 
          error: 'Usuário não autenticado' 
        });
        return;
      }

      const booking = await bookingService.completeBooking(id, performedBy);

      res.json({
        success: true,
        data: booking,
        message: 'Agendamento marcado como concluído'
      });
    } catch (error) {
      console.error('Erro ao completar agendamento:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Marca agendamento como no-show
   */
  async markAsNoShow(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const performedBy = req.user?.id;

      if (!performedBy) {
        res.status(401).json({ 
          error: 'Usuário não autenticado' 
        });
        return;
      }

      const booking = await bookingService.markAsNoShow(id, performedBy);

      res.json({
        success: true,
        data: booking,
        message: 'Agendamento marcado como no-show'
      });
    } catch (error) {
      console.error('Erro ao marcar como no-show:', error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Valida disponibilidade para agendamento
   */
  async validateAvailability(req: Request, res: Response): Promise<void> {
    try {
      const data = req.body;

      if (!data.clientId || !data.professionalId || !data.serviceId || !data.startTime) {
        res.status(400).json({ 
          error: 'Dados obrigatórios: clientId, professionalId, serviceId, startTime' 
        });
        return;
      }

      const validation = await bookingService.validateBookingAvailability(data);

      res.json({
        success: true,
        data: validation
      });
    } catch (error) {
      console.error('Erro ao validar disponibilidade:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Valida se um cancelamento é permitido
   */
  async validateCancellation(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const tenantId = req.user?.tenantId;

      if (!tenantId) {
        res.status(400).json({ 
          error: 'Tenant ID é obrigatório' 
        });
        return;
      }

      const validation = await cancellationPolicyService.validateCancellation(id, tenantId);

      res.json({
        success: true,
        data: validation
      });
    } catch (error) {
      console.error('Erro ao validar cancelamento:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Valida se um reagendamento é permitido
   */
  async validateReschedule(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const { newStartTime } = req.body;
      const tenantId = req.user?.tenantId;

      if (!tenantId) {
        res.status(400).json({ 
          error: 'Tenant ID é obrigatório' 
        });
        return;
      }

      if (!newStartTime) {
        res.status(400).json({ 
          error: 'newStartTime é obrigatório' 
        });
        return;
      }

      const validation = await cancellationPolicyService.validateReschedule(
        id, 
        tenantId, 
        new Date(newStartTime)
      );

      res.json({
        success: true,
        data: validation
      });
    } catch (error) {
      console.error('Erro ao validar reagendamento:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Calcula taxa de cancelamento
   */
  async calculateCancellationFee(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const tenantId = req.user?.tenantId;

      if (!tenantId) {
        res.status(400).json({ 
          error: 'Tenant ID é obrigatório' 
        });
        return;
      }

      const fee = await cancellationPolicyService.calculateCancellationFee(id, tenantId);

      res.json({
        success: true,
        data: fee
      });
    } catch (error) {
      console.error('Erro ao calcular taxa de cancelamento:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Busca o histórico de um agendamento
   */
  async getBookingHistory(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;

      const history = await bookingService.getBookingHistory(id);

      res.json({
        success: true,
        data: history
      });
    } catch (error) {
      console.error('Erro ao buscar histórico do agendamento:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Busca métricas de agendamentos
   */
  async getBookingMetrics(req: Request, res: Response): Promise<void> {
    try {
      const filters = {
        tenantId: req.user?.tenantId,
        professionalId: req.query.professionalId as string,
        startDate: req.query.startDate ? new Date(req.query.startDate as string) : undefined,
        endDate: req.query.endDate ? new Date(req.query.endDate as string) : undefined
      };

      const metrics = await bookingService.getBookingMetrics(filters);

      res.json({
        success: true,
        data: metrics
      });
    } catch (error) {
      console.error('Erro ao buscar métricas:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Busca métricas detalhadas
   */
  async getDetailedMetrics(req: Request, res: Response): Promise<void> {
    try {
      const filters = {
        tenantId: req.user?.tenantId,
        professionalId: req.query.professionalId as string,
        startDate: req.query.startDate ? new Date(req.query.startDate as string) : undefined,
        endDate: req.query.endDate ? new Date(req.query.endDate as string) : undefined
      };

      const metrics = await bookingService.getDetailedMetrics(filters);

      res.json({
        success: true,
        data: metrics
      });
    } catch (error) {
      console.error('Erro ao buscar métricas detalhadas:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Busca tendências de agendamentos
   */
  async getBookingTrends(req: Request, res: Response): Promise<void> {
    try {
      const filters = {
        tenantId: req.user?.tenantId,
        professionalId: req.query.professionalId as string,
        startDate: req.query.startDate ? new Date(req.query.startDate as string) : undefined,
        endDate: req.query.endDate ? new Date(req.query.endDate as string) : undefined
      };

      const trends = await bookingService.getBookingTrends(filters);

      res.json({
        success: true,
        data: trends
      });
    } catch (error) {
      console.error('Erro ao buscar tendências:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Busca padrões de cancelamento
   */
  async getCancellationPatterns(req: Request, res: Response): Promise<void> {
    try {
      const filters = {
        tenantId: req.user?.tenantId,
        professionalId: req.query.professionalId as string,
        startDate: req.query.startDate ? new Date(req.query.startDate as string) : undefined,
        endDate: req.query.endDate ? new Date(req.query.endDate as string) : undefined
      };

      const patterns = await bookingService.getCancellationPatterns(filters);

      res.json({
        success: true,
        data: patterns
      });
    } catch (error) {
      console.error('Erro ao buscar padrões de cancelamento:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }

  /**
   * Busca clientes com alta taxa de cancelamento
   */
  async getHighCancellationClients(req: Request, res: Response): Promise<void> {
    try {
      const tenantId = req.user?.tenantId;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;

      if (!tenantId) {
        res.status(400).json({ 
          error: 'Tenant ID é obrigatório' 
        });
        return;
      }

      const clients = await bookingService.getHighCancellationClients(tenantId, limit);

      res.json({
        success: true,
        data: clients
      });
    } catch (error) {
      console.error('Erro ao buscar clientes com alta taxa de cancelamento:', error);
      res.status(500).json({ 
        error: 'Erro interno do servidor' 
      });
    }
  }
}

export const bookingController = new BookingController();