import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { UserService } from '../services/user.service';
import { RoleService } from '../services/role.service';
import { 
  createUserSchema, 
  updateUserSchema, 
  updateUserProfileSchema,
  updateProfessionalProfileSchema,
  updateClientProfileSchema,
  createRoleSchema,
  updateRoleSchema,
  createPermissionSchema
} from '../types/user.types';

const prisma = new PrismaClient();
const userService = new UserService(prisma);
const roleService = new RoleService(prisma);

/**
 * Get all users with pagination
 */
export async function getUsers(req: Request, res: Response) {
  try {
    const {
      page = '1',
      limit = '10',
      tenantId,
      isActive,
      search,
    } = req.query;

    const result = await userService.getUsers({
      page: parseInt(page as string),
      limit: parseInt(limit as string),
      tenantId: tenantId as string,
      isActive: isActive === 'true' ? true : isActive === 'false' ? false : undefined,
      search: search as string,
    });

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Get user by ID
 */
export async function getUserById(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const user = await userService.getUserById(id);

    if (!user) {
      return res.status(404).json({
        error: 'USER_NOT_FOUND',
        message: 'Usuário não encontrado',
      });
    }

    // Remove password from response
    const { password, ...userWithoutPassword } = user as any;

    res.json({
      success: true,
      data: { user: userWithoutPassword },
    });
  } catch (error) {
    console.error('Get user by ID error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Create new user
 */
export async function createUser(req: Request, res: Response) {
  try {
    const validatedData = createUserSchema.parse(req.body);

    // Check if user already exists
    const existingUser = await userService.getUserByEmail(validatedData.email);
    if (existingUser) {
      return res.status(409).json({
        error: 'USER_EXISTS',
        message: 'Usuário já existe com este email',
      });
    }

    const user = await userService.createUser(validatedData);

    // Remove password from response
    const { password, ...userWithoutPassword } = user as any;

    res.status(201).json({
      success: true,
      message: 'Usuário criado com sucesso',
      data: { user: userWithoutPassword },
    });
  } catch (error) {
    console.error('Create user error:', error);
    
    if (error instanceof Error && error.message.includes('validation')) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Update user
 */
export async function updateUser(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const validatedData = updateUserSchema.parse(req.body);

    const user = await userService.updateUser(id, validatedData);

    if (!user) {
      return res.status(404).json({
        error: 'USER_NOT_FOUND',
        message: 'Usuário não encontrado',
      });
    }

    // Remove password from response
    const { password, ...userWithoutPassword } = user as any;

    res.json({
      success: true,
      message: 'Usuário atualizado com sucesso',
      data: { user: userWithoutPassword },
    });
  } catch (error) {
    console.error('Update user error:', error);
    
    if (error instanceof Error && error.message.includes('validation')) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Update user profile
 */
export async function updateUserProfile(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const validatedData = updateUserProfileSchema.parse(req.body);

    const profile = await userService.updateUserProfile(id, validatedData);

    res.json({
      success: true,
      message: 'Perfil atualizado com sucesso',
      data: { profile },
    });
  } catch (error) {
    console.error('Update user profile error:', error);
    
    if (error instanceof Error && (error.message.includes('validation') || error.message.includes('não encontrado') || error.message.includes('não é'))) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Update professional profile
 */
export async function updateProfessionalProfile(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const validatedData = updateProfessionalProfileSchema.parse(req.body);

    const profile = await userService.updateProfessionalProfile(id, validatedData);

    res.json({
      success: true,
      message: 'Perfil profissional atualizado com sucesso',
      data: { profile },
    });
  } catch (error) {
    console.error('Update professional profile error:', error);
    
    if (error instanceof Error && (error.message.includes('validation') || error.message.includes('não encontrado') || error.message.includes('não é'))) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Update client profile
 */
export async function updateClientProfile(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const validatedData = updateClientProfileSchema.parse(req.body);

    const profile = await userService.updateClientProfile(id, validatedData);

    res.json({
      success: true,
      message: 'Perfil do cliente atualizado com sucesso',
      data: { profile },
    });
  } catch (error) {
    console.error('Update client profile error:', error);
    
    if (error instanceof Error && (error.message.includes('validation') || error.message.includes('não encontrado') || error.message.includes('não é'))) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Upload user avatar
 */
export async function uploadAvatar(req: Request, res: Response) {
  try {
    const { id } = req.params;
    
    if (!req.file) {
      return res.status(400).json({
        error: 'NO_FILE',
        message: 'Nenhum arquivo foi enviado',
      });
    }

    const avatarUrl = await userService.uploadAvatar(id, req.file.filename);

    res.json({
      success: true,
      message: 'Avatar enviado com sucesso',
      data: { avatarUrl },
    });
  } catch (error) {
    console.error('Upload avatar error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Delete user avatar
 */
export async function deleteAvatar(req: Request, res: Response) {
  try {
    const { id } = req.params;
    await userService.deleteAvatar(id);

    res.json({
      success: true,
      message: 'Avatar removido com sucesso',
    });
  } catch (error) {
    console.error('Delete avatar error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Get user profile with custom fields
 */
export async function getUserProfileWithCustomFields(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const profile = await userService.getUserProfileWithCustomFields(id);

    if (!profile) {
      return res.status(404).json({
        error: 'PROFILE_NOT_FOUND',
        message: 'Perfil não encontrado',
      });
    }

    res.json({
      success: true,
      data: { profile },
    });
  } catch (error) {
    console.error('Get user profile with custom fields error:', error);
    
    if (error instanceof Error && error.message.includes('não encontrado')) {
      return res.status(404).json({
        error: 'USER_NOT_FOUND',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Get tenant custom fields for user type
 */
export async function getTenantCustomFields(req: Request, res: Response) {
  try {
    const { tenantId, userType } = req.params;

    if (!['professional', 'client'].includes(userType)) {
      return res.status(400).json({
        error: 'INVALID_USER_TYPE',
        message: 'Tipo de usuário deve ser "professional" ou "client"',
      });
    }

    const customFields = await userService.getTenantCustomFields(tenantId, userType as 'professional' | 'client');

    res.json({
      success: true,
      data: { customFields },
    });
  } catch (error) {
    console.error('Get tenant custom fields error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Deactivate user
 */
export async function deactivateUser(req: Request, res: Response) {
  try {
    const { id } = req.params;
    await userService.deactivateUser(id);

    res.json({
      success: true,
      message: 'Usuário desativado com sucesso',
    });
  } catch (error) {
    console.error('Deactivate user error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Activate user
 */
export async function activateUser(req: Request, res: Response) {
  try {
    const { id } = req.params;
    await userService.activateUser(id);

    res.json({
      success: true,
      message: 'Usuário ativado com sucesso',
    });
  } catch (error) {
    console.error('Activate user error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Delete user
 */
export async function deleteUser(req: Request, res: Response) {
  try {
    const { id } = req.params;
    await userService.deleteUser(id);

    res.json({
      success: true,
      message: 'Usuário removido com sucesso',
    });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

// Role management endpoints

/**
 * Get all roles
 */
export async function getRoles(req: Request, res: Response) {
  try {
    const {
      page = '1',
      limit = '10',
      isActive,
      search,
    } = req.query;

    const result = await roleService.getRoles({
      page: parseInt(page as string),
      limit: parseInt(limit as string),
      isActive: isActive === 'true' ? true : isActive === 'false' ? false : undefined,
      search: search as string,
    });

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error('Get roles error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Create new role
 */
export async function createRole(req: Request, res: Response) {
  try {
    const validatedData = createRoleSchema.parse(req.body);
    const role = await roleService.createRole(validatedData);

    res.status(201).json({
      success: true,
      message: 'Papel criado com sucesso',
      data: { role },
    });
  } catch (error) {
    console.error('Create role error:', error);
    
    if (error instanceof Error && error.message.includes('validation')) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Get all permissions
 */
export async function getPermissions(req: Request, res: Response) {
  try {
    const {
      page = '1',
      limit = '50',
      resource,
      action,
      search,
    } = req.query;

    const result = await roleService.getPermissions({
      page: parseInt(page as string),
      limit: parseInt(limit as string),
      resource: resource as string,
      action: action as string,
      search: search as string,
    });

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error('Get permissions error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}