import { Request, Response } from 'express';
import { reviewService } from '../services/review.service';
import {
  CreateReviewRequest,
  UpdateReviewRequest,
  ReviewFilters,
  ModerateReviewRequest,
  CreateReviewResponseRequest
} from '../types/review.types';

export class ReviewController {
  // Criar avaliação
  async createReview(req: Request, res: Response) {
    try {
      const clientId = req.user?.id;
      if (!clientId) {
        return res.status(401).json({ error: 'Usuário não autenticado' });
      }

      const data: CreateReviewRequest = req.body;
      
      // Validações básicas
      if (!data.bookingId || !data.rating) {
        return res.status(400).json({ error: 'BookingId e rating são obrigatórios' });
      }

      if (data.rating < 1 || data.rating > 5) {
        return res.status(400).json({ error: 'Rating deve ser entre 1 e 5' });
      }

      const review = await reviewService.createReview(clientId, data);
      res.status(201).json(review);
    } catch (error: any) {
      console.error('Erro ao criar avaliação:', error);
      res.status(400).json({ error: error.message });
    }
  }

  // Listar avaliações
  async getReviews(req: Request, res: Response) {
    try {
      const filters: ReviewFilters = {
        professionalId: req.query.professionalId as string,
        rating: req.query.rating ? parseInt(req.query.rating as string) : undefined,
        moderationStatus: req.query.moderationStatus as any,
        isVisible: req.query.isVisible ? req.query.isVisible === 'true' : undefined,
        startDate: req.query.startDate ? new Date(req.query.startDate as string) : undefined,
        endDate: req.query.endDate ? new Date(req.query.endDate as string) : undefined,
        page: req.query.page ? parseInt(req.query.page as string) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 10
      };

      const result = await reviewService.getReviews(filters);
      res.json(result);
    } catch (error: any) {
      console.error('Erro ao buscar avaliações:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Buscar avaliação por ID
  async getReviewById(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const review = await reviewService.getReviewById(id);
      
      if (!review) {
        return res.status(404).json({ error: 'Avaliação não encontrada' });
      }

      res.json(review);
    } catch (error: any) {
      console.error('Erro ao buscar avaliação:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Atualizar avaliação
  async updateReview(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const clientId = req.user?.id;
      
      if (!clientId) {
        return res.status(401).json({ error: 'Usuário não autenticado' });
      }

      const data: UpdateReviewRequest = req.body;
      
      // Validar rating se fornecido
      if (data.rating && (data.rating < 1 || data.rating > 5)) {
        return res.status(400).json({ error: 'Rating deve ser entre 1 e 5' });
      }

      const review = await reviewService.updateReview(id, clientId, data);
      res.json(review);
    } catch (error: any) {
      console.error('Erro ao atualizar avaliação:', error);
      res.status(400).json({ error: error.message });
    }
  }

  // Deletar avaliação
  async deleteReview(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const clientId = req.user?.id;
      
      if (!clientId) {
        return res.status(401).json({ error: 'Usuário não autenticado' });
      }

      await reviewService.deleteReview(id, clientId);
      res.status(204).send();
    } catch (error: any) {
      console.error('Erro ao deletar avaliação:', error);
      res.status(400).json({ error: error.message });
    }
  }

  // Moderar avaliação (apenas admin)
  async moderateReview(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const moderatorId = req.user?.id;
      
      if (!moderatorId) {
        return res.status(401).json({ error: 'Usuário não autenticado' });
      }

      // TODO: Verificar se o usuário tem permissão de admin
      
      const data: ModerateReviewRequest = req.body;
      
      if (!data.moderationStatus) {
        return res.status(400).json({ error: 'Status de moderação é obrigatório' });
      }

      const review = await reviewService.moderateReview(id, moderatorId, data);
      res.json(review);
    } catch (error: any) {
      console.error('Erro ao moderar avaliação:', error);
      res.status(400).json({ error: error.message });
    }
  }

  // Criar resposta do profissional
  async createReviewResponse(req: Request, res: Response) {
    try {
      const { id: reviewId } = req.params;
      const professionalId = req.user?.professional?.id;
      
      if (!professionalId) {
        return res.status(401).json({ error: 'Usuário não é um profissional' });
      }

      const data: CreateReviewResponseRequest = req.body;
      
      if (!data.response) {
        return res.status(400).json({ error: 'Resposta é obrigatória' });
      }

      const review = await reviewService.createReviewResponse(reviewId, professionalId, data);
      res.status(201).json(review);
    } catch (error: any) {
      console.error('Erro ao criar resposta:', error);
      res.status(400).json({ error: error.message });
    }
  }

  // Atualizar resposta do profissional
  async updateReviewResponse(req: Request, res: Response) {
    try {
      const { id: reviewId } = req.params;
      const professionalId = req.user?.professional?.id;
      
      if (!professionalId) {
        return res.status(401).json({ error: 'Usuário não é um profissional' });
      }

      const { response } = req.body;
      
      if (!response) {
        return res.status(400).json({ error: 'Resposta é obrigatória' });
      }

      const review = await reviewService.updateReviewResponse(reviewId, professionalId, response);
      res.json(review);
    } catch (error: any) {
      console.error('Erro ao atualizar resposta:', error);
      res.status(400).json({ error: error.message });
    }
  }

  // Deletar resposta do profissional
  async deleteReviewResponse(req: Request, res: Response) {
    try {
      const { id: reviewId } = req.params;
      const professionalId = req.user?.professional?.id;
      
      if (!professionalId) {
        return res.status(401).json({ error: 'Usuário não é um profissional' });
      }

      await reviewService.deleteReviewResponse(reviewId, professionalId);
      res.status(204).send();
    } catch (error: any) {
      console.error('Erro ao deletar resposta:', error);
      res.status(400).json({ error: error.message });
    }
  }

  // Obter estatísticas de avaliações
  async getReviewStats(req: Request, res: Response) {
    try {
      const professionalId = req.query.professionalId as string;
      const stats = await reviewService.getReviewStats(professionalId);
      res.json(stats);
    } catch (error: any) {
      console.error('Erro ao buscar estatísticas:', error);
      res.status(500).json({ error: error.message });
    }
  }

  // Obter estatísticas por profissional
  async getProfessionalReviewStats(req: Request, res: Response) {
    try {
      const { professionalId } = req.params;
      const stats = await reviewService.getProfessionalReviewStats(professionalId);
      res.json(stats);
    } catch (error: any) {
      console.error('Erro ao buscar estatísticas do profissional:', error);
      res.status(500).json({ error: error.message });
    }
  }
}

export const reviewController = new ReviewController();