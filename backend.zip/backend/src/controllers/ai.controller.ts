import { Request, Response } from 'express';
import { AIService } from '../services/ai.service';
import { ChatContext } from '../types/ai.types';
import { redisClient } from '../config/redis';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const aiService = new AIService(redisClient, prisma);

export class AIController {
  async chat(req: Request, res: Response) {
    try {
      const { message, sessionId } = req.body;
      const userId = req.user?.id;
      const tenantId = req.user?.tenantId;

      if (!message || !userId || !tenantId) {
        return res.status(400).json({
          error: 'Mensagem, usuário e tenant são obrigatórios'
        });
      }

      // Buscar ou criar sessão de chat
      let session = sessionId ? await aiService.getChatSession(sessionId) : null;
      
      if (!session) {
        session = await aiService.createChatSession(userId, tenantId);
      }

      // Buscar perfil do usuário
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: {
          id: true,
          name: true,
          role: true
        }
      });

      // Preparar contexto
      const context: ChatContext = {
        userId,
        sessionId: session.id,
        conversationHistory: session.messages,
        userProfile: user ? {
          name: user.name,
          role: user.role as 'CLIENT' | 'PROFESSIONAL' | 'ADMIN'
        } : undefined,
        tenantId
      };

      // Processar mensagem
      const response = await aiService.processMessage(message, context);

      res.json({
        sessionId: session.id,
        response: response.message,
        intent: response.intent,
        actions: response.actions,
        suggestions: response.suggestions,
        metadata: response.metadata
      });

    } catch (error) {
      console.error('Erro no chat:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  async getChatHistory(req: Request, res: Response) {
    try {
      const { sessionId } = req.params;
      const userId = req.user?.id;

      if (!sessionId || !userId) {
        return res.status(400).json({
          error: 'Session ID e usuário são obrigatórios'
        });
      }

      const session = await aiService.getChatSession(sessionId);
      
      if (!session || session.userId !== userId) {
        return res.status(404).json({
          error: 'Sessão não encontrada'
        });
      }

      res.json({
        sessionId: session.id,
        messages: session.messages,
        startedAt: session.startedAt,
        lastActivity: session.lastActivity,
        isActive: session.isActive
      });

    } catch (error) {
      console.error('Erro ao buscar histórico:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  async createSession(req: Request, res: Response) {
    try {
      const userId = req.user?.id;
      const tenantId = req.user?.tenantId;

      if (!userId || !tenantId) {
        return res.status(400).json({
          error: 'Usuário e tenant são obrigatórios'
        });
      }

      const session = await aiService.createChatSession(userId, tenantId);

      res.status(201).json({
        sessionId: session.id,
        startedAt: session.startedAt,
        isActive: session.isActive
      });

    } catch (error) {
      console.error('Erro ao criar sessão:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  async getRecommendations(req: Request, res: Response) {
    try {
      const userId = req.user?.id;
      const { type } = req.query;

      if (!userId) {
        return res.status(400).json({
          error: 'Usuário é obrigatório'
        });
      }

      const recommendations = await aiService.generateRecommendations(
        userId,
        type as string
      );

      res.json({
        recommendations
      });

    } catch (error) {
      console.error('Erro ao gerar recomendações:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  async getInsights(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      const userRole = req.user?.role;

      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant é obrigatório'
        });
      }

      // Apenas admins e profissionais podem ver insights
      if (userRole !== 'ADMIN' && userRole !== 'PROFESSIONAL') {
        return res.status(403).json({
          error: 'Acesso negado'
        });
      }

      const insights = await aiService.generateInsights(tenantId);

      res.json({
        insights
      });

    } catch (error) {
      console.error('Erro ao gerar insights:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  async getCampaignSuggestions(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      const userRole = req.user?.role;

      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant é obrigatório'
        });
      }

      // Apenas admins podem ver sugestões de campanha
      if (userRole !== 'ADMIN') {
        return res.status(403).json({
          error: 'Acesso negado'
        });
      }

      const suggestions = await aiService.generateCampaignSuggestions(tenantId);

      res.json({
        suggestions
      });

    } catch (error) {
      console.error('Erro ao gerar sugestões de campanha:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }
}