import { Request, Response } from 'express';
import { notificationTemplateService } from '../services/notification-template.service';
import {
  CreateNotificationTemplateData,
  UpdateNotificationTemplateData,
  NotificationType,
  NotificationCategory
} from '../types/notification.types';

export class NotificationTemplateController {
  // Criar template
  async createTemplate(req: Request, res: Response) {
    try {
      const data: CreateNotificationTemplateData = req.body;
      
      // Validar dados obrigatórios
      if (!data.name || !data.type || !data.content || !data.category) {
        return res.status(400).json({
          error: 'Campos obrigatórios: name, type, content, category'
        });
      }

      // Validar tipo de notificação
      if (!Object.values(NotificationType).includes(data.type)) {
        return res.status(400).json({
          error: 'Tipo de notificação inválido'
        });
      }

      // Validar categoria
      if (!Object.values(NotificationCategory).includes(data.category)) {
        return res.status(400).json({
          error: 'Categoria de notificação inválida'
        });
      }

      const template = await notificationTemplateService.createTemplate(data);
      
      res.status(201).json({
        message: 'Template criado com sucesso',
        data: template
      });
    } catch (error: any) {
      console.error('Erro ao criar template:', error);
      
      if (error.code === 'P2002') {
        return res.status(409).json({
          error: 'Já existe um template com este nome para este tenant e idioma'
        });
      }
      
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar templates
  async getTemplates(req: Request, res: Response) {
    try {
      const {
        tenantId,
        type,
        category,
        language,
        isActive
      } = req.query;

      const filters: any = {};
      
      if (tenantId) filters.tenantId = tenantId as string;
      if (type) filters.type = type as NotificationType;
      if (category) filters.category = category as NotificationCategory;
      if (language) filters.language = language as string;
      if (isActive !== undefined) filters.isActive = isActive === 'true';

      const templates = await notificationTemplateService.getTemplates(filters);
      
      res.json({
        message: 'Templates encontrados',
        data: templates,
        total: templates.length
      });
    } catch (error) {
      console.error('Erro ao buscar templates:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar template por ID
  async getTemplateById(req: Request, res: Response) {
    try {
      const { id } = req.params;
      
      const template = await notificationTemplateService.getTemplateById(id);
      
      if (!template) {
        return res.status(404).json({
          error: 'Template não encontrado'
        });
      }
      
      res.json({
        message: 'Template encontrado',
        data: template
      });
    } catch (error) {
      console.error('Erro ao buscar template:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Atualizar template
  async updateTemplate(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const data: UpdateNotificationTemplateData = req.body;
      
      // Validar tipo se fornecido
      if (data.type && !Object.values(NotificationType).includes(data.type)) {
        return res.status(400).json({
          error: 'Tipo de notificação inválido'
        });
      }

      // Validar categoria se fornecida
      if (data.category && !Object.values(NotificationCategory).includes(data.category)) {
        return res.status(400).json({
          error: 'Categoria de notificação inválida'
        });
      }

      const template = await notificationTemplateService.updateTemplate(id, data);
      
      if (!template) {
        return res.status(404).json({
          error: 'Template não encontrado'
        });
      }
      
      res.json({
        message: 'Template atualizado com sucesso',
        data: template
      });
    } catch (error: any) {
      console.error('Erro ao atualizar template:', error);
      
      if (error.code === 'P2002') {
        return res.status(409).json({
          error: 'Já existe um template com este nome para este tenant e idioma'
        });
      }
      
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Deletar template
  async deleteTemplate(req: Request, res: Response) {
    try {
      const { id } = req.params;
      
      const success = await notificationTemplateService.deleteTemplate(id);
      
      if (!success) {
        return res.status(404).json({
          error: 'Template não encontrado'
        });
      }
      
      res.json({
        message: 'Template deletado com sucesso'
      });
    } catch (error) {
      console.error('Erro ao deletar template:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Renderizar template
  async renderTemplate(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const { variables, language } = req.body;
      
      if (!variables || typeof variables !== 'object') {
        return res.status(400).json({
          error: 'Variáveis são obrigatórias e devem ser um objeto'
        });
      }

      const result = await notificationTemplateService.renderTemplate(id, {
        variables,
        language
      });
      
      if (!result) {
        return res.status(404).json({
          error: 'Template não encontrado'
        });
      }
      
      res.json({
        message: 'Template renderizado com sucesso',
        data: result
      });
    } catch (error) {
      console.error('Erro ao renderizar template:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Renderizar template por nome
  async renderTemplateByName(req: Request, res: Response) {
    try {
      const { name } = req.params;
      const { variables, language, tenantId } = req.body;
      
      if (!variables || typeof variables !== 'object') {
        return res.status(400).json({
          error: 'Variáveis são obrigatórias e devem ser um objeto'
        });
      }

      const result = await notificationTemplateService.renderTemplateByName(
        name,
        { variables, language },
        tenantId
      );
      
      if (!result) {
        return res.status(404).json({
          error: 'Template não encontrado'
        });
      }
      
      res.json({
        message: 'Template renderizado com sucesso',
        data: result
      });
    } catch (error) {
      console.error('Erro ao renderizar template:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Validar template
  async validateTemplate(req: Request, res: Response) {
    try {
      const { content, variables } = req.body;
      
      if (!content) {
        return res.status(400).json({
          error: 'Conteúdo do template é obrigatório'
        });
      }

      const validation = await notificationTemplateService.validateTemplate(
        content,
        variables
      );
      
      res.json({
        message: 'Validação concluída',
        data: validation
      });
    } catch (error) {
      console.error('Erro ao validar template:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Criar templates padrão
  async createDefaultTemplates(req: Request, res: Response) {
    try {
      const { tenantId } = req.body;
      
      await notificationTemplateService.createDefaultTemplates(tenantId);
      
      res.json({
        message: 'Templates padrão criados com sucesso'
      });
    } catch (error) {
      console.error('Erro ao criar templates padrão:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Duplicar template
  async duplicateTemplate(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const { targetTenantId } = req.body;
      
      if (!targetTenantId) {
        return res.status(400).json({
          error: 'ID do tenant de destino é obrigatório'
        });
      }

      const duplicatedTemplate = await notificationTemplateService.duplicateTemplate(
        id,
        targetTenantId
      );
      
      if (!duplicatedTemplate) {
        return res.status(404).json({
          error: 'Template não encontrado'
        });
      }
      
      res.json({
        message: 'Template duplicado com sucesso',
        data: duplicatedTemplate
      });
    } catch (error) {
      console.error('Erro ao duplicar template:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Obter estatísticas do template
  async getTemplateStats(req: Request, res: Response) {
    try {
      const { id } = req.params;
      
      const stats = await notificationTemplateService.getTemplateStats(id);
      
      res.json({
        message: 'Estatísticas obtidas com sucesso',
        data: stats
      });
    } catch (error) {
      console.error('Erro ao obter estatísticas:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }
}

export const notificationTemplateController = new NotificationTemplateController();