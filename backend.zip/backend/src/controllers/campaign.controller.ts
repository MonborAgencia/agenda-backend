import { Request, Response } from 'express';
import { CampaignService } from '../services/campaign.service';
import { ClientSegmentService } from '../services/client-segment.service';
import {
  CreateCampaignDto,
  UpdateCampaignDto,
  CampaignType,
  CampaignStatus,
  CampaignFrequency
} from '../types/campaign.types';

const campaignService = new CampaignService();
const clientSegmentService = new ClientSegmentService();

export class CampaignController {
  // Criar nova campanha
  async createCampaign(req: Request, res: Response) {
    try {
      const {
        name,
        description,
        type,
        templateId,
        targetAudience,
        startDate,
        endDate,
        frequency
      } = req.body;

      // Validações básicas
      if (!name || !type) {
        return res.status(400).json({
          error: 'Nome e tipo da campanha são obrigatórios'
        });
      }

      if (!Object.values(CampaignType).includes(type)) {
        return res.status(400).json({
          error: 'Tipo de campanha inválido'
        });
      }

      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const campaignData: CreateCampaignDto = {
        name,
        description,
        type,
        tenantId,
        templateId,
        targetAudience,
        startDate: startDate ? new Date(startDate) : undefined,
        endDate: endDate ? new Date(endDate) : undefined,
        frequency
      };

      const campaign = await campaignService.createCampaign(campaignData);

      res.status(201).json({
        success: true,
        data: campaign
      });
    } catch (error) {
      console.error('Erro ao criar campanha:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Listar campanhas
  async getCampaigns(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const campaigns = await campaignService.getCampaignsByTenant(tenantId);

      res.json({
        success: true,
        data: campaigns
      });
    } catch (error) {
      console.error('Erro ao buscar campanhas:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar campanha por ID
  async getCampaignById(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const campaign = await campaignService.getCampaignById(id);

      if (!campaign) {
        return res.status(404).json({
          error: 'Campanha não encontrada'
        });
      }

      res.json({
        success: true,
        data: campaign
      });
    } catch (error) {
      console.error('Erro ao buscar campanha:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Atualizar campanha
  async updateCampaign(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const updateData: UpdateCampaignDto = req.body;

      // Validar status se fornecido
      if (updateData.status && !Object.values(CampaignStatus).includes(updateData.status)) {
        return res.status(400).json({
          error: 'Status de campanha inválido'
        });
      }

      // Validar frequência se fornecida
      if (updateData.frequency && !Object.values(CampaignFrequency).includes(updateData.frequency)) {
        return res.status(400).json({
          error: 'Frequência de campanha inválida'
        });
      }

      // Converter datas se fornecidas
      if (updateData.startDate) {
        updateData.startDate = new Date(updateData.startDate);
      }
      if (updateData.endDate) {
        updateData.endDate = new Date(updateData.endDate);
      }

      const campaign = await campaignService.updateCampaign(id, updateData);

      res.json({
        success: true,
        data: campaign
      });
    } catch (error) {
      console.error('Erro ao atualizar campanha:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Deletar campanha
  async deleteCampaign(req: Request, res: Response) {
    try {
      const { id } = req.params;
      await campaignService.deleteCampaign(id);

      res.json({
        success: true,
        message: 'Campanha deletada com sucesso'
      });
    } catch (error) {
      console.error('Erro ao deletar campanha:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Executar campanha
  async executeCampaign(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const execution = await campaignService.executeCampaign(id);

      res.json({
        success: true,
        data: execution,
        message: 'Campanha executada com sucesso'
      });
    } catch (error) {
      console.error('Erro ao executar campanha:', error);
      res.status(500).json({
        error: error instanceof Error ? error.message : 'Erro interno do servidor'
      });
    }
  }

  // Pausar campanha
  async pauseCampaign(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const campaign = await campaignService.pauseCampaign(id);

      res.json({
        success: true,
        data: campaign,
        message: 'Campanha pausada com sucesso'
      });
    } catch (error) {
      console.error('Erro ao pausar campanha:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Reativar campanha
  async activateCampaign(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const campaign = await campaignService.activateCampaign(id);

      res.json({
        success: true,
        data: campaign,
        message: 'Campanha ativada com sucesso'
      });
    } catch (error) {
      console.error('Erro ao ativar campanha:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Cancelar campanha
  async cancelCampaign(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const campaign = await campaignService.cancelCampaign(id);

      res.json({
        success: true,
        data: campaign,
        message: 'Campanha cancelada com sucesso'
      });
    } catch (error) {
      console.error('Erro ao cancelar campanha:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar execuções de uma campanha
  async getCampaignExecutions(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const executions = await campaignService.getCampaignExecutions(id);

      res.json({
        success: true,
        data: executions
      });
    } catch (error) {
      console.error('Erro ao buscar execuções:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar relatório de campanha
  async getCampaignReport(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const report = await campaignService.getCampaignReport(id);

      res.json({
        success: true,
        data: report
      });
    } catch (error) {
      console.error('Erro ao buscar relatório:', error);
      res.status(500).json({
        error: error instanceof Error ? error.message : 'Erro interno do servidor'
      });
    }
  }

  // Buscar analytics de campanhas
  async getCampaignAnalytics(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const analytics = await campaignService.getCampaignAnalytics(tenantId);

      res.json({
        success: true,
        data: analytics
      });
    } catch (error) {
      console.error('Erro ao buscar analytics:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar templates de campanha disponíveis
  async getCampaignTemplates(req: Request, res: Response) {
    try {
      const templates = [
        {
          id: 'promotional',
          name: 'Campanha Promocional',
          description: 'Template para campanhas promocionais com desconto',
          type: CampaignType.PROMOTIONAL,
          variables: ['clientName', 'discount', 'validUntil', 'serviceName']
        },
        {
          id: 'reactivation',
          name: 'Reativação de Cliente',
          description: 'Template para reativar clientes inativos',
          type: CampaignType.REACTIVATION,
          variables: ['clientName', 'lastVisit', 'specialOffer']
        },
        {
          id: 'birthday',
          name: 'Aniversário',
          description: 'Template para campanhas de aniversário',
          type: CampaignType.BIRTHDAY,
          variables: ['clientName', 'birthdayDiscount', 'validPeriod']
        }
      ];

      res.json({
        success: true,
        data: templates
      });
    } catch (error) {
      console.error('Erro ao buscar templates:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }
}