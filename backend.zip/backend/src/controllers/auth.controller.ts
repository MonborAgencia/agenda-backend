import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import { AuthService } from '../services/auth.service';
import { UserService } from '../services/user.service';
import { loginSchema, changePasswordSchema } from '../types/user.types';
import { validatePasswordStrength } from '../utils/password.utils';
import AuditService from '../services/audit.service';
import LoggerUtils from '../utils/logger.utils';

const prisma = new PrismaClient();
const authService = new AuthService(prisma);
const userService = new UserService(prisma);

/**
 * Login endpoint
 */
export async function login(req: Request, res: Response) {
  const context = LoggerUtils.createRequestContext(req);
  
  try {
    LoggerUtils.operationStart('USER_LOGIN', context);
    
    // Validate input
    const validatedData = loginSchema.parse(req.body);

    // Authenticate user
    const result = await authService.login(validatedData);

    // Log successful login
    AuditService.logAuth({
      userId: result.user.id,
      email: validatedData.email,
      action: 'LOGIN',
      ipAddress: req.ip || req.socket.remoteAddress || 'unknown',
      userAgent: req.headers['user-agent'] || 'unknown',
      success: true
    });

    LoggerUtils.operationEnd('USER_LOGIN', true, {
      ...context,
      userId: result.user.id
    });

    res.json({
      success: true,
      message: 'Login realizado com sucesso',
      data: result,
    });
  } catch (error) {
    LoggerUtils.error('Login failed', error as Error, context);
    
    // Log failed login attempt
    AuditService.logAuth({
      email: req.body.email,
      action: 'LOGIN_FAILED',
      ipAddress: req.ip || req.socket.remoteAddress || 'unknown',
      userAgent: req.headers['user-agent'] || 'unknown',
      success: false,
      errorMessage: error instanceof Error ? error.message : 'Unknown error'
    });

    LoggerUtils.operationEnd('USER_LOGIN', false, context);
    
    if (error instanceof Error) {
      return res.status(401).json({
        error: 'AUTHENTICATION_FAILED',
        message: error.message,
        requestId: req.requestId
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
      requestId: req.requestId
    });
  }
}

/**
 * Register endpoint
 */
export async function register(req: Request, res: Response) {
  const context = LoggerUtils.createRequestContext(req);
  
  try {
    LoggerUtils.operationStart('USER_REGISTER', context);
    
    // Create a modified schema for registration that accepts 'role' instead of 'roleIds'
    const registerSchema = z.object({
      email: z.string().email('Email inválido'),
      name: z.string().min(2, 'Nome deve ter pelo menos 2 caracteres').max(100, 'Nome muito longo'),
      phone: z.string().regex(/^\+?[\d\s\-\(\)]+$/, 'Formato de telefone inválido').optional(),
      password: z.string()
        .min(8, 'Senha deve ter pelo menos 8 caracteres')
        .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, 'Senha deve conter pelo menos uma letra minúscula, uma maiúscula e um número'),
      tenantId: z.string().optional(),
      role: z.enum(['ADMIN', 'PROFESSIONAL', 'CLIENT']).optional().default('CLIENT')
    });
    
    // Validate input
    const { role, ...userData } = registerSchema.parse(req.body);
    
    // Find role by name
    const roleRecord = await prisma.role.findUnique({
      where: { name: role }
    });
    
    if (!roleRecord) {
      return res.status(400).json({
        error: 'INVALID_ROLE',
        message: `Role '${role}' não encontrado`,
        requestId: req.requestId
      });
    }
    
    // Create validated data with roleIds
    const validatedData = {
      ...userData,
      roleIds: [roleRecord.id]
    };

    // Validate password strength
    const passwordValidation = validatePasswordStrength(validatedData.password);
    if (!passwordValidation.isValid) {
      LoggerUtils.warn('Password validation failed during registration', {
        ...context,
        email: validatedData.email,
        errors: passwordValidation.errors
      });
      
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: 'Senha não atende aos critérios de segurança',
        details: passwordValidation.errors,
        requestId: req.requestId
      });
    }

    // Check if user already exists
    const existingUser = await userService.getUserByEmail(validatedData.email);
    if (existingUser) {
      LoggerUtils.warn('Registration attempt with existing email', {
        ...context,
        email: validatedData.email
      });
      
      return res.status(409).json({
        error: 'USER_EXISTS',
        message: 'Usuário já existe com este email',
        requestId: req.requestId
      });
    }

    // Create user
    const user = await userService.createUser(validatedData);

    // Log successful registration
    AuditService.logAuth({
      userId: user.id,
      email: validatedData.email,
      action: 'REGISTER',
      ipAddress: req.ip || req.socket.remoteAddress || 'unknown',
      userAgent: req.headers['user-agent'] || 'unknown',
      success: true
    });

    LoggerUtils.operationEnd('USER_REGISTER', true, {
      ...context,
      userId: user.id
    });

    // Remove password from response
    const { password, ...userWithoutPassword } = user as any;

    res.status(201).json({
      success: true,
      message: 'Usuário criado com sucesso',
      data: { user: userWithoutPassword },
    });
  } catch (error) {
    LoggerUtils.error('Registration failed', error as Error, context);

    // Log failed registration
    AuditService.logAuth({
      email: req.body.email,
      action: 'REGISTER',
      ipAddress: req.ip || req.socket.remoteAddress || 'unknown',
      userAgent: req.headers['user-agent'] || 'unknown',
      success: false,
      errorMessage: error instanceof Error ? error.message : 'Unknown error'
    });

    LoggerUtils.operationEnd('USER_REGISTER', false, context);

    if (error instanceof Error && error.message.includes('validation')) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
        requestId: req.requestId
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
      requestId: req.requestId
    });
  }
}

/**
 * Refresh token endpoint
 */
export async function refreshToken(req: Request, res: Response) {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: 'Refresh token é obrigatório',
      });
    }

    const tokens = await authService.refreshToken(refreshToken);

    res.json({
      success: true,
      message: 'Token renovado com sucesso',
      data: { tokens },
    });
  } catch (error) {
    console.error('Refresh token error:', error);

    return res.status(401).json({
      error: 'INVALID_REFRESH_TOKEN',
      message: error instanceof Error ? error.message : 'Refresh token inválido',
    });
  }
}

/**
 * Logout endpoint
 */
export async function logout(req: Request, res: Response) {
  const context = LoggerUtils.createRequestContext(req);
  
  try {
    if (!req.user) {
      LoggerUtils.warn('Logout attempt without authentication', context);
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'Usuário não autenticado',
        requestId: req.requestId
      });
    }

    LoggerUtils.operationStart('USER_LOGOUT', {
      ...context,
      userId: req.user.userId
    });

    await authService.logout(req.user.userId);

    // Log successful logout
    AuditService.logAuth({
      userId: req.user.userId,
      action: 'LOGOUT',
      ipAddress: req.ip || req.socket.remoteAddress || 'unknown',
      userAgent: req.headers['user-agent'] || 'unknown',
      success: true
    });

    LoggerUtils.operationEnd('USER_LOGOUT', true, {
      ...context,
      userId: req.user.userId
    });

    res.json({
      success: true,
      message: 'Logout realizado com sucesso',
    });
  } catch (error) {
    LoggerUtils.error('Logout failed', error as Error, {
      ...context,
      userId: req.user?.userId
    });

    LoggerUtils.operationEnd('USER_LOGOUT', false, context);

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
      requestId: req.requestId
    });
  }
}

/**
 * Get current user endpoint
 */
export async function getCurrentUser(req: Request, res: Response) {
  try {
    if (!req.user) {
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'Usuário não autenticado',
      });
    }

    const user = await authService.getCurrentUser(req.user.userId);

    res.json({
      success: true,
      data: { user },
    });
  } catch (error) {
    console.error('Get current user error:', error);

    if (error instanceof Error && error.message === 'Sessão inválida') {
      return res.status(401).json({
        error: 'INVALID_SESSION',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Change password endpoint
 */
export async function changePassword(req: Request, res: Response) {
  try {
    if (!req.user) {
      return res.status(401).json({
        error: 'UNAUTHORIZED',
        message: 'Usuário não autenticado',
      });
    }

    // Validate input
    const validatedData = changePasswordSchema.parse(req.body);

    // Validate new password strength
    const passwordValidation = validatePasswordStrength(validatedData.newPassword);
    if (!passwordValidation.isValid) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: 'Nova senha não atende aos critérios de segurança',
        details: passwordValidation.errors,
      });
    }

    await authService.changePassword(
      req.user.userId,
      validatedData.currentPassword,
      validatedData.newPassword
    );

    res.json({
      success: true,
      message: 'Senha alterada com sucesso',
    });
  } catch (error) {
    console.error('Change password error:', error);

    if (error instanceof Error) {
      return res.status(400).json({
        error: 'CHANGE_PASSWORD_FAILED',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Request password reset endpoint
 */
export async function requestPasswordReset(req: Request, res: Response) {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: 'Email é obrigatório',
      });
    }

    await authService.requestPasswordReset(email);

    // Always return success to prevent email enumeration
    res.json({
      success: true,
      message: 'Se o email existir, você receberá instruções para redefinir sua senha',
    });
  } catch (error) {
    console.error('Request password reset error:', error);

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Verify email endpoint
 */
export async function verifyEmail(req: Request, res: Response) {
  try {
    const { token } = req.params;

    if (!token) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: 'Token de verificação é obrigatório',
      });
    }

    // In a real implementation, you would verify the token and get the user ID
    // For now, we'll assume the token contains the user ID
    // await authService.verifyEmail(userId);

    res.json({
      success: true,
      message: 'Email verificado com sucesso',
    });
  } catch (error) {
    console.error('Verify email error:', error);

    res.status(400).json({
      error: 'EMAIL_VERIFICATION_FAILED',
      message: 'Token de verificação inválido ou expirado',
    });
  }
}