import { Request, Response } from 'express';
import { notificationService } from '../services/notification.service';
import { notificationWorker } from '../workers/notification.worker';
import {
  CreateNotificationData,
  NotificationType,
  NotificationPriority,
  NotificationStatus,
  NotificationCategory
} from '../types/notification.types';

export class NotificationController {
  // Criar notificação
  async createNotification(req: Request, res: Response) {
    try {
      const data: CreateNotificationData = req.body;
      
      // Validar dados obrigatórios
      if (!data.recipientId || !data.type) {
        return res.status(400).json({
          error: 'Campos obrigatórios: recipientId, type'
        });
      }

      // Validar tipo de notificação
      if (!Object.values(NotificationType).includes(data.type)) {
        return res.status(400).json({
          error: 'Tipo de notificação inválido'
        });
      }

      // Se não tem template nem conteúdo, erro
      if (!data.templateId && !data.content) {
        return res.status(400).json({
          error: 'É necessário fornecer templateId ou content'
        });
      }

      const notification = await notificationService.createNotification(data);
      
      res.status(201).json({
        message: 'Notificação criada com sucesso',
        data: notification
      });
    } catch (error: any) {
      console.error('Erro ao criar notificação:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Criar e enfileirar notificação
  async createAndEnqueueNotification(req: Request, res: Response) {
    try {
      const { notificationData, processData } = req.body;
      
      if (!notificationData) {
        return res.status(400).json({
          error: 'notificationData é obrigatório'
        });
      }

      // Validar dados obrigatórios
      if (!notificationData.recipientId || !notificationData.type) {
        return res.status(400).json({
          error: 'Campos obrigatórios: recipientId, type'
        });
      }

      // Validar tipo de notificação
      if (!Object.values(NotificationType).includes(notificationData.type)) {
        return res.status(400).json({
          error: 'Tipo de notificação inválido'
        });
      }

      // Validar prioridade se fornecida
      if (processData?.priority && !Object.values(NotificationPriority).includes(processData.priority)) {
        return res.status(400).json({
          error: 'Prioridade inválida'
        });
      }

      const notification = await notificationService.createAndEnqueueNotification(
        notificationData,
        processData
      );
      
      res.status(201).json({
        message: 'Notificação criada e enfileirada com sucesso',
        data: notification
      });
    } catch (error: any) {
      console.error('Erro ao criar e enfileirar notificação:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar notificações
  async getNotifications(req: Request, res: Response) {
    try {
      const {
        type,
        status,
        recipientId,
        templateId,
        dateFrom,
        dateTo,
        page = '1',
        limit = '20'
      } = req.query;

      const filters: any = {};
      
      if (type) filters.type = type as NotificationType;
      if (status) filters.status = status as NotificationStatus;
      if (recipientId) filters.recipientId = recipientId as string;
      if (templateId) filters.templateId = templateId as string;
      if (dateFrom) filters.dateFrom = new Date(dateFrom as string);
      if (dateTo) filters.dateTo = new Date(dateTo as string);

      const pageNum = parseInt(page as string);
      const limitNum = parseInt(limit as string);

      const result = await notificationService.getNotifications(
        filters,
        pageNum,
        limitNum
      );
      
      res.json({
        message: 'Notificações encontradas',
        data: result.notifications,
        pagination: {
          page: result.page,
          limit: limitNum,
          total: result.total,
          totalPages: result.totalPages
        }
      });
    } catch (error) {
      console.error('Erro ao buscar notificações:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar notificação por ID
  async getNotificationById(req: Request, res: Response) {
    try {
      const { id } = req.params;
      
      const notification = await notificationService.getNotificationById(id);
      
      if (!notification) {
        return res.status(404).json({
          error: 'Notificação não encontrada'
        });
      }
      
      res.json({
        message: 'Notificação encontrada',
        data: notification
      });
    } catch (error) {
      console.error('Erro ao buscar notificação:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Enfileirar notificação existente
  async enqueueNotification(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const { priority, delay } = req.body;
      
      // Validar prioridade se fornecida
      if (priority && !Object.values(NotificationPriority).includes(priority)) {
        return res.status(400).json({
          error: 'Prioridade inválida'
        });
      }

      await notificationService.enqueueNotification({
        notificationId: id,
        priority,
        delay
      });
      
      res.json({
        message: 'Notificação adicionada à fila com sucesso'
      });
    } catch (error: any) {
      console.error('Erro ao enfileirar notificação:', error);
      
      if (error.message === 'Notificação não encontrada') {
        return res.status(404).json({
          error: error.message
        });
      }
      
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Cancelar notificação
  async cancelNotification(req: Request, res: Response) {
    try {
      const { id } = req.params;
      
      const success = await notificationService.cancelNotification(id);
      
      if (!success) {
        return res.status(404).json({
          error: 'Notificação não encontrada ou não pôde ser cancelada'
        });
      }
      
      res.json({
        message: 'Notificação cancelada com sucesso'
      });
    } catch (error) {
      console.error('Erro ao cancelar notificação:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Obter estatísticas das notificações
  async getNotificationStats(req: Request, res: Response) {
    try {
      const {
        type,
        recipientId,
        templateId,
        dateFrom,
        dateTo
      } = req.query;

      const filters: any = {};
      
      if (type) filters.type = type as NotificationType;
      if (recipientId) filters.recipientId = recipientId as string;
      if (templateId) filters.templateId = templateId as string;
      if (dateFrom) filters.dateFrom = new Date(dateFrom as string);
      if (dateTo) filters.dateTo = new Date(dateTo as string);

      const stats = await notificationService.getNotificationStats(filters);
      
      res.json({
        message: 'Estatísticas obtidas com sucesso',
        data: stats
      });
    } catch (error) {
      console.error('Erro ao obter estatísticas:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Obter informações da fila
  async getQueueInfo(req: Request, res: Response) {
    try {
      const { limit = '10' } = req.query;
      const limitNum = parseInt(limit as string);

      const [queueSize, queueItems, workerStatus] = await Promise.all([
        notificationService.getQueueSize(),
        notificationService.getQueueItems(limitNum),
        Promise.resolve(notificationWorker.getStatus())
      ]);
      
      res.json({
        message: 'Informações da fila obtidas com sucesso',
        data: {
          queueSize,
          queueItems,
          workerStatus
        }
      });
    } catch (error) {
      console.error('Erro ao obter informações da fila:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Reprocessar notificações falhadas
  async reprocessFailedNotifications(req: Request, res: Response) {
    try {
      const { limit = '50' } = req.body;
      const limitNum = parseInt(limit);

      const reprocessed = await notificationService.reprocessFailedNotifications(limitNum);
      
      res.json({
        message: 'Notificações falhadas reprocessadas',
        data: {
          reprocessed
        }
      });
    } catch (error) {
      console.error('Erro ao reprocessar notificações falhadas:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Limpar fila (usar com cuidado)
  async clearQueue(req: Request, res: Response) {
    try {
      const { confirm } = req.body;
      
      if (confirm !== 'CLEAR_QUEUE') {
        return res.status(400).json({
          error: 'Para confirmar, envie { "confirm": "CLEAR_QUEUE" }'
        });
      }

      const clearedCount = await notificationService.clearQueue();
      
      res.json({
        message: 'Fila limpa com sucesso',
        data: {
          clearedCount
        }
      });
    } catch (error) {
      console.error('Erro ao limpar fila:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Controlar worker
  async controlWorker(req: Request, res: Response) {
    try {
      const { action } = req.body;
      
      if (!['start', 'stop', 'status'].includes(action)) {
        return res.status(400).json({
          error: 'Ação inválida. Use: start, stop ou status'
        });
      }

      let result;
      
      switch (action) {
        case 'start':
          notificationWorker.start();
          result = { message: 'Worker iniciado' };
          break;
        case 'stop':
          notificationWorker.stop();
          result = { message: 'Worker parado' };
          break;
        case 'status':
          result = notificationWorker.getStatus();
          break;
      }
      
      res.json({
        message: 'Comando executado com sucesso',
        data: result
      });
    } catch (error) {
      console.error('Erro ao controlar worker:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }
}

export const notificationController = new NotificationController();