import { Request, Response } from 'express';
import { notificationProviderService } from '../services/notification-provider.service';
import { pushProvider } from '../providers/push.provider';
import { NotificationType } from '../types/notification.types';

export class NotificationProviderController {
  // Obter status de todos os providers
  async getProvidersStatus(req: Request, res: Response) {
    try {
      const status = notificationProviderService.getProvidersStatus();
      
      res.json({
        message: 'Status dos providers obtido com sucesso',
        data: status
      });
    } catch (error) {
      console.error('Erro ao obter status dos providers:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Testar conectividade de um provider
  async testProvider(req: Request, res: Response) {
    try {
      const { type } = req.params;
      
      if (!Object.values(NotificationType).includes(type as NotificationType)) {
        return res.status(400).json({
          error: 'Tipo de provider inválido'
        });
      }

      const result = await notificationProviderService.testProvider(type as NotificationType);
      
      res.json({
        message: 'Teste do provider concluído',
        data: result
      });
    } catch (error) {
      console.error('Erro ao testar provider:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Obter provider preferido de um usuário
  async getPreferredProvider(req: Request, res: Response) {
    try {
      const { userId } = req.params;
      
      const preferredProvider = await notificationProviderService.getPreferredProvider(userId);
      
      res.json({
        message: 'Provider preferido obtido com sucesso',
        data: {
          userId,
          preferredProvider
        }
      });
    } catch (error) {
      console.error('Erro ao obter provider preferido:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Definir provider preferido para um usuário
  async setPreferredProvider(req: Request, res: Response) {
    try {
      const { userId } = req.params;
      const { type } = req.body;
      
      if (!Object.values(NotificationType).includes(type)) {
        return res.status(400).json({
          error: 'Tipo de provider inválido'
        });
      }

      const success = await notificationProviderService.setPreferredProvider(userId, type);
      
      if (!success) {
        return res.status(400).json({
          error: 'Não foi possível definir o provider preferido'
        });
      }
      
      res.json({
        message: 'Provider preferido definido com sucesso',
        data: {
          userId,
          preferredProvider: type
        }
      });
    } catch (error) {
      console.error('Erro ao definir provider preferido:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Obter estatísticas de entrega por provider
  async getDeliveryStats(req: Request, res: Response) {
    try {
      const { dateFrom, dateTo } = req.query;
      
      const dateFromObj = dateFrom ? new Date(dateFrom as string) : undefined;
      const dateToObj = dateTo ? new Date(dateTo as string) : undefined;

      const stats = await notificationProviderService.getDeliveryStats(dateFromObj, dateToObj);
      
      res.json({
        message: 'Estatísticas de entrega obtidas com sucesso',
        data: stats
      });
    } catch (error) {
      console.error('Erro ao obter estatísticas de entrega:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Reconfigurar provider
  async reconfigureProvider(req: Request, res: Response) {
    try {
      const { type } = req.params;
      
      if (!Object.values(NotificationType).includes(type as NotificationType)) {
        return res.status(400).json({
          error: 'Tipo de provider inválido'
        });
      }

      const success = await notificationProviderService.reconfigureProvider(type as NotificationType);
      
      res.json({
        message: success ? 'Provider reconfigurado com sucesso' : 'Falha ao reconfigurar provider',
        data: {
          type,
          success,
          configured: notificationProviderService.isProviderConfigured(type as NotificationType)
        }
      });
    } catch (error) {
      console.error('Erro ao reconfigurar provider:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Adicionar token de push para um usuário
  async addPushToken(req: Request, res: Response) {
    try {
      const { userId } = req.params;
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({
          error: 'Token é obrigatório'
        });
      }

      const success = await pushProvider.addPushToken(userId, token);
      
      if (!success) {
        return res.status(400).json({
          error: 'Não foi possível adicionar o token'
        });
      }
      
      res.json({
        message: 'Token de push adicionado com sucesso',
        data: {
          userId,
          token
        }
      });
    } catch (error) {
      console.error('Erro ao adicionar token de push:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Remover token de push de um usuário
  async removePushToken(req: Request, res: Response) {
    try {
      const { userId } = req.params;
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({
          error: 'Token é obrigatório'
        });
      }

      const success = await pushProvider.removePushToken(userId, token);
      
      if (!success) {
        return res.status(400).json({
          error: 'Não foi possível remover o token'
        });
      }
      
      res.json({
        message: 'Token de push removido com sucesso',
        data: {
          userId,
          token
        }
      });
    } catch (error) {
      console.error('Erro ao remover token de push:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Enviar notificação para tópico (push notifications)
  async sendToTopic(req: Request, res: Response) {
    try {
      const { topic, title, body, data } = req.body;
      
      if (!topic || !title || !body) {
        return res.status(400).json({
          error: 'Campos obrigatórios: topic, title, body'
        });
      }

      const result = await pushProvider.sendToTopic(topic, title, body, data);
      
      if (result.success) {
        res.json({
          message: 'Notificação enviada para o tópico com sucesso',
          data: result
        });
      } else {
        res.status(400).json({
          error: result.error
        });
      }
    } catch (error) {
      console.error('Erro ao enviar para tópico:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Webhook do WhatsApp
  async whatsappWebhook(req: Request, res: Response) {
    try {
      const { whatsAppProvider } = await import('../providers/whatsapp.provider');
      
      if (req.method === 'GET') {
        // Verificação do webhook
        const mode = req.query['hub.mode'];
        const token = req.query['hub.verify_token'];
        const challenge = req.query['hub.challenge'];
        
        const result = await whatsAppProvider.verifyWebhook(
          mode as string,
          token as string,
          challenge as string
        );
        
        if (result) {
          res.status(200).send(result);
        } else {
          res.status(403).send('Forbidden');
        }
      } else if (req.method === 'POST') {
        // Processamento do webhook
        await whatsAppProvider.processWebhook(req.body);
        res.status(200).send('OK');
      } else {
        res.status(405).send('Method Not Allowed');
      }
    } catch (error) {
      console.error('Erro no webhook WhatsApp:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }
}

export const notificationProviderController = new NotificationProviderController();