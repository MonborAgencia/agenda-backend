import { Request, Response } from 'express';
import { scheduleService } from '../services/schedule.service';
import { 
  CreateScheduleRequest, 
  UpdateScheduleRequest,
  CreateScheduleExceptionRequest,
  UpdateScheduleExceptionRequest,
  WeeklyScheduleRequest,
  SlotGenerationRequest,
  SlotReservationRequest
} from '../types/schedule.types';

export class ScheduleController {
  /**
   * Criar novo horário de trabalho
   */
  async createSchedule(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const scheduleData: CreateScheduleRequest = req.body;

      // Validações básicas
      if (!scheduleData.professionalId || scheduleData.dayOfWeek === undefined || 
          !scheduleData.startTime || !scheduleData.endTime) {
        return res.status(400).json({ 
          error: 'Profissional, dia da semana, horário de início e fim são obrigatórios' 
        });
      }

      const schedule = await scheduleService.createSchedule(scheduleData, tenantId);

      res.status(201).json({
        message: 'Horário criado com sucesso',
        data: schedule
      });
    } catch (error: any) {
      console.error('Erro ao criar horário:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Buscar horários de um profissional
   */
  async getSchedulesByProfessional(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { professionalId } = req.params;
      const schedules = await scheduleService.getSchedulesByProfessional(professionalId, tenantId);

      res.json({
        message: 'Horários encontrados',
        data: schedules,
        count: schedules.length
      });
    } catch (error: any) {
      console.error('Erro ao buscar horários:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Atualizar horário
   */
  async updateSchedule(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { id } = req.params;
      const updateData: UpdateScheduleRequest = req.body;

      const schedule = await scheduleService.updateSchedule(id, updateData, tenantId);

      res.json({
        message: 'Horário atualizado com sucesso',
        data: schedule
      });
    } catch (error: any) {
      console.error('Erro ao atualizar horário:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Deletar horário
   */
  async deleteSchedule(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { id } = req.params;
      await scheduleService.deleteSchedule(id, tenantId);

      res.json({
        message: 'Horário deletado com sucesso'
      });
    } catch (error: any) {
      console.error('Erro ao deletar horário:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Configurar horários da semana completa
   */
  async setWeeklySchedule(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const weeklyData: WeeklyScheduleRequest = req.body;

      if (!weeklyData.professionalId || !weeklyData.schedules) {
        return res.status(400).json({ 
          error: 'Profissional e horários são obrigatórios' 
        });
      }

      const schedules = await scheduleService.setWeeklySchedule(weeklyData, tenantId);

      res.json({
        message: 'Horários da semana configurados com sucesso',
        data: schedules,
        count: schedules.length
      });
    } catch (error: any) {
      console.error('Erro ao configurar horários da semana:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Criar exceção de horário
   */
  async createScheduleException(req: Request, res: Response) {
    try {
      const exceptionData: CreateScheduleExceptionRequest = req.body;

      if (!exceptionData.scheduleId || !exceptionData.date || 
          exceptionData.isBlocked === undefined) {
        return res.status(400).json({ 
          error: 'ID do horário, data e status de bloqueio são obrigatórios' 
        });
      }

      const exception = await scheduleService.createScheduleException(exceptionData);

      res.status(201).json({
        message: 'Exceção criada com sucesso',
        data: exception
      });
    } catch (error: any) {
      console.error('Erro ao criar exceção:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Atualizar exceção de horário
   */
  async updateScheduleException(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const updateData: UpdateScheduleExceptionRequest = req.body;

      const exception = await scheduleService.updateScheduleException(id, updateData);

      res.json({
        message: 'Exceção atualizada com sucesso',
        data: exception
      });
    } catch (error: any) {
      console.error('Erro ao atualizar exceção:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Deletar exceção de horário
   */
  async deleteScheduleException(req: Request, res: Response) {
    try {
      const { id } = req.params;
      await scheduleService.deleteScheduleException(id);

      res.json({
        message: 'Exceção deletada com sucesso'
      });
    } catch (error: any) {
      console.error('Erro ao deletar exceção:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Buscar disponibilidade de um dia específico
   */
  async getDayAvailability(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { professionalId } = req.params;
      const { date, duration } = req.query;

      if (!date) {
        return res.status(400).json({ error: 'Data é obrigatória' });
      }

      const serviceDuration = duration ? parseInt(duration as string) : 60;
      const availability = await scheduleService.getDayAvailability(
        professionalId, 
        date as string, 
        serviceDuration,
        tenantId
      );

      res.json({
        message: 'Disponibilidade encontrada',
        data: availability
      });
    } catch (error: any) {
      console.error('Erro ao buscar disponibilidade:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Visualização de agenda diária
   */
  async getDailyAgenda(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { date } = req.params;
      const { professionalId, serviceId } = req.query;

      if (!date) {
        return res.status(400).json({ error: 'Data é obrigatória' });
      }

      const agenda = await scheduleService.getDailyAgenda(
        date,
        professionalId as string,
        serviceId as string,
        tenantId
      );

      res.json({
        message: 'Agenda diária encontrada',
        data: agenda
      });
    } catch (error: any) {
      console.error('Erro ao buscar agenda diária:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Visualização de agenda semanal
   */
  async getWeeklyAgenda(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { startDate } = req.params;
      const { professionalId, serviceId } = req.query;

      if (!startDate) {
        return res.status(400).json({ error: 'Data de início é obrigatória' });
      }

      const agenda = await scheduleService.getWeeklyAgenda(
        startDate,
        professionalId as string,
        serviceId as string,
        tenantId
      );

      res.json({
        message: 'Agenda semanal encontrada',
        data: agenda
      });
    } catch (error: any) {
      console.error('Erro ao buscar agenda semanal:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Visualização de agenda mensal
   */
  async getMonthlyAgenda(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { year, month } = req.params;
      const { professionalId, serviceId } = req.query;

      if (!year || !month) {
        return res.status(400).json({ error: 'Ano e mês são obrigatórios' });
      }

      const agenda = await scheduleService.getMonthlyAgenda(
        parseInt(year),
        parseInt(month),
        professionalId as string,
        serviceId as string,
        tenantId
      );

      res.json({
        message: 'Agenda mensal encontrada',
        data: agenda
      });
    } catch (error: any) {
      console.error('Erro ao buscar agenda mensal:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Gerar slots disponíveis
   */
  async generateAvailableSlots(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { professionalId, serviceId, startDate, endDate }: SlotGenerationRequest = req.body;

      if (!professionalId || !serviceId || !startDate || !endDate) {
        return res.status(400).json({ 
          error: 'Profissional, serviço, data de início e fim são obrigatórios' 
        });
      }

      const slots = await scheduleService.generateAvailableSlots(
        { professionalId, serviceId, startDate, endDate },
        tenantId
      );

      res.json({
        message: 'Slots disponíveis gerados',
        data: slots,
        count: slots.length,
        availableCount: slots.filter(slot => slot.isAvailable).length
      });
    } catch (error: any) {
      console.error('Erro ao gerar slots disponíveis:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Reservar slot temporariamente
   */
  async reserveSlotTemporarily(req: Request, res: Response) {
    try {
      const { slotId, reservationMinutes }: SlotReservationRequest = req.body;
      const clientId = req.user?.id;

      if (!slotId || !clientId) {
        return res.status(400).json({ 
          error: 'ID do slot e cliente são obrigatórios' 
        });
      }

      const reservation = await scheduleService.reserveSlotTemporarily({
        slotId,
        clientId,
        reservationMinutes
      });

      res.json({
        message: 'Slot reservado temporariamente',
        data: reservation
      });
    } catch (error: any) {
      console.error('Erro ao reservar slot:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Liberar reserva temporária
   */
  async releaseSlotReservation(req: Request, res: Response) {
    try {
      const { slotId } = req.params;

      if (!slotId) {
        return res.status(400).json({ error: 'ID do slot é obrigatório' });
      }

      await scheduleService.releaseSlotReservation(slotId);

      res.json({
        message: 'Reserva liberada com sucesso'
      });
    } catch (error: any) {
      console.error('Erro ao liberar reserva:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Buscar reserva de slot
   */
  async getSlotReservation(req: Request, res: Response) {
    try {
      const { slotId } = req.params;

      if (!slotId) {
        return res.status(400).json({ error: 'ID do slot é obrigatório' });
      }

      const reservation = await scheduleService.getSlotReservation(slotId);

      if (!reservation) {
        return res.status(404).json({ error: 'Reserva não encontrada ou expirada' });
      }

      res.json({
        message: 'Reserva encontrada',
        data: reservation
      });
    } catch (error: any) {
      console.error('Erro ao buscar reserva:', error);
      res.status(400).json({ error: error.message });
    }
  }
}

export const scheduleController = new ScheduleController();