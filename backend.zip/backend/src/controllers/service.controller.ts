import { Request, Response } from 'express';
import { serviceService } from '../services/service.service';
import { CreateServiceRequest, UpdateServiceRequest, ServiceFilters } from '../types/service.types';

export class ServiceController {
  /**
   * Criar novo serviço
   */
  async createService(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const serviceData: CreateServiceRequest = req.body;

      // Validações básicas
      if (!serviceData.name || !serviceData.duration || !serviceData.price || !serviceData.professionalId) {
        return res.status(400).json({ 
          error: 'Nome, duração, preço e profissional são obrigatórios' 
        });
      }

      if (serviceData.duration <= 0) {
        return res.status(400).json({ error: 'Duração deve ser maior que zero' });
      }

      if (serviceData.price <= 0) {
        return res.status(400).json({ error: 'Preço deve ser maior que zero' });
      }

      const service = await serviceService.createService(serviceData, tenantId);

      res.status(201).json({
        message: 'Serviço criado com sucesso',
        data: service
      });
    } catch (error: any) {
      console.error('Erro ao criar serviço:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Listar serviços com filtros
   */
  async getServices(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const filters: ServiceFilters = {
        category: req.query.category as string,
        professionalId: req.query.professionalId as string,
        isActive: req.query.isActive ? req.query.isActive === 'true' : undefined,
        minPrice: req.query.minPrice ? parseFloat(req.query.minPrice as string) : undefined,
        maxPrice: req.query.maxPrice ? parseFloat(req.query.maxPrice as string) : undefined,
        minDuration: req.query.minDuration ? parseInt(req.query.minDuration as string) : undefined,
        maxDuration: req.query.maxDuration ? parseInt(req.query.maxDuration as string) : undefined
      };

      const services = await serviceService.getServices(tenantId, filters);

      res.json({
        message: 'Serviços encontrados',
        data: services,
        count: services.length
      });
    } catch (error: any) {
      console.error('Erro ao buscar serviços:', error);
      res.status(500).json({ error: error.message });
    }
  }

  /**
   * Buscar serviço por ID
   */
  async getServiceById(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { id } = req.params;
      const service = await serviceService.getServiceById(id, tenantId);

      if (!service) {
        return res.status(404).json({ error: 'Serviço não encontrado' });
      }

      res.json({
        message: 'Serviço encontrado',
        data: service
      });
    } catch (error: any) {
      console.error('Erro ao buscar serviço:', error);
      res.status(500).json({ error: error.message });
    }
  }

  /**
   * Atualizar serviço
   */
  async updateService(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { id } = req.params;
      const updateData: UpdateServiceRequest = req.body;

      // Validações
      if (updateData.duration !== undefined && updateData.duration <= 0) {
        return res.status(400).json({ error: 'Duração deve ser maior que zero' });
      }

      if (updateData.price !== undefined && updateData.price <= 0) {
        return res.status(400).json({ error: 'Preço deve ser maior que zero' });
      }

      const service = await serviceService.updateService(id, updateData, tenantId);

      res.json({
        message: 'Serviço atualizado com sucesso',
        data: service
      });
    } catch (error: any) {
      console.error('Erro ao atualizar serviço:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Deletar serviço
   */
  async deleteService(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { id } = req.params;
      await serviceService.deleteService(id, tenantId);

      res.json({
        message: 'Serviço deletado com sucesso'
      });
    } catch (error: any) {
      console.error('Erro ao deletar serviço:', error);
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Buscar serviços por profissional
   */
  async getServicesByProfessional(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { professionalId } = req.params;
      const services = await serviceService.getServicesByProfessional(professionalId, tenantId);

      res.json({
        message: 'Serviços do profissional encontrados',
        data: services,
        count: services.length
      });
    } catch (error: any) {
      console.error('Erro ao buscar serviços do profissional:', error);
      res.status(500).json({ error: error.message });
    }
  }

  /**
   * Buscar categorias de serviços
   */
  async getServiceCategories(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const categories = await serviceService.getServiceCategories(tenantId);

      res.json({
        message: 'Categorias encontradas',
        data: categories,
        count: categories.length
      });
    } catch (error: any) {
      console.error('Erro ao buscar categorias:', error);
      res.status(500).json({ error: error.message });
    }
  }

  /**
   * Transferir serviço para outro profissional
   */
  async transferService(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({ error: 'Tenant ID é obrigatório' });
      }

      const { id } = req.params;
      const { professionalId } = req.body;

      if (!professionalId) {
        return res.status(400).json({ error: 'ID do profissional é obrigatório' });
      }

      const service = await serviceService.transferService(id, professionalId, tenantId);

      res.json({
        message: 'Serviço transferido com sucesso',
        data: service
      });
    } catch (error: any) {
      console.error('Erro ao transferir serviço:', error);
      res.status(400).json({ error: error.message });
    }
  }
}

export const serviceController = new ServiceController();