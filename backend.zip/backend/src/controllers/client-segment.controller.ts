import { Request, Response } from 'express';
import { ClientSegmentService } from '../services/client-segment.service';
import { CreateClientSegmentDto, UpdateClientSegmentDto } from '../types/campaign.types';

const clientSegmentService = new ClientSegmentService();

export class ClientSegmentController {
  // Criar novo segmento
  async createSegment(req: Request, res: Response) {
    try {
      const { name, description, criteria } = req.body;

      // Validações básicas
      if (!name || !criteria) {
        return res.status(400).json({
          error: 'Nome e critérios do segmento são obrigatórios'
        });
      }

      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const segmentData: CreateClientSegmentDto = {
        name,
        description,
        tenantId,
        criteria
      };

      const segment = await clientSegmentService.createSegment(segmentData);

      res.status(201).json({
        success: true,
        data: segment
      });
    } catch (error) {
      console.error('Erro ao criar segmento:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Listar segmentos
  async getSegments(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const segments = await clientSegmentService.getSegmentsByTenant(tenantId);

      res.json({
        success: true,
        data: segments
      });
    } catch (error) {
      console.error('Erro ao buscar segmentos:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar segmento por ID
  async getSegmentById(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const segment = await clientSegmentService.getSegmentById(id);

      if (!segment) {
        return res.status(404).json({
          error: 'Segmento não encontrado'
        });
      }

      res.json({
        success: true,
        data: segment
      });
    } catch (error) {
      console.error('Erro ao buscar segmento:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Atualizar segmento
  async updateSegment(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const updateData: UpdateClientSegmentDto = req.body;

      const segment = await clientSegmentService.updateSegment(id, updateData);

      res.json({
        success: true,
        data: segment
      });
    } catch (error) {
      console.error('Erro ao atualizar segmento:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Deletar segmento
  async deleteSegment(req: Request, res: Response) {
    try {
      const { id } = req.params;
      await clientSegmentService.deleteSegment(id);

      res.json({
        success: true,
        message: 'Segmento deletado com sucesso'
      });
    } catch (error) {
      console.error('Erro ao deletar segmento:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar clientes de um segmento
  async getSegmentClients(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 50;

      const result = await clientSegmentService.getSegmentClients(id, page, limit);

      res.json({
        success: true,
        data: result
      });
    } catch (error) {
      console.error('Erro ao buscar clientes do segmento:', error);
      res.status(500).json({
        error: error instanceof Error ? error.message : 'Erro interno do servidor'
      });
    }
  }

  // Calcular tamanho do segmento
  async calculateSegmentSize(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const size = await clientSegmentService.calculateSegmentSize(id);

      res.json({
        success: true,
        data: { size }
      });
    } catch (error) {
      console.error('Erro ao calcular tamanho do segmento:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Atualizar contagens de todos os segmentos
  async updateAllSegmentCounts(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      await clientSegmentService.updateAllSegmentCounts(tenantId);

      res.json({
        success: true,
        message: 'Contagens atualizadas com sucesso'
      });
    } catch (error) {
      console.error('Erro ao atualizar contagens:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar segmentos sugeridos
  async getSuggestedSegments(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const suggestions = await clientSegmentService.getSuggestedSegments(tenantId);

      res.json({
        success: true,
        data: suggestions
      });
    } catch (error) {
      console.error('Erro ao buscar segmentos sugeridos:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Preview de segmento (calcular sem salvar)
  async previewSegment(req: Request, res: Response) {
    try {
      const { criteria } = req.body;
      const tenantId = req.user?.tenantId;

      if (!criteria || !tenantId) {
        return res.status(400).json({
          error: 'Critérios e tenant ID são obrigatórios'
        });
      }

      // Criar segmento temporário para calcular
      const tempSegment = {
        id: 'temp',
        name: 'Preview',
        tenantId,
        criteria,
        description: '',
        isActive: true,
        lastUpdated: new Date(),
        clientCount: 0,
        createdAt: new Date(),
        updatedAt: new Date()
      };

      const userIds = await clientSegmentService.getUsersInSegment(tempSegment);
      const size = userIds.length;

      // Buscar alguns exemplos de clientes
      const exampleClients = await clientSegmentService.getSegmentClients('temp', 1, 5);

      res.json({
        success: true,
        data: {
          size,
          examples: exampleClients.clients
        }
      });
    } catch (error) {
      console.error('Erro ao fazer preview do segmento:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar critérios disponíveis para segmentação
  async getSegmentationCriteria(req: Request, res: Response) {
    try {
      const criteria = {
        demographic: [
          {
            key: 'ageRange',
            name: 'Faixa Etária',
            type: 'range',
            description: 'Idade mínima e máxima dos clientes'
          },
          {
            key: 'gender',
            name: 'Gênero',
            type: 'multiselect',
            options: ['Masculino', 'Feminino', 'Outro'],
            description: 'Gênero dos clientes'
          },
          {
            key: 'location',
            name: 'Localização',
            type: 'multiselect',
            description: 'Cidade ou região dos clientes'
          }
        ],
        behavioral: [
          {
            key: 'lastBookingDays',
            name: 'Último Agendamento',
            type: 'number',
            description: 'Dias desde o último agendamento'
          },
          {
            key: 'totalBookings',
            name: 'Total de Agendamentos',
            type: 'range',
            description: 'Número total de agendamentos realizados'
          },
          {
            key: 'totalSpent',
            name: 'Valor Total Gasto',
            type: 'range',
            description: 'Valor total gasto em serviços'
          }
        ],
        engagement: [
          {
            key: 'openRate',
            name: 'Taxa de Abertura',
            type: 'range',
            description: 'Porcentagem de abertura de mensagens'
          },
          {
            key: 'clickRate',
            name: 'Taxa de Clique',
            type: 'range',
            description: 'Porcentagem de cliques em mensagens'
          }
        ],
        services: [
          {
            key: 'preferredServices',
            name: 'Serviços Preferidos',
            type: 'multiselect',
            description: 'Serviços mais utilizados pelo cliente'
          },
          {
            key: 'preferredProfessionals',
            name: 'Profissionais Preferidos',
            type: 'multiselect',
            description: 'Profissionais mais procurados pelo cliente'
          }
        ],
        temporal: [
          {
            key: 'registrationDate',
            name: 'Data de Cadastro',
            type: 'daterange',
            description: 'Período de cadastro do cliente'
          },
          {
            key: 'lastLoginDays',
            name: 'Último Login',
            type: 'number',
            description: 'Dias desde o último login'
          }
        ],
        status: [
          {
            key: 'isActive',
            name: 'Status Ativo',
            type: 'boolean',
            description: 'Cliente ativo ou inativo'
          },
          {
            key: 'hasNoShow',
            name: 'Histórico de Faltas',
            type: 'boolean',
            description: 'Cliente com histórico de faltas'
          }
        ]
      };

      res.json({
        success: true,
        data: criteria
      });
    } catch (error) {
      console.error('Erro ao buscar critérios:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }
}