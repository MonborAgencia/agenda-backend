import { Request, Response } from 'express';
import { ClientReactivationService, ReactivationCampaignConfig } from '../services/client-reactivation.service';

const reactivationService = new ClientReactivationService();

export class ClientReactivationController {
  // Detectar clientes inativos
  async getInactiveClients(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const inactivityThreshold = parseInt(req.query.days as string) || 90;
      const inactiveClients = await reactivationService.detectInactiveClients(tenantId, inactivityThreshold);

      res.json({
        success: true,
        data: {
          inactiveClients,
          summary: {
            total: inactiveClients.length,
            highRisk: inactiveClients.filter(c => c.riskScore > 70).length,
            mediumRisk: inactiveClients.filter(c => c.riskScore >= 40 && c.riskScore <= 70).length,
            lowRisk: inactiveClients.filter(c => c.riskScore < 40).length,
          }
        }
      });
    } catch (error) {
      console.error('Erro ao buscar clientes inativos:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Criar campanha de reativação
  async createReactivationCampaign(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const {
        name,
        description,
        templateId,
        inactivityThreshold,
        targetSegments,
        personalizedOffers,
        discountPercentage,
        validityDays
      } = req.body;

      if (!name || !inactivityThreshold) {
        return res.status(400).json({
          error: 'Nome e threshold de inatividade são obrigatórios'
        });
      }

      const config: ReactivationCampaignConfig = {
        name,
        description,
        tenantId,
        templateId,
        inactivityThreshold,
        targetSegments,
        personalizedOffers: personalizedOffers || false,
        discountPercentage,
        validityDays,
      };

      const campaignId = await reactivationService.createReactivationCampaign(config);

      res.status(201).json({
        success: true,
        data: { campaignId },
        message: 'Campanha de reativação criada com sucesso'
      });
    } catch (error) {
      console.error('Erro ao criar campanha de reativação:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Executar reativação personalizada
  async executePersonalizedReactivation(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const { campaignId } = req.params;
      const config: ReactivationCampaignConfig = req.body;

      await reactivationService.executePersonalizedReactivation(tenantId, campaignId, config);

      res.json({
        success: true,
        message: 'Reativação personalizada executada com sucesso'
      });
    } catch (error) {
      console.error('Erro ao executar reativação personalizada:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Analisar efetividade das campanhas de reativação
  async getReactivationMetrics(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const { campaignId } = req.query;
      const metrics = await reactivationService.analyzeReactivationEffectiveness(
        tenantId,
        campaignId as string
      );

      res.json({
        success: true,
        data: metrics
      });
    } catch (error) {
      console.error('Erro ao analisar métricas de reativação:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Sugerir ações de reativação
  async getReactivationSuggestions(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const suggestions = await reactivationService.suggestReactivationActions(tenantId);

      res.json({
        success: true,
        data: { suggestions }
      });
    } catch (error) {
      console.error('Erro ao buscar sugestões de reativação:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Configurar reativação automática
  async setupAutomaticReactivation(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      await reactivationService.scheduleAutomaticReactivation(tenantId);

      res.json({
        success: true,
        message: 'Reativação automática configurada com sucesso'
      });
    } catch (error) {
      console.error('Erro ao configurar reativação automática:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Buscar templates de reativação
  async getReactivationTemplates(req: Request, res: Response) {
    try {
      const templates = [
        {
          id: 'reactivation-basic',
          name: 'Reativação Básica',
          description: 'Template simples para reativar clientes',
          content: 'Olá {{clientName}}! Sentimos sua falta. Que tal agendar um novo horário?',
          variables: ['clientName', 'lastVisit', 'preferredService']
        },
        {
          id: 'reactivation-discount',
          name: 'Reativação com Desconto',
          description: 'Template com oferta de desconto',
          content: 'Oi {{clientName}}! Temos uma oferta especial de {{discount}}% de desconto para seu retorno. Válida até {{validUntil}}.',
          variables: ['clientName', 'discount', 'validUntil', 'preferredService']
        },
        {
          id: 'reactivation-vip',
          name: 'Reativação VIP',
          description: 'Template para clientes especiais',
          content: 'Olá {{clientName}}! Como cliente especial, preparamos uma oferta exclusiva. {{specialOffer}}',
          variables: ['clientName', 'specialOffer', 'totalSpent', 'memberSince']
        },
        {
          id: 'reactivation-birthday',
          name: 'Reativação Aniversário',
          description: 'Template para aniversariantes inativos',
          content: 'Parabéns {{clientName}}! Em comemoração ao seu aniversário, temos um presente especial: {{birthdayOffer}}',
          variables: ['clientName', 'birthdayOffer', 'validPeriod']
        }
      ];

      res.json({
        success: true,
        data: templates
      });
    } catch (error) {
      console.error('Erro ao buscar templates:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  // Simular campanha de reativação
  async simulateReactivationCampaign(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(400).json({
          error: 'Tenant ID é obrigatório'
        });
      }

      const { inactivityThreshold, discountPercentage } = req.body;

      if (!inactivityThreshold) {
        return res.status(400).json({
          error: 'Threshold de inatividade é obrigatório'
        });
      }

      const inactiveClients = await reactivationService.detectInactiveClients(tenantId, inactivityThreshold);
      
      // Simular resultados baseados em dados históricos
      const estimatedOpenRate = 0.25; // 25%
      const estimatedClickRate = 0.15; // 15%
      const estimatedConversionRate = 0.08; // 8%

      const simulation = {
        targetAudience: inactiveClients.length,
        estimatedOpens: Math.round(inactiveClients.length * estimatedOpenRate),
        estimatedClicks: Math.round(inactiveClients.length * estimatedClickRate),
        estimatedConversions: Math.round(inactiveClients.length * estimatedConversionRate),
        estimatedRevenue: Math.round(
          inactiveClients.reduce((sum, client) => sum + client.averageBookingValue, 0) * 
          estimatedConversionRate
        ),
        riskDistribution: {
          high: inactiveClients.filter(c => c.riskScore > 70).length,
          medium: inactiveClients.filter(c => c.riskScore >= 40 && c.riskScore <= 70).length,
          low: inactiveClients.filter(c => c.riskScore < 40).length,
        },
        topClients: inactiveClients
          .sort((a, b) => b.totalSpent - a.totalSpent)
          .slice(0, 5)
          .map(client => ({
            name: client.name,
            totalSpent: client.totalSpent,
            daysSinceLastBooking: client.daysSinceLastBooking,
            riskScore: client.riskScore,
          })),
      };

      res.json({
        success: true,
        data: simulation
      });
    } catch (error) {
      console.error('Erro ao simular campanha:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }
}