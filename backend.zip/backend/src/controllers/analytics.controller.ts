import { Request, Response } from 'express';
import { analyticsService } from '../services/analytics.service';
import { AnalyticsFilters } from '../types/analytics.types';

export class AnalyticsController {
  /**
   * GET /analytics/dashboard
   * Retorna métricas completas do dashboard
   */
  async getDashboardMetrics(req: Request, res: Response) {
    try {
      const { tenantId, startDate, endDate, professionalId, serviceId, status } = req.query;

      if (!tenantId || !startDate || !endDate) {
        return res.status(400).json({
          error: 'tenantId, startDate e endDate são obrigatórios'
        });
      }

      const filters: AnalyticsFilters = {
        tenantId: tenantId as string,
        dateRange: {
          startDate: new Date(startDate as string),
          endDate: new Date(endDate as string)
        },
        professionalId: professionalId as string,
        serviceId: serviceId as string,
        status: status ? (status as string).split(',') : undefined
      };

      const metrics = await analyticsService.generateDashboardMetrics(filters);

      res.json({
        success: true,
        data: metrics
      });
    } catch (error) {
      console.error('Erro ao buscar métricas do dashboard:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  /**
   * GET /analytics/occupancy
   * Retorna métricas de ocupação
   */
  async getOccupancyMetrics(req: Request, res: Response) {
    try {
      const { tenantId, startDate, endDate, professionalId } = req.query;

      if (!tenantId || !startDate || !endDate) {
        return res.status(400).json({
          error: 'tenantId, startDate e endDate são obrigatórios'
        });
      }

      const filters: AnalyticsFilters = {
        tenantId: tenantId as string,
        dateRange: {
          startDate: new Date(startDate as string),
          endDate: new Date(endDate as string)
        },
        professionalId: professionalId as string
      };

      const occupancy = await analyticsService.calculateOccupancyMetrics(filters);

      res.json({
        success: true,
        data: occupancy
      });
    } catch (error) {
      console.error('Erro ao buscar métricas de ocupação:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  /**
   * GET /analytics/revenue
   * Retorna métricas de faturamento
   */
  async getRevenueMetrics(req: Request, res: Response) {
    try {
      const { tenantId, startDate, endDate, professionalId, serviceId } = req.query;

      if (!tenantId || !startDate || !endDate) {
        return res.status(400).json({
          error: 'tenantId, startDate e endDate são obrigatórios'
        });
      }

      const filters: AnalyticsFilters = {
        tenantId: tenantId as string,
        dateRange: {
          startDate: new Date(startDate as string),
          endDate: new Date(endDate as string)
        },
        professionalId: professionalId as string,
        serviceId: serviceId as string
      };

      const revenue = await analyticsService.calculateRevenueMetrics(filters);

      res.json({
        success: true,
        data: revenue
      });
    } catch (error) {
      console.error('Erro ao buscar métricas de faturamento:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  /**
   * GET /analytics/profitable-hours
   * Retorna análise de horários mais rentáveis
   */
  async getProfitableHours(req: Request, res: Response) {
    try {
      const { tenantId, startDate, endDate, professionalId } = req.query;

      if (!tenantId || !startDate || !endDate) {
        return res.status(400).json({
          error: 'tenantId, startDate e endDate são obrigatórios'
        });
      }

      const filters: AnalyticsFilters = {
        tenantId: tenantId as string,
        dateRange: {
          startDate: new Date(startDate as string),
          endDate: new Date(endDate as string)
        },
        professionalId: professionalId as string
      };

      const profitableHours = await analyticsService.analyzeProfitableHours(filters);

      res.json({
        success: true,
        data: profitableHours
      });
    } catch (error) {
      console.error('Erro ao buscar horários rentáveis:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  /**
   * GET /analytics/services
   * Retorna métricas por serviço
   */
  async getServiceMetrics(req: Request, res: Response) {
    try {
      const { tenantId, startDate, endDate, professionalId } = req.query;

      if (!tenantId || !startDate || !endDate) {
        return res.status(400).json({
          error: 'tenantId, startDate e endDate são obrigatórios'
        });
      }

      const filters: AnalyticsFilters = {
        tenantId: tenantId as string,
        dateRange: {
          startDate: new Date(startDate as string),
          endDate: new Date(endDate as string)
        },
        professionalId: professionalId as string
      };

      const services = await analyticsService.calculateServiceMetrics(filters);

      res.json({
        success: true,
        data: services
      });
    } catch (error) {
      console.error('Erro ao buscar métricas de serviços:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  /**
   * GET /analytics/professionals
   * Retorna métricas por profissional
   */
  async getProfessionalMetrics(req: Request, res: Response) {
    try {
      const { tenantId, startDate, endDate } = req.query;

      if (!tenantId || !startDate || !endDate) {
        return res.status(400).json({
          error: 'tenantId, startDate e endDate são obrigatórios'
        });
      }

      const filters: AnalyticsFilters = {
        tenantId: tenantId as string,
        dateRange: {
          startDate: new Date(startDate as string),
          endDate: new Date(endDate as string)
        }
      };

      const professionals = await analyticsService.calculateProfessionalMetrics(filters);

      res.json({
        success: true,
        data: professionals
      });
    } catch (error) {
      console.error('Erro ao buscar métricas de profissionais:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }
}

export const analyticsController = new AnalyticsController();