import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { TenantService, CustomField } from '../services/tenant.service';
import { getLogoUrl, getFaviconUrl } from '../middleware/tenant-upload.middleware';
import { z } from 'zod';

const prisma = new PrismaClient();
const tenantService = new TenantService(prisma);

// Validation schemas
const customFieldSchema = z.object({
  name: z.string().min(1, 'Nome é obrigatório').max(50, 'Nome muito longo'),
  type: z.enum(['text', 'number', 'email', 'phone', 'select', 'multiselect', 'date', 'boolean']),
  label: z.string().min(1, 'Label é obrigatório').max(100, 'Label muito longo'),
  placeholder: z.string().max(200, 'Placeholder muito longo').optional(),
  required: z.boolean().default(false),
  options: z.array(z.string()).optional(),
  validation: z.object({
    min: z.number().optional(),
    max: z.number().optional(),
    pattern: z.string().optional(),
  }).optional(),
  order: z.number().default(0),
});

const createTenantSchema = z.object({
  name: z.string().min(1, 'Nome é obrigatório').max(100, 'Nome muito longo'),
  slug: z.string()
    .min(1, 'Slug é obrigatório')
    .max(50, 'Slug muito longo')
    .regex(/^[a-z0-9-]+$/, 'Slug deve conter apenas letras minúsculas, números e hífens'),
  primaryColor: z.string().regex(/^#[0-9A-F]{6}$/i, 'Cor primária inválida').optional(),
  settings: z.object({
    branding: z.object({
      primaryColor: z.string().regex(/^#[0-9A-F]{6}$/i, 'Cor primária inválida').optional(),
      secondaryColor: z.string().regex(/^#[0-9A-F]{6}$/i, 'Cor secundária inválida').optional(),
    }).optional(),
    features: z.object({
      enableWhatsApp: z.boolean().optional(),
      enableEmailNotifications: z.boolean().optional(),
      enablePushNotifications: z.boolean().optional(),
      enableOnlinePayments: z.boolean().optional(),
      enableReviews: z.boolean().optional(),
    }).optional(),
  }).optional(),
});

const updateTenantSchema = z.object({
  name: z.string().min(1, 'Nome é obrigatório').max(100, 'Nome muito longo').optional(),
  slug: z.string()
    .min(1, 'Slug é obrigatório')
    .max(50, 'Slug muito longo')
    .regex(/^[a-z0-9-]+$/, 'Slug deve conter apenas letras minúsculas, números e hífens')
    .optional(),
  primaryColor: z.string().regex(/^#[0-9A-F]{6}$/i, 'Cor primária inválida').optional(),
  isActive: z.boolean().optional(),
});

const updateTenantSettingsSchema = z.object({
  branding: z.object({
    primaryColor: z.string().regex(/^#[0-9A-F]{6}$/i, 'Cor primária inválida').optional(),
    secondaryColor: z.string().regex(/^#[0-9A-F]{6}$/i, 'Cor secundária inválida').optional(),
    logo: z.string().url('URL do logo inválida').optional(),
    favicon: z.string().url('URL do favicon inválida').optional(),
  }).optional(),
  features: z.object({
    enableWhatsApp: z.boolean().optional(),
    enableEmailNotifications: z.boolean().optional(),
    enablePushNotifications: z.boolean().optional(),
    enableOnlinePayments: z.boolean().optional(),
    enableReviews: z.boolean().optional(),
  }).optional(),
  businessHours: z.record(z.object({
    start: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Formato de hora inválido'),
    end: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Formato de hora inválido'),
    enabled: z.boolean(),
  })).optional(),
  notifications: z.object({
    reminderTimes: z.array(z.string()).optional(),
    templates: z.record(z.string()).optional(),
  }).optional(),
});

/**
 * Get tenant settings
 */
export async function getTenantSettings(req: Request, res: Response) {
  try {
    const { tenantId } = req.params;
    const tenant = await tenantService.getTenantById(tenantId);

    if (!tenant) {
      return res.status(404).json({
        error: 'TENANT_NOT_FOUND',
        message: 'Tenant não encontrado',
      });
    }

    res.json({
      success: true,
      data: { tenant },
    });
  } catch (error) {
    console.error('Get tenant settings error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Update tenant settings
 */
export async function updateTenantSettings(req: Request, res: Response) {
  try {
    const { tenantId } = req.params;
    const validatedData = updateTenantSettingsSchema.parse(req.body);

    const tenant = await tenantService.updateTenantSettings(tenantId, validatedData);

    res.json({
      success: true,
      message: 'Configurações atualizadas com sucesso',
      data: { tenant },
    });
  } catch (error) {
    console.error('Update tenant settings error:', error);
    
    if (error instanceof Error && error.message.includes('validation')) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Get custom fields for user type
 */
export async function getCustomFields(req: Request, res: Response) {
  try {
    const { tenantId, userType } = req.params;

    if (!['professional', 'client'].includes(userType)) {
      return res.status(400).json({
        error: 'INVALID_USER_TYPE',
        message: 'Tipo de usuário deve ser "professional" ou "client"',
      });
    }

    const customFields = await tenantService.getCustomFields(tenantId, userType as 'professional' | 'client');

    res.json({
      success: true,
      data: { customFields },
    });
  } catch (error) {
    console.error('Get custom fields error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Add custom field
 */
export async function addCustomField(req: Request, res: Response) {
  try {
    const { tenantId, userType } = req.params;
    
    if (!['professional', 'client'].includes(userType)) {
      return res.status(400).json({
        error: 'INVALID_USER_TYPE',
        message: 'Tipo de usuário deve ser "professional" ou "client"',
      });
    }

    const validatedData = customFieldSchema.parse(req.body);
    const customField = await tenantService.addCustomField(tenantId, userType as 'professional' | 'client', validatedData);

    res.status(201).json({
      success: true,
      message: 'Campo personalizado criado com sucesso',
      data: { customField },
    });
  } catch (error) {
    console.error('Add custom field error:', error);
    
    if (error instanceof Error && (error.message.includes('validation') || error.message.includes('não encontrado'))) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Update custom field
 */
export async function updateCustomField(req: Request, res: Response) {
  try {
    const { tenantId, userType, fieldId } = req.params;
    
    if (!['professional', 'client'].includes(userType)) {
      return res.status(400).json({
        error: 'INVALID_USER_TYPE',
        message: 'Tipo de usuário deve ser "professional" ou "client"',
      });
    }

    const validatedData = customFieldSchema.partial().parse(req.body);
    const customField = await tenantService.updateCustomField(tenantId, userType as 'professional' | 'client', fieldId, validatedData);

    res.json({
      success: true,
      message: 'Campo personalizado atualizado com sucesso',
      data: { customField },
    });
  } catch (error) {
    console.error('Update custom field error:', error);
    
    if (error instanceof Error && (error.message.includes('validation') || error.message.includes('não encontrado'))) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Remove custom field
 */
export async function removeCustomField(req: Request, res: Response) {
  try {
    const { tenantId, userType, fieldId } = req.params;
    
    if (!['professional', 'client'].includes(userType)) {
      return res.status(400).json({
        error: 'INVALID_USER_TYPE',
        message: 'Tipo de usuário deve ser "professional" ou "client"',
      });
    }

    await tenantService.removeCustomField(tenantId, userType as 'professional' | 'client', fieldId);

    res.json({
      success: true,
      message: 'Campo personalizado removido com sucesso',
    });
  } catch (error) {
    console.error('Remove custom field error:', error);
    
    if (error instanceof Error && error.message.includes('não encontrado')) {
      return res.status(404).json({
        error: 'FIELD_NOT_FOUND',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Create new tenant
 */
export async function createTenant(req: Request, res: Response) {
  try {
    const validatedData = createTenantSchema.parse(req.body);
    const tenant = await tenantService.createTenant(validatedData);

    res.status(201).json({
      success: true,
      message: 'Tenant criado com sucesso',
      data: { tenant },
    });
  } catch (error) {
    console.error('Create tenant error:', error);
    
    if (error instanceof Error && (error.message.includes('validation') || error.message.includes('já está em uso') || error.message.includes('deve conter apenas'))) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Update tenant basic info
 */
export async function updateTenant(req: Request, res: Response) {
  try {
    const { tenantId } = req.params;
    const validatedData = updateTenantSchema.parse(req.body);

    const tenant = await tenantService.updateTenant(tenantId, validatedData);

    res.json({
      success: true,
      message: 'Tenant atualizado com sucesso',
      data: { tenant },
    });
  } catch (error) {
    console.error('Update tenant error:', error);
    
    if (error instanceof Error && (error.message.includes('validation') || error.message.includes('não encontrado') || error.message.includes('já está em uso'))) {
      return res.status(400).json({
        error: 'VALIDATION_ERROR',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Delete tenant
 */
export async function deleteTenant(req: Request, res: Response) {
  try {
    const { tenantId } = req.params;
    await tenantService.deleteTenant(tenantId);

    res.json({
      success: true,
      message: 'Tenant deletado com sucesso',
    });
  } catch (error) {
    console.error('Delete tenant error:', error);
    
    if (error instanceof Error && error.message.includes('não encontrado')) {
      return res.status(404).json({
        error: 'TENANT_NOT_FOUND',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Upload tenant logo
 */
export async function uploadTenantLogo(req: Request, res: Response) {
  try {
    const { tenantId } = req.params;
    
    if (!req.file) {
      return res.status(400).json({
        error: 'NO_FILE',
        message: 'Nenhum arquivo foi enviado',
      });
    }

    const logoUrl = getLogoUrl(req.file.filename);
    
    // Atualizar tenant com nova URL do logo
    const tenant = await tenantService.updateTenant(tenantId, { logo: logoUrl });

    res.json({
      success: true,
      message: 'Logo enviado com sucesso',
      data: { 
        tenant,
        logoUrl,
      },
    });
  } catch (error) {
    console.error('Upload tenant logo error:', error);
    
    if (error instanceof Error && error.message.includes('não encontrado')) {
      return res.status(404).json({
        error: 'TENANT_NOT_FOUND',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Upload tenant favicon
 */
export async function uploadTenantFavicon(req: Request, res: Response) {
  try {
    const { tenantId } = req.params;
    
    if (!req.file) {
      return res.status(400).json({
        error: 'NO_FILE',
        message: 'Nenhum arquivo foi enviado',
      });
    }

    const faviconUrl = getFaviconUrl(req.file.filename);
    
    // Atualizar configurações do tenant com nova URL do favicon
    const currentTenant = await tenantService.getTenantById(tenantId);
    if (!currentTenant) {
      return res.status(404).json({
        error: 'TENANT_NOT_FOUND',
        message: 'Tenant não encontrado',
      });
    }

    const updatedSettings = {
      ...currentTenant.settings,
      branding: {
        ...currentTenant.settings.branding,
        favicon: faviconUrl,
      },
    };

    await tenantService.updateTenantSettings(tenantId, updatedSettings);

    res.json({
      success: true,
      message: 'Favicon enviado com sucesso',
      data: { 
        faviconUrl,
      },
    });
  } catch (error) {
    console.error('Upload tenant favicon error:', error);
    
    if (error instanceof Error && error.message.includes('não encontrado')) {
      return res.status(404).json({
        error: 'TENANT_NOT_FOUND',
        message: error.message,
      });
    }

    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Get tenant statistics
 */
export async function getTenantStats(req: Request, res: Response) {
  try {
    const { tenantId } = req.params;
    const stats = await tenantService.getTenantStats(tenantId);

    res.json({
      success: true,
      data: { stats },
    });
  } catch (error) {
    console.error('Get tenant stats error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}

/**
 * Get all tenants
 */
export async function getTenants(req: Request, res: Response) {
  try {
    const {
      page = '1',
      limit = '10',
      isActive,
      search,
    } = req.query;

    const result = await tenantService.getTenants({
      page: parseInt(page as string),
      limit: parseInt(limit as string),
      isActive: isActive === 'true' ? true : isActive === 'false' ? false : undefined,
      search: search as string,
    });

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error('Get tenants error:', error);
    res.status(500).json({
      error: 'INTERNAL_ERROR',
      message: 'Erro interno do servidor',
    });
  }
}