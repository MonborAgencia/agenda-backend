import { Request, Response } from 'express';
import { reportService } from '../services/report.service';
import { AnalyticsFilters } from '../types/analytics.types';

export class ReportController {
  /**
   * POST /reports/generate/pdf
   * Gera relatório em PDF
   */
  async generatePDFReport(req: Request, res: Response) {
    try {
      const { tenantId, startDate, endDate, professionalId, serviceId, title } = req.body;

      if (!tenantId || !startDate || !endDate) {
        return res.status(400).json({
          error: 'tenantId, startDate e endDate são obrigatórios'
        });
      }

      const filters: AnalyticsFilters = {
        tenantId,
        dateRange: {
          startDate: new Date(startDate),
          endDate: new Date(endDate)
        },
        professionalId,
        serviceId
      };

      const reportTitle = title || `Relatório de Analytics - ${new Date().toLocaleDateString('pt-BR')}`;
      const pdfBuffer = await reportService.generatePDFReport(filters, reportTitle);

      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="relatorio_${Date.now()}.pdf"`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error('Erro ao gerar relatório PDF:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  /**
   * POST /reports/generate/excel
   * Gera relatório em Excel
   */
  async generateExcelReport(req: Request, res: Response) {
    try {
      const { tenantId, startDate, endDate, professionalId, serviceId, title } = req.body;

      if (!tenantId || !startDate || !endDate) {
        return res.status(400).json({
          error: 'tenantId, startDate e endDate são obrigatórios'
        });
      }

      const filters: AnalyticsFilters = {
        tenantId,
        dateRange: {
          startDate: new Date(startDate),
          endDate: new Date(endDate)
        },
        professionalId,
        serviceId
      };

      const reportTitle = title || `Relatório de Analytics - ${new Date().toLocaleDateString('pt-BR')}`;
      const excelBuffer = await reportService.generateExcelReport(filters, reportTitle);

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="relatorio_${Date.now()}.xlsx"`);
      res.send(excelBuffer);
    } catch (error) {
      console.error('Erro ao gerar relatório Excel:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  /**
   * POST /reports/schedule
   * Cria agendamento de relatório automático
   */
  async scheduleReport(req: Request, res: Response) {
    try {
      const {
        name,
        type,
        frequency,
        filters,
        recipients,
        isActive = true
      } = req.body;

      if (!name || !type || !frequency || !filters) {
        return res.status(400).json({
          error: 'name, type, frequency e filters são obrigatórios'
        });
      }

      if (!['PDF', 'EXCEL'].includes(type)) {
        return res.status(400).json({
          error: 'type deve ser PDF ou EXCEL'
        });
      }

      if (!['DAILY', 'WEEKLY', 'MONTHLY'].includes(frequency)) {
        return res.status(400).json({
          error: 'frequency deve ser DAILY, WEEKLY ou MONTHLY'
        });
      }

      if (!filters.tenantId || !filters.dateRange) {
        return res.status(400).json({
          error: 'filters deve conter tenantId e dateRange'
        });
      }

      // Converter dateRange strings para Date objects
      const analyticsFilters: AnalyticsFilters = {
        ...filters,
        dateRange: {
          startDate: new Date(filters.dateRange.startDate),
          endDate: new Date(filters.dateRange.endDate)
        }
      };

      const reportConfig = await reportService.createReportConfig({
        name,
        type,
        frequency,
        filters: analyticsFilters,
        recipients: recipients || [],
        isActive
      });

      res.json({
        success: true,
        data: reportConfig
      });
    } catch (error) {
      console.error('Erro ao agendar relatório:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  /**
   * DELETE /reports/schedule/:id
   * Para agendamento de relatório
   */
  async stopScheduledReport(req: Request, res: Response) {
    try {
      const { id } = req.params;

      if (!id) {
        return res.status(400).json({
          error: 'ID do relatório é obrigatório'
        });
      }

      reportService.stopScheduledReport(id);

      res.json({
        success: true,
        message: 'Relatório agendado parado com sucesso'
      });
    } catch (error) {
      console.error('Erro ao parar relatório agendado:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }

  /**
   * GET /reports/preview
   * Gera preview dos dados do relatório (JSON)
   */
  async previewReport(req: Request, res: Response) {
    try {
      const { tenantId, startDate, endDate, professionalId, serviceId } = req.query;

      if (!tenantId || !startDate || !endDate) {
        return res.status(400).json({
          error: 'tenantId, startDate e endDate são obrigatórios'
        });
      }

      const filters: AnalyticsFilters = {
        tenantId: tenantId as string,
        dateRange: {
          startDate: new Date(startDate as string),
          endDate: new Date(endDate as string)
        },
        professionalId: professionalId as string,
        serviceId: serviceId as string
      };

      // Usar o analytics service para obter os dados
      const { analyticsService } = await import('../services/analytics.service');
      const metrics = await analyticsService.generateDashboardMetrics(filters);

      const reportData = {
        title: `Preview do Relatório - ${new Date().toLocaleDateString('pt-BR')}`,
        generatedAt: new Date(),
        period: filters.dateRange,
        metrics
      };

      res.json({
        success: true,
        data: reportData
      });
    } catch (error) {
      console.error('Erro ao gerar preview do relatório:', error);
      res.status(500).json({
        error: 'Erro interno do servidor'
      });
    }
  }
}

export const reportController = new ReportController();