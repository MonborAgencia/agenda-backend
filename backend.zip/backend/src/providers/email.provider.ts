import nodemailer from 'nodemailer';
import {
  NotificationProvider,
  NotificationType,
  Notification,
  NotificationResult,
  EmailConfig
} from '../types/notification.types';

export class EmailProvider implements NotificationProvider {
  type = NotificationType.EMAIL;
  private transporter: nodemailer.Transporter | null = null;
  private config: EmailConfig | null = null;

  constructor() {
    this.initializeTransporter();
  }

  // Inicializar transporter do nodemailer
  private initializeTransporter(): void {
    const config = this.getEmailConfig();
    
    if (!config) {
      console.warn('Configuração de email não encontrada');
      return;
    }

    this.config = config;
    
    try {
      this.transporter = nodemailer.createTransporter({
        host: config.host,
        port: config.port,
        secure: config.secure,
        auth: config.auth,
        pool: true,
        maxConnections: 5,
        maxMessages: 100,
        rateLimit: 14 // máximo 14 emails por segundo
      });

      console.log('Email provider inicializado com sucesso');
    } catch (error) {
      console.error('Erro ao inicializar email provider:', error);
      this.transporter = null;
    }
  }

  // Obter configuração de email das variáveis de ambiente
  private getEmailConfig(): EmailConfig | null {
    const {
      SMTP_HOST,
      SMTP_PORT,
      SMTP_SECURE,
      SMTP_USER,
      SMTP_PASS,
      SMTP_FROM
    } = process.env;

    if (!SMTP_HOST || !SMTP_PORT || !SMTP_USER || !SMTP_PASS || !SMTP_FROM) {
      return null;
    }

    return {
      host: SMTP_HOST,
      port: parseInt(SMTP_PORT),
      secure: SMTP_SECURE === 'true',
      auth: {
        user: SMTP_USER,
        pass: SMTP_PASS
      },
      from: SMTP_FROM
    };
  }

  // Verificar se o provider está configurado
  isConfigured(): boolean {
    return this.transporter !== null && this.config !== null;
  }

  // Enviar email
  async send(notification: Notification): Promise<NotificationResult> {
    if (!this.isConfigured()) {
      return {
        success: false,
        error: 'Email provider não está configurado'
      };
    }

    if (!this.transporter || !this.config) {
      return {
        success: false,
        error: 'Transporter não inicializado'
      };
    }

    try {
      // Obter dados do destinatário
      const recipient = await this.getRecipientData(notification.recipientId);
      
      if (!recipient?.email) {
        return {
          success: false,
          error: 'Email do destinatário não encontrado'
        };
      }

      // Preparar opções do email
      const mailOptions = {
        from: this.config.from,
        to: recipient.email,
        subject: notification.subject || 'Notificação',
        html: this.formatEmailContent(notification.content, recipient),
        text: this.stripHtml(notification.content)
      };

      // Enviar email
      const info = await this.transporter.sendMail(mailOptions);

      console.log(`Email enviado para ${recipient.email}: ${info.messageId}`);

      return {
        success: true,
        messageId: info.messageId,
        deliveredAt: new Date()
      };
    } catch (error: any) {
      console.error('Erro ao enviar email:', error);
      
      return {
        success: false,
        error: error.message || 'Erro desconhecido ao enviar email'
      };
    }
  }

  // Obter dados do destinatário
  private async getRecipientData(recipientId: string): Promise<{
    email: string;
    name: string;
  } | null> {
    try {
      // Importar Prisma dinamicamente para evitar dependência circular
      const { PrismaClient } = await import('@prisma/client');
      const prisma = new PrismaClient();

      const user = await prisma.user.findUnique({
        where: { id: recipientId },
        select: {
          email: true,
          name: true
        }
      });

      await prisma.$disconnect();

      return user;
    } catch (error) {
      console.error('Erro ao buscar dados do destinatário:', error);
      return null;
    }
  }

  // Formatar conteúdo do email com HTML
  private formatEmailContent(content: string, recipient: { name: string }): string {
    // Converter quebras de linha em <br>
    let htmlContent = content.replace(/\n/g, '<br>');
    
    // Adicionar estrutura HTML básica
    return `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificação</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .content {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }
        .footer {
            margin-top: 20px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 8px;
            font-size: 12px;
            color: #6c757d;
            text-align: center;
        }
        .emoji {
            font-size: 1.2em;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Agenda Lotada 24h</h2>
    </div>
    
    <div class="content">
        ${htmlContent}
    </div>
    
    <div class="footer">
        <p>Esta é uma mensagem automática do sistema Agenda Lotada 24h.</p>
        <p>Se você não deseja mais receber estas notificações, entre em contato conosco.</p>
    </div>
</body>
</html>`;
  }

  // Remover tags HTML para versão texto
  private stripHtml(html: string): string {
    return html.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ');
  }

  // Verificar conexão SMTP
  async verifyConnection(): Promise<boolean> {
    if (!this.transporter) {
      return false;
    }

    try {
      await this.transporter.verify();
      return true;
    } catch (error) {
      console.error('Erro na verificação SMTP:', error);
      return false;
    }
  }

  // Obter informações do provider
  getProviderInfo(): {
    type: string;
    configured: boolean;
    host?: string;
    from?: string;
  } {
    return {
      type: this.type,
      configured: this.isConfigured(),
      host: this.config?.host,
      from: this.config?.from
    };
  }

  // Fechar conexões
  async close(): Promise<void> {
    if (this.transporter) {
      this.transporter.close();
      this.transporter = null;
    }
  }
}

export const emailProvider = new EmailProvider();