import axios, { AxiosInstance } from 'axios';
import {
  NotificationProvider,
  NotificationType,
  Notification,
  NotificationResult,
  WhatsAppConfig
} from '../types/notification.types';

export class WhatsAppProvider implements NotificationProvider {
  type = NotificationType.WHATSAPP;
  private client: AxiosInstance | null = null;
  private config: WhatsAppConfig | null = null;

  constructor() {
    this.initializeClient();
  }

  // Inicializar cliente do WhatsApp Business API
  private initializeClient(): void {
    const config = this.getWhatsAppConfig();
    
    if (!config) {
      console.warn('Configuração do WhatsApp não encontrada');
      return;
    }

    this.config = config;
    
    try {
      this.client = axios.create({
        baseURL: config.apiUrl,
        headers: {
          'Authorization': `Bearer ${config.token}`,
          'Content-Type': 'application/json'
        },
        timeout: 30000 // 30 segundos
      });

      console.log('WhatsApp provider inicializado com sucesso');
    } catch (error) {
      console.error('Erro ao inicializar WhatsApp provider:', error);
      this.client = null;
    }
  }

  // Obter configuração do WhatsApp das variáveis de ambiente
  private getWhatsAppConfig(): WhatsAppConfig | null {
    const {
      WHATSAPP_API_URL,
      WHATSAPP_TOKEN,
      WHATSAPP_PHONE_NUMBER_ID
    } = process.env;

    if (!WHATSAPP_API_URL || !WHATSAPP_TOKEN || !WHATSAPP_PHONE_NUMBER_ID) {
      return null;
    }

    return {
      apiUrl: WHATSAPP_API_URL,
      token: WHATSAPP_TOKEN,
      phoneNumberId: WHATSAPP_PHONE_NUMBER_ID
    };
  }

  // Verificar se o provider está configurado
  isConfigured(): boolean {
    return this.client !== null && this.config !== null;
  }

  // Enviar mensagem WhatsApp
  async send(notification: Notification): Promise<NotificationResult> {
    if (!this.isConfigured()) {
      return {
        success: false,
        error: 'WhatsApp provider não está configurado'
      };
    }

    if (!this.client || !this.config) {
      return {
        success: false,
        error: 'Cliente WhatsApp não inicializado'
      };
    }

    try {
      // Obter dados do destinatário
      const recipient = await this.getRecipientData(notification.recipientId);
      
      if (!recipient?.phone) {
        return {
          success: false,
          error: 'Telefone do destinatário não encontrado'
        };
      }

      // Formatar número de telefone
      const phoneNumber = this.formatPhoneNumber(recipient.phone);
      
      if (!phoneNumber) {
        return {
          success: false,
          error: 'Número de telefone inválido'
        };
      }

      // Preparar payload da mensagem
      const messagePayload = {
        messaging_product: 'whatsapp',
        to: phoneNumber,
        type: 'text',
        text: {
          body: this.formatWhatsAppContent(notification.content, recipient)
        }
      };

      // Enviar mensagem
      const response = await this.client.post(
        `/${this.config.phoneNumberId}/messages`,
        messagePayload
      );

      const messageId = response.data.messages?.[0]?.id;

      console.log(`WhatsApp enviado para ${phoneNumber}: ${messageId}`);

      return {
        success: true,
        messageId,
        deliveredAt: new Date()
      };
    } catch (error: any) {
      console.error('Erro ao enviar WhatsApp:', error);
      
      let errorMessage = 'Erro desconhecido ao enviar WhatsApp';
      
      if (error.response?.data?.error) {
        errorMessage = error.response.data.error.message || errorMessage;
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      return {
        success: false,
        error: errorMessage
      };
    }
  }

  // Obter dados do destinatário
  private async getRecipientData(recipientId: string): Promise<{
    phone: string;
    name: string;
  } | null> {
    try {
      // Importar Prisma dinamicamente para evitar dependência circular
      const { PrismaClient } = await import('@prisma/client');
      const prisma = new PrismaClient();

      const user = await prisma.user.findUnique({
        where: { id: recipientId },
        select: {
          phone: true,
          name: true
        }
      });

      await prisma.$disconnect();

      return user;
    } catch (error) {
      console.error('Erro ao buscar dados do destinatário:', error);
      return null;
    }
  }

  // Formatar número de telefone para WhatsApp
  private formatPhoneNumber(phone: string): string | null {
    if (!phone) return null;

    // Remover caracteres não numéricos
    let cleanPhone = phone.replace(/\D/g, '');

    // Se começar com 0, remover
    if (cleanPhone.startsWith('0')) {
      cleanPhone = cleanPhone.substring(1);
    }

    // Se não começar com código do país, assumir Brasil (+55)
    if (!cleanPhone.startsWith('55') && cleanPhone.length >= 10) {
      cleanPhone = '55' + cleanPhone;
    }

    // Validar formato brasileiro
    if (cleanPhone.startsWith('55') && (cleanPhone.length === 12 || cleanPhone.length === 13)) {
      return cleanPhone;
    }

    return null;
  }

  // Formatar conteúdo para WhatsApp
  private formatWhatsAppContent(content: string, recipient: { name: string }): string {
    // WhatsApp suporta emojis e formatação básica
    let formattedContent = content;

    // Adicionar saudação personalizada se não houver
    if (!content.toLowerCase().includes('olá') && !content.toLowerCase().includes('oi')) {
      formattedContent = `Olá ${recipient.name}! 👋\n\n${formattedContent}`;
    }

    // Adicionar assinatura se não houver
    if (!content.includes('Agenda Lotada')) {
      formattedContent += '\n\n📅 *Agenda Lotada 24h*';
    }

    return formattedContent;
  }

  // Enviar mensagem com template (para mensagens promocionais)
  async sendTemplate(
    recipientPhone: string,
    templateName: string,
    templateParams: string[]
  ): Promise<NotificationResult> {
    if (!this.isConfigured()) {
      return {
        success: false,
        error: 'WhatsApp provider não está configurado'
      };
    }

    if (!this.client || !this.config) {
      return {
        success: false,
        error: 'Cliente WhatsApp não inicializado'
      };
    }

    try {
      const phoneNumber = this.formatPhoneNumber(recipientPhone);
      
      if (!phoneNumber) {
        return {
          success: false,
          error: 'Número de telefone inválido'
        };
      }

      const templatePayload = {
        messaging_product: 'whatsapp',
        to: phoneNumber,
        type: 'template',
        template: {
          name: templateName,
          language: {
            code: 'pt_BR'
          },
          components: [
            {
              type: 'body',
              parameters: templateParams.map(param => ({
                type: 'text',
                text: param
              }))
            }
          ]
        }
      };

      const response = await this.client.post(
        `/${this.config.phoneNumberId}/messages`,
        templatePayload
      );

      const messageId = response.data.messages?.[0]?.id;

      return {
        success: true,
        messageId,
        deliveredAt: new Date()
      };
    } catch (error: any) {
      console.error('Erro ao enviar template WhatsApp:', error);
      
      return {
        success: false,
        error: error.response?.data?.error?.message || error.message
      };
    }
  }

  // Verificar status da mensagem
  async getMessageStatus(messageId: string): Promise<{
    status: 'sent' | 'delivered' | 'read' | 'failed';
    timestamp?: Date;
  } | null> {
    if (!this.client) {
      return null;
    }

    try {
      const response = await this.client.get(`/messages/${messageId}`);
      
      return {
        status: response.data.status,
        timestamp: response.data.timestamp ? new Date(response.data.timestamp * 1000) : undefined
      };
    } catch (error) {
      console.error('Erro ao verificar status da mensagem:', error);
      return null;
    }
  }

  // Obter informações do provider
  getProviderInfo(): {
    type: string;
    configured: boolean;
    phoneNumberId?: string;
  } {
    return {
      type: this.type,
      configured: this.isConfigured(),
      phoneNumberId: this.config?.phoneNumberId
    };
  }

  // Verificar webhook do WhatsApp
  async verifyWebhook(mode: string, token: string, challenge: string): Promise<string | null> {
    const verifyToken = process.env.WHATSAPP_VERIFY_TOKEN;
    
    if (mode === 'subscribe' && token === verifyToken) {
      return challenge;
    }
    
    return null;
  }

  // Processar webhook do WhatsApp
  async processWebhook(body: any): Promise<void> {
    try {
      if (body.object === 'whatsapp_business_account') {
        for (const entry of body.entry) {
          for (const change of entry.changes) {
            if (change.field === 'messages') {
              await this.processMessageStatus(change.value);
            }
          }
        }
      }
    } catch (error) {
      console.error('Erro ao processar webhook WhatsApp:', error);
    }
  }

  // Processar status da mensagem do webhook
  private async processMessageStatus(value: any): Promise<void> {
    if (value.statuses) {
      for (const status of value.statuses) {
        console.log(`Status da mensagem ${status.id}: ${status.status}`);
        
        // Aqui você pode atualizar o status da notificação no banco de dados
        // baseado no messageId (status.id) e no status (status.status)
      }
    }
  }
}

export const whatsAppProvider = new WhatsAppProvider();