import admin from 'firebase-admin';
import {
  NotificationProvider,
  NotificationType,
  Notification,
  NotificationResult,
  PushConfig
} from '../types/notification.types';

export class PushProvider implements NotificationProvider {
  type = NotificationType.PUSH;
  private app: admin.app.App | null = null;
  private config: PushConfig | null = null;

  constructor() {
    this.initializeFirebase();
  }

  // Inicializar Firebase Admin SDK
  private initializeFirebase(): void {
    const config = this.getPushConfig();
    
    if (!config) {
      console.warn('Configuração de push notifications não encontrada');
      return;
    }

    this.config = config;
    
    try {
      // Verificar se já existe uma instância do Firebase
      if (admin.apps.length === 0) {
        const serviceAccount = this.getServiceAccountConfig();
        
        if (serviceAccount) {
          this.app = admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            projectId: serviceAccount.project_id
          });
        } else {
          // Usar credenciais padrão do ambiente
          this.app = admin.initializeApp();
        }
      } else {
        this.app = admin.apps[0];
      }

      console.log('Push provider inicializado com sucesso');
    } catch (error) {
      console.error('Erro ao inicializar push provider:', error);
      this.app = null;
    }
  }

  // Obter configuração de push das variáveis de ambiente
  private getPushConfig(): PushConfig | null {
    const {
      FIREBASE_SERVER_KEY,
      VAPID_PUBLIC_KEY,
      VAPID_PRIVATE_KEY
    } = process.env;

    if (!FIREBASE_SERVER_KEY || !VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) {
      return null;
    }

    return {
      serverKey: FIREBASE_SERVER_KEY,
      vapidKeys: {
        publicKey: VAPID_PUBLIC_KEY,
        privateKey: VAPID_PRIVATE_KEY
      }
    };
  }

  // Obter configuração da conta de serviço
  private getServiceAccountConfig(): admin.ServiceAccount | null {
    const {
      FIREBASE_PROJECT_ID,
      FIREBASE_PRIVATE_KEY,
      FIREBASE_CLIENT_EMAIL
    } = process.env;

    if (!FIREBASE_PROJECT_ID || !FIREBASE_PRIVATE_KEY || !FIREBASE_CLIENT_EMAIL) {
      return null;
    }

    return {
      projectId: FIREBASE_PROJECT_ID,
      privateKey: FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
      clientEmail: FIREBASE_CLIENT_EMAIL
    };
  }

  // Verificar se o provider está configurado
  isConfigured(): boolean {
    return this.app !== null && this.config !== null;
  }

  // Enviar push notification
  async send(notification: Notification): Promise<NotificationResult> {
    if (!this.isConfigured()) {
      return {
        success: false,
        error: 'Push provider não está configurado'
      };
    }

    if (!this.app) {
      return {
        success: false,
        error: 'Firebase não inicializado'
      };
    }

    try {
      // Obter tokens de push do destinatário
      const pushTokens = await this.getRecipientPushTokens(notification.recipientId);
      
      if (!pushTokens || pushTokens.length === 0) {
        return {
          success: false,
          error: 'Tokens de push não encontrados para o destinatário'
        };
      }

      // Preparar mensagem
      const message = this.buildPushMessage(notification, pushTokens);

      // Enviar para múltiplos tokens
      const response = await admin.messaging().sendMulticast(message);

      console.log(`Push notifications enviadas: ${response.successCount}/${pushTokens.length}`);

      // Processar respostas para limpar tokens inválidos
      await this.processResponses(response, pushTokens, notification.recipientId);

      if (response.successCount > 0) {
        return {
          success: true,
          messageId: `push_${Date.now()}`,
          deliveredAt: new Date()
        };
      } else {
        return {
          success: false,
          error: 'Nenhuma notificação foi entregue com sucesso'
        };
      }
    } catch (error: any) {
      console.error('Erro ao enviar push notification:', error);
      
      return {
        success: false,
        error: error.message || 'Erro desconhecido ao enviar push notification'
      };
    }
  }

  // Obter tokens de push do destinatário
  private async getRecipientPushTokens(recipientId: string): Promise<string[] | null> {
    try {
      // Importar Prisma dinamicamente para evitar dependência circular
      const { PrismaClient } = await import('@prisma/client');
      const prisma = new PrismaClient();

      // Assumindo que existe uma tabela para armazenar tokens de push
      // Por enquanto, vamos simular com metadata do usuário
      const user = await prisma.user.findUnique({
        where: { id: recipientId },
        include: {
          profile: true
        }
      });

      await prisma.$disconnect();

      if (!user?.profile?.preferences) {
        return null;
      }

      const preferences = JSON.parse(user.profile.preferences);
      return preferences.pushTokens || [];
    } catch (error) {
      console.error('Erro ao buscar tokens de push:', error);
      return null;
    }
  }

  // Construir mensagem de push
  private buildPushMessage(
    notification: Notification,
    tokens: string[]
  ): admin.messaging.MulticastMessage {
    const title = notification.subject || 'Agenda Lotada 24h';
    const body = this.truncateContent(notification.content, 100);

    return {
      tokens,
      notification: {
        title,
        body
      },
      data: {
        notificationId: notification.id,
        type: notification.type,
        timestamp: new Date().toISOString(),
        ...(notification.metadata || {})
      },
      android: {
        notification: {
          icon: 'ic_notification',
          color: '#2196F3',
          sound: 'default',
          channelId: 'agenda_notifications'
        },
        priority: 'high'
      },
      apns: {
        payload: {
          aps: {
            alert: {
              title,
              body
            },
            sound: 'default',
            badge: 1
          }
        }
      },
      webpush: {
        notification: {
          title,
          body,
          icon: '/icons/notification-icon.png',
          badge: '/icons/badge-icon.png',
          requireInteraction: true,
          actions: [
            {
              action: 'view',
              title: 'Ver detalhes'
            },
            {
              action: 'dismiss',
              title: 'Dispensar'
            }
          ]
        },
        fcmOptions: {
          link: '/notifications'
        }
      }
    };
  }

  // Truncar conteúdo para push notification
  private truncateContent(content: string, maxLength: number): string {
    if (content.length <= maxLength) {
      return content;
    }
    
    return content.substring(0, maxLength - 3) + '...';
  }

  // Processar respostas e limpar tokens inválidos
  private async processResponses(
    response: admin.messaging.BatchResponse,
    tokens: string[],
    recipientId: string
  ): Promise<void> {
    const invalidTokens: string[] = [];

    response.responses.forEach((resp, idx) => {
      if (!resp.success) {
        const error = resp.error;
        
        if (error?.code === 'messaging/invalid-registration-token' ||
            error?.code === 'messaging/registration-token-not-registered') {
          invalidTokens.push(tokens[idx]);
        }
        
        console.error(`Erro ao enviar para token ${idx}:`, error?.message);
      }
    });

    // Remover tokens inválidos
    if (invalidTokens.length > 0) {
      await this.removeInvalidTokens(recipientId, invalidTokens);
    }
  }

  // Remover tokens inválidos do usuário
  private async removeInvalidTokens(recipientId: string, invalidTokens: string[]): Promise<void> {
    try {
      const { PrismaClient } = await import('@prisma/client');
      const prisma = new PrismaClient();

      const user = await prisma.user.findUnique({
        where: { id: recipientId },
        include: { profile: true }
      });

      if (user?.profile?.preferences) {
        const preferences = JSON.parse(user.profile.preferences);
        const currentTokens = preferences.pushTokens || [];
        
        preferences.pushTokens = currentTokens.filter(
          (token: string) => !invalidTokens.includes(token)
        );

        await prisma.userProfile.update({
          where: { userId: recipientId },
          data: {
            preferences: JSON.stringify(preferences)
          }
        });

        console.log(`Removidos ${invalidTokens.length} tokens inválidos do usuário ${recipientId}`);
      }

      await prisma.$disconnect();
    } catch (error) {
      console.error('Erro ao remover tokens inválidos:', error);
    }
  }

  // Adicionar token de push para um usuário
  async addPushToken(recipientId: string, token: string): Promise<boolean> {
    try {
      const { PrismaClient } = await import('@prisma/client');
      const prisma = new PrismaClient();

      const user = await prisma.user.findUnique({
        where: { id: recipientId },
        include: { profile: true }
      });

      if (!user) {
        return false;
      }

      let preferences = {};
      if (user.profile?.preferences) {
        preferences = JSON.parse(user.profile.preferences);
      }

      const currentTokens = (preferences as any).pushTokens || [];
      
      if (!currentTokens.includes(token)) {
        currentTokens.push(token);
        (preferences as any).pushTokens = currentTokens;

        if (user.profile) {
          await prisma.userProfile.update({
            where: { userId: recipientId },
            data: {
              preferences: JSON.stringify(preferences)
            }
          });
        } else {
          await prisma.userProfile.create({
            data: {
              userId: recipientId,
              preferences: JSON.stringify(preferences)
            }
          });
        }
      }

      await prisma.$disconnect();
      return true;
    } catch (error) {
      console.error('Erro ao adicionar token de push:', error);
      return false;
    }
  }

  // Remover token de push de um usuário
  async removePushToken(recipientId: string, token: string): Promise<boolean> {
    try {
      const { PrismaClient } = await import('@prisma/client');
      const prisma = new PrismaClient();

      const user = await prisma.user.findUnique({
        where: { id: recipientId },
        include: { profile: true }
      });

      if (!user?.profile?.preferences) {
        return false;
      }

      const preferences = JSON.parse(user.profile.preferences);
      const currentTokens = preferences.pushTokens || [];
      
      preferences.pushTokens = currentTokens.filter((t: string) => t !== token);

      await prisma.userProfile.update({
        where: { userId: recipientId },
        data: {
          preferences: JSON.stringify(preferences)
        }
      });

      await prisma.$disconnect();
      return true;
    } catch (error) {
      console.error('Erro ao remover token de push:', error);
      return false;
    }
  }

  // Enviar para tópico específico
  async sendToTopic(topic: string, title: string, body: string, data?: Record<string, string>): Promise<NotificationResult> {
    if (!this.isConfigured() || !this.app) {
      return {
        success: false,
        error: 'Push provider não está configurado'
      };
    }

    try {
      const message: admin.messaging.Message = {
        topic,
        notification: {
          title,
          body
        },
        data: data || {},
        android: {
          notification: {
            icon: 'ic_notification',
            color: '#2196F3'
          }
        }
      };

      const messageId = await admin.messaging().send(message);

      return {
        success: true,
        messageId,
        deliveredAt: new Date()
      };
    } catch (error: any) {
      console.error('Erro ao enviar para tópico:', error);
      
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Obter informações do provider
  getProviderInfo(): {
    type: string;
    configured: boolean;
    projectId?: string;
  } {
    const serviceAccount = this.getServiceAccountConfig();
    
    return {
      type: this.type,
      configured: this.isConfigured(),
      projectId: serviceAccount?.projectId
    };
  }
}

export const pushProvider = new PushProvider();