import { PrismaClient } from '@prisma/client';
import { createClient } from 'redis';
import LoggerUtils from '../utils/logger.utils';
import MetricsService from './metrics.service';

export interface HealthCheckResult {
  status: 'healthy' | 'unhealthy' | 'degraded';
  timestamp: string;
  uptime: number;
  version: string;
  environment: string;
  checks: {
    database: HealthCheck;
    redis: HealthCheck;
    memory: HealthCheck;
    disk: HealthCheck;
    external_services: HealthCheck;
  };
  metrics?: {
    requests_per_minute: number;
    average_response_time: number;
    error_rate: number;
    active_connections: number;
  };
}

export interface HealthCheck {
  status: 'healthy' | 'unhealthy' | 'degraded';
  response_time: number;
  message?: string;
  details?: any;
}

export class HealthService {
  private prisma: PrismaClient;
  private redis: any;

  constructor() {
    this.prisma = new PrismaClient();
    this.redis = createClient({
      url: process.env.REDIS_URL || 'redis://localhost:6379'
    });
  }

  /**
   * Executar health check completo
   */
  async performHealthCheck(): Promise<HealthCheckResult> {
    const startTime = Date.now();
    
    LoggerUtils.info('Starting health check', {
      category: 'HEALTH_CHECK',
      phase: 'START'
    });

    try {
      const [
        databaseCheck,
        redisCheck,
        memoryCheck,
        diskCheck,
        externalServicesCheck
      ] = await Promise.allSettled([
        this.checkDatabase(),
        this.checkRedis(),
        this.checkMemory(),
        this.checkDisk(),
        this.checkExternalServices()
      ]);

      const checks = {
        database: this.getCheckResult(databaseCheck),
        redis: this.getCheckResult(redisCheck),
        memory: this.getCheckResult(memoryCheck),
        disk: this.getCheckResult(diskCheck),
        external_services: this.getCheckResult(externalServicesCheck)
      };

      // Determinar status geral
      const overallStatus = this.determineOverallStatus(checks);
      
      const result: HealthCheckResult = {
        status: overallStatus,
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        version: process.env.APP_VERSION || '1.0.0',
        environment: process.env.NODE_ENV || 'development',
        checks,
        metrics: await this.getMetricsSummary()
      };

      const duration = Date.now() - startTime;
      
      LoggerUtils.info('Health check completed', {
        category: 'HEALTH_CHECK',
        phase: 'COMPLETE',
        status: overallStatus,
        duration
      });

      // Registrar métrica de health check
      MetricsService.recordBusinessEvent('health_check', undefined, undefined);

      return result;
    } catch (error) {
      LoggerUtils.error('Health check failed', error as Error, {
        category: 'HEALTH_CHECK',
        phase: 'ERROR'
      });

      return {
        status: 'unhealthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        version: process.env.APP_VERSION || '1.0.0',
        environment: process.env.NODE_ENV || 'development',
        checks: {
          database: { status: 'unhealthy', response_time: 0, message: 'Health check failed' },
          redis: { status: 'unhealthy', response_time: 0, message: 'Health check failed' },
          memory: { status: 'unhealthy', response_time: 0, message: 'Health check failed' },
          disk: { status: 'unhealthy', response_time: 0, message: 'Health check failed' },
          external_services: { status: 'unhealthy', response_time: 0, message: 'Health check failed' }
        }
      };
    }
  }

  /**
   * Verificar saúde do banco de dados
   */
  private async checkDatabase(): Promise<HealthCheck> {
    const startTime = Date.now();
    
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      const responseTime = Date.now() - startTime;
      
      return {
        status: responseTime < 1000 ? 'healthy' : 'degraded',
        response_time: responseTime,
        message: responseTime < 1000 ? 'Database is healthy' : 'Database is slow'
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        response_time: Date.now() - startTime,
        message: 'Database connection failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Verificar saúde do Redis
   */
  private async checkRedis(): Promise<HealthCheck> {
    const startTime = Date.now();
    
    try {
      if (!this.redis.isOpen) {
        await this.redis.connect();
      }
      
      await this.redis.ping();
      const responseTime = Date.now() - startTime;
      
      return {
        status: responseTime < 500 ? 'healthy' : 'degraded',
        response_time: responseTime,
        message: responseTime < 500 ? 'Redis is healthy' : 'Redis is slow'
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        response_time: Date.now() - startTime,
        message: 'Redis connection failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Verificar uso de memória
   */
  private async checkMemory(): Promise<HealthCheck> {
    const startTime = Date.now();
    
    try {
      const memUsage = process.memoryUsage();
      const totalMemory = memUsage.heapTotal;
      const usedMemory = memUsage.heapUsed;
      const memoryUsagePercent = (usedMemory / totalMemory) * 100;
      
      let status: 'healthy' | 'degraded' | 'unhealthy' = 'healthy';
      let message = 'Memory usage is normal';
      
      if (memoryUsagePercent > 90) {
        status = 'unhealthy';
        message = 'Memory usage is critically high';
      } else if (memoryUsagePercent > 75) {
        status = 'degraded';
        message = 'Memory usage is high';
      }
      
      return {
        status,
        response_time: Date.now() - startTime,
        message,
        details: {
          usage_percent: Math.round(memoryUsagePercent),
          heap_used: Math.round(usedMemory / 1024 / 1024),
          heap_total: Math.round(totalMemory / 1024 / 1024),
          rss: Math.round(memUsage.rss / 1024 / 1024)
        }
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        response_time: Date.now() - startTime,
        message: 'Memory check failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Verificar espaço em disco
   */
  private async checkDisk(): Promise<HealthCheck> {
    const startTime = Date.now();
    
    try {
      const fs = require('fs');
      const stats = fs.statSync(process.cwd());
      
      // Simulação de verificação de disco (em produção, usar biblioteca específica)
      return {
        status: 'healthy',
        response_time: Date.now() - startTime,
        message: 'Disk space is adequate',
        details: {
          available: 'N/A - requires disk usage library',
          used: 'N/A - requires disk usage library'
        }
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        response_time: Date.now() - startTime,
        message: 'Disk check failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Verificar serviços externos
   */
  private async checkExternalServices(): Promise<HealthCheck> {
    const startTime = Date.now();
    
    try {
      // Verificar conectividade com serviços externos críticos
      const checks = await Promise.allSettled([
        this.checkOpenAI(),
        this.checkStripe(),
        this.checkEmailService()
      ]);
      
      const failedChecks = checks.filter(check => check.status === 'rejected').length;
      const totalChecks = checks.length;
      
      let status: 'healthy' | 'degraded' | 'unhealthy' = 'healthy';
      let message = 'All external services are healthy';
      
      if (failedChecks === totalChecks) {
        status = 'unhealthy';
        message = 'All external services are down';
      } else if (failedChecks > 0) {
        status = 'degraded';
        message = `${failedChecks}/${totalChecks} external services are down`;
      }
      
      return {
        status,
        response_time: Date.now() - startTime,
        message,
        details: {
          total_services: totalChecks,
          failed_services: failedChecks,
          success_rate: Math.round(((totalChecks - failedChecks) / totalChecks) * 100)
        }
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        response_time: Date.now() - startTime,
        message: 'External services check failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Verificar OpenAI API
   */
  private async checkOpenAI(): Promise<void> {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OpenAI API key not configured');
    }
    // Em produção, fazer uma chamada simples para a API
    return Promise.resolve();
  }

  /**
   * Verificar Stripe API
   */
  private async checkStripe(): Promise<void> {
    if (!process.env.STRIPE_SECRET_KEY) {
      throw new Error('Stripe API key not configured');
    }
    // Em produção, fazer uma chamada simples para a API
    return Promise.resolve();
  }

  /**
   * Verificar serviço de email
   */
  private async checkEmailService(): Promise<void> {
    if (!process.env.SMTP_HOST) {
      throw new Error('Email service not configured');
    }
    // Em produção, verificar conectividade SMTP
    return Promise.resolve();
  }

  /**
   * Obter resultado de um check
   */
  private getCheckResult(settledResult: PromiseSettledResult<HealthCheck>): HealthCheck {
    if (settledResult.status === 'fulfilled') {
      return settledResult.value;
    } else {
      return {
        status: 'unhealthy',
        response_time: 0,
        message: 'Check failed',
        details: settledResult.reason
      };
    }
  }

  /**
   * Determinar status geral baseado nos checks individuais
   */
  private determineOverallStatus(checks: Record<string, HealthCheck>): 'healthy' | 'unhealthy' | 'degraded' {
    const statuses = Object.values(checks).map(check => check.status);
    
    if (statuses.includes('unhealthy')) {
      return 'unhealthy';
    } else if (statuses.includes('degraded')) {
      return 'degraded';
    } else {
      return 'healthy';
    }
  }

  /**
   * Obter resumo das métricas
   */
  private async getMetricsSummary(): Promise<any> {
    try {
      // Em uma implementação real, você calcularia essas métricas
      // baseado nos dados coletados pelo MetricsService
      return {
        requests_per_minute: 0, // Calcular baseado nas métricas coletadas
        average_response_time: 0, // Calcular baseado nas métricas coletadas
        error_rate: 0, // Calcular baseado nas métricas coletadas
        active_connections: parseInt(process.env.ACTIVE_CONNECTIONS || '0')
      };
    } catch (error) {
      LoggerUtils.warn('Failed to get metrics summary', {
        category: 'HEALTH_CHECK',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      return undefined;
    }
  }

  /**
   * Cleanup resources
   */
  async cleanup(): Promise<void> {
    try {
      await this.prisma.$disconnect();
      if (this.redis.isOpen) {
        await this.redis.quit();
      }
    } catch (error) {
      LoggerUtils.error('Error during health service cleanup', error as Error, {
        category: 'HEALTH_CHECK'
      });
    }
  }
}

export default HealthService;