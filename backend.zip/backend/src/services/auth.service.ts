import { PrismaClient } from '@prisma/client';
import { LoginInput, JWTPayload } from '../types/user.types';
import { comparePassword } from '../utils/password.utils';
import { generateTokenPair, verifyRefreshToken, TokenPair } from '../utils/jwt.utils';
import { UserService } from './user.service';

export class AuthService {
  private userService: UserService;

  constructor(private readonly prisma: PrismaClient) {
    this.userService = new UserService(prisma);
  }

  /**
   * Authenticate user with email and password
   */
  async login(credentials: LoginInput): Promise<{
    user: any;
    tokens: TokenPair;
  }> {
    const { email, password } = credentials;

    // Find user by email
    const user = await this.userService.getUserByEmail(email);
    if (!user) {
      throw new Error('Credenciais inválidas');
    }

    // Check if user is active
    if (!user.isActive) {
      throw new Error('Conta desativada. Entre em contato com o suporte.');
    }

    // Verify password
    const isPasswordValid = await comparePassword(password, user.password);
    if (!isPasswordValid) {
      throw new Error('Credenciais inválidas');
    }

    // Update last login
    await this.userService.updateLastLogin(user.id);

    // Generate JWT payload
    const roles = user.userRoles.map(ur => ur.role.name);
    const permissions = user.userRoles.flatMap(ur => 
      ur.role.rolePermissions.map(rp => rp.permission.name)
    );

    const jwtPayload: JWTPayload = {
      userId: user.id,
      email: user.email,
      tenantId: user.tenantId,
      roles,
      permissions,
    };

    // Generate tokens
    const tokens = generateTokenPair(jwtPayload);

    // Remove password from response
    const { password: _, ...userWithoutPassword } = user;

    return {
      user: userWithoutPassword,
      tokens,
    };
  }

  /**
   * Refresh access token using refresh token
   */
  async refreshToken(refreshToken: string): Promise<TokenPair> {
    try {
      // Verify refresh token
      const decoded = verifyRefreshToken(refreshToken);

      // Get user data
      const user = await this.userService.getUserById(decoded.userId);
      if (!user || !user.isActive) {
        throw new Error('Usuário não encontrado ou inativo');
      }

      // Generate new JWT payload
      const roles = user.userRoles.map(ur => ur.role.name);
      const permissions = user.userRoles.flatMap(ur => 
        ur.role.rolePermissions.map(rp => rp.permission.name)
      );

      const jwtPayload: JWTPayload = {
        userId: user.id,
        email: user.email,
        tenantId: user.tenantId,
        roles,
        permissions,
      };

      // Generate new token pair
      return generateTokenPair(jwtPayload);
    } catch (error) {
      throw new Error('Refresh token inválido ou expirado');
    }
  }

  /**
   * Logout user (in a real implementation, you might want to blacklist the token)
   */
  async logout(userId: string): Promise<void> {
    // In a production environment, you might want to:
    // 1. Add the token to a blacklist stored in Redis
    // 2. Update user's last logout timestamp
    // 3. Invalidate all user sessions
    
    // For now, we'll just log the logout action
    console.log(`User ${userId} logged out at ${new Date().toISOString()}`);
  }

  /**
   * Validate user session and get current user
   */
  async getCurrentUser(userId: string) {
    const user = await this.userService.getUserById(userId);
    if (!user || !user.isActive) {
      throw new Error('Sessão inválida');
    }

    // Remove password from response
    const { password, ...userWithoutPassword } = user as any;
    return userWithoutPassword;
  }

  /**
   * Check if user has specific permission
   */
  async checkPermission(userId: string, resource: string, action: string): Promise<boolean> {
    return this.userService.hasPermission(userId, resource, action);
  }

  /**
   * Check if user has any of the specified roles
   */
  async hasRole(userId: string, roles: string[]): Promise<boolean> {
    const userRoles = await this.userService.getUserRoles(userId);
    return roles.some(role => userRoles.includes(role));
  }

  /**
   * Check if user has all of the specified roles
   */
  async hasAllRoles(userId: string, roles: string[]): Promise<boolean> {
    const userRoles = await this.userService.getUserRoles(userId);
    return roles.every(role => userRoles.includes(role));
  }

  /**
   * Verify email (for email verification flow)
   */
  async verifyEmail(userId: string): Promise<void> {
    await this.userService.verifyEmail(userId);
  }

  /**
   * Request password reset (would typically send email)
   */
  async requestPasswordReset(email: string): Promise<void> {
    const user = await this.userService.getUserByEmail(email);
    if (!user) {
      // Don't reveal if email exists or not for security
      return;
    }

    // In a real implementation, you would:
    // 1. Generate a password reset token
    // 2. Store it in the database with expiration
    // 3. Send email with reset link
    
    console.log(`Password reset requested for user: ${email}`);
  }

  /**
   * Reset password using reset token
   */
  async resetPassword(_token: string, _newPassword: string): Promise<void> {
    // In a real implementation, you would:
    // 1. Verify the reset token
    // 2. Check if it's not expired
    // 3. Update the user's password
    // 4. Invalidate the reset token
    
    throw new Error('Password reset not implemented yet');
  }

  /**
   * Change password for authenticated user
   */
  async changePassword(userId: string, currentPassword: string, newPassword: string): Promise<void> {
    await this.userService.changePassword(userId, currentPassword, newPassword);
  }
}