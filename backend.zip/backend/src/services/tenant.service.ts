import { PrismaClient } from '@prisma/client';
import { deleteOldTenantAsset, getFilePathFromUrl } from '../middleware/tenant-upload.middleware';

export interface TenantSettings {
  customFields?: {
    professional?: CustomField[];
    client?: CustomField[];
  };
  branding?: {
    primaryColor?: string;
    secondaryColor?: string;
    logo?: string;
    favicon?: string;
  };
  features?: {
    enableWhatsApp?: boolean;
    enableEmailNotifications?: boolean;
    enablePushNotifications?: boolean;
    enableOnlinePayments?: boolean;
    enableReviews?: boolean;
  };
  businessHours?: {
    [key: string]: {
      start: string;
      end: string;
      enabled: boolean;
    };
  };
  notifications?: {
    reminderTimes?: string[];
    templates?: {
      [key: string]: string;
    };
  };
}

export interface CustomField {
  id: string;
  name: string;
  type: 'text' | 'number' | 'email' | 'phone' | 'select' | 'multiselect' | 'date' | 'boolean';
  label: string;
  placeholder?: string;
  required: boolean;
  options?: string[]; // For select/multiselect fields
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
  };
  order: number;
}

export class TenantService {
  constructor(private readonly prisma: PrismaClient) {}

  /**
   * Get tenant by ID with settings
   */
  async getTenantById(id: string) {
    const tenant = await this.prisma.tenant.findUnique({
      where: { id },
    });

    if (!tenant) {
      return null;
    }

    return {
      ...tenant,
      settings: tenant.settings ? JSON.parse(tenant.settings) : {},
    };
  }

  /**
   * Get tenant by slug with settings
   */
  async getTenantBySlug(slug: string) {
    const tenant = await this.prisma.tenant.findUnique({
      where: { slug },
    });

    if (!tenant) {
      return null;
    }

    return {
      ...tenant,
      settings: tenant.settings ? JSON.parse(tenant.settings) : {},
    };
  }

  /**
   * Update tenant settings
   */
  async updateTenantSettings(tenantId: string, settings: Partial<TenantSettings>) {
    const currentTenant = await this.getTenantById(tenantId);
    if (!currentTenant) {
      throw new Error('Tenant não encontrado');
    }

    const updatedSettings = {
      ...currentTenant.settings,
      ...settings,
    };

    return this.prisma.tenant.update({
      where: { id: tenantId },
      data: {
        settings: JSON.stringify(updatedSettings),
      },
    });
  }

  /**
   * Add custom field to tenant
   */
  async addCustomField(tenantId: string, userType: 'professional' | 'client', field: Omit<CustomField, 'id'>) {
    const tenant = await this.getTenantById(tenantId);
    if (!tenant) {
      throw new Error('Tenant não encontrado');
    }

    const settings = tenant.settings as TenantSettings;
    if (!settings.customFields) {
      settings.customFields = {};
    }
    if (!settings.customFields[userType]) {
      settings.customFields[userType] = [];
    }

    const newField: CustomField = {
      ...field,
      id: `field_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    };

    settings.customFields[userType].push(newField);

    await this.updateTenantSettings(tenantId, settings);
    return newField;
  }

  /**
   * Update custom field
   */
  async updateCustomField(tenantId: string, userType: 'professional' | 'client', fieldId: string, updates: Partial<CustomField>) {
    const tenant = await this.getTenantById(tenantId);
    if (!tenant) {
      throw new Error('Tenant não encontrado');
    }

    const settings = tenant.settings as TenantSettings;
    if (!settings.customFields?.[userType]) {
      throw new Error('Campo personalizado não encontrado');
    }

    const fieldIndex = settings.customFields[userType].findIndex(f => f.id === fieldId);
    if (fieldIndex === -1) {
      throw new Error('Campo personalizado não encontrado');
    }

    settings.customFields[userType][fieldIndex] = {
      ...settings.customFields[userType][fieldIndex],
      ...updates,
    };

    await this.updateTenantSettings(tenantId, settings);
    return settings.customFields[userType][fieldIndex];
  }

  /**
   * Remove custom field
   */
  async removeCustomField(tenantId: string, userType: 'professional' | 'client', fieldId: string) {
    const tenant = await this.getTenantById(tenantId);
    if (!tenant) {
      throw new Error('Tenant não encontrado');
    }

    const settings = tenant.settings as TenantSettings;
    if (!settings.customFields?.[userType]) {
      throw new Error('Campo personalizado não encontrado');
    }

    settings.customFields[userType] = settings.customFields[userType].filter(f => f.id !== fieldId);

    await this.updateTenantSettings(tenantId, settings);
  }

  /**
   * Get custom fields for user type
   */
  async getCustomFields(tenantId: string, userType: 'professional' | 'client'): Promise<CustomField[]> {
    const tenant = await this.getTenantById(tenantId);
    if (!tenant) {
      return [];
    }

    const settings = tenant.settings as TenantSettings;
    return settings.customFields?.[userType] || [];
  }

  /**
   * Validate custom field values
   */
  validateCustomFieldValues(fields: CustomField[], values: Record<string, any>): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    for (const field of fields) {
      const value = values[field.id];

      // Check required fields
      if (field.required && (value === undefined || value === null || value === '')) {
        errors.push(`${field.label} é obrigatório`);
        continue;
      }

      // Skip validation if field is not required and empty
      if (!field.required && (value === undefined || value === null || value === '')) {
        continue;
      }

      // Type-specific validation
      switch (field.type) {
        case 'email':
          if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
            errors.push(`${field.label} deve ser um email válido`);
          }
          break;

        case 'phone':
          if (!/^\+?[\d\s\-\(\)]+$/.test(value)) {
            errors.push(`${field.label} deve ser um telefone válido`);
          }
          break;

        case 'number':
          if (isNaN(Number(value))) {
            errors.push(`${field.label} deve ser um número`);
          } else {
            const numValue = Number(value);
            if (field.validation?.min !== undefined && numValue < field.validation.min) {
              errors.push(`${field.label} deve ser maior que ${field.validation.min}`);
            }
            if (field.validation?.max !== undefined && numValue > field.validation.max) {
              errors.push(`${field.label} deve ser menor que ${field.validation.max}`);
            }
          }
          break;

        case 'text':
          if (typeof value !== 'string') {
            errors.push(`${field.label} deve ser um texto`);
          } else {
            if (field.validation?.min !== undefined && value.length < field.validation.min) {
              errors.push(`${field.label} deve ter pelo menos ${field.validation.min} caracteres`);
            }
            if (field.validation?.max !== undefined && value.length > field.validation.max) {
              errors.push(`${field.label} deve ter no máximo ${field.validation.max} caracteres`);
            }
            if (field.validation?.pattern && !new RegExp(field.validation.pattern).test(value)) {
              errors.push(`${field.label} não atende ao formato exigido`);
            }
          }
          break;

        case 'select':
          if (field.options && !field.options.includes(value)) {
            errors.push(`${field.label} deve ser uma das opções válidas`);
          }
          break;

        case 'multiselect':
          if (!Array.isArray(value)) {
            errors.push(`${field.label} deve ser uma lista`);
          } else if (field.options) {
            const invalidOptions = value.filter(v => !field.options!.includes(v));
            if (invalidOptions.length > 0) {
              errors.push(`${field.label} contém opções inválidas: ${invalidOptions.join(', ')}`);
            }
          }
          break;

        case 'date':
          if (isNaN(Date.parse(value))) {
            errors.push(`${field.label} deve ser uma data válida`);
          }
          break;

        case 'boolean':
          if (typeof value !== 'boolean') {
            errors.push(`${field.label} deve ser verdadeiro ou falso`);
          }
          break;
      }
    }

    return {
      isValid: errors.length === 0,
      errors,
    };
  }

  /**
   * Create new tenant
   */
  async createTenant(data: {
    name: string;
    slug: string;
    logo?: string;
    primaryColor?: string;
    settings?: Partial<TenantSettings>;
  }) {
    // Verificar se slug já existe
    const existingTenant = await this.prisma.tenant.findUnique({
      where: { slug: data.slug },
    });

    if (existingTenant) {
      throw new Error('Slug já está em uso');
    }

    // Validar slug (apenas letras, números e hífens)
    if (!/^[a-z0-9-]+$/.test(data.slug)) {
      throw new Error('Slug deve conter apenas letras minúsculas, números e hífens');
    }

    const tenant = await this.prisma.tenant.create({
      data: {
        name: data.name,
        slug: data.slug,
        logo: data.logo,
        primaryColor: data.primaryColor,
        settings: data.settings ? JSON.stringify(data.settings) : null,
      },
    });

    return {
      ...tenant,
      settings: tenant.settings ? JSON.parse(tenant.settings) : {},
    };
  }

  /**
   * Update tenant basic info
   */
  async updateTenant(tenantId: string, data: {
    name?: string;
    slug?: string;
    logo?: string;
    primaryColor?: string;
    isActive?: boolean;
  }) {
    const currentTenant = await this.getTenantById(tenantId);
    if (!currentTenant) {
      throw new Error('Tenant não encontrado');
    }

    // Se está atualizando o slug, verificar se não existe
    if (data.slug && data.slug !== currentTenant.slug) {
      const existingTenant = await this.prisma.tenant.findUnique({
        where: { slug: data.slug },
      });

      if (existingTenant) {
        throw new Error('Slug já está em uso');
      }

      // Validar slug
      if (!/^[a-z0-9-]+$/.test(data.slug)) {
        throw new Error('Slug deve conter apenas letras minúsculas, números e hífens');
      }
    }

    // Se está atualizando o logo, deletar o antigo
    if (data.logo && currentTenant.logo && currentTenant.logo !== data.logo) {
      const oldLogoPath = getFilePathFromUrl(currentTenant.logo);
      deleteOldTenantAsset(oldLogoPath);
    }

    const tenant = await this.prisma.tenant.update({
      where: { id: tenantId },
      data,
    });

    return {
      ...tenant,
      settings: tenant.settings ? JSON.parse(tenant.settings) : {},
    };
  }

  /**
   * Delete tenant and all related data
   */
  async deleteTenant(tenantId: string) {
    const tenant = await this.getTenantById(tenantId);
    if (!tenant) {
      throw new Error('Tenant não encontrado');
    }

    // Deletar arquivos de logo e favicon se existirem
    if (tenant.logo) {
      const logoPath = getFilePathFromUrl(tenant.logo);
      deleteOldTenantAsset(logoPath);
    }

    const settings = tenant.settings as TenantSettings;
    if (settings?.branding?.favicon) {
      const faviconPath = getFilePathFromUrl(settings.branding.favicon);
      deleteOldTenantAsset(faviconPath);
    }

    // Deletar tenant (cascade irá deletar dados relacionados)
    await this.prisma.tenant.delete({
      where: { id: tenantId },
    });
  }

  /**
   * Get tenant statistics
   */
  async getTenantStats(tenantId: string) {
    const [
      usersCount,
      professionalsCount,
      servicesCount,
      bookingsCount,
      activeBookingsCount,
    ] = await Promise.all([
      this.prisma.user.count({ where: { tenantId, isActive: true } }),
      this.prisma.professional.count({ where: { tenantId } }),
      this.prisma.service.count({ where: { tenantId, isActive: true } }),
      this.prisma.booking.count({ where: { tenantId } }),
      this.prisma.booking.count({ 
        where: { 
          tenantId, 
          status: { in: ['SCHEDULED', 'CONFIRMED'] } 
        } 
      }),
    ]);

    return {
      users: usersCount,
      professionals: professionalsCount,
      services: servicesCount,
      bookings: bookingsCount,
      activeBookings: activeBookingsCount,
    };
  }

  /**
   * Get all tenants with pagination
   */
  async getTenants(params: {
    page?: number;
    limit?: number;
    isActive?: boolean;
    search?: string;
  } = {}) {
    const { page = 1, limit = 10, isActive, search } = params;
    const skip = (page - 1) * limit;

    const where: any = {};

    if (isActive !== undefined) {
      where.isActive = isActive;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { slug: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [tenants, total] = await Promise.all([
      this.prisma.tenant.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          _count: {
            select: {
              users: true,
              professionals: true,
              services: true,
              bookings: true,
            },
          },
        },
      }),
      this.prisma.tenant.count({ where }),
    ]);

    return {
      tenants: tenants.map(tenant => ({
        ...tenant,
        settings: tenant.settings ? JSON.parse(tenant.settings) : {},
        stats: tenant._count,
      })),
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }
}