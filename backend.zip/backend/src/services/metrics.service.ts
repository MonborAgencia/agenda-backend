import client from 'prom-client';
import { Request, Response } from 'express';
import LoggerUtils from '../utils/logger.utils';

// Configurar coleta de métricas padrão
client.collectDefaultMetrics({
  timeout: 10000,
  gcDurationBuckets: [0.001, 0.01, 0.1, 1, 2, 5],
  prefix: 'agenda_lotada_'
});

// Métricas customizadas
const httpRequestsTotal = new client.Counter({
  name: 'agenda_lotada_http_requests_total',
  help: 'Total number of HTTP requests',
  labelNames: ['method', 'route', 'status_code', 'tenant_id']
});

const httpRequestDuration = new client.Histogram({
  name: 'agenda_lotada_http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route', 'status_code', 'tenant_id'],
  buckets: [0.1, 0.3, 0.5, 0.7, 1, 3, 5, 7, 10]
});

const activeConnections = new client.Gauge({
  name: 'agenda_lotada_active_connections',
  help: 'Number of active connections'
});

const databaseConnectionsActive = new client.Gauge({
  name: 'agenda_lotada_database_connections_active',
  help: 'Number of active database connections'
});

const databaseQueryDuration = new client.Histogram({
  name: 'agenda_lotada_database_query_duration_seconds',
  help: 'Duration of database queries in seconds',
  labelNames: ['operation', 'table', 'tenant_id'],
  buckets: [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 2, 5]
});

const cacheOperations = new client.Counter({
  name: 'agenda_lotada_cache_operations_total',
  help: 'Total number of cache operations',
  labelNames: ['operation', 'result', 'tenant_id']
});

const businessMetrics = new client.Counter({
  name: 'agenda_lotada_business_events_total',
  help: 'Total number of business events',
  labelNames: ['event_type', 'tenant_id', 'user_role']
});

const errorRate = new client.Counter({
  name: 'agenda_lotada_errors_total',
  help: 'Total number of errors',
  labelNames: ['error_type', 'service', 'tenant_id']
});

const memoryUsage = new client.Gauge({
  name: 'agenda_lotada_memory_usage_bytes',
  help: 'Memory usage in bytes',
  labelNames: ['type']
});

const cpuUsage = new client.Gauge({
  name: 'agenda_lotada_cpu_usage_percent',
  help: 'CPU usage percentage'
});

export class MetricsService {
  /**
   * Registrar métrica de requisição HTTP
   */
  static recordHttpRequest(
    method: string,
    route: string,
    statusCode: number,
    duration: number,
    tenantId?: string
  ): void {
    const labels = {
      method,
      route,
      status_code: statusCode.toString(),
      tenant_id: tenantId || 'unknown'
    };

    httpRequestsTotal.inc(labels);
    httpRequestDuration.observe(labels, duration / 1000); // Converter para segundos

    LoggerUtils.metric('http_request', duration, {
      method,
      route,
      statusCode,
      tenantId
    });
  }

  /**
   * Registrar métrica de query de banco de dados
   */
  static recordDatabaseQuery(
    operation: string,
    table: string,
    duration: number,
    tenantId?: string
  ): void {
    const labels = {
      operation,
      table,
      tenant_id: tenantId || 'unknown'
    };

    databaseQueryDuration.observe(labels, duration / 1000);

    LoggerUtils.metric('database_query', duration, {
      operation,
      table,
      tenantId
    });
  }

  /**
   * Registrar operação de cache
   */
  static recordCacheOperation(
    operation: 'hit' | 'miss' | 'set' | 'delete' | 'clear',
    result: 'success' | 'failure',
    tenantId?: string
  ): void {
    const labels = {
      operation,
      result,
      tenant_id: tenantId || 'unknown'
    };

    cacheOperations.inc(labels);

    LoggerUtils.metric('cache_operation', 1, {
      operation,
      result,
      tenantId
    });
  }

  /**
   * Registrar evento de negócio
   */
  static recordBusinessEvent(
    eventType: string,
    tenantId?: string,
    userRole?: string
  ): void {
    const labels = {
      event_type: eventType,
      tenant_id: tenantId || 'unknown',
      user_role: userRole || 'unknown'
    };

    businessMetrics.inc(labels);

    LoggerUtils.business(eventType, {
      tenantId,
      userRole
    });
  }

  /**
   * Registrar erro
   */
  static recordError(
    errorType: string,
    service: string,
    tenantId?: string
  ): void {
    const labels = {
      error_type: errorType,
      service,
      tenant_id: tenantId || 'unknown'
    };

    errorRate.inc(labels);

    LoggerUtils.metric('error', 1, {
      errorType,
      service,
      tenantId
    });
  }

  /**
   * Atualizar conexões ativas
   */
  static updateActiveConnections(count: number): void {
    activeConnections.set(count);
  }

  /**
   * Atualizar conexões de banco de dados ativas
   */
  static updateDatabaseConnections(count: number): void {
    databaseConnectionsActive.set(count);
  }

  /**
   * Atualizar métricas de sistema
   */
  static updateSystemMetrics(): void {
    const memUsage = process.memoryUsage();
    
    memoryUsage.set({ type: 'rss' }, memUsage.rss);
    memoryUsage.set({ type: 'heap_used' }, memUsage.heapUsed);
    memoryUsage.set({ type: 'heap_total' }, memUsage.heapTotal);
    memoryUsage.set({ type: 'external' }, memUsage.external);

    // CPU usage (aproximado baseado no uptime)
    const cpuPercent = process.cpuUsage();
    const totalCpu = cpuPercent.user + cpuPercent.system;
    cpuUsage.set(totalCpu / 1000000); // Converter para segundos
  }

  /**
   * Obter todas as métricas em formato Prometheus
   */
  static async getMetrics(): Promise<string> {
    // Atualizar métricas de sistema antes de retornar
    this.updateSystemMetrics();
    
    return client.register.metrics();
  }

  /**
   * Limpar todas as métricas
   */
  static clearMetrics(): void {
    client.register.clear();
    LoggerUtils.info('Metrics cleared', {
      category: 'METRICS',
      action: 'CLEAR'
    });
  }

  /**
   * Obter métricas específicas por nome
   */
  static getMetric(name: string): client.Metric<string> | undefined {
    return client.register.getSingleMetric(name);
  }

  /**
   * Registrar métricas customizadas de negócio
   */
  static recordBookingMetrics(
    action: 'created' | 'cancelled' | 'completed' | 'no_show',
    tenantId: string,
    professionalId?: string,
    serviceId?: string
  ): void {
    this.recordBusinessEvent(`booking_${action}`, tenantId);
    
    LoggerUtils.business(`Booking ${action}`, {
      tenantId,
      professionalId,
      serviceId,
      action
    });
  }

  /**
   * Registrar métricas de autenticação
   */
  static recordAuthMetrics(
    action: 'login' | 'logout' | 'register' | 'failed_login',
    tenantId?: string,
    userRole?: string
  ): void {
    this.recordBusinessEvent(`auth_${action}`, tenantId, userRole);
  }

  /**
   * Registrar métricas de notificação
   */
  static recordNotificationMetrics(
    channel: 'email' | 'whatsapp' | 'push',
    status: 'sent' | 'failed' | 'delivered',
    tenantId?: string
  ): void {
    this.recordBusinessEvent(`notification_${channel}_${status}`, tenantId);
  }

  /**
   * Registrar métricas de IA
   */
  static recordAIMetrics(
    operation: 'chat' | 'recommendation' | 'analysis',
    duration: number,
    success: boolean,
    tenantId?: string
  ): void {
    this.recordBusinessEvent(`ai_${operation}_${success ? 'success' : 'failure'}`, tenantId);
    
    LoggerUtils.performance(`AI ${operation}`, duration, {
      tenantId,
      success
    });
  }
}

export default MetricsService;