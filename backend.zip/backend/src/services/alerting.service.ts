import LoggerUtils from '../utils/logger.utils';
import MetricsService from './metrics.service';
import HealthService from './health.service';

export interface AlertRule {
  id: string;
  name: string;
  description: string;
  metric: string;
  condition: 'greater_than' | 'less_than' | 'equals' | 'not_equals';
  threshold: number;
  duration: number; // em segundos
  severity: 'low' | 'medium' | 'high' | 'critical';
  enabled: boolean;
  lastTriggered?: Date;
  cooldown: number; // em segundos
}

export interface Alert {
  id: string;
  ruleId: string;
  ruleName: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  value: number;
  threshold: number;
  timestamp: Date;
  resolved: boolean;
  resolvedAt?: Date;
}

export class AlertingService {
  private static instance: AlertingService;
  private alerts: Alert[] = [];
  private rules: AlertRule[] = [];
  private healthService: HealthService;
  private monitoringInterval?: NodeJS.Timeout;

  constructor() {
    this.healthService = new HealthService();
    this.initializeDefaultRules();
  }

  static getInstance(): AlertingService {
    if (!AlertingService.instance) {
      AlertingService.instance = new AlertingService();
    }
    return AlertingService.instance;
  }

  /**
   * Inicializar regras de alerta padrão
   */
  private initializeDefaultRules(): void {
    this.rules = [
      {
        id: 'high_memory_usage',
        name: 'High Memory Usage',
        description: 'Memory usage is above 85%',
        metric: 'memory_usage_percent',
        condition: 'greater_than',
        threshold: 85,
        duration: 300, // 5 minutos
        severity: 'high',
        enabled: true,
        cooldown: 900 // 15 minutos
      },
      {
        id: 'high_error_rate',
        name: 'High Error Rate',
        description: 'Error rate is above 5%',
        metric: 'error_rate_percent',
        condition: 'greater_than',
        threshold: 5,
        duration: 180, // 3 minutos
        severity: 'high',
        enabled: true,
        cooldown: 600 // 10 minutos
      },
      {
        id: 'slow_response_time',
        name: 'Slow Response Time',
        description: 'Average response time is above 2 seconds',
        metric: 'avg_response_time_seconds',
        condition: 'greater_than',
        threshold: 2,
        duration: 300, // 5 minutos
        severity: 'medium',
        enabled: true,
        cooldown: 600 // 10 minutos
      },
      {
        id: 'database_connection_failure',
        name: 'Database Connection Failure',
        description: 'Database health check is failing',
        metric: 'database_health',
        condition: 'equals',
        threshold: 0, // 0 = unhealthy
        duration: 60, // 1 minuto
        severity: 'critical',
        enabled: true,
        cooldown: 300 // 5 minutos
      },
      {
        id: 'redis_connection_failure',
        name: 'Redis Connection Failure',
        description: 'Redis health check is failing',
        metric: 'redis_health',
        condition: 'equals',
        threshold: 0, // 0 = unhealthy
        duration: 60, // 1 minuto
        severity: 'high',
        enabled: true,
        cooldown: 300 // 5 minutos
      },
      {
        id: 'high_active_connections',
        name: 'High Active Connections',
        description: 'Too many active connections',
        metric: 'active_connections',
        condition: 'greater_than',
        threshold: 1000,
        duration: 180, // 3 minutos
        severity: 'medium',
        enabled: true,
        cooldown: 600 // 10 minutos
      }
    ];

    LoggerUtils.info('Default alert rules initialized', {
      category: 'ALERTING',
      rulesCount: this.rules.length
    });
  }

  /**
   * Iniciar monitoramento de alertas
   */
  startMonitoring(intervalMs: number = 60000): void { // Default: 1 minuto
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
    }

    this.monitoringInterval = setInterval(async () => {
      await this.checkAlerts();
    }, intervalMs);

    LoggerUtils.info('Alert monitoring started', {
      category: 'ALERTING',
      interval: intervalMs
    });
  }

  /**
   * Parar monitoramento de alertas
   */
  stopMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = undefined;
    }

    LoggerUtils.info('Alert monitoring stopped', {
      category: 'ALERTING'
    });
  }

  /**
   * Verificar todas as regras de alerta
   */
  private async checkAlerts(): Promise<void> {
    try {
      const enabledRules = this.rules.filter(rule => rule.enabled);
      
      for (const rule of enabledRules) {
        await this.checkRule(rule);
      }
    } catch (error) {
      LoggerUtils.error('Error checking alerts', error as Error, {
        category: 'ALERTING'
      });
    }
  }

  /**
   * Verificar uma regra específica
   */
  private async checkRule(rule: AlertRule): Promise<void> {
    try {
      // Verificar cooldown
      if (rule.lastTriggered) {
        const timeSinceLastTrigger = (Date.now() - rule.lastTriggered.getTime()) / 1000;
        if (timeSinceLastTrigger < rule.cooldown) {
          return; // Ainda em cooldown
        }
      }

      const currentValue = await this.getMetricValue(rule.metric);
      const conditionMet = this.evaluateCondition(currentValue, rule.condition, rule.threshold);

      if (conditionMet) {
        await this.triggerAlert(rule, currentValue);
      }
    } catch (error) {
      LoggerUtils.error(`Error checking rule ${rule.id}`, error as Error, {
        category: 'ALERTING',
        ruleId: rule.id
      });
    }
  }

  /**
   * Obter valor atual de uma métrica
   */
  private async getMetricValue(metricName: string): Promise<number> {
    switch (metricName) {
      case 'memory_usage_percent':
        const memUsage = process.memoryUsage();
        return (memUsage.heapUsed / memUsage.heapTotal) * 100;

      case 'error_rate_percent':
        // Em uma implementação real, calcular baseado nas métricas coletadas
        return 0; // Placeholder

      case 'avg_response_time_seconds':
        // Em uma implementação real, calcular baseado nas métricas coletadas
        return 0; // Placeholder

      case 'database_health':
        const healthResult = await this.healthService.performHealthCheck();
        return healthResult.checks.database.status === 'healthy' ? 1 : 0;

      case 'redis_health':
        const redisHealthResult = await this.healthService.performHealthCheck();
        return redisHealthResult.checks.redis.status === 'healthy' ? 1 : 0;

      case 'active_connections':
        return parseInt(process.env.ACTIVE_CONNECTIONS || '0');

      default:
        throw new Error(`Unknown metric: ${metricName}`);
    }
  }

  /**
   * Avaliar condição de alerta
   */
  private evaluateCondition(value: number, condition: string, threshold: number): boolean {
    switch (condition) {
      case 'greater_than':
        return value > threshold;
      case 'less_than':
        return value < threshold;
      case 'equals':
        return value === threshold;
      case 'not_equals':
        return value !== threshold;
      default:
        return false;
    }
  }

  /**
   * Disparar alerta
   */
  private async triggerAlert(rule: AlertRule, currentValue: number): Promise<void> {
    const alert: Alert = {
      id: `${rule.id}_${Date.now()}`,
      ruleId: rule.id,
      ruleName: rule.name,
      severity: rule.severity,
      message: `${rule.description}. Current value: ${currentValue}, Threshold: ${rule.threshold}`,
      value: currentValue,
      threshold: rule.threshold,
      timestamp: new Date(),
      resolved: false
    };

    this.alerts.push(alert);
    rule.lastTriggered = new Date();

    // Log do alerta
    LoggerUtils.warn(`Alert triggered: ${rule.name}`, {
      category: 'ALERTING',
      alertId: alert.id,
      ruleId: rule.id,
      severity: rule.severity,
      currentValue,
      threshold: rule.threshold
    });

    // Registrar métrica de alerta
    MetricsService.recordError(`alert_${rule.severity}`, 'alerting', undefined);

    // Enviar notificação (implementar conforme necessário)
    await this.sendAlertNotification(alert);
  }

  /**
   * Enviar notificação de alerta
   */
  private async sendAlertNotification(alert: Alert): Promise<void> {
    try {
      // Implementar envio de notificações (email, Slack, webhook, etc.)
      LoggerUtils.info(`Alert notification sent: ${alert.ruleName}`, {
        category: 'ALERTING',
        alertId: alert.id,
        severity: alert.severity
      });
    } catch (error) {
      LoggerUtils.error('Failed to send alert notification', error as Error, {
        category: 'ALERTING',
        alertId: alert.id
      });
    }
  }

  /**
   * Resolver alerta
   */
  resolveAlert(alertId: string): boolean {
    const alert = this.alerts.find(a => a.id === alertId && !a.resolved);
    
    if (alert) {
      alert.resolved = true;
      alert.resolvedAt = new Date();
      
      LoggerUtils.info(`Alert resolved: ${alert.ruleName}`, {
        category: 'ALERTING',
        alertId: alert.id,
        duration: alert.resolvedAt.getTime() - alert.timestamp.getTime()
      });
      
      return true;
    }
    
    return false;
  }

  /**
   * Obter alertas ativos
   */
  getActiveAlerts(): Alert[] {
    return this.alerts.filter(alert => !alert.resolved);
  }

  /**
   * Obter todos os alertas
   */
  getAllAlerts(): Alert[] {
    return [...this.alerts];
  }

  /**
   * Obter regras de alerta
   */
  getRules(): AlertRule[] {
    return [...this.rules];
  }

  /**
   * Adicionar nova regra
   */
  addRule(rule: Omit<AlertRule, 'id'>): AlertRule {
    const newRule: AlertRule = {
      ...rule,
      id: `custom_${Date.now()}`
    };
    
    this.rules.push(newRule);
    
    LoggerUtils.info(`New alert rule added: ${newRule.name}`, {
      category: 'ALERTING',
      ruleId: newRule.id
    });
    
    return newRule;
  }

  /**
   * Atualizar regra existente
   */
  updateRule(ruleId: string, updates: Partial<AlertRule>): boolean {
    const ruleIndex = this.rules.findIndex(rule => rule.id === ruleId);
    
    if (ruleIndex !== -1) {
      this.rules[ruleIndex] = { ...this.rules[ruleIndex], ...updates };
      
      LoggerUtils.info(`Alert rule updated: ${this.rules[ruleIndex].name}`, {
        category: 'ALERTING',
        ruleId
      });
      
      return true;
    }
    
    return false;
  }

  /**
   * Remover regra
   */
  removeRule(ruleId: string): boolean {
    const ruleIndex = this.rules.findIndex(rule => rule.id === ruleId);
    
    if (ruleIndex !== -1) {
      const removedRule = this.rules.splice(ruleIndex, 1)[0];
      
      LoggerUtils.info(`Alert rule removed: ${removedRule.name}`, {
        category: 'ALERTING',
        ruleId
      });
      
      return true;
    }
    
    return false;
  }

  /**
   * Limpar alertas antigos
   */
  cleanupOldAlerts(maxAgeMs: number = 7 * 24 * 60 * 60 * 1000): void { // Default: 7 dias
    const cutoffTime = Date.now() - maxAgeMs;
    const initialCount = this.alerts.length;
    
    this.alerts = this.alerts.filter(alert => 
      alert.timestamp.getTime() > cutoffTime || !alert.resolved
    );
    
    const removedCount = initialCount - this.alerts.length;
    
    if (removedCount > 0) {
      LoggerUtils.info(`Cleaned up old alerts`, {
        category: 'ALERTING',
        removedCount,
        remainingCount: this.alerts.length
      });
    }
  }
}

export default AlertingService;