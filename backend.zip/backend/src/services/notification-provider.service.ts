import {
  NotificationProvider,
  NotificationType,
  Notification,
  NotificationResult
} from '../types/notification.types';
import { emailProvider } from '../providers/email.provider';
import { whatsAppProvider } from '../providers/whatsapp.provider';
import { pushProvider } from '../providers/push.provider';

export class NotificationProviderService {
  private providers: Map<NotificationType, NotificationProvider> = new Map();

  constructor() {
    this.initializeProviders();
  }

  // Inicializar todos os providers
  private initializeProviders(): void {
    this.providers.set(NotificationType.EMAIL, emailProvider);
    this.providers.set(NotificationType.WHATSAPP, whatsAppProvider);
    this.providers.set(NotificationType.PUSH, pushProvider);

    console.log('Notification providers inicializados');
  }

  // Obter provider por tipo
  getProvider(type: NotificationType): NotificationProvider | null {
    return this.providers.get(type) || null;
  }

  // Verificar se um provider está configurado
  isProviderConfigured(type: NotificationType): boolean {
    const provider = this.getProvider(type);
    return provider ? provider.isConfigured() : false;
  }

  // Enviar notificação usando o provider apropriado
  async sendNotification(notification: Notification): Promise<NotificationResult> {
    const provider = this.getProvider(notification.type);
    
    if (!provider) {
      return {
        success: false,
        error: `Provider não encontrado para o tipo: ${notification.type}`
      };
    }

    if (!provider.isConfigured()) {
      return {
        success: false,
        error: `Provider ${notification.type} não está configurado`
      };
    }

    try {
      const result = await provider.send(notification);
      
      console.log(`Notificação ${notification.id} (${notification.type}): ${result.success ? 'sucesso' : 'falha'}`);
      
      return result;
    } catch (error: any) {
      console.error(`Erro no provider ${notification.type}:`, error);
      
      return {
        success: false,
        error: error.message || 'Erro desconhecido no provider'
      };
    }
  }

  // Enviar notificação para múltiplos canais
  async sendMultiChannelNotification(
    notifications: Notification[]
  ): Promise<Record<string, NotificationResult>> {
    const results: Record<string, NotificationResult> = {};
    
    const promises = notifications.map(async (notification) => {
      const result = await this.sendNotification(notification);
      results[notification.id] = result;
      return result;
    });

    await Promise.all(promises);
    
    return results;
  }

  // Obter status de todos os providers
  getProvidersStatus(): Record<NotificationType, {
    configured: boolean;
    info: any;
  }> {
    const status: any = {};
    
    for (const [type, provider] of this.providers) {
      status[type] = {
        configured: provider.isConfigured(),
        info: (provider as any).getProviderInfo?.() || {}
      };
    }
    
    return status;
  }

  // Testar conectividade de um provider
  async testProvider(type: NotificationType): Promise<{
    success: boolean;
    message: string;
    details?: any;
  }> {
    const provider = this.getProvider(type);
    
    if (!provider) {
      return {
        success: false,
        message: `Provider ${type} não encontrado`
      };
    }

    if (!provider.isConfigured()) {
      return {
        success: false,
        message: `Provider ${type} não está configurado`
      };
    }

    try {
      // Teste específico por tipo de provider
      switch (type) {
        case NotificationType.EMAIL:
          const emailResult = await (emailProvider as any).verifyConnection?.();
          return {
            success: emailResult || false,
            message: emailResult ? 'Conexão SMTP verificada' : 'Falha na conexão SMTP'
          };

        case NotificationType.WHATSAPP:
          // Para WhatsApp, podemos tentar fazer uma requisição de teste
          return {
            success: true,
            message: 'WhatsApp provider configurado (teste completo requer número válido)'
          };

        case NotificationType.PUSH:
          // Para Push, verificar se o Firebase está inicializado
          return {
            success: true,
            message: 'Push provider configurado (Firebase inicializado)'
          };

        default:
          return {
            success: false,
            message: `Teste não implementado para ${type}`
          };
      }
    } catch (error: any) {
      return {
        success: false,
        message: `Erro ao testar ${type}: ${error.message}`,
        details: error
      };
    }
  }

  // Obter provider preferido para um usuário
  async getPreferredProvider(recipientId: string): Promise<NotificationType | null> {
    try {
      // Importar Prisma dinamicamente
      const { PrismaClient } = await import('@prisma/client');
      const prisma = new PrismaClient();

      const user = await prisma.user.findUnique({
        where: { id: recipientId },
        include: { profile: true }
      });

      await prisma.$disconnect();

      if (user?.profile?.preferences) {
        const preferences = JSON.parse(user.profile.preferences);
        const preferredChannel = preferences.preferredNotificationChannel;
        
        if (preferredChannel && this.isProviderConfigured(preferredChannel)) {
          return preferredChannel;
        }
      }

      // Fallback: retornar o primeiro provider configurado
      for (const type of Object.values(NotificationType)) {
        if (this.isProviderConfigured(type)) {
          return type;
        }
      }

      return null;
    } catch (error) {
      console.error('Erro ao obter provider preferido:', error);
      return null;
    }
  }

  // Definir provider preferido para um usuário
  async setPreferredProvider(recipientId: string, type: NotificationType): Promise<boolean> {
    try {
      if (!this.isProviderConfigured(type)) {
        return false;
      }

      const { PrismaClient } = await import('@prisma/client');
      const prisma = new PrismaClient();

      const user = await prisma.user.findUnique({
        where: { id: recipientId },
        include: { profile: true }
      });

      if (!user) {
        return false;
      }

      let preferences = {};
      if (user.profile?.preferences) {
        preferences = JSON.parse(user.profile.preferences);
      }

      (preferences as any).preferredNotificationChannel = type;

      if (user.profile) {
        await prisma.userProfile.update({
          where: { userId: recipientId },
          data: {
            preferences: JSON.stringify(preferences)
          }
        });
      } else {
        await prisma.userProfile.create({
          data: {
            userId: recipientId,
            preferences: JSON.stringify(preferences)
          }
        });
      }

      await prisma.$disconnect();
      return true;
    } catch (error) {
      console.error('Erro ao definir provider preferido:', error);
      return false;
    }
  }

  // Obter estatísticas de entrega por provider
  async getDeliveryStats(dateFrom?: Date, dateTo?: Date): Promise<Record<NotificationType, {
    total: number;
    sent: number;
    delivered: number;
    failed: number;
    deliveryRate: number;
  }>> {
    try {
      const { PrismaClient } = await import('@prisma/client');
      const prisma = new PrismaClient();

      const where: any = {};
      if (dateFrom || dateTo) {
        where.createdAt = {};
        if (dateFrom) where.createdAt.gte = dateFrom;
        if (dateTo) where.createdAt.lte = dateTo;
      }

      const stats = await prisma.notification.groupBy({
        by: ['type', 'status'],
        where,
        _count: { status: true }
      });

      await prisma.$disconnect();

      const result: any = {};

      // Inicializar estatísticas para todos os tipos
      for (const type of Object.values(NotificationType)) {
        result[type] = {
          total: 0,
          sent: 0,
          delivered: 0,
          failed: 0,
          deliveryRate: 0
        };
      }

      // Processar estatísticas do banco
      for (const stat of stats) {
        const type = stat.type as NotificationType;
        const status = stat.status;
        const count = stat._count.status;

        if (!result[type]) continue;

        result[type].total += count;

        switch (status) {
          case 'SENT':
            result[type].sent += count;
            break;
          case 'DELIVERED':
            result[type].delivered += count;
            break;
          case 'FAILED':
            result[type].failed += count;
            break;
        }
      }

      // Calcular taxa de entrega
      for (const type of Object.values(NotificationType)) {
        const typeStats = result[type];
        if (typeStats.total > 0) {
          typeStats.deliveryRate = Math.round(
            ((typeStats.sent + typeStats.delivered) / typeStats.total) * 100 * 100
          ) / 100;
        }
      }

      return result;
    } catch (error) {
      console.error('Erro ao obter estatísticas de entrega:', error);
      return {} as any;
    }
  }

  // Reconfigurar provider
  async reconfigureProvider(type: NotificationType): Promise<boolean> {
    try {
      const provider = this.getProvider(type);
      
      if (!provider) {
        return false;
      }

      // Reinicializar o provider
      if (type === NotificationType.EMAIL) {
        (emailProvider as any).initializeTransporter?.();
      } else if (type === NotificationType.WHATSAPP) {
        (whatsAppProvider as any).initializeClient?.();
      } else if (type === NotificationType.PUSH) {
        (pushProvider as any).initializeFirebase?.();
      }

      return provider.isConfigured();
    } catch (error) {
      console.error(`Erro ao reconfigurar provider ${type}:`, error);
      return false;
    }
  }
}

export const notificationProviderService = new NotificationProviderService();