import { PrismaClient } from '@prisma/client';
import { CampaignService } from './campaign.service';
import { ClientSegmentService } from './client-segment.service';
import {
  CampaignType,
  CampaignStatus,
  CreateCampaignDto,
  SegmentationCriteria
} from '../types/campaign.types';

const prisma = new PrismaClient();

export interface InactiveClient {
  id: string;
  name: string;
  email: string;
  phone?: string;
  lastBookingDate?: Date;
  daysSinceLastBooking: number;
  totalBookings: number;
  totalSpent: number;
  averageBookingValue: number;
  preferredServices: string[];
  riskScore: number; // 0-100, onde 100 é maior risco de churn
}

export interface ReactivationCampaignConfig {
  name: string;
  description?: string;
  tenantId: string;
  templateId?: string;
  inactivityThreshold: number; // dias
  targetSegments?: string[];
  personalizedOffers: boolean;
  discountPercentage?: number;
  validityDays?: number;
}

export interface ReactivationMetrics {
  totalInactiveClients: number;
  campaignsSent: number;
  reactivatedClients: number;
  reactivationRate: number;
  averageDaysToReactivation: number;
  revenueFromReactivation: number;
  costPerReactivation: number;
  roi: number;
}

export class ClientReactivationService {
  private campaignService: CampaignService;
  private segmentService: ClientSegmentService;

  constructor() {
    this.campaignService = new CampaignService();
    this.segmentService = new ClientSegmentService();
  }

  // Detectar clientes inativos
  async detectInactiveClients(tenantId: string, inactivityThreshold: number = 90): Promise<InactiveClient[]> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - inactivityThreshold);

    const users = await prisma.user.findMany({
      where: {
        tenantId,
        isActive: true,
        OR: [
          {
            bookings: {
              none: {
                createdAt: {
                  gte: cutoffDate,
                },
              },
            },
          },
          {
            bookings: {
              every: {
                createdAt: {
                  lt: cutoffDate,
                },
              },
            },
          },
        ],
      },
      include: {
        bookings: {
          orderBy: {
            createdAt: 'desc',
          },
          include: {
            service: true,
          },
        },
      },
    });

    const inactiveClients: InactiveClient[] = users.map(user => {
      const lastBooking = user.bookings[0];
      const totalSpent = user.bookings.reduce((sum, booking) => sum + booking.price, 0);
      const averageBookingValue = user.bookings.length > 0 ? totalSpent / user.bookings.length : 0;
      
      // Calcular dias desde o último agendamento
      const daysSinceLastBooking = lastBooking 
        ? Math.floor((new Date().getTime() - lastBooking.createdAt.getTime()) / (1000 * 60 * 60 * 24))
        : Infinity;

      // Calcular serviços preferidos
      const serviceCount: { [key: string]: number } = {};
      user.bookings.forEach(booking => {
        const serviceName = booking.service.name;
        serviceCount[serviceName] = (serviceCount[serviceName] || 0) + 1;
      });
      
      const preferredServices = Object.entries(serviceCount)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 3)
        .map(([service]) => service);

      // Calcular score de risco (0-100)
      const riskScore = this.calculateRiskScore(user.bookings, daysSinceLastBooking, totalSpent);

      return {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone || undefined,
        lastBookingDate: lastBooking?.createdAt,
        daysSinceLastBooking,
        totalBookings: user.bookings.length,
        totalSpent,
        averageBookingValue,
        preferredServices,
        riskScore,
      };
    });

    // Ordenar por score de risco (maior risco primeiro)
    return inactiveClients.sort((a, b) => b.riskScore - a.riskScore);
  }

  // Calcular score de risco de churn
  private calculateRiskScore(bookings: any[], daysSinceLastBooking: number, totalSpent: number): number {
    let score = 0;

    // Fator tempo (40% do score)
    if (daysSinceLastBooking > 180) score += 40;
    else if (daysSinceLastBooking > 120) score += 30;
    else if (daysSinceLastBooking > 90) score += 20;
    else if (daysSinceLastBooking > 60) score += 10;

    // Fator frequência (30% do score)
    const bookingFrequency = bookings.length;
    if (bookingFrequency === 1) score += 30;
    else if (bookingFrequency <= 3) score += 20;
    else if (bookingFrequency <= 5) score += 10;

    // Fator valor (20% do score)
    if (totalSpent < 100) score += 20;
    else if (totalSpent < 300) score += 15;
    else if (totalSpent < 500) score += 10;
    else if (totalSpent < 1000) score += 5;

    // Fator tendência (10% do score)
    if (bookings.length >= 2) {
      const recentBookings = bookings.slice(0, Math.min(3, bookings.length));
      const olderBookings = bookings.slice(3, Math.min(6, bookings.length));
      
      if (olderBookings.length > 0) {
        const recentAvg = recentBookings.reduce((sum, b) => sum + b.price, 0) / recentBookings.length;
        const olderAvg = olderBookings.reduce((sum, b) => sum + b.price, 0) / olderBookings.length;
        
        if (recentAvg < olderAvg * 0.8) score += 10; // Valor decrescente
      }
    }

    return Math.min(100, score);
  }

  // Criar campanha de reativação automática
  async createReactivationCampaign(config: ReactivationCampaignConfig): Promise<string> {
    // Criar segmento de clientes inativos
    const segmentCriteria: SegmentationCriteria = {
      lastBookingDays: config.inactivityThreshold,
      isActive: true,
    };

    const segment = await this.segmentService.createSegment({
      name: `Clientes Inativos - ${config.name}`,
      description: `Clientes sem agendamento há mais de ${config.inactivityThreshold} dias`,
      tenantId: config.tenantId,
      criteria: segmentCriteria,
    });

    // Criar campanha
    const campaignData: CreateCampaignDto = {
      name: config.name,
      description: config.description,
      type: CampaignType.REACTIVATION,
      tenantId: config.tenantId,
      templateId: config.templateId,
      targetAudience: {
        segments: [segment.id],
        criteria: segmentCriteria,
      },
    };

    const campaign = await this.campaignService.createCampaign(campaignData);

    // Ativar campanha
    await this.campaignService.updateCampaign(campaign.id, {
      status: CampaignStatus.ACTIVE,
    });

    return campaign.id;
  }

  // Executar campanha de reativação com personalização
  async executePersonalizedReactivation(
    tenantId: string,
    campaignId: string,
    config: ReactivationCampaignConfig
  ): Promise<void> {
    const inactiveClients = await this.detectInactiveClients(tenantId, config.inactivityThreshold);

    for (const client of inactiveClients) {
      // Personalizar oferta baseada no perfil do cliente
      const personalizedOffer = this.generatePersonalizedOffer(client, config);
      
      // Aqui integraria com o serviço de notificações para enviar mensagem personalizada
      console.log(`Enviando oferta personalizada para ${client.name}:`, personalizedOffer);
    }
  }

  // Gerar oferta personalizada
  private generatePersonalizedOffer(client: InactiveClient, config: ReactivationCampaignConfig) {
    let discount = config.discountPercentage || 15;
    let message = '';

    // Ajustar desconto baseado no perfil do cliente
    if (client.totalSpent > 1000) {
      discount = Math.max(discount, 20); // Clientes VIP recebem desconto maior
      message = `Olá ${client.name}! Sentimos sua falta. Como cliente especial, temos uma oferta exclusiva de ${discount}% de desconto.`;
    } else if (client.riskScore > 70) {
      discount = Math.max(discount, 25); // Clientes com alto risco recebem desconto maior
      message = `${client.name}, que tal voltar? Temos uma oferta especial de ${discount}% de desconto só para você!`;
    } else {
      message = `Oi ${client.name}! Preparamos uma oferta especial de ${discount}% de desconto para seu retorno.`;
    }

    // Mencionar serviços preferidos
    if (client.preferredServices.length > 0) {
      message += ` Que tal agendar um ${client.preferredServices[0]}?`;
    }

    return {
      clientId: client.id,
      discount,
      message,
      validityDays: config.validityDays || 30,
      preferredServices: client.preferredServices,
    };
  }

  // Analisar efetividade das campanhas de reativação
  async analyzeReactivationEffectiveness(tenantId: string, campaignId?: string): Promise<ReactivationMetrics> {
    const whereClause: any = {
      tenantId,
      type: CampaignType.REACTIVATION,
    };

    if (campaignId) {
      whereClause.id = campaignId;
    }

    const campaigns = await prisma.campaign.findMany({
      where: whereClause,
      include: {
        executions: {
          include: {
            targets: {
              include: {
                user: {
                  include: {
                    bookings: {
                      where: {
                        createdAt: {
                          gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000), // Últimos 90 dias
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    });

    let totalInactiveClients = 0;
    let campaignsSent = 0;
    let reactivatedClients = 0;
    let revenueFromReactivation = 0;
    let totalDaysToReactivation = 0;
    let reactivationCount = 0;

    campaigns.forEach(campaign => {
      campaign.executions.forEach(execution => {
        totalInactiveClients += execution.totalTargets;
        campaignsSent += execution.successCount;

        execution.targets.forEach(target => {
          if (target.user.bookings.length > 0) {
            reactivatedClients++;
            reactivationCount++;
            
            // Calcular receita da reativação
            const reactivationRevenue = target.user.bookings.reduce(
              (sum, booking) => sum + booking.price,
              0
            );
            revenueFromReactivation += reactivationRevenue;

            // Calcular dias para reativação
            if (target.sentAt && target.user.bookings[0]) {
              const daysToReactivation = Math.floor(
                (target.user.bookings[0].createdAt.getTime() - target.sentAt.getTime()) /
                (1000 * 60 * 60 * 24)
              );
              totalDaysToReactivation += daysToReactivation;
            }
          }
        });
      });
    });

    const reactivationRate = campaignsSent > 0 ? (reactivatedClients / campaignsSent) * 100 : 0;
    const averageDaysToReactivation = reactivationCount > 0 ? totalDaysToReactivation / reactivationCount : 0;
    const costPerReactivation = reactivatedClients > 0 ? 50 / reactivatedClients : 0; // Custo estimado
    const roi = costPerReactivation > 0 ? ((revenueFromReactivation - (reactivatedClients * 50)) / (reactivatedClients * 50)) * 100 : 0;

    return {
      totalInactiveClients,
      campaignsSent,
      reactivatedClients,
      reactivationRate,
      averageDaysToReactivation,
      revenueFromReactivation,
      costPerReactivation,
      roi,
    };
  }

  // Sugerir próximas ações para reativação
  async suggestReactivationActions(tenantId: string): Promise<string[]> {
    const inactiveClients = await this.detectInactiveClients(tenantId);
    const suggestions: string[] = [];

    const highRiskClients = inactiveClients.filter(c => c.riskScore > 70);
    const mediumRiskClients = inactiveClients.filter(c => c.riskScore >= 40 && c.riskScore <= 70);
    const lowRiskClients = inactiveClients.filter(c => c.riskScore < 40);

    if (highRiskClients.length > 0) {
      suggestions.push(
        `Criar campanha urgente para ${highRiskClients.length} clientes de alto risco com desconto de 25-30%`
      );
    }

    if (mediumRiskClients.length > 0) {
      suggestions.push(
        `Enviar lembretes personalizados para ${mediumRiskClients.length} clientes de risco médio`
      );
    }

    if (lowRiskClients.length > 0) {
      suggestions.push(
        `Criar campanha informativa para ${lowRiskClients.length} clientes de baixo risco`
      );
    }

    // Analisar padrões sazonais
    const currentMonth = new Date().getMonth();
    if ([11, 0, 1].includes(currentMonth)) { // Dezembro, Janeiro, Fevereiro
      suggestions.push('Criar campanha de "Novo Ano, Novo Visual" com foco em renovação');
    } else if ([5, 6, 7].includes(currentMonth)) { // Junho, Julho, Agosto
      suggestions.push('Aproveitar o inverno para campanhas de cuidados especiais');
    }

    return suggestions;
  }

  // Agendar campanhas automáticas de reativação
  async scheduleAutomaticReactivation(tenantId: string): Promise<void> {
    // Implementar lógica de agendamento automático
    // Por exemplo, executar semanalmente para detectar novos clientes inativos
    
    const configs = [
      {
        name: 'Reativação 60 dias',
        description: 'Campanha para clientes inativos há 60 dias',
        tenantId,
        inactivityThreshold: 60,
        personalizedOffers: true,
        discountPercentage: 15,
        validityDays: 30,
      },
      {
        name: 'Reativação 90 dias',
        description: 'Campanha para clientes inativos há 90 dias',
        tenantId,
        inactivityThreshold: 90,
        personalizedOffers: true,
        discountPercentage: 20,
        validityDays: 30,
      },
      {
        name: 'Reativação 180 dias',
        description: 'Campanha urgente para clientes inativos há 180 dias',
        tenantId,
        inactivityThreshold: 180,
        personalizedOffers: true,
        discountPercentage: 25,
        validityDays: 45,
      },
    ];

    for (const config of configs) {
      try {
        await this.createReactivationCampaign(config);
        console.log(`Campanha automática criada: ${config.name}`);
      } catch (error) {
        console.error(`Erro ao criar campanha ${config.name}:`, error);
      }
    }
  }
}