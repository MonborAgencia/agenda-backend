import { PrismaClient } from '@prisma/client';
import { 
  CreateScheduleRequest, 
  UpdateScheduleRequest, 
  ScheduleResponse,
  CreateScheduleExceptionRequest,
  UpdateScheduleExceptionRequest,
  ScheduleExceptionResponse,
  WeeklyScheduleRequest,
  ScheduleConflict,
  AvailabilitySlot,
  DayAvailability,
  AgendaDay,
  AgendaWeek,
  AgendaMonth,
  AgendaBooking,
  SlotGenerationRequest,
  AvailableSlot,
  SlotReservationRequest,
  SlotReservation
} from '../types/schedule.types';
import { redisClient, CACHE_KEYS, CACHE_TTL } from '../config/redis';
import { cacheService } from './cache.service';
import { cacheInvalidationService } from './cache-invalidation.service';

export class ScheduleService {
  constructor(private readonly prisma: PrismaClient) {}
  /**
   * Criar um novo horário de trabalho
   */
  async createSchedule(data: CreateScheduleRequest, tenantId: string): Promise<ScheduleResponse> {
    // Verificar se o profissional existe e pertence ao tenant
    const professional = await this.prisma.professional.findFirst({
      where: {
        id: data.professionalId,
        tenantId: tenantId
      }
    });

    if (!professional) {
      throw new Error('Profissional não encontrado ou não pertence ao tenant');
    }

    // Validar horários
    const conflicts = await this.validateScheduleTime(data);
    if (conflicts.length > 0) {
      throw new Error(conflicts[0].message);
    }

    // Verificar se já existe horário para este dia da semana
    const existingSchedule = await this.prisma.schedule.findFirst({
      where: {
        professionalId: data.professionalId,
        dayOfWeek: data.dayOfWeek
      }
    });

    if (existingSchedule) {
      throw new Error('Já existe um horário configurado para este dia da semana');
    }

    const schedule = await this.prisma.schedule.create({
      data,
      include: {
        professional: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true
              }
            }
          }
        },
        exceptions: true
      }
    });

    // Invalidate cache after creating schedule
    await cacheInvalidationService.invalidate('schedule', data.professionalId, tenantId);

    return schedule;
  }

  /**
   * Buscar horários de um profissional
   */
  async getSchedulesByProfessional(professionalId: string, tenantId: string): Promise<ScheduleResponse[]> {
    // Try to get from cache first
    const cacheKey = CACHE_KEYS.PROFESSIONAL_SCHEDULE(professionalId);
    const cached = await cacheService.get<ScheduleResponse[]>(cacheKey, {
      prefix: `tenant:${tenantId}`,
      ttl: CACHE_TTL.PROFESSIONAL_SCHEDULE
    });

    if (cached) {
      return cached;
    }

    // Verificar se o profissional pertence ao tenant
    const professional = await this.prisma.professional.findFirst({
      where: {
        id: professionalId,
        tenantId: tenantId
      }
    });

    if (!professional) {
      throw new Error('Profissional não encontrado ou não pertence ao tenant');
    }

    const schedules = await this.prisma.schedule.findMany({
      where: {
        professionalId
      },
      include: {
        professional: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true
              }
            }
          }
        },
        exceptions: {
          orderBy: {
            date: 'asc'
          }
        }
      },
      orderBy: {
        dayOfWeek: 'asc'
      }
    });

    // Cache the result
    await cacheService.set(cacheKey, schedules, {
      prefix: `tenant:${tenantId}`,
      ttl: CACHE_TTL.PROFESSIONAL_SCHEDULE
    });

    return schedules;
  }

  /**
   * Atualizar horário
   */
  async updateSchedule(id: string, data: UpdateScheduleRequest, tenantId: string): Promise<ScheduleResponse> {
    // Verificar se o horário existe e pertence ao tenant
    const existingSchedule = await this.prisma.schedule.findFirst({
      where: {
        id
      },
      include: {
        professional: true
      }
    });

    if (!existingSchedule || existingSchedule.professional.tenantId !== tenantId) {
      throw new Error('Horário não encontrado');
    }

    // Se está alterando horários, validar
    if (data.startTime || data.endTime || data.dayOfWeek !== undefined) {
      const updateData = {
        professionalId: existingSchedule.professionalId,
        dayOfWeek: data.dayOfWeek ?? existingSchedule.dayOfWeek,
        startTime: data.startTime ?? existingSchedule.startTime,
        endTime: data.endTime ?? existingSchedule.endTime
      };

      const conflicts = await this.validateScheduleTime(updateData, id);
      if (conflicts.length > 0) {
        throw new Error(conflicts[0].message);
      }
    }

    const schedule = await this.prisma.schedule.update({
      where: { id },
      data,
      include: {
        professional: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true
              }
            }
          }
        },
        exceptions: true
      }
    });

    return schedule;
  }

  /**
   * Deletar horário
   */
  async deleteSchedule(id: string, tenantId: string): Promise<void> {
    // Verificar se o horário existe e pertence ao tenant
    const schedule = await this.prisma.schedule.findFirst({
      where: {
        id
      },
      include: {
        professional: true
      }
    });

    if (!schedule || schedule.professional.tenantId !== tenantId) {
      throw new Error('Horário não encontrado');
    }

    // Verificar se há agendamentos futuros neste horário
    const futureBookings = await this.prisma.booking.findFirst({
      where: {
        professionalId: schedule.professionalId,
        startTime: {
          gte: new Date()
        },
        status: {
          in: ['SCHEDULED', 'CONFIRMED']
        }
      }
    });

    if (futureBookings) {
      throw new Error('Não é possível deletar um horário com agendamentos futuros');
    }

    await this.prisma.schedule.delete({
      where: { id }
    });
  }

  /**
   * Configurar horários da semana completa
   */
  async setWeeklySchedule(data: WeeklyScheduleRequest, tenantId: string): Promise<ScheduleResponse[]> {
    // Verificar se o profissional existe e pertence ao tenant
    const professional = await this.prisma.professional.findFirst({
      where: {
        id: data.professionalId,
        tenantId: tenantId
      }
    });

    if (!professional) {
      throw new Error('Profissional não encontrado ou não pertence ao tenant');
    }

    // Validar todos os horários
    for (const schedule of data.schedules) {
      const conflicts = await this.validateScheduleTime({
        professionalId: data.professionalId,
        dayOfWeek: schedule.dayOfWeek,
        startTime: schedule.startTime,
        endTime: schedule.endTime
      });

      if (conflicts.length > 0) {
        throw new Error(`Dia ${schedule.dayOfWeek}: ${conflicts[0].message}`);
      }
    }

    // Deletar horários existentes
    await this.prisma.schedule.deleteMany({
      where: {
        professionalId: data.professionalId
      }
    });

    // Criar novos horários
    const schedules = await Promise.all(
      data.schedules
        .filter(s => s.isActive)
        .map(schedule => 
          this.prisma.schedule.create({
            data: {
              professionalId: data.professionalId,
              dayOfWeek: schedule.dayOfWeek,
              startTime: schedule.startTime,
              endTime: schedule.endTime,
              isActive: schedule.isActive
            },
            include: {
              professional: {
                include: {
                  user: {
                    select: {
                      id: true,
                      name: true,
                      email: true
                    }
                  }
                }
              },
              exceptions: true
            }
          })
        )
    );

    return schedules;
  }

  /**
   * Criar exceção de horário
   */
  async createScheduleException(data: CreateScheduleExceptionRequest): Promise<ScheduleExceptionResponse> {
    // Verificar se o horário existe
    const schedule = await this.prisma.schedule.findUnique({
      where: { id: data.scheduleId }
    });

    if (!schedule) {
      throw new Error('Horário não encontrado');
    }

    // Validar data
    const exceptionDate = new Date(data.date);
    if (exceptionDate < new Date()) {
      throw new Error('Não é possível criar exceção para datas passadas');
    }

    // Verificar se já existe exceção para esta data
    const existingException = await this.prisma.scheduleException.findFirst({
      where: {
        scheduleId: data.scheduleId,
        date: exceptionDate
      }
    });

    if (existingException) {
      throw new Error('Já existe uma exceção para esta data');
    }

    // Validar horários customizados se fornecidos
    if (!data.isBlocked && data.startTime && data.endTime) {
      if (data.startTime >= data.endTime) {
        throw new Error('Horário de início deve ser anterior ao horário de fim');
      }
    }

    const exception = await this.prisma.scheduleException.create({
      data: {
        scheduleId: data.scheduleId,
        date: exceptionDate,
        isBlocked: data.isBlocked,
        startTime: data.startTime,
        endTime: data.endTime,
        reason: data.reason
      }
    });

    return exception;
  }

  /**
   * Atualizar exceção de horário
   */
  async updateScheduleException(id: string, data: UpdateScheduleExceptionRequest): Promise<ScheduleExceptionResponse> {
    const exception = await this.prisma.scheduleException.findUnique({
      where: { id }
    });

    if (!exception) {
      throw new Error('Exceção não encontrada');
    }

    // Validar horários customizados se fornecidos
    if (!data.isBlocked && data.startTime && data.endTime) {
      if (data.startTime >= data.endTime) {
        throw new Error('Horário de início deve ser anterior ao horário de fim');
      }
    }

    const updatedException = await this.prisma.scheduleException.update({
      where: { id },
      data
    });

    return updatedException;
  }

  /**
   * Deletar exceção de horário
   */
  async deleteScheduleException(id: string): Promise<void> {
    const exception = await this.prisma.scheduleException.findUnique({
      where: { id }
    });

    if (!exception) {
      throw new Error('Exceção não encontrada');
    }

    await this.prisma.scheduleException.delete({
      where: { id }
    });
  }

  /**
   * Validar conflitos de horário
   */
  private async validateScheduleTime(
    data: CreateScheduleRequest, 
    excludeScheduleId?: string
  ): Promise<ScheduleConflict[]> {
    const conflicts: ScheduleConflict[] = [];

    // Validar formato de horário
    if (data.startTime >= data.endTime) {
      conflicts.push({
        type: 'INVALID_TIME',
        message: 'Horário de início deve ser anterior ao horário de fim'
      });
      return conflicts;
    }

    // Validar dia da semana
    if (data.dayOfWeek < 0 || data.dayOfWeek > 6) {
      conflicts.push({
        type: 'INVALID_TIME',
        message: 'Dia da semana deve estar entre 0 (domingo) e 6 (sábado)'
      });
      return conflicts;
    }

    // Verificar sobreposição com outros horários do mesmo profissional
    const existingSchedules = await this.prisma.schedule.findMany({
      where: {
        professionalId: data.professionalId,
        dayOfWeek: data.dayOfWeek,
        ...(excludeScheduleId && { id: { not: excludeScheduleId } })
      }
    });

    for (const existing of existingSchedules) {
      // Verificar sobreposição de horários
      if (
        (data.startTime >= existing.startTime && data.startTime < existing.endTime) ||
        (data.endTime > existing.startTime && data.endTime <= existing.endTime) ||
        (data.startTime <= existing.startTime && data.endTime >= existing.endTime)
      ) {
        conflicts.push({
          type: 'OVERLAP',
          message: `Horário conflita com horário existente: ${existing.startTime} - ${existing.endTime}`,
          conflictingSchedule: existing as any
        });
      }
    }

    return conflicts;
  }

  /**
   * Calcular disponibilidade para um dia específico
   */
  async getDayAvailability(
    professionalId: string, 
    date: string, 
    serviceDuration: number = 60,
    tenantId: string
  ): Promise<DayAvailability> {
    // Verificar se o profissional pertence ao tenant
    const professional = await this.prisma.professional.findFirst({
      where: {
        id: professionalId,
        tenantId: tenantId
      }
    });

    if (!professional) {
      throw new Error('Profissional não encontrado ou não pertence ao tenant');
    }

    const targetDate = new Date(date);
    const dayOfWeek = targetDate.getDay();

    // Buscar horário do dia da semana
    const schedule = await this.prisma.schedule.findFirst({
      where: {
        professionalId,
        dayOfWeek,
        isActive: true
      },
      include: {
        exceptions: {
          where: {
            date: targetDate
          }
        }
      }
    });

    if (!schedule) {
      return {
        date,
        dayOfWeek,
        slots: [],
        totalSlots: 0,
        availableSlots: 0
      };
    }

    // Verificar exceções
    const exception = schedule.exceptions[0];
    let workStartTime = schedule.startTime;
    let workEndTime = schedule.endTime;

    if (exception) {
      if (exception.isBlocked) {
        return {
          date,
          dayOfWeek,
          slots: [],
          totalSlots: 0,
          availableSlots: 0
        };
      }

      if (exception.startTime && exception.endTime) {
        workStartTime = exception.startTime;
        workEndTime = exception.endTime;
      }
    }

    // Buscar agendamentos existentes
    const existingBookings = await this.prisma.booking.findMany({
      where: {
        professionalId,
        startTime: {
          gte: new Date(`${date}T00:00:00`),
          lt: new Date(`${date}T23:59:59`)
        },
        status: {
          in: ['SCHEDULED', 'CONFIRMED']
        }
      }
    });

    // Gerar slots de tempo
    const slots = this.generateTimeSlots(
      workStartTime, 
      workEndTime, 
      serviceDuration, 
      existingBookings,
      date
    );

    return {
      date,
      dayOfWeek,
      slots,
      totalSlots: slots.length,
      availableSlots: slots.filter(slot => slot.isAvailable).length
    };
  }

  /**
   * Gerar slots de tempo disponíveis
   */
  private generateTimeSlots(
    startTime: string, 
    endTime: string, 
    duration: number, 
    existingBookings: any[],
    date: string
  ): AvailabilitySlot[] {
    const slots: AvailabilitySlot[] = [];
    
    const [startHour, startMinute] = startTime.split(':').map(Number);
    const [endHour, endMinute] = endTime.split(':').map(Number);
    
    const startMinutes = startHour * 60 + startMinute;
    const endMinutes = endHour * 60 + endMinute;
    
    for (let currentMinutes = startMinutes; currentMinutes + duration <= endMinutes; currentMinutes += duration) {
      const slotStartHour = Math.floor(currentMinutes / 60);
      const slotStartMinute = currentMinutes % 60;
      const slotEndMinutes = currentMinutes + duration;
      const slotEndHour = Math.floor(slotEndMinutes / 60);
      const slotEndMinuteValue = slotEndMinutes % 60;
      
      const slotStartTime = `${slotStartHour.toString().padStart(2, '0')}:${slotStartMinute.toString().padStart(2, '0')}`;
      const slotEndTime = `${slotEndHour.toString().padStart(2, '0')}:${slotEndMinuteValue.toString().padStart(2, '0')}`;
      
      // Verificar se há conflito com agendamentos existentes
      const slotStart = new Date(`${date}T${slotStartTime}:00`);
      const slotEnd = new Date(`${date}T${slotEndTime}:00`);
      
      const hasConflict = existingBookings.some(booking => {
        const bookingStart = new Date(booking.startTime);
        const bookingEnd = new Date(booking.endTime);
        
        return (
          (slotStart >= bookingStart && slotStart < bookingEnd) ||
          (slotEnd > bookingStart && slotEnd <= bookingEnd) ||
          (slotStart <= bookingStart && slotEnd >= bookingEnd)
        );
      });
      
      slots.push({
        startTime: slotStartTime,
        endTime: slotEndTime,
        duration,
        isAvailable: !hasConflict,
        reason: hasConflict ? 'Horário já agendado' : undefined
      });
    }
    
    return slots;
  }

  /**
   * Visualização de agenda diária
   */
  async getDailyAgenda(
    date: string,
    professionalId?: string,
    serviceId?: string,
    tenantId?: string
  ): Promise<AgendaDay> {
    const targetDate = new Date(date);
    const dayOfWeek = targetDate.getDay();

    // Build where clause for bookings
    const whereClause: any = {
      startTime: {
        gte: new Date(`${date}T00:00:00`),
        lt: new Date(`${date}T23:59:59`)
      },
      status: {
        in: ['SCHEDULED', 'CONFIRMED', 'COMPLETED']
      }
    };

    if (tenantId) {
      whereClause.tenantId = tenantId;
    }

    if (professionalId) {
      whereClause.professionalId = professionalId;
    }

    if (serviceId) {
      whereClause.serviceId = serviceId;
    }

    // Get bookings for the day
    const bookings = await this.prisma.booking.findMany({
      where: whereClause,
      include: {
        client: {
          select: {
            name: true,
            phone: true
          }
        },
        service: {
          select: {
            name: true
          }
        }
      },
      orderBy: {
        startTime: 'asc'
      }
    });

    // Transform bookings
    const agendaBookings: AgendaBooking[] = bookings.map(booking => ({
      id: booking.id,
      clientName: booking.client.name,
      clientPhone: booking.client.phone || undefined,
      serviceName: booking.service.name,
      startTime: booking.startTime,
      endTime: booking.endTime,
      status: booking.status,
      price: booking.price,
      notes: booking.notes || undefined
    }));

    // Calculate metrics
    const totalRevenue = bookings.reduce((sum, booking) => sum + booking.price, 0);
    
    // Calculate occupancy rate (simplified - based on 8-hour workday)
    const totalBookingMinutes = bookings.reduce((sum, booking) => {
      const duration = (booking.endTime.getTime() - booking.startTime.getTime()) / (1000 * 60);
      return sum + duration;
    }, 0);
    
    const workDayMinutes = 8 * 60; // 8 hours
    const occupancyRate = Math.min((totalBookingMinutes / workDayMinutes) * 100, 100);

    return {
      date,
      dayOfWeek,
      bookings: agendaBookings,
      totalBookings: bookings.length,
      totalRevenue,
      occupancyRate: Math.round(occupancyRate * 100) / 100
    };
  }

  /**
   * Visualização de agenda semanal
   */
  async getWeeklyAgenda(
    startDate: string,
    professionalId?: string,
    serviceId?: string,
    tenantId?: string
  ): Promise<AgendaWeek> {
    const start = new Date(startDate);
    const end = new Date(start);
    end.setDate(start.getDate() + 6);

    const endDate = end.toISOString().split('T')[0];

    // Get daily agendas for each day of the week
    const days: AgendaDay[] = [];
    const currentDate = new Date(start);

    for (let i = 0; i < 7; i++) {
      const dateStr = currentDate.toISOString().split('T')[0];
      const dayAgenda = await this.getDailyAgenda(dateStr, professionalId, serviceId, tenantId);
      days.push(dayAgenda);
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // Calculate week totals
    const totalBookings = days.reduce((sum, day) => sum + day.totalBookings, 0);
    const totalRevenue = days.reduce((sum, day) => sum + day.totalRevenue, 0);
    const averageOccupancyRate = days.reduce((sum, day) => sum + day.occupancyRate, 0) / 7;

    return {
      startDate,
      endDate,
      days,
      totalBookings,
      totalRevenue,
      averageOccupancyRate: Math.round(averageOccupancyRate * 100) / 100
    };
  }

  /**
   * Visualização de agenda mensal
   */
  async getMonthlyAgenda(
    year: number,
    month: number,
    professionalId?: string,
    serviceId?: string,
    tenantId?: string
  ): Promise<AgendaMonth> {
    // Get first day of month and calculate weeks
    const firstDay = new Date(year, month - 1, 1);
    const lastDay = new Date(year, month, 0);
    
    // Find the Monday of the week containing the first day
    const startOfFirstWeek = new Date(firstDay);
    const dayOfWeek = firstDay.getDay();
    const daysToSubtract = dayOfWeek === 0 ? 6 : dayOfWeek - 1; // Monday = 0
    startOfFirstWeek.setDate(firstDay.getDate() - daysToSubtract);

    const weeks: AgendaWeek[] = [];
    const currentWeekStart = new Date(startOfFirstWeek);

    // Generate weeks until we cover the entire month
    while (currentWeekStart <= lastDay) {
      const weekStartStr = currentWeekStart.toISOString().split('T')[0];
      const weekAgenda = await this.getWeeklyAgenda(weekStartStr, professionalId, serviceId, tenantId);
      weeks.push(weekAgenda);
      
      currentWeekStart.setDate(currentWeekStart.getDate() + 7);
    }

    // Calculate month totals
    const totalBookings = weeks.reduce((sum, week) => sum + week.totalBookings, 0);
    const totalRevenue = weeks.reduce((sum, week) => sum + week.totalRevenue, 0);
    const averageOccupancyRate = weeks.reduce((sum, week) => sum + week.averageOccupancyRate, 0) / weeks.length;

    return {
      year,
      month,
      weeks,
      totalBookings,
      totalRevenue,
      averageOccupancyRate: Math.round(averageOccupancyRate * 100) / 100
    };
  }

  /**
   * Gerar slots disponíveis para um período
   */
  async generateAvailableSlots(
    request: SlotGenerationRequest,
    tenantId: string
  ): Promise<AvailableSlot[]> {
    const { professionalId, serviceId, startDate, endDate } = request;

    // Verificar se o profissional e serviço existem e pertencem ao tenant
    const professional = await this.prisma.professional.findFirst({
      where: {
        id: professionalId,
        tenantId: tenantId
      }
    });

    if (!professional) {
      throw new Error('Profissional não encontrado ou não pertence ao tenant');
    }

    const service = await this.prisma.service.findFirst({
      where: {
        id: serviceId,
        tenantId: tenantId,
        professionalId: professionalId
      }
    });

    if (!service) {
      throw new Error('Serviço não encontrado ou não pertence ao profissional');
    }

    // Verificar cache primeiro
    const cacheKey = CACHE_KEYS.AVAILABLE_SLOTS(professionalId, `${startDate}_${endDate}_${serviceId}`);
    
    try {
      if (redisClient.isReady) {
        const cachedSlots = await redisClient.get(cacheKey);
        if (cachedSlots) {
          return JSON.parse(cachedSlots);
        }
      }
    } catch (error) {
      console.warn('Redis cache read error:', error);
    }

    const slots: AvailableSlot[] = [];
    const start = new Date(startDate);
    const end = new Date(endDate);
    const currentDate = new Date(start);

    while (currentDate <= end) {
      const dateStr = currentDate.toISOString().split('T')[0];
      const daySlots = await this.generateDaySlots(
        professionalId,
        serviceId,
        dateStr,
        service.duration,
        service.price
      );
      slots.push(...daySlots);
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // Cache os resultados
    try {
      if (redisClient.isReady) {
        await redisClient.setEx(cacheKey, CACHE_TTL.AVAILABLE_SLOTS, JSON.stringify(slots));
      }
    } catch (error) {
      console.warn('Redis cache write error:', error);
    }

    return slots;
  }

  /**
   * Gerar slots para um dia específico
   */
  private async generateDaySlots(
    professionalId: string,
    serviceId: string,
    date: string,
    serviceDuration: number,
    servicePrice: number
  ): Promise<AvailableSlot[]> {
    const targetDate = new Date(date);
    const dayOfWeek = targetDate.getDay();

    // Buscar horário do profissional para este dia
    const schedule = await this.prisma.schedule.findFirst({
      where: {
        professionalId,
        dayOfWeek,
        isActive: true
      },
      include: {
        exceptions: {
          where: {
            date: targetDate
          }
        }
      }
    });

    if (!schedule) {
      return [];
    }

    // Verificar exceções
    const exception = schedule.exceptions[0];
    let workStartTime = schedule.startTime;
    let workEndTime = schedule.endTime;

    if (exception) {
      if (exception.isBlocked) {
        return [];
      }

      if (exception.startTime && exception.endTime) {
        workStartTime = exception.startTime;
        workEndTime = exception.endTime;
      }
    }

    // Buscar agendamentos existentes
    const existingBookings = await this.prisma.booking.findMany({
      where: {
        professionalId,
        startTime: {
          gte: new Date(`${date}T00:00:00`),
          lt: new Date(`${date}T23:59:59`)
        },
        status: {
          in: ['SCHEDULED', 'CONFIRMED']
        }
      }
    });

    // Gerar slots
    const slots: AvailableSlot[] = [];
    const [startHour, startMinute] = workStartTime.split(':').map(Number);
    const [endHour, endMinute] = workEndTime.split(':').map(Number);
    
    const startMinutes = startHour * 60 + startMinute;
    const endMinutes = endHour * 60 + endMinute;
    
    for (let currentMinutes = startMinutes; currentMinutes + serviceDuration <= endMinutes; currentMinutes += serviceDuration) {
      const slotStartHour = Math.floor(currentMinutes / 60);
      const slotStartMinute = currentMinutes % 60;
      const slotEndMinutes = currentMinutes + serviceDuration;
      const slotEndHour = Math.floor(slotEndMinutes / 60);
      const slotEndMinuteValue = slotEndMinutes % 60;
      
      const slotStartTime = `${slotStartHour.toString().padStart(2, '0')}:${slotStartMinute.toString().padStart(2, '0')}`;
      const slotEndTime = `${slotEndHour.toString().padStart(2, '0')}:${slotEndMinuteValue.toString().padStart(2, '0')}`;
      
      const slotStart = new Date(`${date}T${slotStartTime}:00`);
      const slotEnd = new Date(`${date}T${slotEndTime}:00`);
      
      // Verificar conflito com agendamentos existentes
      const hasConflict = existingBookings.some(booking => {
        const bookingStart = new Date(booking.startTime);
        const bookingEnd = new Date(booking.endTime);
        
        return (
          (slotStart >= bookingStart && slotStart < bookingEnd) ||
          (slotEnd > bookingStart && slotEnd <= bookingEnd) ||
          (slotStart <= bookingStart && slotEnd >= bookingEnd)
        );
      });

      // Verificar se está reservado temporariamente
      const slotId = `${professionalId}_${serviceId}_${slotStart.getTime()}`;
      const isTemporarilyReserved = await this.isSlotTemporarilyReserved(slotId);
      
      slots.push({
        id: slotId,
        professionalId,
        serviceId,
        startTime: slotStart,
        endTime: slotEnd,
        duration: serviceDuration,
        isAvailable: !hasConflict && !isTemporarilyReserved,
        isTemporarilyReserved,
        price: servicePrice
      });
    }
    
    return slots;
  }

  /**
   * Reservar slot temporariamente
   */
  async reserveSlotTemporarily(
    request: SlotReservationRequest
  ): Promise<SlotReservation> {
    const { slotId, clientId, reservationMinutes = 15 } = request;

    // Verificar se o slot já está reservado
    const isReserved = await this.isSlotTemporarilyReserved(slotId);
    if (isReserved) {
      throw new Error('Slot já está reservado temporariamente');
    }

    const reservedAt = new Date();
    const expiresAt = new Date(reservedAt.getTime() + reservationMinutes * 60 * 1000);

    const reservation: SlotReservation = {
      slotId,
      clientId,
      reservedAt,
      expiresAt
    };

    // Salvar reserva no Redis
    try {
      if (redisClient.isReady) {
        const cacheKey = CACHE_KEYS.SLOT_RESERVATION(slotId);
        await redisClient.setEx(
          cacheKey, 
          reservationMinutes * 60, 
          JSON.stringify(reservation)
        );
      }
    } catch (error) {
      console.warn('Redis reservation error:', error);
      throw new Error('Erro ao reservar slot temporariamente');
    }

    return reservation;
  }

  /**
   * Liberar reserva temporária de slot
   */
  async releaseSlotReservation(slotId: string): Promise<void> {
    try {
      if (redisClient.isReady) {
        const cacheKey = CACHE_KEYS.SLOT_RESERVATION(slotId);
        await redisClient.del(cacheKey);
      }
    } catch (error) {
      console.warn('Redis release error:', error);
    }
  }

  /**
   * Verificar se slot está reservado temporariamente
   */
  private async isSlotTemporarilyReserved(slotId: string): Promise<boolean> {
    try {
      if (redisClient.isReady) {
        const cacheKey = CACHE_KEYS.SLOT_RESERVATION(slotId);
        const reservation = await redisClient.get(cacheKey);
        
        if (reservation) {
          const reservationData: SlotReservation = JSON.parse(reservation);
          const now = new Date();
          const expiresAt = new Date(reservationData.expiresAt);
          
          // Se a reserva expirou, remove do cache
          if (now > expiresAt) {
            await redisClient.del(cacheKey);
            return false;
          }
          
          return true;
        }
      }
    } catch (error) {
      console.warn('Redis check error:', error);
    }
    
    return false;
  }

  /**
   * Buscar reserva temporária de slot
   */
  async getSlotReservation(slotId: string): Promise<SlotReservation | null> {
    try {
      if (redisClient.isReady) {
        const cacheKey = CACHE_KEYS.SLOT_RESERVATION(slotId);
        const reservation = await redisClient.get(cacheKey);
        
        if (reservation) {
          const reservationData: SlotReservation = JSON.parse(reservation);
          const now = new Date();
          const expiresAt = new Date(reservationData.expiresAt);
          
          // Se a reserva expirou, remove do cache
          if (now > expiresAt) {
            await redisClient.del(cacheKey);
            return null;
          }
          
          return reservationData;
        }
      }
    } catch (error) {
      console.warn('Redis get reservation error:', error);
    }
    
    return null;
  }

  /**
   * Invalidar cache de slots disponíveis
   */
  async invalidateAvailableSlotsCache(professionalId: string): Promise<void> {
    try {
      if (redisClient.isReady) {
        // Buscar todas as chaves relacionadas ao profissional
        const pattern = `slots:available:${professionalId}:*`;
        const keys = await redisClient.keys(pattern);
        
        if (keys.length > 0) {
          await redisClient.del(keys);
        }
      }
    } catch (error) {
      console.warn('Redis cache invalidation error:', error);
    }
  }
}

const prisma = new PrismaClient();
export const scheduleService = new ScheduleService(prisma);