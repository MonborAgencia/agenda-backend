import { PrismaClient } from '@prisma/client';
import puppeteer from 'puppeteer';
import ExcelJS from 'exceljs';
import * as cron from 'node-cron';
import path from 'path';
import fs from 'fs/promises';
import { analyticsService } from './analytics.service';
import {
  ReportConfig,
  ReportData,
  AnalyticsFilters,
  DashboardMetrics
} from '../types/analytics.types';

const prisma = new PrismaClient();

export class ReportService {
  private scheduledJobs: Map<string, cron.ScheduledTask> = new Map();

  /**
   * Gera relatório em PDF
   */
  async generatePDFReport(filters: AnalyticsFilters, title: string): Promise<Buffer> {
    const metrics = await analyticsService.generateDashboardMetrics(filters);
    
    const reportData: ReportData = {
      title,
      generatedAt: new Date(),
      period: filters.dateRange,
      metrics
    };

    const html = this.generateHTMLReport(reportData);
    
    const browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    try {
      const page = await browser.newPage();
      await page.setContent(html, { waitUntil: 'networkidle0' });
      
      const pdfBuffer = await page.pdf({
        format: 'A4',
        printBackground: true,
        margin: {
          top: '20mm',
          right: '15mm',
          bottom: '20mm',
          left: '15mm'
        }
      });
      
      return pdfBuffer;
    } finally {
      await browser.close();
    }
  }

  /**
   * Gera relatório em Excel
   */
  async generateExcelReport(filters: AnalyticsFilters, title: string): Promise<Buffer> {
    const metrics = await analyticsService.generateDashboardMetrics(filters);
    
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Agenda Lotada 24h';
    workbook.created = new Date();

    // Aba de Resumo
    const summarySheet = workbook.addWorksheet('Resumo');
    this.createSummarySheet(summarySheet, metrics, title, filters.dateRange);

    // Aba de Ocupação
    const occupancySheet = workbook.addWorksheet('Ocupação');
    this.createOccupancySheet(occupancySheet, metrics.occupancy);

    // Aba de Faturamento
    const revenueSheet = workbook.addWorksheet('Faturamento');
    this.createRevenueSheet(revenueSheet, metrics.revenue, metrics.periodComparison);

    // Aba de Horários Rentáveis
    const hoursSheet = workbook.addWorksheet('Horários Rentáveis');
    this.createProfitableHoursSheet(hoursSheet, metrics.profitableHours);

    // Aba de Serviços
    const servicesSheet = workbook.addWorksheet('Serviços');
    this.createServicesSheet(servicesSheet, metrics.topServices);

    // Aba de Profissionais
    const professionalsSheet = workbook.addWorksheet('Profissionais');
    this.createProfessionalsSheet(professionalsSheet, metrics.professionalPerformance);

    const buffer = await workbook.xlsx.writeBuffer();
    return buffer as Buffer;
  }

  /**
   * Cria configuração de relatório automático
   */
  async createReportConfig(config: Omit<ReportConfig, 'id' | 'createdAt' | 'updatedAt'>): Promise<ReportConfig> {
    // Em uma implementação real, isso seria salvo no banco de dados
    // Por simplicidade, vamos simular com um objeto em memória
    const reportConfig: ReportConfig = {
      id: `report_${Date.now()}`,
      ...config,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    // Agendar o relatório
    if (config.isActive) {
      this.scheduleReport(reportConfig);
    }

    return reportConfig;
  }

  /**
   * Agenda relatório automático
   */
  private scheduleReport(config: ReportConfig): void {
    const cronExpression = this.getCronExpression(config.frequency);
    
    const task = cron.schedule(cronExpression, async () => {
      try {
        console.log(`Gerando relatório automático: ${config.name}`);
        
        let reportBuffer: Buffer;
        const title = `${config.name} - ${new Date().toLocaleDateString('pt-BR')}`;
        
        if (config.type === 'PDF') {
          reportBuffer = await this.generatePDFReport(config.filters, title);
        } else {
          reportBuffer = await this.generateExcelReport(config.filters, title);
        }

        // Salvar arquivo
        const fileName = `${config.name}_${Date.now()}.${config.type.toLowerCase()}`;
        const filePath = path.join(process.cwd(), 'reports', fileName);
        
        // Criar diretório se não existir
        await fs.mkdir(path.dirname(filePath), { recursive: true });
        await fs.writeFile(filePath, reportBuffer);

        console.log(`Relatório salvo: ${filePath}`);
        
        // Aqui você poderia enviar por email para os recipients
        // await this.sendReportByEmail(config.recipients, reportBuffer, fileName);
        
      } catch (error) {
        console.error(`Erro ao gerar relatório automático ${config.name}:`, error);
      }
    }, {
      scheduled: false
    });

    this.scheduledJobs.set(config.id, task);
    task.start();
  }

  /**
   * Para relatório agendado
   */
  stopScheduledReport(configId: string): void {
    const task = this.scheduledJobs.get(configId);
    if (task) {
      task.stop();
      this.scheduledJobs.delete(configId);
    }
  }

  /**
   * Gera HTML para o relatório PDF
   */
  private generateHTMLReport(data: ReportData): string {
    const { title, generatedAt, period, metrics } = data;
    
    return `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>${title}</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 20px;
                color: #333;
            }
            .header {
                text-align: center;
                border-bottom: 2px solid #007bff;
                padding-bottom: 20px;
                margin-bottom: 30px;
            }
            .header h1 {
                color: #007bff;
                margin: 0;
            }
            .period {
                color: #666;
                margin-top: 10px;
            }
            .metrics-grid {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 20px;
                margin-bottom: 30px;
            }
            .metric-card {
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 20px;
                background: #f8f9fa;
            }
            .metric-title {
                font-weight: bold;
                color: #007bff;
                margin-bottom: 15px;
                font-size: 18px;
            }
            .metric-value {
                font-size: 24px;
                font-weight: bold;
                color: #28a745;
                margin-bottom: 5px;
            }
            .metric-label {
                color: #666;
                font-size: 14px;
            }
            .table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 30px;
            }
            .table th,
            .table td {
                border: 1px solid #ddd;
                padding: 12px;
                text-align: left;
            }
            .table th {
                background-color: #007bff;
                color: white;
                font-weight: bold;
            }
            .table tr:nth-child(even) {
                background-color: #f8f9fa;
            }
            .section-title {
                color: #007bff;
                font-size: 20px;
                font-weight: bold;
                margin: 30px 0 15px 0;
                border-bottom: 1px solid #ddd;
                padding-bottom: 5px;
            }
            .footer {
                text-align: center;
                margin-top: 40px;
                padding-top: 20px;
                border-top: 1px solid #ddd;
                color: #666;
                font-size: 12px;
            }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>${title}</h1>
            <div class="period">
                Período: ${period.startDate.toLocaleDateString('pt-BR')} - ${period.endDate.toLocaleDateString('pt-BR')}
            </div>
            <div class="period">
                Gerado em: ${generatedAt.toLocaleDateString('pt-BR')} às ${generatedAt.toLocaleTimeString('pt-BR')}
            </div>
        </div>

        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-title">Taxa de Ocupação</div>
                <div class="metric-value">${metrics.occupancy.occupancyRate.toFixed(1)}%</div>
                <div class="metric-label">${metrics.occupancy.bookedSlots} de ${metrics.occupancy.totalSlots} slots</div>
            </div>
            
            <div class="metric-card">
                <div class="metric-title">Faturamento Total</div>
                <div class="metric-value">R$ ${metrics.revenue.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
                <div class="metric-label">${metrics.revenue.totalBookings} agendamentos</div>
            </div>
            
            <div class="metric-card">
                <div class="metric-title">Ticket Médio</div>
                <div class="metric-value">R$ ${metrics.revenue.averageBookingValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
                <div class="metric-label">Por agendamento</div>
            </div>
            
            <div class="metric-card">
                <div class="metric-title">Crescimento</div>
                <div class="metric-value" style="color: ${(metrics.periodComparison?.growthRate || 0) >= 0 ? '#28a745' : '#dc3545'}">
                    ${(metrics.periodComparison?.growthRate || 0) >= 0 ? '+' : ''}${(metrics.periodComparison?.growthRate || 0).toFixed(1)}%
                </div>
                <div class="metric-label">Em relação ao período anterior</div>
            </div>
        </div>

        <div class="section-title">Horários Mais Rentáveis</div>
        <table class="table">
            <thead>
                <tr>
                    <th>Horário</th>
                    <th>Agendamentos</th>
                    <th>Faturamento</th>
                    <th>Ticket Médio</th>
                    <th>Taxa de Ocupação</th>
                </tr>
            </thead>
            <tbody>
                ${metrics.profitableHours.slice(0, 10).map(hour => `
                    <tr>
                        <td>${hour.hour}:00</td>
                        <td>${hour.totalBookings}</td>
                        <td>R$ ${hour.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                        <td>R$ ${hour.averageRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                        <td>${hour.occupancyRate.toFixed(1)}%</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>

        <div class="section-title">Serviços Mais Populares</div>
        <table class="table">
            <thead>
                <tr>
                    <th>Ranking</th>
                    <th>Serviço</th>
                    <th>Agendamentos</th>
                    <th>Faturamento</th>
                    <th>Preço Médio</th>
                </tr>
            </thead>
            <tbody>
                ${metrics.topServices.slice(0, 10).map(service => `
                    <tr>
                        <td>${service.popularityRank}º</td>
                        <td>${service.serviceName}</td>
                        <td>${service.totalBookings}</td>
                        <td>R$ ${service.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                        <td>R$ ${service.averagePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>

        <div class="footer">
            Relatório gerado automaticamente pelo sistema Agenda Lotada 24h
        </div>
    </body>
    </html>
    `;
  }

  /**
   * Cria aba de resumo no Excel
   */
  private createSummarySheet(sheet: ExcelJS.Worksheet, metrics: DashboardMetrics, title: string, period: { startDate: Date; endDate: Date }): void {
    sheet.columns = [
      { header: 'Métrica', key: 'metric', width: 30 },
      { header: 'Valor', key: 'value', width: 20 }
    ];

    // Título
    sheet.addRow(['RELATÓRIO DE ANALYTICS', '']);
    sheet.addRow([title, '']);
    sheet.addRow([`Período: ${period.startDate.toLocaleDateString('pt-BR')} - ${period.endDate.toLocaleDateString('pt-BR')}`, '']);
    sheet.addRow(['', '']);

    // Métricas principais
    sheet.addRow(['OCUPAÇÃO', '']);
    sheet.addRow(['Taxa de Ocupação', `${metrics.occupancy.occupancyRate.toFixed(1)}%`]);
    sheet.addRow(['Slots Ocupados', metrics.occupancy.bookedSlots]);
    sheet.addRow(['Slots Totais', metrics.occupancy.totalSlots]);
    sheet.addRow(['', '']);

    sheet.addRow(['FATURAMENTO', '']);
    sheet.addRow(['Faturamento Total', `R$ ${metrics.revenue.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`]);
    sheet.addRow(['Faturamento Confirmado', `R$ ${metrics.revenue.confirmedRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`]);
    sheet.addRow(['Ticket Médio', `R$ ${metrics.revenue.averageBookingValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`]);
    sheet.addRow(['Total de Agendamentos', metrics.revenue.totalBookings]);

    // Estilizar cabeçalhos
    sheet.getRow(1).font = { bold: true, size: 16 };
    sheet.getRow(2).font = { bold: true, size: 14 };
  }

  /**
   * Cria aba de ocupação no Excel
   */
  private createOccupancySheet(sheet: ExcelJS.Worksheet, occupancy: any): void {
    sheet.columns = [
      { header: 'Métrica', key: 'metric', width: 25 },
      { header: 'Valor', key: 'value', width: 15 }
    ];

    sheet.addRow(['Taxa de Ocupação', `${occupancy.occupancyRate.toFixed(1)}%`]);
    sheet.addRow(['Slots Ocupados', occupancy.bookedSlots]);
    sheet.addRow(['Slots Disponíveis', occupancy.availableSlots]);
    sheet.addRow(['Total de Slots', occupancy.totalSlots]);
  }

  /**
   * Cria aba de faturamento no Excel
   */
  private createRevenueSheet(sheet: ExcelJS.Worksheet, revenue: any, comparison?: any): void {
    sheet.columns = [
      { header: 'Métrica', key: 'metric', width: 25 },
      { header: 'Valor Atual', key: 'current', width: 20 },
      { header: 'Valor Anterior', key: 'previous', width: 20 },
      { header: 'Crescimento', key: 'growth', width: 15 }
    ];

    sheet.addRow([
      'Faturamento Total',
      `R$ ${revenue.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
      comparison ? `R$ ${comparison.previous.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : '-',
      comparison ? `${comparison.growthRate >= 0 ? '+' : ''}${comparison.growthRate.toFixed(1)}%` : '-'
    ]);

    sheet.addRow([
      'Faturamento Confirmado',
      `R$ ${revenue.confirmedRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
      comparison ? `R$ ${comparison.previous.confirmedRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : '-',
      '-'
    ]);

    sheet.addRow([
      'Ticket Médio',
      `R$ ${revenue.averageBookingValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
      comparison ? `R$ ${comparison.previous.averageBookingValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : '-',
      '-'
    ]);
  }

  /**
   * Cria aba de horários rentáveis no Excel
   */
  private createProfitableHoursSheet(sheet: ExcelJS.Worksheet, hours: any[]): void {
    sheet.columns = [
      { header: 'Horário', key: 'hour', width: 10 },
      { header: 'Agendamentos', key: 'bookings', width: 15 },
      { header: 'Faturamento', key: 'revenue', width: 20 },
      { header: 'Ticket Médio', key: 'average', width: 20 },
      { header: 'Taxa de Ocupação', key: 'occupancy', width: 20 }
    ];

    hours.forEach(hour => {
      sheet.addRow([
        `${hour.hour}:00`,
        hour.totalBookings,
        `R$ ${hour.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
        `R$ ${hour.averageRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
        `${hour.occupancyRate.toFixed(1)}%`
      ]);
    });
  }

  /**
   * Cria aba de serviços no Excel
   */
  private createServicesSheet(sheet: ExcelJS.Worksheet, services: any[]): void {
    sheet.columns = [
      { header: 'Ranking', key: 'rank', width: 10 },
      { header: 'Serviço', key: 'name', width: 30 },
      { header: 'Agendamentos', key: 'bookings', width: 15 },
      { header: 'Faturamento', key: 'revenue', width: 20 },
      { header: 'Preço Médio', key: 'price', width: 20 }
    ];

    services.forEach(service => {
      sheet.addRow([
        `${service.popularityRank}º`,
        service.serviceName,
        service.totalBookings,
        `R$ ${service.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
        `R$ ${service.averagePrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
      ]);
    });
  }

  /**
   * Cria aba de profissionais no Excel
   */
  private createProfessionalsSheet(sheet: ExcelJS.Worksheet, professionals: any[]): void {
    sheet.columns = [
      { header: 'Profissional', key: 'name', width: 25 },
      { header: 'Agendamentos', key: 'bookings', width: 15 },
      { header: 'Faturamento', key: 'revenue', width: 20 },
      { header: 'Taxa de Ocupação', key: 'occupancy', width: 20 },
      { header: 'Taxa de No-Show', key: 'noshow', width: 20 },
      { header: 'Taxa de Cancelamento', key: 'cancellation', width: 20 }
    ];

    professionals.forEach(prof => {
      sheet.addRow([
        prof.professionalName,
        prof.totalBookings,
        `R$ ${prof.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
        `${prof.occupancyRate.toFixed(1)}%`,
        `${prof.noShowRate.toFixed(1)}%`,
        `${prof.cancellationRate.toFixed(1)}%`
      ]);
    });
  }

  /**
   * Converte frequência em expressão cron
   */
  private getCronExpression(frequency: 'DAILY' | 'WEEKLY' | 'MONTHLY'): string {
    switch (frequency) {
      case 'DAILY':
        return '0 8 * * *'; // Todo dia às 8h
      case 'WEEKLY':
        return '0 8 * * 1'; // Toda segunda-feira às 8h
      case 'MONTHLY':
        return '0 8 1 * *'; // Todo dia 1 do mês às 8h
      default:
        return '0 8 * * *';
    }
  }
}

export const reportService = new ReportService();