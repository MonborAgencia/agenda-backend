import { PrismaClient } from '@prisma/client';
import { 
  CreateBookingRequest, 
  UpdateBookingRequest,
  RescheduleBookingRequest,
  BookingFilters, 
  BookingResponse,
  BookingHistory,
  BookingMetrics,
  BookingValidationResult,
  CancellationPolicy,
  BookingStatus,
  PaymentStatus,
  BookingAction,
  AvailabilitySlot
} from '../types/booking.types';
import { cancellationPolicyService } from './cancellation-policy.service';
import { bookingHistoryService } from './booking-history.service';
import { cacheService } from './cache.service';
import { cacheInvalidationService } from './cache-invalidation.service';
import { CACHE_KEYS, CACHE_TTL } from '../config/redis';

const prisma = new PrismaClient();

export class BookingService {
  
  /**
   * Cria um novo agendamento com validação de disponibilidade
   */
  async createBooking(data: CreateBookingRequest, tenantId: string): Promise<BookingResponse> {
    // 1. Validar disponibilidade
    const validationResult = await this.validateBookingAvailability(data);
    if (!validationResult.isValid) {
      throw new Error(`Erro de validação: ${validationResult.errors.join(', ')}`);
    }

    // 2. Buscar informações do serviço para calcular horário de fim e preço
    const service = await prisma.service.findUnique({
      where: { id: data.serviceId },
      include: { professional: true }
    });

    if (!service) {
      throw new Error('Serviço não encontrado');
    }

    if (service.professionalId !== data.professionalId) {
      throw new Error('Serviço não está associado ao profissional selecionado');
    }

    // 3. Calcular horário de fim baseado na duração do serviço
    const startTime = new Date(data.startTime);
    const endTime = new Date(startTime.getTime() + service.duration * 60000);

    // 4. Criar o agendamento
    const booking = await prisma.booking.create({
      data: {
        clientId: data.clientId,
        professionalId: data.professionalId,
        serviceId: data.serviceId,
        tenantId,
        startTime,
        endTime,
        notes: data.notes,
        price: service.price,
        status: 'SCHEDULED',
        paymentStatus: 'PENDING'
      },
      include: {
        client: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true
          }
        },
        professional: {
          include: {
            user: {
              select: {
                name: true,
                email: true
              }
            }
          }
        },
        service: {
          select: {
            id: true,
            name: true,
            duration: true,
            price: true
          }
        }
      }
    });

    // 5. Invalidate cache after creating booking
    await cacheInvalidationService.invalidate('booking', booking.id, tenantId);
    await cacheInvalidationService.invalidateDate(startTime.toISOString().split('T')[0], tenantId);

    // 6. Registrar no histórico
    await this.createBookingHistory({
      bookingId: booking.id,
      action: 'CREATED',
      newStatus: 'SCHEDULED',
      performedBy: data.clientId,
      reason: 'Agendamento criado'
    });

    // 6. Confirmar automaticamente se configurado
    const shouldAutoConfirm = await this.shouldAutoConfirm(tenantId);
    if (shouldAutoConfirm) {
      await this.confirmBooking(booking.id, data.clientId);
    }

    return this.formatBookingResponse(booking);
  }

  /**
   * Valida se um agendamento pode ser criado
   */
  async validateBookingAvailability(data: CreateBookingRequest): Promise<BookingValidationResult> {
    const errors: string[] = [];
    const warnings: string[] = [];

    // 1. Verificar se o cliente existe
    const client = await prisma.user.findUnique({
      where: { id: data.clientId }
    });
    if (!client) {
      errors.push('Cliente não encontrado');
    }

    // 2. Verificar se o profissional existe
    const professional = await prisma.professional.findUnique({
      where: { id: data.professionalId },
      include: { user: true }
    });
    if (!professional) {
      errors.push('Profissional não encontrado');
    }

    // 3. Verificar se o serviço existe
    const service = await prisma.service.findUnique({
      where: { id: data.serviceId }
    });
    if (!service) {
      errors.push('Serviço não encontrado');
    }

    if (errors.length > 0) {
      return { isValid: false, errors, warnings };
    }

    // 4. Verificar disponibilidade do horário
    const startTime = new Date(data.startTime);
    const endTime = new Date(startTime.getTime() + service!.duration * 60000);

    const conflictingBookings = await prisma.booking.findMany({
      where: {
        professionalId: data.professionalId,
        status: {
          in: ['SCHEDULED', 'CONFIRMED']
        },
        OR: [
          {
            AND: [
              { startTime: { lte: startTime } },
              { endTime: { gt: startTime } }
            ]
          },
          {
            AND: [
              { startTime: { lt: endTime } },
              { endTime: { gte: endTime } }
            ]
          },
          {
            AND: [
              { startTime: { gte: startTime } },
              { endTime: { lte: endTime } }
            ]
          }
        ]
      }
    });

    if (conflictingBookings.length > 0) {
      errors.push('Horário não disponível - já existe um agendamento neste período');
    }

    // 5. Verificar se está dentro do horário de funcionamento
    const dayOfWeek = startTime.getDay();
    const timeString = startTime.toTimeString().substring(0, 5);

    const schedule = await prisma.schedule.findFirst({
      where: {
        professionalId: data.professionalId,
        dayOfWeek,
        isActive: true
      }
    });

    if (!schedule) {
      errors.push('Profissional não trabalha neste dia da semana');
    } else if (timeString < schedule.startTime || timeString >= schedule.endTime) {
      errors.push('Horário fora do expediente do profissional');
    }

    // 6. Verificar exceções na agenda
    const dateString = startTime.toISOString().split('T')[0];
    const exception = await prisma.scheduleException.findFirst({
      where: {
        schedule: {
          professionalId: data.professionalId
        },
        date: {
          gte: new Date(dateString),
          lt: new Date(new Date(dateString).getTime() + 24 * 60 * 60 * 1000)
        }
      }
    });

    if (exception?.isBlocked) {
      errors.push('Data bloqueada na agenda do profissional');
    }

    // 7. Verificar se não é no passado
    if (startTime < new Date()) {
      errors.push('Não é possível agendar para datas passadas');
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  /**
   * Confirma um agendamento
   */
  async confirmBooking(bookingId: string, performedBy: string): Promise<BookingResponse> {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId }
    });

    if (!booking) {
      throw new Error('Agendamento não encontrado');
    }

    if (booking.status !== 'SCHEDULED') {
      throw new Error('Apenas agendamentos com status SCHEDULED podem ser confirmados');
    }

    const updatedBooking = await prisma.booking.update({
      where: { id: bookingId },
      data: { 
        status: 'CONFIRMED',
        updatedAt: new Date()
      },
      include: {
        client: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true
          }
        },
        professional: {
          include: {
            user: {
              select: {
                name: true,
                email: true
              }
            }
          }
        },
        service: {
          select: {
            id: true,
            name: true,
            duration: true,
            price: true
          }
        }
      }
    });

    // Registrar no histórico
    await this.createBookingHistory({
      bookingId,
      action: 'CONFIRMED',
      previousStatus: 'SCHEDULED',
      newStatus: 'CONFIRMED',
      performedBy,
      reason: 'Agendamento confirmado'
    });

    return this.formatBookingResponse(updatedBooking);
  }

  /**
   * Reagenda um agendamento
   */
  async rescheduleBooking(
    bookingId: string, 
    data: RescheduleBookingRequest, 
    performedBy: string
  ): Promise<BookingResponse> {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: { service: true }
    });

    if (!booking) {
      throw new Error('Agendamento não encontrado');
    }

    if (!['SCHEDULED', 'CONFIRMED'].includes(booking.status)) {
      throw new Error('Apenas agendamentos agendados ou confirmados podem ser reagendados');
    }

    // Validar política de reagendamento
    const rescheduleValidation = await cancellationPolicyService.validateReschedule(
      bookingId, 
      booking.tenantId, 
      data.newStartTime
    );

    if (!rescheduleValidation.allowed) {
      throw new Error(rescheduleValidation.reason || 'Reagendamento não permitido');
    }

    // Validar nova disponibilidade
    const validationData = {
      clientId: booking.clientId,
      professionalId: booking.professionalId,
      serviceId: booking.serviceId,
      startTime: data.newStartTime
    };

    const validationResult = await this.validateBookingAvailability(validationData);
    if (!validationResult.isValid) {
      throw new Error(`Erro de validação: ${validationResult.errors.join(', ')}`);
    }

    const previousStartTime = booking.startTime;
    const newStartTime = new Date(data.newStartTime);
    const newEndTime = new Date(newStartTime.getTime() + booking.service.duration * 60000);

    const updatedBooking = await prisma.booking.update({
      where: { id: bookingId },
      data: {
        startTime: newStartTime,
        endTime: newEndTime,
        status: 'RESCHEDULED',
        updatedAt: new Date()
      },
      include: {
        client: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true
          }
        },
        professional: {
          include: {
            user: {
              select: {
                name: true,
                email: true
              }
            }
          }
        },
        service: {
          select: {
            id: true,
            name: true,
            duration: true,
            price: true
          }
        }
      }
    });

    // Liberar horário anterior
    await cancellationPolicyService.releaseTimeSlot(bookingId);

    // Registrar no histórico
    await this.createBookingHistory({
      bookingId,
      action: 'RESCHEDULED',
      previousStatus: booking.status as BookingStatus,
      newStatus: 'RESCHEDULED',
      previousStartTime,
      newStartTime,
      performedBy,
      reason: data.reason || 'Reagendamento solicitado'
    });

    return this.formatBookingResponse(updatedBooking);
  }

  /**
   * Cancela um agendamento
   */
  async cancelBooking(
    bookingId: string, 
    performedBy: string, 
    reason?: string
  ): Promise<BookingResponse> {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId }
    });

    if (!booking) {
      throw new Error('Agendamento não encontrado');
    }

    if (!['SCHEDULED', 'CONFIRMED', 'RESCHEDULED'].includes(booking.status)) {
      throw new Error('Agendamento não pode ser cancelado');
    }

    // Verificar política de cancelamento
    const cancellationValidation = await cancellationPolicyService.validateCancellation(
      bookingId, 
      booking.tenantId
    );

    if (!cancellationValidation.allowed) {
      throw new Error(cancellationValidation.reason || 'Cancelamento não permitido');
    }

    const updatedBooking = await prisma.booking.update({
      where: { id: bookingId },
      data: {
        status: 'CANCELLED',
        updatedAt: new Date()
      },
      include: {
        client: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true
          }
        },
        professional: {
          include: {
            user: {
              select: {
                name: true,
                email: true
              }
            }
          }
        },
        service: {
          select: {
            id: true,
            name: true,
            duration: true,
            price: true
          }
        }
      }
    });

    // Liberar horário automaticamente
    await cancellationPolicyService.releaseTimeSlot(bookingId);

    // Registrar no histórico
    await this.createBookingHistory({
      bookingId,
      action: 'CANCELLED',
      previousStatus: booking.status as BookingStatus,
      newStatus: 'CANCELLED',
      performedBy,
      reason: reason || 'Cancelamento solicitado'
    });

    return this.formatBookingResponse(updatedBooking);
  }

  /**
   * Lista agendamentos com filtros
   */
  async getBookings(filters: BookingFilters): Promise<BookingResponse[]> {
    const where: any = {};

    if (filters.clientId) where.clientId = filters.clientId;
    if (filters.professionalId) where.professionalId = filters.professionalId;
    if (filters.serviceId) where.serviceId = filters.serviceId;
    if (filters.status) where.status = filters.status;
    if (filters.tenantId) where.tenantId = filters.tenantId;

    if (filters.startDate || filters.endDate) {
      where.startTime = {};
      if (filters.startDate) where.startTime.gte = filters.startDate;
      if (filters.endDate) where.startTime.lte = filters.endDate;
    }

    const bookings = await prisma.booking.findMany({
      where,
      include: {
        client: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true
          }
        },
        professional: {
          include: {
            user: {
              select: {
                name: true,
                email: true
              }
            }
          }
        },
        service: {
          select: {
            id: true,
            name: true,
            duration: true,
            price: true
          }
        }
      },
      orderBy: {
        startTime: 'asc'
      }
    });

    return bookings.map(booking => this.formatBookingResponse(booking));
  }

  /**
   * Busca um agendamento por ID
   */
  async getBookingById(id: string): Promise<BookingResponse | null> {
    const booking = await prisma.booking.findUnique({
      where: { id },
      include: {
        client: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true
          }
        },
        professional: {
          include: {
            user: {
              select: {
                name: true,
                email: true
              }
            }
          }
        },
        service: {
          select: {
            id: true,
            name: true,
            duration: true,
            price: true
          }
        }
      }
    });

    return booking ? this.formatBookingResponse(booking) : null;
  }

  /**
   * Atualiza um agendamento
   */
  async updateBooking(
    id: string, 
    data: UpdateBookingRequest, 
    performedBy: string
  ): Promise<BookingResponse> {
    const booking = await prisma.booking.findUnique({
      where: { id }
    });

    if (!booking) {
      throw new Error('Agendamento não encontrado');
    }

    const previousStatus = booking.status;
    const previousStartTime = booking.startTime;

    const updatedBooking = await prisma.booking.update({
      where: { id },
      data: {
        ...data,
        updatedAt: new Date()
      },
      include: {
        client: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true
          }
        },
        professional: {
          include: {
            user: {
              select: {
                name: true,
                email: true
              }
            }
          }
        },
        service: {
          select: {
            id: true,
            name: true,
            duration: true,
            price: true
          }
        }
      }
    });

    // Registrar no histórico
    await this.createBookingHistory({
      bookingId: id,
      action: 'UPDATED',
      previousStatus: previousStatus as BookingStatus,
      newStatus: (data.status || previousStatus) as BookingStatus,
      previousStartTime: data.startTime ? previousStartTime : undefined,
      newStartTime: data.startTime,
      performedBy,
      reason: 'Agendamento atualizado'
    });

    return this.formatBookingResponse(updatedBooking);
  }

  /**
   * Marca agendamento como concluído
   */
  async completeBooking(bookingId: string, performedBy: string): Promise<BookingResponse> {
    return this.updateBooking(bookingId, { status: 'COMPLETED' }, performedBy);
  }

  /**
   * Marca agendamento como no-show
   */
  async markAsNoShow(bookingId: string, performedBy: string): Promise<BookingResponse> {
    return this.updateBooking(bookingId, { status: 'NO_SHOW' }, performedBy);
  }

  /**
   * Busca o histórico de um agendamento
   */
  async getBookingHistory(bookingId: string): Promise<BookingHistory[]> {
    return await bookingHistoryService.getBookingHistory(bookingId);
  }

  /**
   * Calcula métricas de agendamentos
   */
  async getBookingMetrics(filters: {
    tenantId?: string;
    professionalId?: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<BookingMetrics> {
    return await bookingHistoryService.calculateBookingMetrics(filters);
  }

  /**
   * Busca métricas detalhadas
   */
  async getDetailedMetrics(filters: {
    tenantId?: string;
    professionalId?: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<any> {
    return await bookingHistoryService.getDetailedMetrics(filters);
  }

  /**
   * Busca tendências de agendamentos
   */
  async getBookingTrends(filters: {
    tenantId?: string;
    professionalId?: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<any> {
    return await bookingHistoryService.getBookingTrends(filters);
  }

  /**
   * Busca padrões de cancelamento
   */
  async getCancellationPatterns(filters: {
    tenantId?: string;
    professionalId?: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<any> {
    return await bookingHistoryService.getCancellationPatterns(filters);
  }

  /**
   * Busca clientes com alta taxa de cancelamento
   */
  async getHighCancellationClients(tenantId: string, limit?: number): Promise<any[]> {
    return await bookingHistoryService.getHighCancellationClients(tenantId, limit);
  }

  // Métodos auxiliares privados

  private async shouldAutoConfirm(tenantId: string): Promise<boolean> {
    // Por padrão, confirma automaticamente
    // Pode ser configurável por tenant no futuro
    return true;
  }

  private async getCancellationPolicy(tenantId: string): Promise<CancellationPolicy> {
    return await cancellationPolicyService.getPolicyByTenant(tenantId);
  }

  private async createBookingHistory(data: {
    bookingId: string;
    action: BookingAction;
    previousStatus?: BookingStatus;
    newStatus?: BookingStatus;
    previousStartTime?: Date;
    newStartTime?: Date;
    performedBy: string;
    reason?: string;
  }): Promise<void> {
    await bookingHistoryService.createHistoryEntry(data);
  }

  private formatBookingResponse(booking: any): BookingResponse {
    return {
      id: booking.id,
      clientId: booking.clientId,
      professionalId: booking.professionalId,
      serviceId: booking.serviceId,
      tenantId: booking.tenantId,
      startTime: booking.startTime,
      endTime: booking.endTime,
      status: booking.status as BookingStatus,
      notes: booking.notes,
      price: booking.price,
      paymentStatus: booking.paymentStatus as PaymentStatus,
      createdAt: booking.createdAt,
      updatedAt: booking.updatedAt,
      client: booking.client,
      professional: booking.professional,
      service: booking.service
    };
  }
}

export const bookingService = new BookingService();