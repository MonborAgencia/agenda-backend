# Sistema de Cache e Otimização de Performance

Este documento descreve o sistema de cache Redis e otimizações de performance implementadas no Agenda Lotada 24h.

## Visão Geral

O sistema implementa uma solução completa de cache com Redis, incluindo:
- Cache inteligente com TTL configurável
- Invalidação automática de cache
- Métricas de performance
- Monitoramento de queries
- Otimização de índices do banco de dados

## Componentes Principais

### 1. CacheService (`cache.service.ts`)

Serviço centralizado para operações de cache:

```typescript
// Operações básicas
await cacheService.get<T>(key, options);
await cacheService.set<T>(key, value, options);
await cacheService.del(key, options);

// Padrão get-or-set
const result = await cacheService.getOrSet(key, async () => {
  return await expensiveOperation();
}, { ttl: 3600 });

// Contadores
await cacheService.increment(key, options);

// Métricas
const metrics = cacheService.getMetrics();
```

### 2. CacheInvalidationService (`cache-invalidation.service.ts`)

Sistema inteligente de invalidação de cache:

```typescript
// Invalidar por entidade
await cacheInvalidationService.invalidate('user', userId, tenantId);

// Invalidar por padrão
await cacheInvalidationService.invalidatePattern('booking:*', tenantId);

// Invalidar por data
await cacheInvalidationService.invalidateDate('2024-01-15', tenantId);

// Invalidação inteligente baseada em tempo
await cacheInvalidationService.smartInvalidation(tenantId);
```

### 3. CacheMetricsService (`cache-metrics.service.ts`)

Monitoramento e métricas de performance:

```typescript
// Métricas detalhadas
const metrics = await cacheMetricsService.getDetailedMetrics();

// Relatório de performance
const report = await cacheMetricsService.getPerformanceReport();

// Status de saúde
const health = await cacheMetricsService.getHealthStatus();
```

### 4. QueryOptimizationService (`query-optimization.service.ts`)

Otimizações de queries do banco de dados:

```typescript
// Paginação otimizada
const result = await queryOptimizationService.getBookingsOptimized(
  tenantId, 
  { page: 1, limit: 10, status: 'SCHEDULED' }
);

// Métricas de dashboard
const metrics = await queryOptimizationService.getDashboardMetricsOptimized(
  tenantId, 
  startDate, 
  endDate
);

// Busca otimizada
const users = await queryOptimizationService.searchUsersOptimized(
  tenantId, 
  'search term'
);
```

## Middlewares

### 1. Cache Middleware (`cache.middleware.ts`)

Middleware automático para cache de respostas GET:

```typescript
// Cache básico
app.get('/api/users', cacheMiddleware({ ttl: 3600 }), handler);

// Cache específico para usuários
app.get('/api/users/:id', userCacheMiddleware(3600), handler);

// Cache para analytics
app.get('/api/analytics', analyticsCacheMiddleware(14400), handler);

// Invalidação após mutações
app.post('/api/users', invalidateCacheMiddleware(['user:*']), handler);
```

### 2. Query Monitor Middleware (`query-monitor.middleware.ts`)

Monitoramento automático de performance:

```typescript
// Aplicado globalmente
app.use(queryMonitorMiddleware);

// Estatísticas disponíveis
const stats = getQueryStats();
```

## Configuração de Cache

### Chaves de Cache (`redis.ts`)

```typescript
export const CACHE_KEYS = {
  // Usuários e perfis
  USER_PROFILE: (userId: string) => `user:${userId}:profile`,
  USER_PERMISSIONS: (userId: string) => `user:${userId}:permissions`,
  
  // Agendamentos
  AVAILABLE_SLOTS: (professionalId: string, date: string) => 
    `slots:available:${professionalId}:${date}`,
  BOOKING_LIST: (userId: string, page: number, filters: string) => 
    `booking:${userId}:list:${page}:${filters}`,
  
  // Analytics
  DASHBOARD_DATA: (tenantId: string, userId: string) => 
    `dashboard:${tenantId}:${userId}`,
  ANALYTICS_DATA: (tenantId: string, type: string, period: string) => 
    `analytics:${tenantId}:${type}:${period}`,
};
```

### TTL (Time To Live)

```typescript
export const CACHE_TTL = {
  // Cache de curto prazo (5 minutos)
  AVAILABLE_SLOTS: 300,
  DAY_AVAILABILITY: 300,
  
  // Cache de médio prazo (15 minutos)
  BOOKING_LIST: 900,
  SERVICE_LIST: 900,
  
  // Cache de longo prazo (1 hora)
  USER_PROFILE: 3600,
  PROFESSIONAL_SCHEDULE: 3600,
  
  // Cache de analytics (4 horas)
  ANALYTICS_DATA: 14400,
  REPORT_DATA: 14400,
};
```

## Otimizações de Banco de Dados

### Índices Implementados

O script `optimize-database.ts` cria índices otimizados para:

1. **Tabela de Bookings** (mais crítica):
   - `idx_bookings_tenant_start_time`
   - `idx_bookings_professional_start_time`
   - `idx_bookings_client_start_time`
   - `idx_bookings_status_tenant`
   - `idx_bookings_professional_status_start`

2. **Tabela de Users**:
   - `idx_users_tenant_id`
   - `idx_users_email_tenant`
   - `idx_users_active_tenant`

3. **Tabela de Schedules**:
   - `idx_schedules_professional_day`
   - `idx_schedules_professional_active`

4. **Outras tabelas otimizadas**:
   - Notifications, Campaigns, Reviews, Payments

### Executar Otimização

```bash
# Via API (recomendado)
POST /api/performance/optimize-database

# Via script direto
npm run optimize-db
```

## APIs de Monitoramento

### Cache Management (`/api/cache`)

```bash
# Métricas de cache
GET /api/cache/metrics

# Relatório de performance
GET /api/cache/performance-report

# Status de saúde
GET /api/cache/health

# Limpar cache por padrão
DELETE /api/cache/clear
Body: { "pattern": "user:*", "tenantId": "tenant-id" }

# Limpar cache de tenant
DELETE /api/cache/clear-tenant/:tenantId

# Limpar cache de usuário
DELETE /api/cache/clear-user/:userId
```

### Performance Monitoring (`/api/performance`)

```bash
# Estatísticas de queries
GET /api/performance/query-stats

# Queries lentas
GET /api/performance/slow-queries?threshold=1000

# Análise de endpoints
GET /api/performance/endpoint-analysis

# Performance por tenant
GET /api/performance/tenant-performance

# Score de saúde do sistema
GET /api/performance/health-score

# Recomendações de otimização
GET /api/performance/recommendations

# Testar performance de query
POST /api/performance/test-query
Body: { 
  "queryType": "bookings", 
  "params": { "page": 1, "limit": 10 } 
}
```

## Estratégias de Cache

### 1. Cache-Aside Pattern

```typescript
// Implementado no getOrSet
const userData = await cacheService.getOrSet(
  CACHE_KEYS.USER_PROFILE(userId),
  async () => {
    return await userService.getUserById(userId);
  },
  { ttl: CACHE_TTL.USER_PROFILE }
);
```

### 2. Write-Through Pattern

```typescript
// Atualizar dados e cache simultaneamente
await userService.updateUser(userId, data);
await cacheService.set(
  CACHE_KEYS.USER_PROFILE(userId), 
  updatedUser, 
  { ttl: CACHE_TTL.USER_PROFILE }
);
```

### 3. Cache Invalidation

```typescript
// Invalidação automática após mutações
app.post('/api/bookings', async (req, res) => {
  const booking = await bookingService.create(req.body);
  
  // Invalidar caches relacionados
  await cacheInvalidationService.invalidate('booking', booking.id, tenantId);
  await cacheInvalidationService.invalidateDate(booking.startTime, tenantId);
  
  res.json(booking);
});
```

## Métricas e Monitoramento

### Métricas Coletadas

- **Hit Rate**: Percentual de acertos do cache
- **Response Time**: Tempo médio de resposta
- **Memory Usage**: Uso de memória do Redis
- **Key Count**: Número de chaves no cache
- **Slow Queries**: Queries que demoram > 1s

### Alertas Automáticos

- Hit rate < 70%
- Tempo médio de resposta > 1s
- Uso de memória > 90%
- Muitas queries lentas (> 10%)

### Dashboard de Performance

Acesse `/api/performance/health-score` para ver:
- Score geral do sistema (0-100)
- Status: excellent, good, fair, poor
- Issues identificados
- Recomendações de otimização

## Boas Práticas

### 1. Chaves de Cache

- Use prefixos consistentes (`tenant:id:entity:id`)
- Inclua tenant ID para isolamento
- Use nomes descritivos e padronizados

### 2. TTL Strategy

- Dados frequentemente alterados: TTL baixo (5-15 min)
- Dados estáveis: TTL médio (1 hora)
- Dados analíticos: TTL alto (4+ horas)

### 3. Invalidação

- Invalide imediatamente após mutações
- Use padrões para invalidação em lote
- Implemente invalidação inteligente baseada em tempo

### 4. Monitoramento

- Monitore hit rate regularmente
- Identifique e otimize queries lentas
- Mantenha uso de memória sob controle

## Troubleshooting

### Cache Miss Alto

1. Verifique TTL das chaves
2. Analise padrões de invalidação
3. Revise estratégia de cache

### Performance Ruim

1. Verifique índices do banco
2. Analise queries lentas
3. Otimize operações custosas

### Uso Alto de Memória

1. Revise TTL das chaves
2. Implemente LRU eviction
3. Comprima dados grandes

### Redis Indisponível

- Sistema continua funcionando sem cache
- Logs de erro são gerados
- Reconexão automática implementada

## Exemplo de Uso Completo

```typescript
// Service com cache integrado
export class BookingService {
  async getBookings(tenantId: string, filters: any) {
    const cacheKey = CACHE_KEYS.BOOKING_LIST(
      filters.userId, 
      filters.page, 
      JSON.stringify(filters)
    );
    
    return await cacheService.getOrSet(
      cacheKey,
      async () => {
        return await this.fetchBookingsFromDB(tenantId, filters);
      },
      { 
        ttl: CACHE_TTL.BOOKING_LIST,
        prefix: `tenant:${tenantId}`
      }
    );
  }
  
  async createBooking(data: any, tenantId: string) {
    const booking = await this.createBookingInDB(data);
    
    // Invalidar caches relacionados
    await cacheInvalidationService.invalidate('booking', booking.id, tenantId);
    await cacheInvalidationService.invalidateDate(
      booking.startTime.toISOString().split('T')[0], 
      tenantId
    );
    
    return booking;
  }
}
```

Este sistema de cache fornece uma base sólida para alta performance e escalabilidade do Agenda Lotada 24h.