import { PrismaClient } from '@prisma/client';
import { Redis } from 'ioredis';
import {
  Notification,
  CreateNotificationData,
  NotificationStatus,
  NotificationPriority,
  ProcessNotificationData,
  NotificationResult,
  NotificationFilter,
  NotificationStats
} from '../types/notification.types';
import { notificationTemplateService } from './notification-template.service';
import { redisClient } from '../config/redis';

const prisma = new PrismaClient();

export class NotificationService {
  private redis: Redis;
  private readonly QUEUE_KEY = 'notification:queue';
  private readonly PROCESSING_KEY = 'notification:processing';
  private readonly RETRY_DELAY = 60; // 1 minuto em segundos

  constructor() {
    this.redis = redisClient;
  }

  // Criar notificação
  async createNotification(data: CreateNotificationData): Promise<Notification> {
    let content = data.content;
    let subject = data.subject;

    // Se usar template, renderizar com variáveis
    if (data.templateId && data.variables) {
      const rendered = await notificationTemplateService.renderTemplate(
        data.templateId,
        { variables: data.variables }
      );
      
      if (rendered) {
        content = rendered.content;
        subject = rendered.subject || subject;
      }
    }

    const notification = await prisma.notification.create({
      data: {
        templateId: data.templateId,
        recipientId: data.recipientId,
        type: data.type,
        subject,
        content: content || '',
        scheduledFor: data.scheduledFor,
        metadata: data.metadata ? JSON.stringify(data.metadata) : null
      }
    });

    return this.formatNotification(notification);
  }

  // Buscar notificação por ID
  async getNotificationById(id: string): Promise<Notification | null> {
    const notification = await prisma.notification.findUnique({
      where: { id },
      include: {
        template: true,
        recipient: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true
          }
        }
      }
    });

    return notification ? this.formatNotification(notification) : null;
  }

  // Buscar notificações com filtros
  async getNotifications(
    filters: NotificationFilter = {},
    page: number = 1,
    limit: number = 20
  ): Promise<{
    notifications: Notification[];
    total: number;
    page: number;
    totalPages: number;
  }> {
    const skip = (page - 1) * limit;
    
    const where: any = {};
    
    if (filters.type) where.type = filters.type;
    if (filters.status) where.status = filters.status;
    if (filters.recipientId) where.recipientId = filters.recipientId;
    if (filters.templateId) where.templateId = filters.templateId;
    
    if (filters.dateFrom || filters.dateTo) {
      where.createdAt = {};
      if (filters.dateFrom) where.createdAt.gte = filters.dateFrom;
      if (filters.dateTo) where.createdAt.lte = filters.dateTo;
    }

    const [notifications, total] = await Promise.all([
      prisma.notification.findMany({
        where,
        include: {
          template: true,
          recipient: {
            select: {
              id: true,
              name: true,
              email: true,
              phone: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      prisma.notification.count({ where })
    ]);

    return {
      notifications: notifications.map(n => this.formatNotification(n)),
      total,
      page,
      totalPages: Math.ceil(total / limit)
    };
  }

  // Adicionar notificação à fila
  async enqueueNotification(data: ProcessNotificationData): Promise<void> {
    const notification = await this.getNotificationById(data.notificationId);
    if (!notification) {
      throw new Error('Notificação não encontrada');
    }

    // Verificar se já está na fila
    const isInQueue = await this.redis.zscore(this.QUEUE_KEY, data.notificationId);
    if (isInQueue !== null) {
      return; // Já está na fila
    }

    const priority = data.priority || NotificationPriority.NORMAL;
    const delay = data.delay || 0;
    const score = Date.now() + (delay * 1000) - (priority * 1000000); // Prioridade afeta a ordem

    // Adicionar à fila ordenada por prioridade e tempo
    await this.redis.zadd(this.QUEUE_KEY, score, data.notificationId);

    // Criar registro na tabela de fila
    await prisma.notificationQueue.create({
      data: {
        notificationId: data.notificationId,
        priority,
        nextAttempt: new Date(Date.now() + (delay * 1000)),
        data: JSON.stringify({
          priority,
          delay,
          enqueuedAt: new Date()
        })
      }
    });

    console.log(`Notificação ${data.notificationId} adicionada à fila com prioridade ${priority}`);
  }

  // Processar próxima notificação da fila
  async processNextNotification(): Promise<boolean> {
    // Buscar próxima notificação da fila
    const result = await this.redis.zpopmin(this.QUEUE_KEY, 1);
    
    if (!result || result.length === 0) {
      return false; // Fila vazia
    }

    const notificationId = result[0];
    const score = parseFloat(result[1]);

    // Verificar se é hora de processar
    if (score > Date.now()) {
      // Recolocar na fila
      await this.redis.zadd(this.QUEUE_KEY, score, notificationId);
      return false;
    }

    try {
      // Marcar como processando
      await this.redis.setex(`${this.PROCESSING_KEY}:${notificationId}`, 300, '1'); // 5 minutos

      const success = await this.processNotification(notificationId);
      
      if (success) {
        // Remover da tabela de fila
        await prisma.notificationQueue.delete({
          where: { notificationId }
        }).catch(() => {}); // Ignorar erro se já foi removido
      } else {
        // Reagendar para retry
        await this.scheduleRetry(notificationId);
      }

      // Remover lock de processamento
      await this.redis.del(`${this.PROCESSING_KEY}:${notificationId}`);
      
      return true;
    } catch (error) {
      console.error(`Erro ao processar notificação ${notificationId}:`, error);
      
      // Reagendar para retry
      await this.scheduleRetry(notificationId);
      
      // Remover lock de processamento
      await this.redis.del(`${this.PROCESSING_KEY}:${notificationId}`);
      
      return false;
    }
  }

  // Processar notificação específica
  private async processNotification(notificationId: string): Promise<boolean> {
    const notification = await this.getNotificationById(notificationId);
    if (!notification) {
      console.error(`Notificação ${notificationId} não encontrada`);
      return false;
    }

    // Verificar se já foi processada
    if (notification.status !== NotificationStatus.PENDING) {
      console.log(`Notificação ${notificationId} já foi processada`);
      return true;
    }

    try {
      // Atualizar status para enviando
      await this.updateNotificationStatus(notificationId, NotificationStatus.SENT);

      // Usar o provider service para enviar a notificação
      const { notificationProviderService } = await import('./notification-provider.service');
      const result = await notificationProviderService.sendNotification(notification);

      if (result.success) {
        await this.updateNotificationStatus(
          notificationId, 
          NotificationStatus.DELIVERED,
          {
            messageId: result.messageId,
            deliveredAt: result.deliveredAt
          }
        );
        
        console.log(`Notificação ${notificationId} enviada com sucesso`);
        return true;
      } else {
        await this.updateNotificationStatus(
          notificationId, 
          NotificationStatus.FAILED,
          { failureReason: result.error }
        );
        
        console.error(`Falha ao enviar notificação ${notificationId}: ${result.error}`);
        return false;
      }
    } catch (error: any) {
      await this.updateNotificationStatus(
        notificationId, 
        NotificationStatus.FAILED,
        { failureReason: error.message }
      );
      
      console.error(`Erro ao processar notificação ${notificationId}:`, error);
      return false;
    }
  }

  // Reagendar notificação para retry
  private async scheduleRetry(notificationId: string): Promise<void> {
    const queueItem = await prisma.notificationQueue.findUnique({
      where: { notificationId }
    });

    if (!queueItem) {
      return;
    }

    const notification = await this.getNotificationById(notificationId);
    if (!notification) {
      return;
    }

    // Incrementar contador de tentativas
    const newAttempts = queueItem.attempts + 1;
    const newRetryCount = notification.retryCount + 1;

    // Verificar se excedeu o máximo de tentativas
    if (newRetryCount >= notification.maxRetries) {
      await this.updateNotificationStatus(
        notificationId,
        NotificationStatus.FAILED,
        { failureReason: 'Máximo de tentativas excedido' }
      );
      
      await prisma.notificationQueue.delete({
        where: { notificationId }
      }).catch(() => {});
      
      return;
    }

    // Calcular delay exponencial: 1min, 2min, 4min, 8min...
    const delay = Math.min(this.RETRY_DELAY * Math.pow(2, newAttempts - 1), 3600); // Max 1 hora
    const nextAttempt = new Date(Date.now() + (delay * 1000));
    const score = nextAttempt.getTime();

    // Atualizar contador de retry na notificação
    await prisma.notification.update({
      where: { id: notificationId },
      data: { retryCount: newRetryCount }
    });

    // Atualizar item da fila
    await prisma.notificationQueue.update({
      where: { notificationId },
      data: {
        attempts: newAttempts,
        nextAttempt
      }
    });

    // Recolocar na fila Redis
    await this.redis.zadd(this.QUEUE_KEY, score, notificationId);

    console.log(`Notificação ${notificationId} reagendada para ${nextAttempt} (tentativa ${newAttempts})`);
  }

  // Atualizar status da notificação
  private async updateNotificationStatus(
    notificationId: string,
    status: NotificationStatus,
    metadata?: Record<string, any>
  ): Promise<void> {
    const updateData: any = { status };

    if (status === NotificationStatus.SENT) {
      updateData.sentAt = new Date();
    } else if (status === NotificationStatus.DELIVERED) {
      updateData.deliveredAt = metadata?.deliveredAt || new Date();
    } else if (status === NotificationStatus.FAILED) {
      updateData.failureReason = metadata?.failureReason;
    }

    if (metadata) {
      const existingNotification = await prisma.notification.findUnique({
        where: { id: notificationId }
      });
      
      const existingMetadata = existingNotification?.metadata 
        ? JSON.parse(existingNotification.metadata)
        : {};
      
      updateData.metadata = JSON.stringify({
        ...existingMetadata,
        ...metadata
      });
    }

    await prisma.notification.update({
      where: { id: notificationId },
      data: updateData
    });
  }

  // Cancelar notificação
  async cancelNotification(notificationId: string): Promise<boolean> {
    try {
      // Remover da fila Redis
      await this.redis.zrem(this.QUEUE_KEY, notificationId);
      
      // Remover da tabela de fila
      await prisma.notificationQueue.delete({
        where: { notificationId }
      }).catch(() => {}); // Ignorar erro se não existir
      
      // Atualizar status
      await this.updateNotificationStatus(notificationId, NotificationStatus.CANCELLED);
      
      return true;
    } catch (error) {
      console.error(`Erro ao cancelar notificação ${notificationId}:`, error);
      return false;
    }
  }

  // Obter estatísticas das notificações
  async getNotificationStats(filters: NotificationFilter = {}): Promise<NotificationStats> {
    const where: any = {};
    
    if (filters.type) where.type = filters.type;
    if (filters.recipientId) where.recipientId = filters.recipientId;
    if (filters.templateId) where.templateId = filters.templateId;
    
    if (filters.dateFrom || filters.dateTo) {
      where.createdAt = {};
      if (filters.dateFrom) where.createdAt.gte = filters.dateFrom;
      if (filters.dateTo) where.createdAt.lte = filters.dateTo;
    }

    const stats = await prisma.notification.groupBy({
      by: ['status'],
      where,
      _count: { status: true }
    });

    const total = stats.reduce((sum, stat) => sum + stat._count.status, 0);
    const sent = stats.find(s => s.status === 'SENT')?._count.status || 0;
    const delivered = stats.find(s => s.status === 'DELIVERED')?._count.status || 0;
    const failed = stats.find(s => s.status === 'FAILED')?._count.status || 0;
    const pending = stats.find(s => s.status === 'PENDING')?._count.status || 0;

    const deliveryRate = total > 0 ? ((sent + delivered) / total) * 100 : 0;

    return {
      total,
      sent,
      delivered,
      failed,
      pending,
      deliveryRate: Math.round(deliveryRate * 100) / 100
    };
  }

  // Obter tamanho da fila
  async getQueueSize(): Promise<number> {
    return await this.redis.zcard(this.QUEUE_KEY);
  }

  // Obter próximas notificações da fila
  async getQueueItems(limit: number = 10): Promise<Array<{
    notificationId: string;
    score: number;
    scheduledFor: Date;
  }>> {
    const items = await this.redis.zrange(this.QUEUE_KEY, 0, limit - 1, 'WITHSCORES');
    const result = [];

    for (let i = 0; i < items.length; i += 2) {
      const notificationId = items[i];
      const score = parseFloat(items[i + 1]);
      
      result.push({
        notificationId,
        score,
        scheduledFor: new Date(score)
      });
    }

    return result;
  }

  // Limpar fila (usar com cuidado)
  async clearQueue(): Promise<number> {
    const count = await this.redis.zcard(this.QUEUE_KEY);
    await this.redis.del(this.QUEUE_KEY);
    
    // Limpar também a tabela de fila
    await prisma.notificationQueue.deleteMany({});
    
    return count;
  }

  // Formatar notificação do banco para o tipo TypeScript
  private formatNotification(notification: any): Notification {
    return {
      ...notification,
      metadata: notification.metadata ? JSON.parse(notification.metadata) : null
    };
  }

  // Criar e enfileirar notificação em uma operação
  async createAndEnqueueNotification(
    data: CreateNotificationData,
    processData?: Omit<ProcessNotificationData, 'notificationId'>
  ): Promise<Notification> {
    const notification = await this.createNotification(data);
    
    await this.enqueueNotification({
      notificationId: notification.id,
      ...processData
    });
    
    return notification;
  }

  // Reprocessar notificações falhadas
  async reprocessFailedNotifications(limit: number = 50): Promise<number> {
    const failedNotifications = await prisma.notification.findMany({
      where: {
        status: NotificationStatus.FAILED,
        retryCount: {
          lt: 3 // Apenas notificações que ainda podem ser tentadas novamente
        }
      },
      take: limit,
      orderBy: { updatedAt: 'asc' }
    });

    let reprocessed = 0;
    
    for (const notification of failedNotifications) {
      try {
        await this.enqueueNotification({
          notificationId: notification.id,
          priority: NotificationPriority.HIGH
        });
        
        // Resetar status para pending
        await this.updateNotificationStatus(notification.id, NotificationStatus.PENDING);
        
        reprocessed++;
      } catch (error) {
        console.error(`Erro ao reprocessar notificação ${notification.id}:`, error);
      }
    }

    return reprocessed;
  }
}

export const notificationService = new NotificationService();