import { PrismaClient } from '@prisma/client';
import {
  NotificationTemplate,
  CreateNotificationTemplateData,
  UpdateNotificationTemplateData,
  TemplateVariable,
  NotificationType,
  NotificationCategory,
  TemplateRenderData,
  DefaultTemplates
} from '../types/notification.types';

const prisma = new PrismaClient();

export class NotificationTemplateService {
  // Criar template
  async createTemplate(data: CreateNotificationTemplateData): Promise<NotificationTemplate> {
    const templateData = {
      name: data.name,
      type: data.type,
      subject: data.subject,
      content: data.content,
      language: data.language || 'pt-BR',
      category: data.category,
      tenantId: data.tenantId,
      variables: data.variables ? JSON.stringify(data.variables) : null
    };

    const template = await prisma.notificationTemplate.create({
      data: templateData
    });

    return this.formatTemplate(template);
  }

  // Buscar template por ID
  async getTemplateById(id: string): Promise<NotificationTemplate | null> {
    const template = await prisma.notificationTemplate.findUnique({
      where: { id }
    });

    return template ? this.formatTemplate(template) : null;
  }

  // Buscar templates com filtros
  async getTemplates(filters: {
    tenantId?: string;
    type?: NotificationType;
    category?: NotificationCategory;
    language?: string;
    isActive?: boolean;
  } = {}): Promise<NotificationTemplate[]> {
    const templates = await prisma.notificationTemplate.findMany({
      where: {
        tenantId: filters.tenantId,
        type: filters.type,
        category: filters.category,
        language: filters.language,
        isActive: filters.isActive
      },
      orderBy: { createdAt: 'desc' }
    });

    return templates.map(template => this.formatTemplate(template));
  }

  // Buscar template por nome e tenant
  async getTemplateByName(
    name: string, 
    tenantId?: string, 
    language: string = 'pt-BR'
  ): Promise<NotificationTemplate | null> {
    const template = await prisma.notificationTemplate.findFirst({
      where: {
        name,
        tenantId,
        language,
        isActive: true
      }
    });

    return template ? this.formatTemplate(template) : null;
  }

  // Atualizar template
  async updateTemplate(
    id: string, 
    data: UpdateNotificationTemplateData
  ): Promise<NotificationTemplate | null> {
    const updateData: any = { ...data };
    
    if (data.variables) {
      updateData.variables = JSON.stringify(data.variables);
    }

    const template = await prisma.notificationTemplate.update({
      where: { id },
      data: updateData
    });

    return this.formatTemplate(template);
  }

  // Deletar template
  async deleteTemplate(id: string): Promise<boolean> {
    try {
      await prisma.notificationTemplate.delete({
        where: { id }
      });
      return true;
    } catch (error) {
      return false;
    }
  }

  // Renderizar template com variáveis
  async renderTemplate(
    templateId: string, 
    renderData: TemplateRenderData
  ): Promise<{ subject?: string; content: string } | null> {
    const template = await this.getTemplateById(templateId);
    if (!template) {
      return null;
    }

    const renderedContent = this.processTemplate(template.content, renderData.variables);
    const renderedSubject = template.subject 
      ? this.processTemplate(template.subject, renderData.variables)
      : undefined;

    return {
      subject: renderedSubject,
      content: renderedContent
    };
  }

  // Renderizar template por nome
  async renderTemplateByName(
    name: string,
    renderData: TemplateRenderData,
    tenantId?: string
  ): Promise<{ subject?: string; content: string } | null> {
    const template = await this.getTemplateByName(
      name, 
      tenantId, 
      renderData.language || 'pt-BR'
    );
    
    if (!template) {
      return null;
    }

    const renderedContent = this.processTemplate(template.content, renderData.variables);
    const renderedSubject = template.subject 
      ? this.processTemplate(template.subject, renderData.variables)
      : undefined;

    return {
      subject: renderedSubject,
      content: renderedContent
    };
  }

  // Processar template substituindo variáveis
  private processTemplate(template: string, variables: Record<string, any>): string {
    let processed = template;

    // Substituir variáveis no formato {{variable}}
    Object.keys(variables).forEach(key => {
      const regex = new RegExp(`{{\\s*${key}\\s*}}`, 'g');
      const value = this.formatVariableValue(variables[key]);
      processed = processed.replace(regex, value);
    });

    // Remover variáveis não substituídas
    processed = processed.replace(/{{[^}]+}}/g, '');

    return processed;
  }

  // Formatar valor da variável
  private formatVariableValue(value: any): string {
    if (value === null || value === undefined) {
      return '';
    }

    if (value instanceof Date) {
      return value.toLocaleString('pt-BR');
    }

    if (typeof value === 'number') {
      return value.toLocaleString('pt-BR');
    }

    return String(value);
  }

  // Validar template
  async validateTemplate(content: string, variables?: TemplateVariable[]): Promise<{
    isValid: boolean;
    errors: string[];
    unusedVariables: string[];
  }> {
    const errors: string[] = [];
    const unusedVariables: string[] = [];

    // Extrair variáveis do template
    const templateVariables = this.extractVariables(content);

    if (variables) {
      // Verificar variáveis obrigatórias
      const requiredVariables = variables
        .filter(v => v.required)
        .map(v => v.name);

      requiredVariables.forEach(varName => {
        if (!templateVariables.includes(varName)) {
          errors.push(`Variável obrigatória '${varName}' não encontrada no template`);
        }
      });

      // Verificar variáveis não utilizadas
      variables.forEach(variable => {
        if (!templateVariables.includes(variable.name)) {
          unusedVariables.push(variable.name);
        }
      });
    }

    return {
      isValid: errors.length === 0,
      errors,
      unusedVariables
    };
  }

  // Extrair variáveis do template
  private extractVariables(template: string): string[] {
    const regex = /{{([^}]+)}}/g;
    const variables: string[] = [];
    let match;

    while ((match = regex.exec(template)) !== null) {
      const varName = match[1].trim();
      if (!variables.includes(varName)) {
        variables.push(varName);
      }
    }

    return variables;
  }

  // Criar templates padrão do sistema
  async createDefaultTemplates(tenantId?: string): Promise<void> {
    const defaultTemplates = this.getDefaultTemplates();

    for (const [name, template] of Object.entries(defaultTemplates)) {
      const existingTemplate = await this.getTemplateByName(name, tenantId);
      
      if (!existingTemplate) {
        await this.createTemplate({
          name,
          type: NotificationType.EMAIL, // Padrão para email
          subject: template.subject,
          content: template.content,
          category: this.getCategoryFromName(name),
          tenantId,
          variables: template.variables.map(varName => ({
            name: varName,
            description: `Variável ${varName}`,
            type: 'string',
            required: true
          }))
        });
      }
    }
  }

  // Obter templates padrão
  private getDefaultTemplates(): DefaultTemplates {
    return {
      BOOKING_CONFIRMATION: {
        subject: 'Agendamento Confirmado - {{serviceName}}',
        content: `Olá {{clientName}},

Seu agendamento foi confirmado com sucesso!

📅 Data: {{date}}
🕐 Horário: {{time}}
👨‍💼 Profissional: {{professionalName}}
💼 Serviço: {{serviceName}}
💰 Valor: {{price}}

📍 Local: {{businessName}}
{{businessAddress}}

Em caso de dúvidas, entre em contato conosco.

Obrigado!`,
        variables: ['clientName', 'date', 'time', 'professionalName', 'serviceName', 'price', 'businessName', 'businessAddress']
      },
      BOOKING_REMINDER: {
        subject: 'Lembrete: Seu agendamento é amanhã - {{serviceName}}',
        content: `Olá {{clientName}},

Este é um lembrete do seu agendamento:

📅 Data: {{date}}
🕐 Horário: {{time}}
👨‍💼 Profissional: {{professionalName}}
💼 Serviço: {{serviceName}}

📍 Local: {{businessName}}
{{businessAddress}}

Nos vemos em breve!

Para reagendar ou cancelar, acesse: {{bookingUrl}}`,
        variables: ['clientName', 'date', 'time', 'professionalName', 'serviceName', 'businessName', 'businessAddress', 'bookingUrl']
      },
      BOOKING_CANCELLATION: {
        subject: 'Agendamento Cancelado - {{serviceName}}',
        content: `Olá {{clientName}},

Seu agendamento foi cancelado:

📅 Data: {{date}}
🕐 Horário: {{time}}
💼 Serviço: {{serviceName}}
👨‍💼 Profissional: {{professionalName}}

{{cancellationReason}}

Para fazer um novo agendamento, acesse: {{bookingUrl}}

Obrigado pela compreensão!`,
        variables: ['clientName', 'date', 'time', 'serviceName', 'professionalName', 'cancellationReason', 'bookingUrl']
      },
      BOOKING_RESCHEDULED: {
        subject: 'Agendamento Reagendado - {{serviceName}}',
        content: `Olá {{clientName}},

Seu agendamento foi reagendado:

📅 Nova Data: {{newDate}}
🕐 Novo Horário: {{newTime}}
💼 Serviço: {{serviceName}}
👨‍💼 Profissional: {{professionalName}}

📍 Local: {{businessName}}
{{businessAddress}}

Nos vemos na nova data!

Para mais alterações, acesse: {{bookingUrl}}`,
        variables: ['clientName', 'newDate', 'newTime', 'serviceName', 'professionalName', 'businessName', 'businessAddress', 'bookingUrl']
      }
    };
  }

  // Obter categoria baseada no nome do template
  private getCategoryFromName(name: string): NotificationCategory {
    if (name.includes('CONFIRMATION')) return NotificationCategory.CONFIRMATION;
    if (name.includes('REMINDER')) return NotificationCategory.REMINDER;
    if (name.includes('CANCELLATION')) return NotificationCategory.CANCELLATION;
    if (name.includes('RESCHEDULED')) return NotificationCategory.SYSTEM;
    return NotificationCategory.SYSTEM;
  }

  // Formatar template do banco para o tipo TypeScript
  private formatTemplate(template: any): NotificationTemplate {
    return {
      ...template,
      variables: template.variables ? JSON.parse(template.variables) : []
    };
  }

  // Duplicar template para outro tenant
  async duplicateTemplate(
    templateId: string, 
    targetTenantId: string
  ): Promise<NotificationTemplate | null> {
    const sourceTemplate = await this.getTemplateById(templateId);
    if (!sourceTemplate) {
      return null;
    }

    const duplicatedTemplate = await this.createTemplate({
      name: sourceTemplate.name,
      type: sourceTemplate.type,
      subject: sourceTemplate.subject,
      content: sourceTemplate.content,
      language: sourceTemplate.language,
      category: sourceTemplate.category,
      tenantId: targetTenantId,
      variables: sourceTemplate.variables
    });

    return duplicatedTemplate;
  }

  // Obter estatísticas de uso do template
  async getTemplateStats(templateId: string): Promise<{
    totalNotifications: number;
    sentNotifications: number;
    deliveredNotifications: number;
    failedNotifications: number;
    deliveryRate: number;
  }> {
    const stats = await prisma.notification.groupBy({
      by: ['status'],
      where: { templateId },
      _count: { status: true }
    });

    const totalNotifications = stats.reduce((sum, stat) => sum + stat._count.status, 0);
    const sentNotifications = stats.find(s => s.status === 'SENT')?._count.status || 0;
    const deliveredNotifications = stats.find(s => s.status === 'DELIVERED')?._count.status || 0;
    const failedNotifications = stats.find(s => s.status === 'FAILED')?._count.status || 0;

    const deliveryRate = totalNotifications > 0 
      ? ((sentNotifications + deliveredNotifications) / totalNotifications) * 100 
      : 0;

    return {
      totalNotifications,
      sentNotifications,
      deliveredNotifications,
      failedNotifications,
      deliveryRate: Math.round(deliveryRate * 100) / 100
    };
  }
}

export const notificationTemplateService = new NotificationTemplateService();