import { PrismaClient } from '@prisma/client';
import { BookingHistory, BookingMetrics, BookingAction, BookingStatus } from '../types/booking.types';

const prisma = new PrismaClient();

export interface BookingHistoryEntry {
  id?: string;
  bookingId: string;
  action: BookingAction;
  previousStatus?: BookingStatus;
  newStatus?: BookingStatus;
  previousStartTime?: Date;
  newStartTime?: Date;
  reason?: string;
  performedBy: string;
  performedAt?: Date;
  metadata?: any;
}

export interface BookingMetricsFilters {
  tenantId?: string;
  professionalId?: string;
  startDate?: Date;
  endDate?: Date;
  period?: 'day' | 'week' | 'month' | 'year';
}

export class BookingHistoryService {

  /**
   * Cria uma entrada no histórico de agendamentos
   */
  async createHistoryEntry(data: BookingHistoryEntry): Promise<void> {
    try {
      await prisma.bookingHistory.create({
        data: {
          bookingId: data.bookingId,
          action: data.action,
          previousStatus: data.previousStatus,
          newStatus: data.newStatus,
          previousStartTime: data.previousStartTime,
          newStartTime: data.newStartTime,
          reason: data.reason,
          performedBy: data.performedBy,
          performedAt: data.performedAt || new Date(),
          metadata: data.metadata ? JSON.stringify(data.metadata) : null
        }
      });
    } catch (error) {
      console.error('Erro ao criar entrada no histórico:', error);
      // Não falhar a operação principal se o histórico falhar
    }
  }

  /**
   * Busca o histórico de um agendamento específico
   */
  async getBookingHistory(bookingId: string): Promise<BookingHistory[]> {
    const history = await prisma.bookingHistory.findMany({
      where: { bookingId },
      include: {
        performedByUser: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      },
      orderBy: {
        performedAt: 'desc'
      }
    });

    return history.map(entry => ({
      id: entry.id,
      bookingId: entry.bookingId,
      action: entry.action as BookingAction,
      previousStatus: entry.previousStatus as BookingStatus,
      newStatus: entry.newStatus as BookingStatus,
      previousStartTime: entry.previousStartTime,
      newStartTime: entry.newStartTime,
      reason: entry.reason,
      performedBy: entry.performedBy,
      performedAt: entry.performedAt
    }));
  }

  /**
   * Calcula métricas de agendamentos
   */
  async calculateBookingMetrics(filters: BookingMetricsFilters): Promise<BookingMetrics> {
    const where: any = {};

    if (filters.tenantId) where.tenantId = filters.tenantId;
    if (filters.professionalId) where.professionalId = filters.professionalId;

    if (filters.startDate || filters.endDate) {
      where.createdAt = {};
      if (filters.startDate) where.createdAt.gte = filters.startDate;
      if (filters.endDate) where.createdAt.lte = filters.endDate;
    }

    // Buscar todos os agendamentos no período
    const bookings = await prisma.booking.findMany({
      where,
      select: {
        id: true,
        status: true,
        price: true,
        createdAt: true
      }
    });

    const totalBookings = bookings.length;
    const completedBookings = bookings.filter(b => b.status === 'COMPLETED').length;
    const cancelledBookings = bookings.filter(b => b.status === 'CANCELLED').length;
    const noShowBookings = bookings.filter(b => b.status === 'NO_SHOW').length;

    const completionRate = totalBookings > 0 ? (completedBookings / totalBookings) * 100 : 0;
    const cancellationRate = totalBookings > 0 ? (cancelledBookings / totalBookings) * 100 : 0;
    const noShowRate = totalBookings > 0 ? (noShowBookings / totalBookings) * 100 : 0;

    const totalRevenue = bookings
      .filter(b => b.status === 'COMPLETED')
      .reduce((sum, b) => sum + b.price, 0);

    const averageBookingValue = completedBookings > 0 ? totalRevenue / completedBookings : 0;

    return {
      totalBookings,
      completedBookings,
      cancelledBookings,
      noShowBookings,
      completionRate: Math.round(completionRate * 100) / 100,
      cancellationRate: Math.round(cancellationRate * 100) / 100,
      noShowRate: Math.round(noShowRate * 100) / 100,
      averageBookingValue: Math.round(averageBookingValue * 100) / 100,
      totalRevenue: Math.round(totalRevenue * 100) / 100
    };
  }

  /**
   * Busca métricas detalhadas por período
   */
  async getDetailedMetrics(filters: BookingMetricsFilters): Promise<any> {
    const where: any = {};

    if (filters.tenantId) where.tenantId = filters.tenantId;
    if (filters.professionalId) where.professionalId = filters.professionalId;

    if (filters.startDate || filters.endDate) {
      where.createdAt = {};
      if (filters.startDate) where.createdAt.gte = filters.startDate;
      if (filters.endDate) where.createdAt.lte = filters.endDate;
    }

    // Métricas por status
    const statusMetrics = await prisma.booking.groupBy({
      by: ['status'],
      where,
      _count: {
        id: true
      },
      _sum: {
        price: true
      }
    });

    // Métricas por profissional
    const professionalMetrics = await prisma.booking.groupBy({
      by: ['professionalId'],
      where,
      _count: {
        id: true
      },
      _sum: {
        price: true
      }
    });

    // Métricas por serviço
    const serviceMetrics = await prisma.booking.groupBy({
      by: ['serviceId'],
      where,
      _count: {
        id: true
      },
      _sum: {
        price: true
      }
    });

    return {
      byStatus: statusMetrics.map(metric => ({
        status: metric.status,
        count: metric._count.id,
        revenue: metric._sum.price || 0
      })),
      byProfessional: professionalMetrics.map(metric => ({
        professionalId: metric.professionalId,
        count: metric._count.id,
        revenue: metric._sum.price || 0
      })),
      byService: serviceMetrics.map(metric => ({
        serviceId: metric.serviceId,
        count: metric._count.id,
        revenue: metric._sum.price || 0
      }))
    };
  }

  /**
   * Busca tendências de agendamentos
   */
  async getBookingTrends(filters: BookingMetricsFilters): Promise<any> {
    const where: any = {};

    if (filters.tenantId) where.tenantId = filters.tenantId;
    if (filters.professionalId) where.professionalId = filters.professionalId;

    // Definir período padrão se não especificado
    const endDate = filters.endDate || new Date();
    const startDate = filters.startDate || new Date(endDate.getTime() - 30 * 24 * 60 * 60 * 1000); // 30 dias atrás

    where.createdAt = {
      gte: startDate,
      lte: endDate
    };

    // Buscar agendamentos no período
    const bookings = await prisma.booking.findMany({
      where,
      select: {
        id: true,
        status: true,
        price: true,
        createdAt: true,
        startTime: true
      },
      orderBy: {
        createdAt: 'asc'
      }
    });

    // Agrupar por dia
    const dailyData: { [key: string]: any } = {};

    bookings.forEach(booking => {
      const dateKey = booking.createdAt.toISOString().split('T')[0];
      
      if (!dailyData[dateKey]) {
        dailyData[dateKey] = {
          date: dateKey,
          total: 0,
          completed: 0,
          cancelled: 0,
          noShow: 0,
          revenue: 0
        };
      }

      dailyData[dateKey].total++;
      
      if (booking.status === 'COMPLETED') {
        dailyData[dateKey].completed++;
        dailyData[dateKey].revenue += booking.price;
      } else if (booking.status === 'CANCELLED') {
        dailyData[dateKey].cancelled++;
      } else if (booking.status === 'NO_SHOW') {
        dailyData[dateKey].noShow++;
      }
    });

    return Object.values(dailyData);
  }

  /**
   * Identifica padrões de cancelamento
   */
  async getCancellationPatterns(filters: BookingMetricsFilters): Promise<any> {
    const where: any = {
      status: {
        in: ['CANCELLED', 'NO_SHOW']
      }
    };

    if (filters.tenantId) where.tenantId = filters.tenantId;
    if (filters.professionalId) where.professionalId = filters.professionalId;

    if (filters.startDate || filters.endDate) {
      where.createdAt = {};
      if (filters.startDate) where.createdAt.gte = filters.startDate;
      if (filters.endDate) where.createdAt.lte = filters.endDate;
    }

    const cancelledBookings = await prisma.booking.findMany({
      where,
      include: {
        client: {
          select: {
            id: true,
            name: true
          }
        },
        service: {
          select: {
            id: true,
            name: true,
            category: true
          }
        }
      }
    });

    // Analisar padrões
    const patterns = {
      byHour: {} as { [key: number]: number },
      byDayOfWeek: {} as { [key: number]: number },
      byService: {} as { [key: string]: number },
      byClient: {} as { [key: string]: number },
      averageHoursBeforeCancellation: 0
    };

    let totalHoursBeforeCancellation = 0;
    let validCancellations = 0;

    cancelledBookings.forEach(booking => {
      // Por hora do dia
      const hour = booking.startTime.getHours();
      patterns.byHour[hour] = (patterns.byHour[hour] || 0) + 1;

      // Por dia da semana
      const dayOfWeek = booking.startTime.getDay();
      patterns.byDayOfWeek[dayOfWeek] = (patterns.byDayOfWeek[dayOfWeek] || 0) + 1;

      // Por serviço
      const serviceName = booking.service.name;
      patterns.byService[serviceName] = (patterns.byService[serviceName] || 0) + 1;

      // Por cliente
      const clientName = booking.client.name;
      patterns.byClient[clientName] = (patterns.byClient[clientName] || 0) + 1;

      // Calcular horas antes do cancelamento
      const hoursBeforeCancellation = (booking.startTime.getTime() - booking.updatedAt.getTime()) / (1000 * 60 * 60);
      if (hoursBeforeCancellation > 0) {
        totalHoursBeforeCancellation += hoursBeforeCancellation;
        validCancellations++;
      }
    });

    patterns.averageHoursBeforeCancellation = validCancellations > 0 
      ? Math.round((totalHoursBeforeCancellation / validCancellations) * 100) / 100 
      : 0;

    return patterns;
  }

  /**
   * Busca clientes com maior taxa de cancelamento
   */
  async getHighCancellationClients(tenantId: string, limit: number = 10): Promise<any[]> {
    const clients = await prisma.user.findMany({
      where: {
        tenantId,
        bookings: {
          some: {}
        }
      },
      include: {
        bookings: {
          select: {
            id: true,
            status: true
          }
        }
      }
    });

    const clientStats = clients.map(client => {
      const totalBookings = client.bookings.length;
      const cancelledBookings = client.bookings.filter(b => 
        ['CANCELLED', 'NO_SHOW'].includes(b.status)
      ).length;
      
      const cancellationRate = totalBookings > 0 ? (cancelledBookings / totalBookings) * 100 : 0;

      return {
        clientId: client.id,
        clientName: client.name,
        clientEmail: client.email,
        totalBookings,
        cancelledBookings,
        cancellationRate: Math.round(cancellationRate * 100) / 100
      };
    });

    return clientStats
      .filter(stat => stat.totalBookings >= 3) // Apenas clientes com pelo menos 3 agendamentos
      .sort((a, b) => b.cancellationRate - a.cancellationRate)
      .slice(0, limit);
  }
}

export const bookingHistoryService = new BookingHistoryService();