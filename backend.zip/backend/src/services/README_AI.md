# AI Service - Agenda Lotada 24h

## Visão Geral

O AI Service implementa funcionalidades de inteligência artificial para o sistema de agendamento, incluindo:

- **Chatbot inteligente** para interação com usuários
- **Sistema de recomendações** personalizadas
- **Analytics preditivos** para insights de negócio
- **Sugestões de campanhas** automatizadas

## Funcionalidades Implementadas

### 1. Chatbot Básico (9.1)

- Processamento de linguagem natural com OpenAI
- Detecção de intents (agendamento, cancelamento, informações)
- Contexto de conversa mantido em sessões
- Sugestões automáticas baseadas no intent
- Cache de respostas para performance

**Endpoints:**
- `POST /api/ai/chat` - Enviar mensagem para o chatbot
- `POST /api/ai/sessions` - Criar nova sessão de chat
- `GET /api/ai/sessions/:id/history` - Buscar histórico da conversa

### 2. Sistema de Recomendações (9.2)

- Recomendações de serviços baseadas no histórico
- Sugestões de profissionais qualificados
- Horários otimizados baseados em padrões do usuário
- Promoções personalizadas

**Endpoints:**
- `GET /api/ai/recommendations` - Buscar recomendações para o usuário
- `GET /api/ai/recommendations?type=SERVICE` - Filtrar por tipo

### 3. Analytics Preditivos (9.3)

- Análise de períodos ociosos
- Previsão de demanda
- Detecção de clientes em risco de abandono
- Otimizações de preço
- Sugestões de campanhas automáticas

**Endpoints:**
- `GET /api/ai/insights` - Buscar insights (Admin/Professional)
- `GET /api/ai/campaign-suggestions` - Sugestões de campanha (Admin)

## Configuração

### Variáveis de Ambiente

```env
# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key
OPENAI_MODEL=gpt-3.5-turbo
OPENAI_TEMPERATURE=0.7
OPENAI_MAX_TOKENS=1000

# AI Service Configuration
AI_ENABLE_RECOMMENDATIONS=true
AI_ENABLE_INSIGHTS=true
AI_CACHE_ENABLED=true
AI_CACHE_TTL=3600
```

## Exemplos de Uso

### Chatbot

```javascript
// Enviar mensagem para o chatbot
const response = await fetch('/api/ai/chat', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer ' + token,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    message: 'Quero agendar um horário',
    sessionId: 'session-123' // opcional
  })
});

const data = await response.json();
console.log(data.response); // Resposta do chatbot
console.log(data.suggestions); // Sugestões automáticas
```

### Recomendações

```javascript
// Buscar recomendações de serviços
const recommendations = await fetch('/api/ai/recommendations?type=SERVICE', {
  headers: { 'Authorization': 'Bearer ' + token }
});

const data = await recommendations.json();
data.recommendations.forEach(rec => {
  console.log(`${rec.title} - Confiança: ${rec.confidence}`);
});
```

### Insights

```javascript
// Buscar insights (apenas Admin/Professional)
const insights = await fetch('/api/ai/insights', {
  headers: { 'Authorization': 'Bearer ' + token }
});

const data = await insights.json();
data.insights.forEach(insight => {
  console.log(`${insight.title}: ${insight.description}`);
});
```

## Tipos de Intent Detectados

- `book_appointment` - Agendamento
- `check_availability` - Verificar disponibilidade
- `cancel_booking` - Cancelamento
- `reschedule` - Reagendamento
- `service_info` - Informações sobre serviços
- `professional_info` - Informações sobre profissionais
- `greeting` - Saudação
- `unknown` - Intent não reconhecido

## Tipos de Recomendações

- `SERVICE` - Recomendações de serviços
- `PROFESSIONAL` - Recomendações de profissionais
- `TIME_SLOT` - Horários otimizados
- `PROMOTION` - Promoções personalizadas

## Tipos de Insights

- `IDLE_PERIOD` - Períodos ociosos identificados
- `DEMAND_PREDICTION` - Previsões de demanda
- `CHURN_RISK` - Clientes em risco de abandono
- `PRICING_OPTIMIZATION` - Otimizações de preço

## Segurança e Permissões

- Todas as rotas requerem autenticação JWT
- Insights e campanhas são restritos a Admin/Professional
- Dados são isolados por tenant
- Cache com TTL configurável

## Performance

- Cache Redis para respostas frequentes
- Paginação em listagens
- Timeouts configuráveis
- Retry automático para falhas da OpenAI

## Próximos Passos

1. Implementar sistema de avaliações para melhorar recomendações
2. Adicionar mais tipos de insights
3. Integrar com sistema de campanhas real
4. Implementar A/B testing para otimização
5. Adicionar métricas de performance do chatbot