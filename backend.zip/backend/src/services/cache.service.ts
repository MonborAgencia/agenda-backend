import { redisClient } from '../config/redis';

export interface CacheOptions {
  ttl?: number; // Time to live in seconds
  prefix?: string;
}

export interface CacheMetrics {
  hits: number;
  misses: number;
  hitRate: number;
  totalRequests: number;
  avgResponseTime: number;
}

export class CacheService {
  private metrics: Map<string, { hits: number; misses: number; totalTime: number }> = new Map();

  /**
   * Get value from cache
   */
  async get<T>(key: string, options?: CacheOptions): Promise<T | null> {
    const startTime = Date.now();
    const fullKey = this.buildKey(key, options?.prefix);
    
    try {
      const value = await redisClient.get(fullKey);
      const endTime = Date.now();
      
      this.updateMetrics(key, value !== null, endTime - startTime);
      
      if (value === null) {
        return null;
      }
      
      return JSON.parse(value);
    } catch (error) {
      console.error(`Cache get error for key ${fullKey}:`, error);
      return null;
    }
  }

  /**
   * Set value in cache
   */
  async set<T>(key: string, value: T, options?: CacheOptions): Promise<boolean> {
    const fullKey = this.buildKey(key, options?.prefix);
    
    try {
      const serializedValue = JSON.stringify(value);
      
      if (options?.ttl) {
        await redisClient.setex(fullKey, options.ttl, serializedValue);
      } else {
        await redisClient.set(fullKey, serializedValue);
      }
      
      return true;
    } catch (error) {
      console.error(`Cache set error for key ${fullKey}:`, error);
      return false;
    }
  }

  /**
   * Delete value from cache
   */
  async del(key: string, options?: CacheOptions): Promise<boolean> {
    const fullKey = this.buildKey(key, options?.prefix);
    
    try {
      const result = await redisClient.del(fullKey);
      return result > 0;
    } catch (error) {
      console.error(`Cache delete error for key ${fullKey}:`, error);
      return false;
    }
  }

  /**
   * Delete multiple keys by pattern
   */
  async delPattern(pattern: string, options?: CacheOptions): Promise<number> {
    const fullPattern = this.buildKey(pattern, options?.prefix);
    
    try {
      const keys = await redisClient.keys(fullPattern);
      if (keys.length === 0) {
        return 0;
      }
      
      const result = await redisClient.del(...keys);
      return result;
    } catch (error) {
      console.error(`Cache delete pattern error for pattern ${fullPattern}:`, error);
      return 0;
    }
  }

  /**
   * Check if key exists in cache
   */
  async exists(key: string, options?: CacheOptions): Promise<boolean> {
    const fullKey = this.buildKey(key, options?.prefix);
    
    try {
      const result = await redisClient.exists(fullKey);
      return result === 1;
    } catch (error) {
      console.error(`Cache exists error for key ${fullKey}:`, error);
      return false;
    }
  }

  /**
   * Get or set pattern - if key doesn't exist, execute callback and cache result
   */
  async getOrSet<T>(
    key: string, 
    callback: () => Promise<T>, 
    options?: CacheOptions
  ): Promise<T> {
    const cached = await this.get<T>(key, options);
    
    if (cached !== null) {
      return cached;
    }
    
    const result = await callback();
    await this.set(key, result, options);
    
    return result;
  }

  /**
   * Increment counter in cache
   */
  async increment(key: string, options?: CacheOptions): Promise<number> {
    const fullKey = this.buildKey(key, options?.prefix);
    
    try {
      const result = await redisClient.incr(fullKey);
      
      if (options?.ttl) {
        await redisClient.expire(fullKey, options.ttl);
      }
      
      return result;
    } catch (error) {
      console.error(`Cache increment error for key ${fullKey}:`, error);
      return 0;
    }
  }

  /**
   * Set expiration for key
   */
  async expire(key: string, ttl: number, options?: CacheOptions): Promise<boolean> {
    const fullKey = this.buildKey(key, options?.prefix);
    
    try {
      const result = await redisClient.expire(fullKey, ttl);
      return result === 1;
    } catch (error) {
      console.error(`Cache expire error for key ${fullKey}:`, error);
      return false;
    }
  }

  /**
   * Get cache metrics for a specific key pattern
   */
  getMetrics(keyPattern?: string): CacheMetrics {
    let totalHits = 0;
    let totalMisses = 0;
    let totalTime = 0;
    let matchingKeys = 0;

    for (const [key, metrics] of this.metrics.entries()) {
      if (!keyPattern || key.includes(keyPattern)) {
        totalHits += metrics.hits;
        totalMisses += metrics.misses;
        totalTime += metrics.totalTime;
        matchingKeys++;
      }
    }

    const totalRequests = totalHits + totalMisses;
    const hitRate = totalRequests > 0 ? (totalHits / totalRequests) * 100 : 0;
    const avgResponseTime = totalRequests > 0 ? totalTime / totalRequests : 0;

    return {
      hits: totalHits,
      misses: totalMisses,
      hitRate: Math.round(hitRate * 100) / 100,
      totalRequests,
      avgResponseTime: Math.round(avgResponseTime * 100) / 100
    };
  }

  /**
   * Clear all metrics
   */
  clearMetrics(): void {
    this.metrics.clear();
  }

  /**
   * Build full cache key with prefix
   */
  private buildKey(key: string, prefix?: string): string {
    const basePrefix = process.env.CACHE_PREFIX || 'agenda-lotada';
    const fullPrefix = prefix ? `${basePrefix}:${prefix}` : basePrefix;
    return `${fullPrefix}:${key}`;
  }

  /**
   * Update cache metrics
   */
  private updateMetrics(key: string, isHit: boolean, responseTime: number): void {
    const existing = this.metrics.get(key) || { hits: 0, misses: 0, totalTime: 0 };
    
    if (isHit) {
      existing.hits++;
    } else {
      existing.misses++;
    }
    
    existing.totalTime += responseTime;
    this.metrics.set(key, existing);
  }
}

// Export singleton instance
export const cacheService = new CacheService();