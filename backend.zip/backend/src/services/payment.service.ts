import { PrismaClient } from '@prisma/client';
import { stripe, stripeConfig, brazilConfig } from '../config/stripe';
import {
  Payment,
  PaymentIntent,
  PaymentMethod,
  CreatePaymentRequest,
  CreatePaymentResponse,
  RefundPaymentRequest,
  RefundPaymentResponse,
  PaymentStatus,
  PaymentStats,
  StripeCustomer
} from '../types/payment.types';
import Stripe from 'stripe';

const prisma = new PrismaClient();

export class PaymentService {
  /**
   * Cria um novo pagamento e Payment Intent no Stripe
   */
  async createPayment(data: CreatePaymentRequest): Promise<CreatePaymentResponse> {
    try {
      // Buscar informações do agendamento
      const booking = await prisma.booking.findUnique({
        where: { id: data.bookingId },
        include: {
          client: true,
          service: true,
          professional: {
            include: { user: true }
          }
        }
      });

      if (!booking) {
        throw new Error('Agendamento não encontrado');
      }

      // Criar ou buscar cliente no Stripe
      const stripeCustomer = await this.getOrCreateStripeCustomer(booking.client);

      // Criar Payment Intent no Stripe
      const paymentIntent = await stripe.paymentIntents.create({
        amount: data.amount,
        currency: data.currency || brazilConfig.currency,
        customer: stripeCustomer.id,
        payment_method_types: data.paymentMethodTypes || brazilConfig.paymentMethodTypes,
        description: data.description || `Pagamento para ${booking.service.name}`,
        metadata: {
          bookingId: data.bookingId,
          clientId: booking.clientId,
          professionalId: booking.professionalId,
          serviceId: booking.serviceId,
          ...data.metadata
        },
        automatic_payment_methods: {
          enabled: true,
        },
      });

      // Salvar pagamento no banco
      const payment = await prisma.payment.create({
        data: {
          bookingId: data.bookingId,
          stripeCustomerId: stripeCustomer.id,
          amount: data.amount,
          currency: data.currency || brazilConfig.currency,
          status: PaymentStatus.PENDING,
          description: data.description,
          metadata: JSON.stringify(data.metadata || {}),
        }
      });

      // Salvar Payment Intent no banco
      const paymentIntentRecord = await prisma.paymentIntent.create({
        data: {
          paymentId: payment.id,
          stripePaymentIntentId: paymentIntent.id,
          amount: data.amount,
          currency: data.currency || brazilConfig.currency,
          status: paymentIntent.status,
          clientSecret: paymentIntent.client_secret,
          paymentMethodTypes: JSON.stringify(data.paymentMethodTypes || brazilConfig.paymentMethodTypes),
          metadata: JSON.stringify(paymentIntent.metadata),
        }
      });

      // Atualizar payment com o ID do Stripe
      const updatedPayment = await prisma.payment.update({
        where: { id: payment.id },
        data: { stripePaymentId: paymentIntent.id }
      });

      return {
        payment: updatedPayment as Payment,
        paymentIntent: paymentIntentRecord as PaymentIntent,
        clientSecret: paymentIntent.client_secret!
      };

    } catch (error) {
      console.error('Erro ao criar pagamento:', error);
      throw new Error(`Falha ao criar pagamento: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    }
  }

  /**
   * Busca ou cria um cliente no Stripe
   */
  private async getOrCreateStripeCustomer(user: any): Promise<StripeCustomer> {
    try {
      // Verificar se já existe um customer no Stripe
      const existingCustomers = await stripe.customers.list({
        email: user.email,
        limit: 1
      });

      if (existingCustomers.data.length > 0) {
        return existingCustomers.data[0] as StripeCustomer;
      }

      // Criar novo customer no Stripe
      const customer = await stripe.customers.create({
        email: user.email,
        name: user.name,
        phone: user.phone,
        metadata: {
          userId: user.id,
        }
      });

      return customer as StripeCustomer;

    } catch (error) {
      console.error('Erro ao criar/buscar cliente no Stripe:', error);
      throw error;
    }
  }

  /**
   * Confirma um pagamento
   */
  async confirmPayment(paymentIntentId: string): Promise<Payment> {
    try {
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      
      const payment = await prisma.payment.findFirst({
        where: { stripePaymentId: paymentIntentId }
      });

      if (!payment) {
        throw new Error('Pagamento não encontrado');
      }

      const updatedPayment = await prisma.payment.update({
        where: { id: payment.id },
        data: {
          status: paymentIntent.status === 'succeeded' ? PaymentStatus.SUCCEEDED : PaymentStatus.FAILED,
          paidAt: paymentIntent.status === 'succeeded' ? new Date() : null,
          failureReason: paymentIntent.last_payment_error?.message
        }
      });

      // Atualizar status do agendamento se pagamento foi bem-sucedido
      if (paymentIntent.status === 'succeeded') {
        await prisma.booking.update({
          where: { id: payment.bookingId },
          data: { paymentStatus: 'PAID' }
        });
      }

      return updatedPayment as Payment;

    } catch (error) {
      console.error('Erro ao confirmar pagamento:', error);
      throw error;
    }
  }

  /**
   * Processa reembolso de pagamento
   */
  async refundPayment(data: RefundPaymentRequest): Promise<RefundPaymentResponse> {
    try {
      const payment = await prisma.payment.findUnique({
        where: { id: data.paymentId }
      });

      if (!payment) {
        throw new Error('Pagamento não encontrado');
      }

      if (!payment.stripePaymentId) {
        throw new Error('ID do pagamento no Stripe não encontrado');
      }

      if (payment.status !== PaymentStatus.SUCCEEDED) {
        throw new Error('Apenas pagamentos bem-sucedidos podem ser reembolsados');
      }

      // Criar reembolso no Stripe
      const refund = await stripe.refunds.create({
        payment_intent: payment.stripePaymentId,
        amount: data.amount, // se não especificado, reembolsa o valor total
        reason: 'requested_by_customer',
        metadata: {
          paymentId: payment.id,
          reason: data.reason || 'Reembolso solicitado'
        }
      });

      // Atualizar pagamento no banco
      const updatedPayment = await prisma.payment.update({
        where: { id: payment.id },
        data: {
          status: PaymentStatus.REFUNDED,
          refundAmount: refund.amount,
          refundReason: data.reason,
          refundedAt: new Date()
        }
      });

      // Atualizar status do agendamento
      await prisma.booking.update({
        where: { id: payment.bookingId },
        data: { paymentStatus: 'REFUNDED' }
      });

      return {
        payment: updatedPayment as Payment,
        refundId: refund.id,
        status: refund.status
      };

    } catch (error) {
      console.error('Erro ao processar reembolso:', error);
      throw error;
    }
  }

  /**
   * Lista pagamentos com filtros
   */
  async listPayments(filters: {
    userId?: string;
    status?: PaymentStatus;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
  }): Promise<{ payments: Payment[]; total: number }> {
    try {
      const where: any = {};

      if (filters.userId) {
        where.booking = {
          clientId: filters.userId
        };
      }

      if (filters.status) {
        where.status = filters.status;
      }

      if (filters.startDate || filters.endDate) {
        where.createdAt = {};
        if (filters.startDate) {
          where.createdAt.gte = filters.startDate;
        }
        if (filters.endDate) {
          where.createdAt.lte = filters.endDate;
        }
      }

      const [payments, total] = await Promise.all([
        prisma.payment.findMany({
          where,
          include: {
            booking: {
              include: {
                client: true,
                service: true,
                professional: {
                  include: { user: true }
                }
              }
            }
          },
          orderBy: { createdAt: 'desc' },
          take: filters.limit || 50,
          skip: filters.offset || 0
        }),
        prisma.payment.count({ where })
      ]);

      return {
        payments: payments as Payment[],
        total
      };

    } catch (error) {
      console.error('Erro ao listar pagamentos:', error);
      throw error;
    }
  }

  /**
   * Busca pagamento por ID
   */
  async getPaymentById(id: string): Promise<Payment | null> {
    try {
      const payment = await prisma.payment.findUnique({
        where: { id },
        include: {
          booking: {
            include: {
              client: true,
              service: true,
              professional: {
                include: { user: true }
              }
            }
          },
          paymentIntents: true
        }
      });

      return payment as Payment | null;

    } catch (error) {
      console.error('Erro ao buscar pagamento:', error);
      throw error;
    }
  }

  /**
   * Busca pagamento por agendamento
   */
  async getPaymentByBookingId(bookingId: string): Promise<Payment | null> {
    try {
      const payment = await prisma.payment.findUnique({
        where: { bookingId },
        include: {
          booking: {
            include: {
              client: true,
              service: true
            }
          },
          paymentIntents: true
        }
      });

      return payment as Payment | null;

    } catch (error) {
      console.error('Erro ao buscar pagamento por agendamento:', error);
      throw error;
    }
  }

  /**
   * Gera estatísticas de pagamentos
   */
  async getPaymentStats(filters: {
    tenantId?: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<PaymentStats> {
    try {
      const where: any = {
        status: PaymentStatus.SUCCEEDED
      };

      if (filters.tenantId) {
        where.booking = {
          tenantId: filters.tenantId
        };
      }

      if (filters.startDate || filters.endDate) {
        where.createdAt = {};
        if (filters.startDate) {
          where.createdAt.gte = filters.startDate;
        }
        if (filters.endDate) {
          where.createdAt.lte = filters.endDate;
        }
      }

      const payments = await prisma.payment.findMany({
        where,
        include: {
          booking: true
        }
      });

      const totalRevenue = payments.reduce((sum, payment) => sum + payment.amount, 0) / 100; // converter de centavos
      const totalTransactions = payments.length;
      
      const failedPayments = await prisma.payment.count({
        where: {
          ...where,
          status: PaymentStatus.FAILED
        }
      });

      const refundedPayments = await prisma.payment.findMany({
        where: {
          ...where,
          status: PaymentStatus.REFUNDED
        }
      });

      const refundedAmount = refundedPayments.reduce((sum, payment) => sum + (payment.refundAmount || 0), 0) / 100;

      // Agrupar por método de pagamento
      const paymentMethodBreakdown: Record<string, number> = {};
      payments.forEach(payment => {
        const method = payment.paymentMethod || 'unknown';
        paymentMethodBreakdown[method] = (paymentMethodBreakdown[method] || 0) + 1;
      });

      // Receita mensal (últimos 12 meses)
      const monthlyRevenue = await this.getMonthlyRevenue(filters.tenantId);

      return {
        totalRevenue,
        totalTransactions,
        successfulPayments: totalTransactions,
        failedPayments,
        refundedAmount,
        averageTransactionValue: totalTransactions > 0 ? totalRevenue / totalTransactions : 0,
        paymentMethodBreakdown,
        monthlyRevenue
      };

    } catch (error) {
      console.error('Erro ao gerar estatísticas de pagamentos:', error);
      throw error;
    }
  }

  /**
   * Gera receita mensal dos últimos 12 meses
   */
  private async getMonthlyRevenue(tenantId?: string): Promise<Array<{ month: string; revenue: number; transactions: number }>> {
    try {
      const endDate = new Date();
      const startDate = new Date();
      startDate.setMonth(startDate.getMonth() - 12);

      const where: any = {
        status: PaymentStatus.SUCCEEDED,
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      };

      if (tenantId) {
        where.booking = {
          tenantId
        };
      }

      const payments = await prisma.payment.findMany({
        where,
        select: {
          amount: true,
          createdAt: true
        }
      });

      // Agrupar por mês
      const monthlyData: Record<string, { revenue: number; transactions: number }> = {};

      payments.forEach(payment => {
        const monthKey = payment.createdAt.toISOString().substring(0, 7); // YYYY-MM
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = { revenue: 0, transactions: 0 };
        }
        monthlyData[monthKey].revenue += payment.amount / 100; // converter de centavos
        monthlyData[monthKey].transactions += 1;
      });

      // Converter para array ordenado
      return Object.entries(monthlyData)
        .map(([month, data]) => ({
          month,
          revenue: data.revenue,
          transactions: data.transactions
        }))
        .sort((a, b) => a.month.localeCompare(b.month));

    } catch (error) {
      console.error('Erro ao gerar receita mensal:', error);
      return [];
    }
  }

  /**
   * Salva método de pagamento do cliente
   */
  async savePaymentMethod(userId: string, stripePaymentMethodId: string): Promise<PaymentMethod> {
    try {
      // Buscar detalhes do método de pagamento no Stripe
      const stripePaymentMethod = await stripe.paymentMethods.retrieve(stripePaymentMethodId);

      // Desativar outros métodos como padrão se este for o primeiro
      const existingMethods = await prisma.paymentMethod.count({
        where: { userId }
      });

      const paymentMethod = await prisma.paymentMethod.create({
        data: {
          userId,
          stripeMethodId: stripePaymentMethodId,
          type: stripePaymentMethod.type,
          brand: stripePaymentMethod.card?.brand,
          last4: stripePaymentMethod.card?.last4,
          expiryMonth: stripePaymentMethod.card?.exp_month,
          expiryYear: stripePaymentMethod.card?.exp_year,
          isDefault: existingMethods === 0, // primeiro método é padrão
          metadata: JSON.stringify(stripePaymentMethod.metadata)
        }
      });

      return paymentMethod as PaymentMethod;

    } catch (error) {
      console.error('Erro ao salvar método de pagamento:', error);
      throw error;
    }
  }

  /**
   * Lista métodos de pagamento do usuário
   */
  async getUserPaymentMethods(userId: string): Promise<PaymentMethod[]> {
    try {
      const paymentMethods = await prisma.paymentMethod.findMany({
        where: {
          userId,
          isActive: true
        },
        orderBy: [
          { isDefault: 'desc' },
          { createdAt: 'desc' }
        ]
      });

      return paymentMethods as PaymentMethod[];

    } catch (error) {
      console.error('Erro ao listar métodos de pagamento:', error);
      throw error;
    }
  }

  /**
   * Remove método de pagamento
   */
  async removePaymentMethod(userId: string, paymentMethodId: string): Promise<void> {
    try {
      const paymentMethod = await prisma.paymentMethod.findFirst({
        where: {
          id: paymentMethodId,
          userId
        }
      });

      if (!paymentMethod) {
        throw new Error('Método de pagamento não encontrado');
      }

      // Remover do Stripe
      await stripe.paymentMethods.detach(paymentMethod.stripeMethodId);

      // Remover do banco
      await prisma.paymentMethod.delete({
        where: { id: paymentMethodId }
      });

    } catch (error) {
      console.error('Erro ao remover método de pagamento:', error);
      throw error;
    }
  }
}

export const paymentService = new PaymentService();