import { cacheService } from './cache.service';

export interface InvalidationRule {
  pattern: string;
  dependencies: string[];
  ttl?: number;
}

export class CacheInvalidationService {
  private invalidationRules: Map<string, InvalidationRule[]> = new Map();

  constructor() {
    this.setupDefaultRules();
  }

  /**
   * Setup default invalidation rules
   */
  private setupDefaultRules(): void {
    // User-related invalidations
    this.addRule('user', [
      { pattern: 'user:*', dependencies: ['user'] },
      { pattern: 'professional:*', dependencies: ['user', 'professional'] },
      { pattern: 'client:*', dependencies: ['user', 'client'] }
    ]);

    // Schedule-related invalidations
    this.addRule('schedule', [
      { pattern: 'schedule:*', dependencies: ['schedule'] },
      { pattern: 'availability:*', dependencies: ['schedule', 'booking'] },
      { pattern: 'slots:*', dependencies: ['schedule', 'booking'] },
      { pattern: 'agenda:*', dependencies: ['schedule', 'booking'] }
    ]);

    // Booking-related invalidations
    this.addRule('booking', [
      { pattern: 'booking:*', dependencies: ['booking'] },
      { pattern: 'availability:*', dependencies: ['schedule', 'booking'] },
      { pattern: 'slots:*', dependencies: ['schedule', 'booking'] },
      { pattern: 'agenda:*', dependencies: ['schedule', 'booking'] },
      { pattern: 'metrics:*', dependencies: ['booking'] },
      { pattern: 'analytics:*', dependencies: ['booking'] }
    ]);

    // Service-related invalidations
    this.addRule('service', [
      { pattern: 'service:*', dependencies: ['service'] },
      { pattern: 'availability:*', dependencies: ['service', 'schedule'] },
      { pattern: 'professional:*', dependencies: ['service'] }
    ]);

    // Analytics-related invalidations
    this.addRule('analytics', [
      { pattern: 'analytics:*', dependencies: ['analytics'] },
      { pattern: 'metrics:*', dependencies: ['analytics', 'booking'] },
      { pattern: 'dashboard:*', dependencies: ['analytics', 'booking'] }
    ]);

    // Notification-related invalidations
    this.addRule('notification', [
      { pattern: 'notification:*', dependencies: ['notification'] },
      { pattern: 'template:*', dependencies: ['notification'] }
    ]);
  }

  /**
   * Add invalidation rule
   */
  addRule(entity: string, rules: InvalidationRule[]): void {
    this.invalidationRules.set(entity, rules);
  }

  /**
   * Invalidate cache based on entity change
   */
  async invalidate(entity: string, entityId?: string, tenantId?: string): Promise<void> {
    const rules = this.invalidationRules.get(entity);
    if (!rules) {
      console.warn(`No invalidation rules found for entity: ${entity}`);
      return;
    }

    const invalidationPromises: Promise<any>[] = [];

    for (const rule of rules) {
      let pattern = rule.pattern;
      
      // Replace wildcards with specific IDs if provided
      if (entityId) {
        pattern = pattern.replace('*', `${entityId}:*`);
      }
      
      // Add tenant prefix if provided
      if (tenantId) {
        pattern = `tenant:${tenantId}:${pattern}`;
      }

      invalidationPromises.push(
        cacheService.delPattern(pattern).catch(error => {
          console.error(`Failed to invalidate pattern ${pattern}:`, error);
        })
      );
    }

    await Promise.all(invalidationPromises);
    console.log(`Cache invalidated for entity: ${entity}, patterns: ${rules.map(r => r.pattern).join(', ')}`);
  }

  /**
   * Invalidate specific cache key
   */
  async invalidateKey(key: string, tenantId?: string): Promise<void> {
    const fullKey = tenantId ? `tenant:${tenantId}:${key}` : key;
    await cacheService.del(fullKey);
    console.log(`Cache key invalidated: ${fullKey}`);
  }

  /**
   * Invalidate multiple keys by pattern
   */
  async invalidatePattern(pattern: string, tenantId?: string): Promise<number> {
    const fullPattern = tenantId ? `tenant:${tenantId}:${pattern}` : pattern;
    const deletedCount = await cacheService.delPattern(fullPattern);
    console.log(`Cache pattern invalidated: ${fullPattern}, deleted ${deletedCount} keys`);
    return deletedCount;
  }

  /**
   * Invalidate tenant-specific cache
   */
  async invalidateTenant(tenantId: string): Promise<void> {
    const pattern = `tenant:${tenantId}:*`;
    const deletedCount = await cacheService.delPattern(pattern);
    console.log(`Tenant cache invalidated: ${tenantId}, deleted ${deletedCount} keys`);
  }

  /**
   * Invalidate user-specific cache
   */
  async invalidateUser(userId: string, tenantId?: string): Promise<void> {
    const patterns = [
      `user:${userId}:*`,
      `professional:${userId}:*`,
      `client:${userId}:*`,
      `schedule:${userId}:*`,
      `booking:*:${userId}:*`,
      `availability:${userId}:*`
    ];

    const invalidationPromises = patterns.map(pattern => {
      const fullPattern = tenantId ? `tenant:${tenantId}:${pattern}` : pattern;
      return cacheService.delPattern(fullPattern);
    });

    await Promise.all(invalidationPromises);
    console.log(`User cache invalidated: ${userId}`);
  }

  /**
   * Invalidate date-specific cache (for schedules and bookings)
   */
  async invalidateDate(date: string, tenantId?: string): Promise<void> {
    const patterns = [
      `availability:*:${date}:*`,
      `slots:*:${date}:*`,
      `agenda:*:${date}:*`,
      `booking:*:${date}:*`
    ];

    const invalidationPromises = patterns.map(pattern => {
      const fullPattern = tenantId ? `tenant:${tenantId}:${pattern}` : pattern;
      return cacheService.delPattern(fullPattern);
    });

    await Promise.all(invalidationPromises);
    console.log(`Date-specific cache invalidated: ${date}`);
  }

  /**
   * Smart invalidation based on time
   * Invalidates cache that might be stale based on business rules
   */
  async smartInvalidation(tenantId?: string): Promise<void> {
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    const currentHour = now.getHours();

    // Invalidate today's availability if it's business hours
    if (currentHour >= 8 && currentHour <= 20) {
      await this.invalidateDate(today, tenantId);
    }

    // Invalidate analytics cache at the end of business day
    if (currentHour === 21) {
      await this.invalidatePattern('analytics:*', tenantId);
      await this.invalidatePattern('metrics:*', tenantId);
    }

    // Invalidate dashboard cache every hour during business hours
    if (currentHour >= 8 && currentHour <= 20) {
      await this.invalidatePattern('dashboard:*', tenantId);
    }
  }

  /**
   * Get invalidation statistics
   */
  getInvalidationRules(): Map<string, InvalidationRule[]> {
    return new Map(this.invalidationRules);
  }
}

// Export singleton instance
export const cacheInvalidationService = new CacheInvalidationService();