import { PrismaClient } from '@prisma/client';
import {
  AnalyticsFilters,
  DashboardMetrics,
  OccupancyMetrics,
  RevenueMetrics,
  ProfitableHoursAnalysis,
  ServiceMetrics,
  ProfessionalMetrics,
  DateRange
} from '../types/analytics.types';

const prisma = new PrismaClient();

export class AnalyticsService {
  /**
   * Calcula métricas de ocupação da agenda
   */
  async calculateOccupancyMetrics(filters: AnalyticsFilters): Promise<OccupancyMetrics> {
    const { tenantId, dateRange, professionalId } = filters;

    // Buscar todos os agendamentos no período
    const bookings = await prisma.booking.findMany({
      where: {
        tenantId,
        professionalId,
        startTime: {
          gte: dateRange.startDate,
          lte: dateRange.endDate,
        },
        status: {
          in: ['SCHEDULED', 'CONFIRMED', 'COMPLETED']
        }
      },
      include: {
        service: true,
        professional: {
          include: {
            schedules: true
          }
        }
      }
    });

    // Calcular slots totais disponíveis baseado nos horários de trabalho
    const totalSlots = await this.calculateTotalAvailableSlots(
      filters.professionalId ? [filters.professionalId] : undefined,
      dateRange,
      tenantId
    );

    const bookedSlots = bookings.length;
    const occupancyRate = totalSlots > 0 ? (bookedSlots / totalSlots) * 100 : 0;
    const availableSlots = totalSlots - bookedSlots;

    return {
      totalSlots,
      bookedSlots,
      occupancyRate: Math.round(occupancyRate * 100) / 100,
      availableSlots
    };
  }

  /**
   * Calcula métricas de faturamento
   */
  async calculateRevenueMetrics(filters: AnalyticsFilters): Promise<RevenueMetrics> {
    const { tenantId, dateRange, professionalId, serviceId } = filters;

    const bookings = await prisma.booking.findMany({
      where: {
        tenantId,
        professionalId,
        serviceId,
        startTime: {
          gte: dateRange.startDate,
          lte: dateRange.endDate,
        }
      },
      select: {
        price: true,
        status: true,
        paymentStatus: true
      }
    });

    const totalBookings = bookings.length;
    const totalRevenue = bookings.reduce((sum, booking) => sum + booking.price, 0);
    
    const confirmedRevenue = bookings
      .filter(b => ['COMPLETED'].includes(b.status))
      .reduce((sum, booking) => sum + booking.price, 0);
    
    const pendingRevenue = bookings
      .filter(b => ['SCHEDULED', 'CONFIRMED'].includes(b.status))
      .reduce((sum, booking) => sum + booking.price, 0);

    const averageBookingValue = totalBookings > 0 ? totalRevenue / totalBookings : 0;

    return {
      totalRevenue: Math.round(totalRevenue * 100) / 100,
      confirmedRevenue: Math.round(confirmedRevenue * 100) / 100,
      pendingRevenue: Math.round(pendingRevenue * 100) / 100,
      averageBookingValue: Math.round(averageBookingValue * 100) / 100,
      totalBookings
    };
  }

  /**
   * Analisa horários mais rentáveis
   */
  async analyzeProfitableHours(filters: AnalyticsFilters): Promise<ProfitableHoursAnalysis[]> {
    const { tenantId, dateRange, professionalId } = filters;

    const bookings = await prisma.booking.findMany({
      where: {
        tenantId,
        professionalId,
        startTime: {
          gte: dateRange.startDate,
          lte: dateRange.endDate,
        },
        status: {
          in: ['SCHEDULED', 'CONFIRMED', 'COMPLETED']
        }
      },
      select: {
        startTime: true,
        price: true,
        status: true
      }
    });

    // Agrupar por hora
    const hourlyData: { [hour: number]: { bookings: number; revenue: number } } = {};
    
    for (let hour = 0; hour < 24; hour++) {
      hourlyData[hour] = { bookings: 0, revenue: 0 };
    }

    bookings.forEach(booking => {
      const hour = booking.startTime.getHours();
      hourlyData[hour].bookings += 1;
      hourlyData[hour].revenue += booking.price;
    });

    // Calcular slots totais por hora para taxa de ocupação
    const totalSlotsByHour = await this.calculateSlotsByHour(
      filters.professionalId ? [filters.professionalId] : undefined,
      dateRange,
      tenantId
    );

    return Object.entries(hourlyData).map(([hour, data]) => {
      const hourNum = parseInt(hour);
      const totalSlots = totalSlotsByHour[hourNum] || 0;
      const occupancyRate = totalSlots > 0 ? (data.bookings / totalSlots) * 100 : 0;
      
      return {
        hour: hourNum,
        totalBookings: data.bookings,
        totalRevenue: Math.round(data.revenue * 100) / 100,
        averageRevenue: data.bookings > 0 ? Math.round((data.revenue / data.bookings) * 100) / 100 : 0,
        occupancyRate: Math.round(occupancyRate * 100) / 100
      };
    }).sort((a, b) => b.totalRevenue - a.totalRevenue);
  }

  /**
   * Calcula métricas por serviço
   */
  async calculateServiceMetrics(filters: AnalyticsFilters): Promise<ServiceMetrics[]> {
    const { tenantId, dateRange, professionalId } = filters;

    const bookings = await prisma.booking.findMany({
      where: {
        tenantId,
        professionalId,
        startTime: {
          gte: dateRange.startDate,
          lte: dateRange.endDate,
        }
      },
      include: {
        service: true
      }
    });

    // Agrupar por serviço
    const serviceData: { [serviceId: string]: {
      serviceName: string;
      bookings: number;
      revenue: number;
      prices: number[];
    } } = {};

    bookings.forEach(booking => {
      const serviceId = booking.serviceId;
      if (!serviceData[serviceId]) {
        serviceData[serviceId] = {
          serviceName: booking.service.name,
          bookings: 0,
          revenue: 0,
          prices: []
        };
      }
      serviceData[serviceId].bookings += 1;
      serviceData[serviceId].revenue += booking.price;
      serviceData[serviceId].prices.push(booking.price);
    });

    // Converter para array e ordenar por popularidade
    const services = Object.entries(serviceData)
      .map(([serviceId, data]) => ({
        serviceId,
        serviceName: data.serviceName,
        totalBookings: data.bookings,
        totalRevenue: Math.round(data.revenue * 100) / 100,
        averagePrice: Math.round((data.revenue / data.bookings) * 100) / 100,
        popularityRank: 0 // será definido após ordenação
      }))
      .sort((a, b) => b.totalBookings - a.totalBookings);

    // Definir ranking
    services.forEach((service, index) => {
      service.popularityRank = index + 1;
    });

    return services;
  }

  /**
   * Calcula métricas por profissional
   */
  async calculateProfessionalMetrics(filters: AnalyticsFilters): Promise<ProfessionalMetrics[]> {
    const { tenantId, dateRange } = filters;

    const professionals = await prisma.professional.findMany({
      where: {
        tenantId,
        ...(filters.professionalId && { id: filters.professionalId })
      },
      include: {
        user: true,
        bookings: {
          where: {
            startTime: {
              gte: dateRange.startDate,
              lte: dateRange.endDate,
            }
          }
        }
      }
    });

    const metrics: ProfessionalMetrics[] = [];

    for (const professional of professionals) {
      const bookings = professional.bookings;
      const totalBookings = bookings.length;
      const totalRevenue = bookings.reduce((sum, b) => sum + b.price, 0);
      
      const completedBookings = bookings.filter(b => b.status === 'COMPLETED').length;
      const noShowBookings = bookings.filter(b => b.status === 'NO_SHOW').length;
      const cancelledBookings = bookings.filter(b => b.status === 'CANCELLED').length;

      const noShowRate = totalBookings > 0 ? (noShowBookings / totalBookings) * 100 : 0;
      const cancellationRate = totalBookings > 0 ? (cancelledBookings / totalBookings) * 100 : 0;

      // Calcular taxa de ocupação
      const totalSlots = await this.calculateTotalAvailableSlots(
        [professional.id],
        dateRange,
        tenantId
      );
      const occupancyRate = totalSlots > 0 ? (totalBookings / totalSlots) * 100 : 0;

      metrics.push({
        professionalId: professional.id,
        professionalName: professional.user.name,
        totalBookings,
        totalRevenue: Math.round(totalRevenue * 100) / 100,
        occupancyRate: Math.round(occupancyRate * 100) / 100,
        noShowRate: Math.round(noShowRate * 100) / 100,
        cancellationRate: Math.round(cancellationRate * 100) / 100
      });
    }

    return metrics.sort((a, b) => b.totalRevenue - a.totalRevenue);
  }

  /**
   * Gera dashboard completo com todas as métricas
   */
  async generateDashboardMetrics(filters: AnalyticsFilters): Promise<DashboardMetrics> {
    const [
      occupancy,
      revenue,
      profitableHours,
      topServices,
      professionalPerformance
    ] = await Promise.all([
      this.calculateOccupancyMetrics(filters),
      this.calculateRevenueMetrics(filters),
      this.analyzeProfitableHours(filters),
      this.calculateServiceMetrics(filters),
      this.calculateProfessionalMetrics(filters)
    ]);

    // Calcular comparação com período anterior se necessário
    let periodComparison;
    const periodDuration = filters.dateRange.endDate.getTime() - filters.dateRange.startDate.getTime();
    const previousPeriodStart = new Date(filters.dateRange.startDate.getTime() - periodDuration);
    const previousPeriodEnd = new Date(filters.dateRange.endDate.getTime() - periodDuration);

    const previousRevenue = await this.calculateRevenueMetrics({
      ...filters,
      dateRange: {
        startDate: previousPeriodStart,
        endDate: previousPeriodEnd
      }
    });

    const growthRate = previousRevenue.totalRevenue > 0 
      ? ((revenue.totalRevenue - previousRevenue.totalRevenue) / previousRevenue.totalRevenue) * 100
      : 0;

    periodComparison = {
      current: revenue,
      previous: previousRevenue,
      growthRate: Math.round(growthRate * 100) / 100
    };

    return {
      occupancy,
      revenue,
      profitableHours: profitableHours.slice(0, 10), // Top 10 horários
      topServices: topServices.slice(0, 10), // Top 10 serviços
      professionalPerformance,
      periodComparison
    };
  }

  /**
   * Calcula total de slots disponíveis baseado nos horários de trabalho
   */
  private async calculateTotalAvailableSlots(
    professionalIds?: string[],
    dateRange?: DateRange,
    tenantId?: string
  ): Promise<number> {
    // Implementação simplificada - assumindo slots de 30 minutos
    // Em uma implementação real, seria baseado nos horários de trabalho dos profissionais
    const days = dateRange 
      ? Math.ceil((dateRange.endDate.getTime() - dateRange.startDate.getTime()) / (1000 * 60 * 60 * 24))
      : 1;
    
    const professionalsCount = professionalIds?.length || 1;
    const slotsPerDay = 16; // 8 horas * 2 slots por hora (30min cada)
    
    return days * professionalsCount * slotsPerDay;
  }

  /**
   * Calcula slots disponíveis por hora
   */
  private async calculateSlotsByHour(
    professionalIds?: string[],
    dateRange?: DateRange,
    tenantId?: string
  ): Promise<{ [hour: number]: number }> {
    // Implementação simplificada
    const days = dateRange 
      ? Math.ceil((dateRange.endDate.getTime() - dateRange.startDate.getTime()) / (1000 * 60 * 60 * 24))
      : 1;
    
    const professionalsCount = professionalIds?.length || 1;
    const slotsByHour: { [hour: number]: number } = {};
    
    // Assumindo horário comercial das 8h às 18h
    for (let hour = 8; hour < 18; hour++) {
      slotsByHour[hour] = days * professionalsCount * 2; // 2 slots por hora
    }
    
    return slotsByHour;
  }
}

export const analyticsService = new AnalyticsService();