import { PrismaClient } from '@prisma/client';
import {
  CreateReviewRequest,
  UpdateReviewRequest,
  ReviewResponse,
  ReviewStats,
  ReviewFilters,
  ModerateReviewRequest,
  ProfessionalReviewStats,
  CreateReviewResponseRequest
} from '../types/review.types';

const prisma = new PrismaClient();

export class ReviewService {
  // Criar uma nova avaliação
  async createReview(clientId: string, data: CreateReviewRequest): Promise<ReviewResponse> {
    // Verificar se o booking existe e pertence ao cliente
    const booking = await prisma.booking.findFirst({
      where: {
        id: data.bookingId,
        clientId: clientId,
        status: 'COMPLETED' // Só permite avaliar agendamentos concluídos
      },
      include: {
        service: true,
        professional: true
      }
    });

    if (!booking) {
      throw new Error('Agendamento não encontrado ou não pode ser avaliado');
    }

    // Verificar se já existe uma avaliação para este booking
    const existingReview = await prisma.review.findUnique({
      where: { bookingId: data.bookingId }
    });

    if (existingReview) {
      throw new Error('Este agendamento já foi avaliado');
    }

    // Validar rating
    if (data.rating < 1 || data.rating > 5) {
      throw new Error('A avaliação deve ser entre 1 e 5 estrelas');
    }

    const review = await prisma.review.create({
      data: {
        bookingId: data.bookingId,
        clientId: clientId,
        professionalId: booking.professionalId,
        rating: data.rating,
        comment: data.comment,
        moderationStatus: 'APPROVED', // Auto-aprovar por enquanto
        isVisible: true
      },
      include: {
        client: {
          select: {
            id: true,
            name: true,
            profile: {
              select: {
                avatar: true
              }
            }
          }
        },
        professional: {
          include: {
            user: {
              select: {
                name: true,
                profile: {
                  select: {
                    avatar: true
                  }
                }
              }
            }
          }
        },
        booking: {
          include: {
            service: {
              select: {
                name: true
              }
            }
          }
        },
        response: true
      }
    });

    return this.formatReviewResponse(review);
  }

  // Buscar avaliações com filtros
  async getReviews(filters: ReviewFilters): Promise<{ reviews: ReviewResponse[]; total: number }> {
    const where: any = {};

    if (filters.professionalId) {
      where.professionalId = filters.professionalId;
    }

    if (filters.rating) {
      where.rating = filters.rating;
    }

    if (filters.moderationStatus) {
      where.moderationStatus = filters.moderationStatus;
    }

    if (filters.isVisible !== undefined) {
      where.isVisible = filters.isVisible;
    }

    if (filters.startDate || filters.endDate) {
      where.createdAt = {};
      if (filters.startDate) {
        where.createdAt.gte = filters.startDate;
      }
      if (filters.endDate) {
        where.createdAt.lte = filters.endDate;
      }
    }

    const page = filters.page || 1;
    const limit = filters.limit || 10;
    const skip = (page - 1) * limit;

    const [reviews, total] = await Promise.all([
      prisma.review.findMany({
        where,
        include: {
          client: {
            select: {
              id: true,
              name: true,
              profile: {
                select: {
                  avatar: true
                }
              }
            }
          },
          professional: {
            include: {
              user: {
                select: {
                  name: true,
                  profile: {
                    select: {
                      avatar: true
                    }
                  }
                }
              }
            }
          },
          booking: {
            include: {
              service: {
                select: {
                  name: true
                }
              }
            }
          },
          response: true
        },
        orderBy: {
          createdAt: 'desc'
        },
        skip,
        take: limit
      }),
      prisma.review.count({ where })
    ]);

    return {
      reviews: reviews.map(review => this.formatReviewResponse(review)),
      total
    };
  }

  // Buscar avaliação por ID
  async getReviewById(id: string): Promise<ReviewResponse | null> {
    const review = await prisma.review.findUnique({
      where: { id },
      include: {
        client: {
          select: {
            id: true,
            name: true,
            profile: {
              select: {
                avatar: true
              }
            }
          }
        },
        professional: {
          include: {
            user: {
              select: {
                name: true,
                profile: {
                  select: {
                    avatar: true
                  }
                }
              }
            }
          }
        },
        booking: {
          include: {
            service: {
              select: {
                name: true
              }
            }
          }
        },
        response: true
      }
    });

    return review ? this.formatReviewResponse(review) : null;
  }

  // Atualizar avaliação (apenas pelo cliente)
  async updateReview(id: string, clientId: string, data: UpdateReviewRequest): Promise<ReviewResponse> {
    const existingReview = await prisma.review.findFirst({
      where: {
        id,
        clientId
      }
    });

    if (!existingReview) {
      throw new Error('Avaliação não encontrada');
    }

    // Validar rating se fornecido
    if (data.rating && (data.rating < 1 || data.rating > 5)) {
      throw new Error('A avaliação deve ser entre 1 e 5 estrelas');
    }

    const review = await prisma.review.update({
      where: { id },
      data: {
        ...(data.rating && { rating: data.rating }),
        ...(data.comment !== undefined && { comment: data.comment }),
        moderationStatus: 'PENDING', // Requer nova moderação após edição
        updatedAt: new Date()
      },
      include: {
        client: {
          select: {
            id: true,
            name: true,
            profile: {
              select: {
                avatar: true
              }
            }
          }
        },
        professional: {
          include: {
            user: {
              select: {
                name: true,
                profile: {
                  select: {
                    avatar: true
                  }
                }
              }
            }
          }
        },
        booking: {
          include: {
            service: {
              select: {
                name: true
              }
            }
          }
        },
        response: true
      }
    });

    return this.formatReviewResponse(review);
  }

  // Deletar avaliação (apenas pelo cliente)
  async deleteReview(id: string, clientId: string): Promise<void> {
    const existingReview = await prisma.review.findFirst({
      where: {
        id,
        clientId
      }
    });

    if (!existingReview) {
      throw new Error('Avaliação não encontrada');
    }

    await prisma.review.delete({
      where: { id }
    });
  }

  // Moderar avaliação (apenas admin)
  async moderateReview(id: string, moderatorId: string, data: ModerateReviewRequest): Promise<ReviewResponse> {
    const review = await prisma.review.update({
      where: { id },
      data: {
        moderationStatus: data.moderationStatus,
        moderationReason: data.moderationReason,
        moderatedAt: new Date(),
        moderatedBy: moderatorId,
        isVisible: data.isVisible ?? (data.moderationStatus === 'APPROVED'),
        isModerated: true
      },
      include: {
        client: {
          select: {
            id: true,
            name: true,
            profile: {
              select: {
                avatar: true
              }
            }
          }
        },
        professional: {
          include: {
            user: {
              select: {
                name: true,
                profile: {
                  select: {
                    avatar: true
                  }
                }
              }
            }
          }
        },
        booking: {
          include: {
            service: {
              select: {
                name: true
              }
            }
          }
        },
        response: true
      }
    });

    return this.formatReviewResponse(review);
  }

  // Criar resposta do profissional
  async createReviewResponse(reviewId: string, professionalId: string, data: CreateReviewResponseRequest): Promise<ReviewResponse> {
    // Verificar se a avaliação existe e pertence ao profissional
    const review = await prisma.review.findFirst({
      where: {
        id: reviewId,
        professionalId
      }
    });

    if (!review) {
      throw new Error('Avaliação não encontrada');
    }

    // Verificar se já existe uma resposta
    const existingResponse = await prisma.reviewResponse.findUnique({
      where: { reviewId }
    });

    if (existingResponse) {
      throw new Error('Esta avaliação já possui uma resposta');
    }

    await prisma.reviewResponse.create({
      data: {
        reviewId,
        professionalId,
        response: data.response
      }
    });

    return this.getReviewById(reviewId) as Promise<ReviewResponse>;
  }

  // Atualizar resposta do profissional
  async updateReviewResponse(reviewId: string, professionalId: string, response: string): Promise<ReviewResponse> {
    const existingResponse = await prisma.reviewResponse.findFirst({
      where: {
        reviewId,
        professionalId
      }
    });

    if (!existingResponse) {
      throw new Error('Resposta não encontrada');
    }

    await prisma.reviewResponse.update({
      where: { id: existingResponse.id },
      data: {
        response,
        updatedAt: new Date()
      }
    });

    return this.getReviewById(reviewId) as Promise<ReviewResponse>;
  }

  // Deletar resposta do profissional
  async deleteReviewResponse(reviewId: string, professionalId: string): Promise<void> {
    const existingResponse = await prisma.reviewResponse.findFirst({
      where: {
        reviewId,
        professionalId
      }
    });

    if (!existingResponse) {
      throw new Error('Resposta não encontrada');
    }

    await prisma.reviewResponse.delete({
      where: { id: existingResponse.id }
    });
  }

  // Obter estatísticas de avaliações
  async getReviewStats(professionalId?: string): Promise<ReviewStats> {
    const where: any = {
      isVisible: true,
      moderationStatus: 'APPROVED'
    };

    if (professionalId) {
      where.professionalId = professionalId;
    }

    const [reviews, ratingStats] = await Promise.all([
      prisma.review.findMany({
        where,
        include: {
          client: {
            select: {
              id: true,
              name: true,
              profile: {
                select: {
                  avatar: true
                }
              }
            }
          },
          booking: {
            include: {
              service: {
                select: {
                  name: true
                }
              }
            }
          },
          response: true
        },
        orderBy: {
          createdAt: 'desc'
        },
        take: 5
      }),
      prisma.review.groupBy({
        by: ['rating'],
        where,
        _count: {
          rating: true
        }
      })
    ]);

    const totalReviews = reviews.length;
    const averageRating = totalReviews > 0 
      ? reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews 
      : 0;

    const ratingDistribution = {
      1: 0,
      2: 0,
      3: 0,
      4: 0,
      5: 0
    };

    ratingStats.forEach(stat => {
      ratingDistribution[stat.rating as keyof typeof ratingDistribution] = stat._count.rating;
    });

    return {
      totalReviews,
      averageRating: Math.round(averageRating * 10) / 10,
      ratingDistribution,
      recentReviews: reviews.map(review => this.formatReviewResponse(review))
    };
  }

  // Obter estatísticas por profissional
  async getProfessionalReviewStats(professionalId: string): Promise<ProfessionalReviewStats> {
    const where = {
      professionalId,
      isVisible: true,
      moderationStatus: 'APPROVED'
    };

    const [reviews, ratingStats, responseCount] = await Promise.all([
      prisma.review.findMany({
        where,
        orderBy: {
          createdAt: 'desc'
        }
      }),
      prisma.review.groupBy({
        by: ['rating'],
        where,
        _count: {
          rating: true
        }
      }),
      prisma.reviewResponse.count({
        where: {
          review: where
        }
      })
    ]);

    const totalReviews = reviews.length;
    const averageRating = totalReviews > 0 
      ? reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews 
      : 0;

    const ratingDistribution = {
      1: 0,
      2: 0,
      3: 0,
      4: 0,
      5: 0
    };

    ratingStats.forEach(stat => {
      ratingDistribution[stat.rating as keyof typeof ratingDistribution] = stat._count.rating;
    });

    const responseRate = totalReviews > 0 ? (responseCount / totalReviews) * 100 : 0;
    const lastReviewDate = reviews.length > 0 ? reviews[0].createdAt : undefined;

    return {
      professionalId,
      totalReviews,
      averageRating: Math.round(averageRating * 10) / 10,
      ratingDistribution,
      responseRate: Math.round(responseRate * 10) / 10,
      lastReviewDate
    };
  }

  // Formatar resposta da avaliação
  private formatReviewResponse(review: any): ReviewResponse {
    return {
      id: review.id,
      bookingId: review.bookingId,
      clientId: review.clientId,
      professionalId: review.professionalId,
      rating: review.rating,
      comment: review.comment,
      isModerated: review.isModerated,
      moderationStatus: review.moderationStatus,
      moderationReason: review.moderationReason,
      moderatedAt: review.moderatedAt,
      moderatedBy: review.moderatedBy,
      isVisible: review.isVisible,
      createdAt: review.createdAt,
      updatedAt: review.updatedAt,
      client: review.client ? {
        id: review.client.id,
        name: review.client.name,
        avatar: review.client.profile?.avatar
      } : undefined,
      professional: review.professional ? {
        id: review.professional.id,
        user: {
          name: review.professional.user.name,
          avatar: review.professional.user.profile?.avatar
        }
      } : undefined,
      booking: review.booking ? {
        service: {
          name: review.booking.service.name
        },
        startTime: review.booking.startTime
      } : undefined,
      response: review.response
    };
  }
}

export const reviewService = new ReviewService();