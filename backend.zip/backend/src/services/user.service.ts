import { PrismaClient } from '@prisma/client';
import { 
  CreateUserInput, 
  UpdateUserInput, 
  UpdateUserProfileInput,
  UpdateProfessionalProfileInput,
  UpdateClientProfileInput,
  UserWithRoles 
} from '../types/user.types';
import { hashPassword, comparePassword } from '../utils/password.utils';
import { deleteOldAvatar, getAvatarUrl } from '../middleware/upload.middleware';
import { TenantService } from './tenant.service';
import { cacheService } from './cache.service';
import { cacheInvalidationService } from './cache-invalidation.service';
import { CACHE_KEYS, CACHE_TTL } from '../config/redis';
import path from 'path';

export class UserService {
  private tenantService: TenantService;

  constructor(private readonly prisma: PrismaClient) {
    this.tenantService = new TenantService(prisma);
  }

  /**
   * Create a new user with roles
   */
  async createUser(data: CreateUserInput): Promise<UserWithRoles> {
    const { roleIds, password, ...userData } = data;

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create user with roles in a transaction
    const user = await this.prisma.$transaction(async (tx) => {
      // Create user
      const newUser = await tx.user.create({
        data: {
          ...userData,
          password: hashedPassword,
        },
      });

      // Assign roles
      await tx.userRole.createMany({
        data: roleIds.map(roleId => ({
          userId: newUser.id,
          roleId,
        })),
      });

      // Return the created user ID so we can fetch it outside the transaction
      return newUser.id;
    });

    // Fetch the complete user with roles outside the transaction
    const completeUser = await this.getUserById(user);
    if (!completeUser) {
      throw new Error('Erro ao criar usuário');
    }

    return completeUser;
  }

  /**
   * Get user by ID with roles and permissions
   */
  async getUserById(id: string): Promise<UserWithRoles | null> {
    return this.prisma.user.findUnique({
      where: { id },
      include: {
        profile: true,
        userRoles: {
          include: {
            role: {
              include: {
                rolePermissions: {
                  include: {
                    permission: true,
                  },
                },
              },
            },
          },
        },
      },
    });
  }

  /**
   * Get user by email with roles and permissions
   */
  async getUserByEmail(email: string): Promise<UserWithRoles | null> {
    return this.prisma.user.findUnique({
      where: { email },
      include: {
        profile: true,
        userRoles: {
          include: {
            role: {
              include: {
                rolePermissions: {
                  include: {
                    permission: true,
                  },
                },
              },
            },
          },
        },
      },
    });
  }

  /**
   * Update user data
   */
  async updateUser(id: string, data: UpdateUserInput): Promise<UserWithRoles | null> {
    const { roleIds, ...updateData } = data;

    const user = await this.prisma.$transaction(async (tx) => {
      // Update user data
      await tx.user.update({
        where: { id },
        data: updateData,
      });

      // Update roles if provided
      if (roleIds) {
        // Remove existing roles
        await tx.userRole.deleteMany({
          where: { userId: id },
        });

        // Add new roles
        await tx.userRole.createMany({
          data: roleIds.map(roleId => ({
            userId: id,
            roleId,
          })),
        });
      }

      return this.getUserById(id);
    });

    return user;
  }

  /**
   * Update user profile
   */
  async updateUserProfile(userId: string, data: UpdateUserProfileInput) {
    return this.prisma.userProfile.upsert({
      where: { userId },
      update: data,
      create: {
        userId,
        ...data,
      },
    });
  }

  /**
   * Update professional profile with specific validations
   */
  async updateProfessionalProfile(userId: string, data: UpdateProfessionalProfileInput & { customFields?: Record<string, any> }) {
    // Validate that user is a professional
    const user = await this.getUserById(userId);
    if (!user) {
      throw new Error('Usuário não encontrado');
    }

    const isProfessional = user.userRoles.some(ur => ur.role.name === 'PROFESSIONAL');
    if (!isProfessional) {
      throw new Error('Usuário não é um profissional');
    }

    // Validate custom fields if tenant has them
    if (user.tenantId && data.customFields) {
      const customFields = await this.tenantService.getCustomFields(user.tenantId, 'professional');
      const validation = this.tenantService.validateCustomFieldValues(customFields, data.customFields);
      
      if (!validation.isValid) {
        throw new Error(`Campos personalizados inválidos: ${validation.errors.join(', ')}`);
      }
    }

    // Convert data to JSON strings for SQLite
    const profileData = {
      avatar: data.avatar,
      bio: data.bio,
      specialties: data.specialties ? JSON.stringify(data.specialties) : undefined,
      workingHours: data.workingHours ? JSON.stringify(data.workingHours) : undefined,
      preferences: data.customFields ? JSON.stringify(data.customFields) : undefined,
    };

    return this.prisma.userProfile.upsert({
      where: { userId },
      update: profileData,
      create: {
        userId,
        ...profileData,
      },
    });
  }

  /**
   * Update client profile with specific validations
   */
  async updateClientProfile(userId: string, data: UpdateClientProfileInput & { customFields?: Record<string, any> }) {
    // Validate that user is a client
    const user = await this.getUserById(userId);
    if (!user) {
      throw new Error('Usuário não encontrado');
    }

    const isClient = user.userRoles.some(ur => ur.role.name === 'CLIENT');
    if (!isClient) {
      throw new Error('Usuário não é um cliente');
    }

    // Validate custom fields if tenant has them
    if (user.tenantId && data.customFields) {
      const customFields = await this.tenantService.getCustomFields(user.tenantId, 'client');
      const validation = this.tenantService.validateCustomFieldValues(customFields, data.customFields);
      
      if (!validation.isValid) {
        throw new Error(`Campos personalizados inválidos: ${validation.errors.join(', ')}`);
      }
    }

    // Merge custom fields with standard preferences
    const allPreferences = {
      ...data.preferences,
      customFields: data.customFields,
    };

    // Convert preferences to JSON string for SQLite
    const profileData = {
      avatar: data.avatar,
      bio: data.bio,
      preferences: allPreferences ? JSON.stringify(allPreferences) : undefined,
    };

    return this.prisma.userProfile.upsert({
      where: { userId },
      update: profileData,
      create: {
        userId,
        ...profileData,
      },
    });
  }

  /**
   * Upload user avatar
   */
  async uploadAvatar(userId: string, filename: string): Promise<string> {
    // Get current profile to delete old avatar
    const currentProfile = await this.prisma.userProfile.findUnique({
      where: { userId },
    });

    // Delete old avatar file if exists
    if (currentProfile?.avatar) {
      const oldAvatarPath = path.join(process.cwd(), 'uploads', 'avatars', path.basename(currentProfile.avatar));
      deleteOldAvatar(oldAvatarPath);
    }

    // Generate avatar URL
    const avatarUrl = getAvatarUrl(filename);

    // Update profile with new avatar
    await this.prisma.userProfile.upsert({
      where: { userId },
      update: { avatar: avatarUrl },
      create: {
        userId,
        avatar: avatarUrl,
      },
    });

    return avatarUrl;
  }

  /**
   * Delete user avatar
   */
  async deleteAvatar(userId: string): Promise<void> {
    const profile = await this.prisma.userProfile.findUnique({
      where: { userId },
    });

    if (profile?.avatar) {
      // Delete file
      const avatarPath = path.join(process.cwd(), 'uploads', 'avatars', path.basename(profile.avatar));
      deleteOldAvatar(avatarPath);

      // Update profile
      await this.prisma.userProfile.update({
        where: { userId },
        data: { avatar: null },
      });
    }
  }

  /**
   * Change user password
   */
  async changePassword(userId: string, currentPassword: string, newPassword: string): Promise<boolean> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { password: true },
    });

    if (!user) {
      throw new Error('Usuário não encontrado');
    }

    // Verify current password
    const isCurrentPasswordValid = await comparePassword(currentPassword, user.password);
    if (!isCurrentPasswordValid) {
      throw new Error('Senha atual incorreta');
    }

    // Hash new password
    const hashedNewPassword = await hashPassword(newPassword);

    // Update password
    await this.prisma.user.update({
      where: { id: userId },
      data: { password: hashedNewPassword },
    });

    return true;
  }

  /**
   * Deactivate user
   */
  async deactivateUser(id: string): Promise<void> {
    await this.prisma.user.update({
      where: { id },
      data: { isActive: false },
    });
  }

  /**
   * Activate user
   */
  async activateUser(id: string): Promise<void> {
    await this.prisma.user.update({
      where: { id },
      data: { isActive: true },
    });
  }

  /**
   * Delete user (soft delete by deactivating)
   */
  async deleteUser(id: string): Promise<void> {
    await this.deactivateUser(id);
  }

  /**
   * Get all users with pagination
   */
  async getUsers(params: {
    page?: number;
    limit?: number;
    tenantId?: string;
    isActive?: boolean;
    search?: string;
  } = {}) {
    const { page = 1, limit = 10, tenantId, isActive, search } = params;
    const skip = (page - 1) * limit;

    const where: any = {};

    if (tenantId) {
      where.tenantId = tenantId;
    }

    if (isActive !== undefined) {
      where.isActive = isActive;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [users, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        skip,
        take: limit,
        include: {
          profile: true,
          userRoles: {
            include: {
              role: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.user.count({ where }),
    ]);

    return {
      users,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Check if user has permission
   */
  async hasPermission(userId: string, resource: string, action: string): Promise<boolean> {
    const user = await this.getUserById(userId);
    if (!user || !user.isActive) {
      return false;
    }

    // Check if user has the specific permission
    for (const userRole of user.userRoles) {
      for (const rolePermission of userRole.role.rolePermissions) {
        const permission = rolePermission.permission;
        if (
          (permission.resource === resource && permission.action === action) ||
          (permission.resource === resource && permission.action === 'manage') ||
          permission.name === `${resource}:${action}` ||
          permission.name === `${resource}:manage`
        ) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Get user permissions
   */
  async getUserPermissions(userId: string): Promise<string[]> {
    const user = await this.getUserById(userId);
    if (!user) {
      return [];
    }

    const permissions = new Set<string>();

    for (const userRole of user.userRoles) {
      for (const rolePermission of userRole.role.rolePermissions) {
        permissions.add(rolePermission.permission.name);
      }
    }

    return Array.from(permissions);
  }

  /**
   * Get user roles
   */
  async getUserRoles(userId: string): Promise<string[]> {
    const user = await this.getUserById(userId);
    if (!user) {
      return [];
    }

    return user.userRoles.map(userRole => userRole.role.name);
  }

  /**
   * Update last login timestamp
   */
  async updateLastLogin(userId: string): Promise<void> {
    await this.prisma.user.update({
      where: { id: userId },
      data: { lastLoginAt: new Date() },
    });
  }

  /**
   * Verify user email
   */
  async verifyEmail(userId: string): Promise<void> {
    await this.prisma.user.update({
      where: { id: userId },
      data: { emailVerified: true },
    });
  }

  /**
   * Get user profile with custom fields
   */
  async getUserProfileWithCustomFields(userId: string) {
    const user = await this.getUserById(userId);
    if (!user) {
      throw new Error('Usuário não encontrado');
    }

    const profile = user.profile;
    if (!profile) {
      return null;
    }

    // Parse JSON fields
    const parsedProfile = {
      ...profile,
      specialties: profile.specialties ? (typeof profile.specialties === 'string' ? JSON.parse(profile.specialties) : profile.specialties) : [],
      workingHours: profile.workingHours ? (typeof profile.workingHours === 'string' ? JSON.parse(profile.workingHours) : profile.workingHours) : {},
      preferences: profile.preferences ? (typeof profile.preferences === 'string' ? JSON.parse(profile.preferences) : profile.preferences) : {},
    };

    // Get custom fields definition if user has tenant
    let customFieldsDefinition = [];
    if (user.tenantId) {
      const userType = user.userRoles.some(ur => ur.role.name === 'PROFESSIONAL') ? 'professional' : 'client';
      customFieldsDefinition = await this.tenantService.getCustomFields(user.tenantId, userType);
    }

    return {
      ...parsedProfile,
      customFieldsDefinition,
    };
  }

  /**
   * Get tenant custom fields for user type
   */
  async getTenantCustomFields(tenantId: string, userType: 'professional' | 'client') {
    return this.tenantService.getCustomFields(tenantId, userType);
  }
}