import OpenAI from 'openai';
import { Redis } from 'ioredis';
import { PrismaClient } from '@prisma/client';
import {
  ChatContext,
  ChatResponse,
  ChatMessage,
  Intent,
  ChatAction,
  Recommendation,
  ServiceRecommendation,
  ProfessionalRecommendation,
  TimeSlotRecommendation,
  PromotionRecommendation,
  AIInsight,
  CampaignSuggestion,
  ChatSession,
  AIConfig
} from '../types/ai.types';

export class AIService {
  private openai: OpenAI;
  private redis: Redis;
  private prisma: PrismaClient;
  private config: AIConfig;

  constructor(redis: Redis, prisma: PrismaClient) {
    this.redis = redis;
    this.prisma = prisma;
    
    this.config = {
      openaiApiKey: process.env.OPENAI_API_KEY || '',
      model: process.env.OPENAI_MODEL || 'gpt-3.5-turbo',
      temperature: parseFloat(process.env.OPENAI_TEMPERATURE || '0.7'),
      maxTokens: parseInt(process.env.OPENAI_MAX_TOKENS || '1000'),
      systemPrompt: this.getSystemPrompt(),
      enableRecommendations: process.env.AI_ENABLE_RECOMMENDATIONS !== 'false',
      enableInsights: process.env.AI_ENABLE_INSIGHTS !== 'false',
      cacheEnabled: process.env.AI_CACHE_ENABLED !== 'false',
      cacheTtl: parseInt(process.env.AI_CACHE_TTL || '3600')
    };

    if (!this.config.openaiApiKey) {
      throw new Error('OPENAI_API_KEY is required');
    }

    this.openai = new OpenAI({
      apiKey: this.config.openaiApiKey
    });
  }

  private getSystemPrompt(): string {
    return `Você é um assistente inteligente para o sistema de agendamento "Agenda Lotada 24h".
    
Suas responsabilidades incluem:
- Ajudar clientes a agendar serviços
- Responder perguntas sobre disponibilidade
- Fornecer informações sobre serviços e profissionais
- Auxiliar no reagendamento e cancelamento
- Oferecer recomendações personalizadas

Diretrizes:
- Seja sempre educado e profissional
- Mantenha respostas concisas e úteis
- Quando não souber algo, seja honesto e ofereça alternativas
- Priorize a experiência do usuário
- Use linguagem natural e amigável
- Sempre confirme informações importantes antes de executar ações

Contexto do sistema:
- Sistema de agendamento para profissionais de beleza, saúde e bem-estar
- Suporte a múltiplos profissionais e serviços
- Integração com WhatsApp, email e notificações push
- Funcionalidades de relatórios e analytics`;
  }

  async processMessage(message: string, context: ChatContext): Promise<ChatResponse> {
    try {
      // Salvar mensagem do usuário
      await this.saveMessage(context.sessionId, {
        id: this.generateId(),
        role: 'user',
        content: message,
        timestamp: new Date()
      });

      // Verificar cache se habilitado
      if (this.config.cacheEnabled) {
        const cachedResponse = await this.getCachedResponse(message, context);
        if (cachedResponse) {
          return cachedResponse;
        }
      }

      // Detectar intent
      const intent = await this.detectIntent(message, context);

      // Preparar mensagens para OpenAI
      const messages = await this.prepareMessages(message, context);

      // Chamar OpenAI
      const completion = await this.openai.chat.completions.create({
        model: this.config.model,
        messages,
        temperature: this.config.temperature,
        max_tokens: this.config.maxTokens
      });

      const responseContent = completion.choices[0]?.message?.content || 'Desculpe, não consegui processar sua mensagem.';

      // Determinar ações baseadas no intent
      const actions = await this.determineActions(intent, context);

      // Gerar sugestões
      const suggestions = await this.generateSuggestions(intent, context);

      const response: ChatResponse = {
        message: responseContent,
        intent,
        actions,
        suggestions,
        metadata: {
          model: this.config.model,
          tokens: completion.usage?.total_tokens || 0
        }
      };

      // Salvar resposta do assistente
      await this.saveMessage(context.sessionId, {
        id: this.generateId(),
        role: 'assistant',
        content: responseContent,
        timestamp: new Date(),
        metadata: response.metadata
      });

      // Cache da resposta se habilitado
      if (this.config.cacheEnabled) {
        await this.cacheResponse(message, context, response);
      }

      return response;

    } catch (error) {
      console.error('Erro ao processar mensagem:', error);
      return {
        message: 'Desculpe, ocorreu um erro ao processar sua mensagem. Tente novamente em alguns instantes.',
        intent: { name: 'error', confidence: 1.0 },
        actions: [{ type: 'TRANSFER_TO_HUMAN' }]
      };
    }
  }

  private async detectIntent(message: string, context: ChatContext): Promise<Intent> {
    const lowerMessage = message.toLowerCase();
    
    // Intents básicos baseados em palavras-chave
    const intents = [
      {
        name: 'book_appointment',
        keywords: ['agendar', 'marcar', 'reservar', 'horário', 'consulta'],
        confidence: 0.8
      },
      {
        name: 'check_availability',
        keywords: ['disponível', 'disponibilidade', 'livre', 'vago', 'horários'],
        confidence: 0.7
      },
      {
        name: 'cancel_booking',
        keywords: ['cancelar', 'desmarcar', 'remover agendamento'],
        confidence: 0.9
      },
      {
        name: 'reschedule',
        keywords: ['reagendar', 'remarcar', 'mudar horário', 'trocar'],
        confidence: 0.8
      },
      {
        name: 'service_info',
        keywords: ['serviço', 'preço', 'valor', 'duração', 'tempo'],
        confidence: 0.6
      },
      {
        name: 'professional_info',
        keywords: ['profissional', 'especialista', 'quem atende', 'cabeleireiro', 'dentista'],
        confidence: 0.6
      },
      {
        name: 'greeting',
        keywords: ['oi', 'olá', 'bom dia', 'boa tarde', 'boa noite'],
        confidence: 0.5
      }
    ];

    for (const intent of intents) {
      const matchCount = intent.keywords.filter(keyword => 
        lowerMessage.includes(keyword)
      ).length;
      
      if (matchCount > 0) {
        return {
          name: intent.name,
          confidence: intent.confidence * (matchCount / intent.keywords.length)
        };
      }
    }

    return { name: 'unknown', confidence: 0.1 };
  }

  private async prepareMessages(message: string, context: ChatContext): Promise<any[]> {
    const messages = [
      { role: 'system', content: this.config.systemPrompt }
    ];

    // Adicionar contexto do usuário
    if (context.userProfile) {
      messages.push({
        role: 'system',
        content: `Informações do usuário: Nome: ${context.userProfile.name || 'Não informado'}, Tipo: ${context.userProfile.role}`
      });
    }

    // Adicionar histórico da conversa (últimas 10 mensagens)
    const recentHistory = context.conversationHistory.slice(-10);
    for (const msg of recentHistory) {
      messages.push({
        role: msg.role,
        content: msg.content
      });
    }

    // Adicionar mensagem atual
    messages.push({ role: 'user', content: message });

    return messages;
  }

  private async determineActions(intent: Intent, context: ChatContext): Promise<ChatAction[]> {
    const actions: ChatAction[] = [];

    switch (intent.name) {
      case 'book_appointment':
        actions.push({
          type: 'SHOW_AVAILABILITY',
          data: { userId: context.userId }
        });
        break;
      
      case 'check_availability':
        actions.push({
          type: 'SHOW_AVAILABILITY',
          data: { userId: context.userId }
        });
        break;
      
      case 'cancel_booking':
        actions.push({
          type: 'CANCEL_BOOKING',
          data: { userId: context.userId }
        });
        break;
      
      case 'service_info':
        actions.push({
          type: 'SHOW_SERVICES',
          data: { tenantId: context.tenantId }
        });
        break;
    }

    return actions;
  }

  private async generateSuggestions(intent: Intent, context: ChatContext): Promise<string[]> {
    const suggestions: string[] = [];

    switch (intent.name) {
      case 'greeting':
        suggestions.push(
          'Quero agendar um horário',
          'Ver serviços disponíveis',
          'Verificar meus agendamentos'
        );
        break;
      
      case 'book_appointment':
        suggestions.push(
          'Mostrar horários disponíveis hoje',
          'Ver profissionais disponíveis',
          'Quais serviços vocês oferecem?'
        );
        break;
      
      case 'service_info':
        suggestions.push(
          'Agendar este serviço',
          'Ver outros serviços',
          'Quem são os profissionais?'
        );
        break;
    }

    return suggestions;
  }

  async createChatSession(userId: string, tenantId: string): Promise<ChatSession> {
    const session: ChatSession = {
      id: this.generateId(),
      userId,
      tenantId,
      startedAt: new Date(),
      lastActivity: new Date(),
      isActive: true,
      messages: []
    };

    // Salvar sessão no Redis
    await this.redis.setex(
      `chat_session:${session.id}`,
      this.config.cacheTtl,
      JSON.stringify(session)
    );

    return session;
  }

  async getChatSession(sessionId: string): Promise<ChatSession | null> {
    const sessionData = await this.redis.get(`chat_session:${sessionId}`);
    if (!sessionData) return null;

    return JSON.parse(sessionData);
  }

  async updateChatSession(session: ChatSession): Promise<void> {
    session.lastActivity = new Date();
    await this.redis.setex(
      `chat_session:${session.id}`,
      this.config.cacheTtl,
      JSON.stringify(session)
    );
  }

  private async saveMessage(sessionId: string, message: ChatMessage): Promise<void> {
    const session = await this.getChatSession(sessionId);
    if (session) {
      session.messages.push(message);
      await this.updateChatSession(session);
    }
  }

  private async getCachedResponse(message: string, context: ChatContext): Promise<ChatResponse | null> {
    const cacheKey = `ai_response:${this.hashMessage(message)}:${context.tenantId}`;
    const cachedData = await this.redis.get(cacheKey);
    
    if (cachedData) {
      return JSON.parse(cachedData);
    }
    
    return null;
  }

  private async cacheResponse(message: string, context: ChatContext, response: ChatResponse): Promise<void> {
    const cacheKey = `ai_response:${this.hashMessage(message)}:${context.tenantId}`;
    await this.redis.setex(cacheKey, this.config.cacheTtl, JSON.stringify(response));
  }

  private hashMessage(message: string): string {
    // Simples hash para cache - em produção usar crypto
    return Buffer.from(message.toLowerCase().trim()).toString('base64');
  }

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  async generateRecommendations(userId: string, type?: string): Promise<Recommendation[]> {
    try {
      const recommendations: Recommendation[] = [];

      // Buscar dados do usuário
      const user = await this.prisma.user.findUnique({
        where: { id: userId },
        include: {
          bookings: {
            include: {
              service: true,
              professional: true
            },
            orderBy: { createdAt: 'desc' },
            take: 10
          }
        }
      });

      if (!user) {
        return recommendations;
      }

      // Gerar diferentes tipos de recomendações
      if (!type || type === 'SERVICE') {
        const serviceRecs = await this.generateServiceRecommendations(user);
        recommendations.push(...serviceRecs);
      }

      if (!type || type === 'PROFESSIONAL') {
        const professionalRecs = await this.generateProfessionalRecommendations(user);
        recommendations.push(...professionalRecs);
      }

      if (!type || type === 'TIME_SLOT') {
        const timeSlotRecs = await this.generateTimeSlotRecommendations(user);
        recommendations.push(...timeSlotRecs);
      }

      if (!type || type === 'PROMOTION') {
        const promotionRecs = await this.generatePromotionRecommendations(user);
        recommendations.push(...promotionRecs);
      }

      // Ordenar por confiança
      return recommendations.sort((a, b) => b.confidence - a.confidence);

    } catch (error) {
      console.error('Erro ao gerar recomendações:', error);
      return [];
    }
  }

  private async generateServiceRecommendations(user: any): Promise<ServiceRecommendation[]> {
    const recommendations: ServiceRecommendation[] = [];

    try {
      // Buscar serviços populares no tenant
      const popularServices = await this.prisma.service.findMany({
        where: {
          tenantId: user.tenantId,
          isActive: true
        },
        include: {
          _count: {
            select: {
              bookings: true
            }
          }
        },
        orderBy: {
          bookings: {
            _count: 'desc'
          }
        },
        take: 5
      });

      // Analisar histórico do usuário
      const userServiceHistory = user.bookings.map((booking: any) => booking.service.id);
      const userServiceCategories = [...new Set(user.bookings.map((booking: any) => booking.service.category))];

      for (const service of popularServices) {
        let confidence = 0.5; // Base confidence
        let reason = 'Serviço popular';

        // Aumentar confiança se o usuário já usou serviços da mesma categoria
        if (service.category && userServiceCategories.includes(service.category)) {
          confidence += 0.2;
          reason = 'Baseado em seus serviços anteriores';
        }

        // Diminuir confiança se o usuário já usou este serviço recentemente
        if (userServiceHistory.includes(service.id)) {
          confidence -= 0.1;
        }

        // Aumentar confiança baseado na popularidade
        const popularityScore = Math.min(service._count.bookings / 100, 0.3);
        confidence += popularityScore;

        recommendations.push({
          id: this.generateId(),
          type: 'SERVICE',
          title: `Recomendamos: ${service.name}`,
          description: service.description || 'Serviço recomendado para você',
          confidence: Math.min(confidence, 1.0),
          data: {
            serviceId: service.id,
            serviceName: service.name,
            price: service.price,
            duration: service.duration,
            category: service.category || 'Geral'
          },
          reason
        });
      }

    } catch (error) {
      console.error('Erro ao gerar recomendações de serviços:', error);
    }

    return recommendations;
  }

  private async generateProfessionalRecommendations(user: any): Promise<ProfessionalRecommendation[]> {
    const recommendations: ProfessionalRecommendation[] = [];

    try {
      // Buscar profissionais ativos no tenant
      const professionals = await this.prisma.professional.findMany({
        where: {
          tenantId: user.tenantId
        },
        include: {
          user: true,
          bookings: {
            where: {
              status: 'COMPLETED'
            }
          },
          services: {
            include: {
              service: true
            }
          }
        },
        take: 5
      });

      // Analisar histórico do usuário
      const userProfessionalHistory = user.bookings.map((booking: any) => booking.professionalId);
      const userServiceCategories = [...new Set(user.bookings.map((booking: any) => booking.service.category))];

      for (const professional of professionals) {
        if (!professional.user.isActive) continue;

        let confidence = 0.4; // Base confidence
        let reason = 'Profissional qualificado';

        // Aumentar confiança baseado no número de atendimentos
        const completedBookings = professional.bookings.length;
        if (completedBookings > 10) {
          confidence += 0.2;
          reason = `Profissional experiente com ${completedBookings} atendimentos`;
        }

        // Verificar se o profissional oferece serviços que o usuário já usou
        const professionalCategories = professional.services
          .map((ps: any) => ps.service.category)
          .filter((cat: string) => cat !== null);
        
        const hasMatchingCategories = professionalCategories.some((cat: string) => 
          userServiceCategories.includes(cat)
        );
        
        if (hasMatchingCategories) {
          confidence += 0.2;
          reason = 'Especialista em serviços que você já utilizou';
        }

        // Diminuir confiança se o usuário já usou este profissional recentemente
        if (userProfessionalHistory.includes(professional.id)) {
          confidence -= 0.1;
        }

        recommendations.push({
          id: this.generateId(),
          type: 'PROFESSIONAL',
          title: `Recomendamos: ${professional.user.name}`,
          description: `Profissional especializado com ${completedBookings} atendimentos`,
          confidence: Math.min(confidence, 1.0),
          data: {
            professionalId: professional.id,
            professionalName: professional.user.name,
            rating: 4.5, // Rating padrão até implementar sistema de avaliações
            specialties: professionalCategories,
            availability: [] // Será preenchido dinamicamente
          },
          reason
        });
      }

    } catch (error) {
      console.error('Erro ao gerar recomendações de profissionais:', error);
    }

    return recommendations;
  }

  private async generateTimeSlotRecommendations(user: any): Promise<TimeSlotRecommendation[]> {
    const recommendations: TimeSlotRecommendation[] = [];

    try {
      // Analisar padrões de agendamento do usuário
      const userBookings = user.bookings.filter((booking: any) => booking.status === 'COMPLETED');
      
      if (userBookings.length === 0) {
        return recommendations;
      }

      // Calcular horários preferidos do usuário
      const preferredHours = userBookings.map((booking: any) => {
        const hour = new Date(booking.startTime).getHours();
        return hour;
      });

      const hourFrequency = preferredHours.reduce((acc: any, hour: number) => {
        acc[hour] = (acc[hour] || 0) + 1;
        return acc;
      }, {});

      const mostFrequentHour = Object.keys(hourFrequency).reduce((a, b) => 
        hourFrequency[a] > hourFrequency[b] ? a : b
      );

      // Calcular dias da semana preferidos
      const preferredDays = userBookings.map((booking: any) => {
        const day = new Date(booking.startTime).getDay();
        return day;
      });

      const dayFrequency = preferredDays.reduce((acc: any, day: number) => {
        acc[day] = (acc[day] || 0) + 1;
        return acc;
      }, {});

      const mostFrequentDay = Object.keys(dayFrequency).reduce((a, b) => 
        dayFrequency[a] > dayFrequency[b] ? a : b
      );

      // Gerar recomendações para os próximos 7 dias
      for (let i = 1; i <= 7; i++) {
        const date = new Date();
        date.setDate(date.getDate() + i);
        
        let confidence = 0.3; // Base confidence
        let reason = 'Horário disponível';

        // Aumentar confiança se for o dia da semana preferido
        if (date.getDay().toString() === mostFrequentDay) {
          confidence += 0.3;
          reason = 'Baseado em seu dia preferido da semana';
        }

        // Sugerir horário preferido
        const suggestedTime = `${mostFrequentHour.padStart(2, '0')}:00`;

        recommendations.push({
          id: this.generateId(),
          type: 'TIME_SLOT',
          title: `Horário otimizado: ${date.toLocaleDateString()} às ${suggestedTime}`,
          description: 'Horário baseado em seus padrões de agendamento',
          confidence: Math.min(confidence, 1.0),
          data: {
            date: date.toISOString().split('T')[0],
            time: suggestedTime,
            professionalId: '', // Será preenchido dinamicamente
            serviceId: '', // Será preenchido dinamicamente
            isOptimal: confidence > 0.5
          },
          reason
        });
      }

    } catch (error) {
      console.error('Erro ao gerar recomendações de horários:', error);
    }

    return recommendations.slice(0, 3); // Retornar apenas os 3 melhores
  }

  private async generatePromotionRecommendations(user: any): Promise<PromotionRecommendation[]> {
    const recommendations: PromotionRecommendation[] = [];

    try {
      // Por enquanto, gerar promoções fictícias baseadas no histórico do usuário
      // Em uma implementação futura, isso seria baseado em um modelo de Promotion real
      
      const userServiceCategories = [...new Set(user.bookings.map((booking: any) => booking.service.category))];
      const userServices = [...new Set(user.bookings.map((booking: any) => booking.service))];

      // Gerar promoção para serviços que o usuário já usou
      if (userServices.length > 0) {
        const randomService = userServices[Math.floor(Math.random() * userServices.length)] as any;
        
        recommendations.push({
          id: this.generateId(),
          type: 'PROMOTION',
          title: `Oferta especial: 20% de desconto em ${randomService.name}`,
          description: 'Promoção especial para clientes fiéis',
          confidence: 0.8,
          data: {
            promotionId: this.generateId(),
            discount: 20,
            validUntil: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 dias
            applicableServices: [randomService.id]
          },
          reason: 'Baseado em seus serviços favoritos'
        });
      }

      // Gerar promoção para novos clientes
      if (user.bookings.length <= 2) {
        recommendations.push({
          id: this.generateId(),
          type: 'PROMOTION',
          title: 'Desconto de boas-vindas: 15% off',
          description: 'Oferta especial para novos clientes',
          confidence: 0.7,
          data: {
            promotionId: this.generateId(),
            discount: 15,
            validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 dias
            applicableServices: []
          },
          reason: 'Oferta de boas-vindas'
        });
      }

    } catch (error) {
      console.error('Erro ao gerar recomendações de promoções:', error);
    }

    return recommendations;
  }

  async generateInsights(tenantId: string): Promise<AIInsight[]> {
    try {
      const insights: AIInsight[] = [];

      // Gerar diferentes tipos de insights
      const idlePeriodInsights = await this.generateIdlePeriodInsights(tenantId);
      insights.push(...idlePeriodInsights);

      const demandPredictions = await this.generateDemandPredictions(tenantId);
      insights.push(...demandPredictions);

      const churnRisks = await this.generateChurnRiskInsights(tenantId);
      insights.push(...churnRisks);

      const pricingOptimizations = await this.generatePricingOptimizations(tenantId);
      insights.push(...pricingOptimizations);

      // Ordenar por confiança
      return insights.sort((a, b) => b.confidence - a.confidence);

    } catch (error) {
      console.error('Erro ao gerar insights:', error);
      return [];
    }
  }

  async generateCampaignSuggestions(tenantId: string): Promise<CampaignSuggestion[]> {
    try {
      const suggestions: CampaignSuggestion[] = [];

      // Gerar diferentes tipos de campanhas
      const reactivationCampaigns = await this.generateReactivationCampaigns(tenantId);
      suggestions.push(...reactivationCampaigns);

      const promotionalCampaigns = await this.generatePromotionalCampaigns(tenantId);
      suggestions.push(...promotionalCampaigns);

      const retentionCampaigns = await this.generateRetentionCampaigns(tenantId);
      suggestions.push(...retentionCampaigns);

      return suggestions;

    } catch (error) {
      console.error('Erro ao gerar sugestões de campanha:', error);
      return [];
    }
  }

  private async generateIdlePeriodInsights(tenantId: string): Promise<AIInsight[]> {
    const insights: AIInsight[] = [];

    try {
      // Buscar profissionais do tenant
      const professionals = await this.prisma.professional.findMany({
        where: { tenantId },
        include: {
          user: true,
          bookings: {
            where: {
              startTime: {
                gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // Últimos 30 dias
              }
            }
          },
          schedules: true
        }
      });

      for (const professional of professionals) {
        // Analisar padrões de ocupação
        const totalHoursAvailable = this.calculateTotalAvailableHours(professional.schedules);
        const totalHoursBooked = this.calculateTotalBookedHours(professional.bookings);
        const occupationRate = totalHoursAvailable > 0 ? totalHoursBooked / totalHoursAvailable : 0;

        // Identificar períodos ociosos se a taxa de ocupação for baixa
        if (occupationRate < 0.6) {
          const idleSlots = this.identifyIdleTimeSlots(professional.schedules, professional.bookings);
          
          insights.push({
            id: this.generateId(),
            type: 'IDLE_PERIOD',
            title: `${professional.user.name} tem baixa ocupação`,
            description: `Taxa de ocupação de ${(occupationRate * 100).toFixed(1)}% nos últimos 30 dias`,
            confidence: 1 - occupationRate, // Maior confiança para menor ocupação
            data: {
              professionalId: professional.id,
              date: new Date().toISOString().split('T')[0],
              timeSlots: idleSlots,
              suggestedActions: [
                'Criar promoção para horários vagos',
                'Ajustar preços para horários de baixa demanda',
                'Oferecer serviços expressos'
              ]
            },
            actionable: true,
            createdAt: new Date()
          });
        }
      }

    } catch (error) {
      console.error('Erro ao gerar insights de períodos ociosos:', error);
    }

    return insights;
  }

  private async generateDemandPredictions(tenantId: string): Promise<AIInsight[]> {
    const insights: AIInsight[] = [];

    try {
      // Buscar dados históricos de agendamentos
      const historicalBookings = await this.prisma.booking.findMany({
        where: {
          tenantId,
          createdAt: {
            gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000) // Últimos 90 dias
          }
        },
        include: {
          service: true
        }
      });

      // Analisar padrões por dia da semana
      const demandByDay = this.analyzeDemandByDay(historicalBookings);
      
      // Prever demanda para os próximos 7 dias
      for (let i = 1; i <= 7; i++) {
        const futureDate = new Date();
        futureDate.setDate(futureDate.getDate() + i);
        const dayOfWeek = futureDate.getDay();
        
        const predictedDemand = demandByDay[dayOfWeek] || 0;
        const confidence = predictedDemand > 0 ? Math.min(predictedDemand / 10, 0.9) : 0.3;

        insights.push({
          id: this.generateId(),
          type: 'DEMAND_PREDICTION',
          title: `Previsão de demanda para ${futureDate.toLocaleDateString()}`,
          description: `Demanda prevista: ${predictedDemand} agendamentos`,
          confidence,
          data: {
            date: futureDate.toISOString().split('T')[0],
            predictedDemand,
            factors: [
              'Histórico do dia da semana',
              'Tendência dos últimos 90 dias',
              'Sazonalidade'
            ]
          },
          actionable: true,
          createdAt: new Date()
        });
      }

    } catch (error) {
      console.error('Erro ao gerar previsões de demanda:', error);
    }

    return insights.slice(0, 3); // Retornar apenas os 3 mais relevantes
  }

  private async generateChurnRiskInsights(tenantId: string): Promise<AIInsight[]> {
    const insights: AIInsight[] = [];

    try {
      // Buscar clientes que não agendam há mais de 60 dias
      const inactiveClients = await this.prisma.user.findMany({
        where: {
          tenantId,
          bookings: {
            every: {
              createdAt: {
                lt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000)
              }
            }
          }
        },
        include: {
          bookings: {
            orderBy: { createdAt: 'desc' },
            take: 5
          }
        }
      });

      for (const client of inactiveClients.slice(0, 10)) { // Limitar a 10 clientes
        const daysSinceLastBooking = client.bookings.length > 0 
          ? Math.floor((Date.now() - client.bookings[0].createdAt.getTime()) / (1000 * 60 * 60 * 24))
          : 365;

        const riskScore = Math.min(daysSinceLastBooking / 90, 1); // Risco máximo após 90 dias

        insights.push({
          id: this.generateId(),
          type: 'CHURN_RISK',
          title: `${client.name} em risco de abandono`,
          description: `Sem agendamentos há ${daysSinceLastBooking} dias`,
          confidence: riskScore,
          data: {
            clientId: client.id,
            riskScore,
            factors: [
              `${daysSinceLastBooking} dias sem agendamento`,
              'Histórico de cancelamentos',
              'Redução na frequência'
            ],
            suggestedActions: [
              'Enviar campanha de reativação',
              'Oferecer desconto especial',
              'Contato personalizado'
            ]
          },
          actionable: true,
          createdAt: new Date()
        });
      }

    } catch (error) {
      console.error('Erro ao gerar insights de risco de churn:', error);
    }

    return insights;
  }

  private async generatePricingOptimizations(tenantId: string): Promise<AIInsight[]> {
    const insights: AIInsight[] = [];

    try {
      // Buscar serviços com baixa demanda
      const services = await this.prisma.service.findMany({
        where: { tenantId, isActive: true },
        include: {
          _count: {
            select: {
              bookings: {
                where: {
                  createdAt: {
                    gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
                  }
                }
              }
            }
          }
        }
      });

      for (const service of services) {
        const monthlyBookings = service._count.bookings;
        
        // Se o serviço tem menos de 5 agendamentos no mês, sugerir otimização
        if (monthlyBookings < 5) {
          const suggestedPriceReduction = Math.min(service.price * 0.2, service.price * 0.4);
          const newPrice = service.price - suggestedPriceReduction;

          insights.push({
            id: this.generateId(),
            type: 'PRICING_OPTIMIZATION',
            title: `Otimização de preço para ${service.name}`,
            description: `Apenas ${monthlyBookings} agendamentos este mês`,
            confidence: monthlyBookings === 0 ? 0.9 : 0.6,
            data: {
              serviceId: service.id,
              currentPrice: service.price,
              suggestedPrice: newPrice,
              expectedImpact: 0.3, // 30% de aumento esperado na demanda
              reasoning: [
                'Baixa demanda atual',
                'Preço pode estar acima do mercado',
                'Redução temporária pode aumentar volume'
              ]
            },
            actionable: true,
            createdAt: new Date()
          });
        }
      }

    } catch (error) {
      console.error('Erro ao gerar otimizações de preço:', error);
    }

    return insights;
  }

  private async generateReactivationCampaigns(tenantId: string): Promise<CampaignSuggestion[]> {
    const campaigns: CampaignSuggestion[] = [];

    try {
      // Buscar clientes inativos
      const inactiveCount = await this.prisma.user.count({
        where: {
          tenantId,
          bookings: {
            every: {
              createdAt: {
                lt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000)
              }
            }
          }
        }
      });

      if (inactiveCount > 0) {
        campaigns.push({
          id: this.generateId(),
          type: 'REACTIVATION',
          title: 'Campanha de Reativação - "Sentimos sua falta"',
          description: `Reativar ${inactiveCount} clientes inativos`,
          targetAudience: {
            criteria: {
              lastBooking: '45+ dias atrás',
              totalBookings: '2+ agendamentos históricos'
            },
            estimatedSize: inactiveCount
          },
          content: {
            subject: 'Sentimos sua falta! Oferta especial para você',
            message: 'Olá {{nome}}! Notamos que você não agenda conosco há um tempo. Que tal voltar com 25% de desconto no seu próximo agendamento?',
            callToAction: 'Agendar com Desconto'
          },
          timing: {
            bestTime: '10:00 - 16:00',
            frequency: 'Uma vez por semana por 3 semanas'
          },
          expectedResults: {
            openRate: 0.35,
            clickRate: 0.12,
            conversionRate: 0.08
          },
          createdAt: new Date()
        });
      }

    } catch (error) {
      console.error('Erro ao gerar campanhas de reativação:', error);
    }

    return campaigns;
  }

  private async generatePromotionalCampaigns(tenantId: string): Promise<CampaignSuggestion[]> {
    const campaigns: CampaignSuggestion[] = [];

    try {
      // Identificar horários com baixa ocupação
      const lowDemandPeriods = await this.identifyLowDemandPeriods(tenantId);

      if (lowDemandPeriods.length > 0) {
        campaigns.push({
          id: this.generateId(),
          type: 'PROMOTION',
          title: 'Campanha de Horários Especiais',
          description: 'Promover horários com baixa demanda',
          targetAudience: {
            criteria: {
              lastBooking: 'Últimos 30 dias',
              preferredTimes: 'Flexível'
            },
            estimatedSize: 150
          },
          content: {
            subject: 'Horários especiais com desconto!',
            message: 'Aproveite nossos horários especiais com 30% de desconto. Disponível das {{horario_inicio}} às {{horario_fim}}.',
            callToAction: 'Ver Horários Disponíveis'
          },
          timing: {
            bestTime: '09:00 - 11:00',
            frequency: 'Duas vezes por semana'
          },
          expectedResults: {
            openRate: 0.42,
            clickRate: 0.18,
            conversionRate: 0.12
          },
          createdAt: new Date()
        });
      }

    } catch (error) {
      console.error('Erro ao gerar campanhas promocionais:', error);
    }

    return campaigns;
  }

  private async generateRetentionCampaigns(tenantId: string): Promise<CampaignSuggestion[]> {
    const campaigns: CampaignSuggestion[] = [];

    try {
      // Buscar clientes frequentes
      const frequentClientsCount = await this.prisma.user.count({
        where: {
          tenantId,
          bookings: {
            some: {
              createdAt: {
                gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
              }
            }
          }
        }
      });

      if (frequentClientsCount > 0) {
        campaigns.push({
          id: this.generateId(),
          type: 'RETENTION',
          title: 'Programa de Fidelidade',
          description: 'Recompensar clientes fiéis',
          targetAudience: {
            criteria: {
              totalBookings: '5+ agendamentos',
              lastBooking: 'Últimos 30 dias'
            },
            estimatedSize: frequentClientsCount
          },
          content: {
            subject: 'Você é especial para nós!',
            message: 'Obrigado por ser um cliente fiel! A cada 5 agendamentos, ganhe 1 grátis. Você já tem {{agendamentos_count}} agendamentos.',
            callToAction: 'Ver Meus Pontos'
          },
          timing: {
            bestTime: '14:00 - 17:00',
            frequency: 'Mensal'
          },
          expectedResults: {
            openRate: 0.55,
            clickRate: 0.25,
            conversionRate: 0.18
          },
          createdAt: new Date()
        });
      }

    } catch (error) {
      console.error('Erro ao gerar campanhas de retenção:', error);
    }

    return campaigns;
  }

  // Métodos auxiliares
  private calculateTotalAvailableHours(schedules: any[]): number {
    // Simplificado - calcular horas disponíveis por semana
    let totalHours = 0;
    for (const schedule of schedules) {
      if (schedule.isActive) {
        const start = this.timeToMinutes(schedule.startTime);
        const end = this.timeToMinutes(schedule.endTime);
        totalHours += (end - start) / 60;
      }
    }
    return totalHours * 4; // 4 semanas no mês
  }

  private calculateTotalBookedHours(bookings: any[]): number {
    return bookings.reduce((total, booking) => {
      const duration = (new Date(booking.endTime).getTime() - new Date(booking.startTime).getTime()) / (1000 * 60 * 60);
      return total + duration;
    }, 0);
  }

  private identifyIdleTimeSlots(schedules: any[], bookings: any[]): string[] {
    // Simplificado - retornar slots genéricos
    return ['09:00-10:00', '14:00-15:00', '16:00-17:00'];
  }

  private analyzeDemandByDay(bookings: any[]): number[] {
    const demandByDay = new Array(7).fill(0);
    
    for (const booking of bookings) {
      const dayOfWeek = new Date(booking.startTime).getDay();
      demandByDay[dayOfWeek]++;
    }
    
    return demandByDay;
  }

  private async identifyLowDemandPeriods(tenantId: string): Promise<string[]> {
    // Simplificado - retornar períodos genéricos
    return ['10:00-12:00', '14:00-16:00'];
  }

  private timeToMinutes(time: string): number {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  }
}