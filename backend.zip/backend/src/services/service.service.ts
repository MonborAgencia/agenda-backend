import { PrismaClient } from '@prisma/client';
import { 
  CreateServiceRequest, 
  UpdateServiceRequest, 
  ServiceResponse, 
  ServiceFilters,
  ServiceCategory 
} from '../types/service.types';

export class ServiceService {
  constructor(private readonly prisma: PrismaClient) {}
  /**
   * Criar um novo serviço
   */
  async createService(data: CreateServiceRequest, tenantId: string): Promise<ServiceResponse> {
    // Verificar se o profissional existe e pertence ao tenant
    const professional = await this.prisma.professional.findFirst({
      where: {
        id: data.professionalId,
        tenantId: tenantId
      },
      include: {
        user: true
      }
    });

    if (!professional) {
      throw new Error('Profissional não encontrado ou não pertence ao tenant');
    }

    // Verificar se já existe um serviço com o mesmo nome para este profissional
    const existingService = await this.prisma.service.findFirst({
      where: {
        name: data.name,
        professionalId: data.professionalId,
        tenantId: tenantId
      }
    });

    if (existingService) {
      throw new Error('Já existe um serviço com este nome para este profissional');
    }

    const service = await this.prisma.service.create({
      data: {
        ...data,
        tenantId
      },
      include: {
        professional: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true
              }
            }
          }
        }
      }
    });

    return service;
  }

  /**
   * Buscar serviços com filtros
   */
  async getServices(tenantId: string, filters: ServiceFilters = {}): Promise<ServiceResponse[]> {
    const where: any = {
      tenantId,
      ...(filters.category && { category: filters.category }),
      ...(filters.professionalId && { professionalId: filters.professionalId }),
      ...(filters.isActive !== undefined && { isActive: filters.isActive }),
      ...(filters.minPrice && { price: { gte: filters.minPrice } }),
      ...(filters.maxPrice && { price: { lte: filters.maxPrice } }),
      ...(filters.minDuration && { duration: { gte: filters.minDuration } }),
      ...(filters.maxDuration && { duration: { lte: filters.maxDuration } })
    };

    // Combinar filtros de preço se ambos existirem
    if (filters.minPrice && filters.maxPrice) {
      where.price = {
        gte: filters.minPrice,
        lte: filters.maxPrice
      };
    }

    // Combinar filtros de duração se ambos existirem
    if (filters.minDuration && filters.maxDuration) {
      where.duration = {
        gte: filters.minDuration,
        lte: filters.maxDuration
      };
    }

    const services = await this.prisma.service.findMany({
      where,
      include: {
        professional: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true
              }
            }
          }
        }
      },
      orderBy: [
        { category: 'asc' },
        { name: 'asc' }
      ]
    });

    return services;
  }

  /**
   * Buscar serviço por ID
   */
  async getServiceById(id: string, tenantId: string): Promise<ServiceResponse | null> {
    const service = await this.prisma.service.findFirst({
      where: {
        id,
        tenantId
      },
      include: {
        professional: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true
              }
            }
          }
        }
      }
    });

    return service;
  }

  /**
   * Atualizar serviço
   */
  async updateService(id: string, data: UpdateServiceRequest, tenantId: string): Promise<ServiceResponse> {
    // Verificar se o serviço existe e pertence ao tenant
    const existingService = await this.prisma.service.findFirst({
      where: {
        id,
        tenantId
      }
    });

    if (!existingService) {
      throw new Error('Serviço não encontrado');
    }

    // Se está alterando o nome, verificar se não há conflito
    if (data.name && data.name !== existingService.name) {
      const conflictingService = await this.prisma.service.findFirst({
        where: {
          name: data.name,
          professionalId: existingService.professionalId,
          tenantId,
          id: { not: id }
        }
      });

      if (conflictingService) {
        throw new Error('Já existe um serviço com este nome para este profissional');
      }
    }

    const service = await this.prisma.service.update({
      where: { id },
      data,
      include: {
        professional: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true
              }
            }
          }
        }
      }
    });

    return service;
  }

  /**
   * Deletar serviço
   */
  async deleteService(id: string, tenantId: string): Promise<void> {
    // Verificar se o serviço existe e pertence ao tenant
    const service = await this.prisma.service.findFirst({
      where: {
        id,
        tenantId
      }
    });

    if (!service) {
      throw new Error('Serviço não encontrado');
    }

    // Verificar se há agendamentos ativos para este serviço
    const activeBookings = await this.prisma.booking.findFirst({
      where: {
        serviceId: id,
        status: {
          in: ['SCHEDULED', 'CONFIRMED']
        }
      }
    });

    if (activeBookings) {
      throw new Error('Não é possível deletar um serviço com agendamentos ativos');
    }

    await this.prisma.service.delete({
      where: { id }
    });
  }

  /**
   * Buscar serviços por profissional
   */
  async getServicesByProfessional(professionalId: string, tenantId: string): Promise<ServiceResponse[]> {
    const services = await this.prisma.service.findMany({
      where: {
        professionalId,
        tenantId,
        isActive: true
      },
      include: {
        professional: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true
              }
            }
          }
        }
      },
      orderBy: [
        { category: 'asc' },
        { name: 'asc' }
      ]
    });

    return services;
  }

  /**
   * Buscar categorias de serviços
   */
  async getServiceCategories(tenantId: string): Promise<ServiceCategory[]> {
    const categories = await this.prisma.service.groupBy({
      by: ['category'],
      where: {
        tenantId,
        isActive: true,
        category: {
          not: null
        }
      },
      _count: {
        category: true
      },
      orderBy: {
        category: 'asc'
      }
    });

    return categories.map((cat: any) => ({
      name: cat.category || '',
      count: cat._count.category
    }));
  }

  /**
   * Associar serviço a profissional (transferir serviço)
   */
  async transferService(serviceId: string, newProfessionalId: string, tenantId: string): Promise<ServiceResponse> {
    // Verificar se o serviço existe
    const service = await this.prisma.service.findFirst({
      where: {
        id: serviceId,
        tenantId
      }
    });

    if (!service) {
      throw new Error('Serviço não encontrado');
    }

    // Verificar se o novo profissional existe e pertence ao tenant
    const professional = await this.prisma.professional.findFirst({
      where: {
        id: newProfessionalId,
        tenantId
      }
    });

    if (!professional) {
      throw new Error('Profissional não encontrado ou não pertence ao tenant');
    }

    // Verificar se não há conflito de nome
    const conflictingService = await this.prisma.service.findFirst({
      where: {
        name: service.name,
        professionalId: newProfessionalId,
        tenantId,
        id: { not: serviceId }
      }
    });

    if (conflictingService) {
      throw new Error('O profissional já possui um serviço com este nome');
    }

    const updatedService = await this.prisma.service.update({
      where: { id: serviceId },
      data: {
        professionalId: newProfessionalId
      },
      include: {
        professional: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true
              }
            }
          }
        }
      }
    });

    return updatedService;
  }
}

const prisma = new PrismaClient();
export const serviceService = new ServiceService(prisma);