import { PrismaClient } from '@prisma/client';
import { CancellationPolicy } from '../types/booking.types';

const prisma = new PrismaClient();

export interface CancellationPolicyConfig {
  id?: string;
  tenantId: string;
  minimumHours: number;
  allowCancellation: boolean;
  chargePercentage: number;
  allowReschedule: boolean;
  rescheduleMinimumHours: number;
  maxReschedules: number;
  reason?: string;
  isActive: boolean;
}

export class CancellationPolicyService {

  /**
   * Busca a política de cancelamento para um tenant
   */
  async getPolicyByTenant(tenantId: string): Promise<CancellationPolicy> {
    // Por enquanto retorna política padrão
    // No futuro pode buscar de uma tabela de configurações
    return {
      minimumHours: 24,
      allowCancellation: true,
      chargePercentage: 0,
      reason: 'Política padrão do sistema'
    };
  }

  /**
   * Cria ou atualiza política de cancelamento para um tenant
   */
  async upsertPolicy(config: CancellationPolicyConfig): Promise<CancellationPolicyConfig> {
    // Por enquanto apenas retorna a configuração
    // No futuro implementar persistência
    console.log('Política de cancelamento configurada:', config);
    return config;
  }

  /**
   * Valida se um cancelamento é permitido
   */
  async validateCancellation(
    bookingId: string, 
    tenantId: string, 
    requestedAt: Date = new Date()
  ): Promise<{ allowed: boolean; reason?: string; chargePercentage?: number }> {
    
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId }
    });

    if (!booking) {
      return { allowed: false, reason: 'Agendamento não encontrado' };
    }

    if (!['SCHEDULED', 'CONFIRMED', 'RESCHEDULED'].includes(booking.status)) {
      return { allowed: false, reason: 'Agendamento não pode ser cancelado no status atual' };
    }

    const policy = await this.getPolicyByTenant(tenantId);
    
    if (!policy.allowCancellation) {
      return { allowed: false, reason: 'Cancelamento não permitido pela política do estabelecimento' };
    }

    const hoursUntilBooking = (booking.startTime.getTime() - requestedAt.getTime()) / (1000 * 60 * 60);
    
    if (hoursUntilBooking < policy.minimumHours) {
      return { 
        allowed: false, 
        reason: `Cancelamento deve ser feito com pelo menos ${policy.minimumHours} horas de antecedência`,
        chargePercentage: policy.chargePercentage
      };
    }

    return { 
      allowed: true, 
      chargePercentage: policy.chargePercentage 
    };
  }

  /**
   * Valida se um reagendamento é permitido
   */
  async validateReschedule(
    bookingId: string, 
    tenantId: string, 
    newStartTime: Date,
    requestedAt: Date = new Date()
  ): Promise<{ allowed: boolean; reason?: string }> {
    
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId }
    });

    if (!booking) {
      return { allowed: false, reason: 'Agendamento não encontrado' };
    }

    if (!['SCHEDULED', 'CONFIRMED'].includes(booking.status)) {
      return { allowed: false, reason: 'Agendamento não pode ser reagendado no status atual' };
    }

    // Verificar se não está reagendando para o passado
    if (newStartTime < requestedAt) {
      return { allowed: false, reason: 'Não é possível reagendar para datas passadas' };
    }

    // Verificar política de reagendamento (implementação futura)
    const policy = await this.getPolicyByTenant(tenantId);
    const hoursUntilBooking = (booking.startTime.getTime() - requestedAt.getTime()) / (1000 * 60 * 60);
    
    // Por enquanto usa a mesma regra do cancelamento
    if (hoursUntilBooking < policy.minimumHours) {
      return { 
        allowed: false, 
        reason: `Reagendamento deve ser feito com pelo menos ${policy.minimumHours} horas de antecedência`
      };
    }

    return { allowed: true };
  }

  /**
   * Calcula taxa de cancelamento
   */
  async calculateCancellationFee(
    bookingId: string, 
    tenantId: string
  ): Promise<{ fee: number; percentage: number }> {
    
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId }
    });

    if (!booking) {
      throw new Error('Agendamento não encontrado');
    }

    const policy = await this.getPolicyByTenant(tenantId);
    const fee = (booking.price * policy.chargePercentage) / 100;

    return {
      fee,
      percentage: policy.chargePercentage
    };
  }

  /**
   * Libera automaticamente horário após cancelamento
   */
  async releaseTimeSlot(bookingId: string): Promise<void> {
    // Implementação futura - pode incluir:
    // - Notificar outros clientes na lista de espera
    // - Atualizar cache de disponibilidade
    // - Registrar slot como disponível novamente
    
    console.log(`Horário liberado para booking ${bookingId}`);
    
    // Por enquanto apenas log
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        professional: {
          include: {
            user: { select: { name: true } }
          }
        },
        service: { select: { name: true } }
      }
    });

    if (booking) {
      console.log(`Slot liberado: ${booking.professional.user.name} - ${booking.service.name} - ${booking.startTime}`);
    }
  }

  /**
   * Processa liberação automática de horários cancelados
   */
  async processAutomaticRelease(): Promise<void> {
    // Buscar agendamentos cancelados recentemente
    const recentlyCancelled = await prisma.booking.findMany({
      where: {
        status: 'CANCELLED',
        updatedAt: {
          gte: new Date(Date.now() - 60 * 60 * 1000) // última hora
        }
      }
    });

    for (const booking of recentlyCancelled) {
      await this.releaseTimeSlot(booking.id);
    }

    console.log(`Processados ${recentlyCancelled.length} cancelamentos para liberação automática`);
  }
}

export const cancellationPolicyService = new CancellationPolicyService();