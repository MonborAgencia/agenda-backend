import { PrismaClient } from '@prisma/client';

export interface QueryOptimizationOptions {
  page?: number;
  limit?: number;
  orderBy?: Record<string, 'asc' | 'desc'>;
  select?: Record<string, boolean>;
  include?: Record<string, any>;
}

export interface PaginationResult<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

export class QueryOptimizationService {
  constructor(private readonly prisma: PrismaClient) {}

  /**
   * Create optimized pagination
   */
  createPagination(page: number = 1, limit: number = 10) {
    const skip = (page - 1) * limit;
    return {
      skip,
      take: limit
    };
  }

  /**
   * Build pagination result
   */
  buildPaginationResult<T>(
    data: T[],
    total: number,
    page: number,
    limit: number
  ): PaginationResult<T> {
    const totalPages = Math.ceil(total / limit);
    
    return {
      data,
      pagination: {
        page,
        limit,
        total,
        totalPages,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    };
  }

  /**
   * Optimized booking queries with proper indexes
   */
  async getBookingsOptimized(
    tenantId: string,
    filters: {
      professionalId?: string;
      clientId?: string;
      status?: string;
      startDate?: Date;
      endDate?: Date;
      page?: number;
      limit?: number;
    }
  ): Promise<PaginationResult<any>> {
    const { page = 1, limit = 10, ...whereFilters } = filters;
    const { skip, take } = this.createPagination(page, limit);

    // Build optimized where clause
    const where: any = {
      tenantId,
      ...whereFilters
    };

    // Add date range filter if provided
    if (filters.startDate || filters.endDate) {
      where.startTime = {};
      if (filters.startDate) {
        where.startTime.gte = filters.startDate;
      }
      if (filters.endDate) {
        where.startTime.lte = filters.endDate;
      }
    }

    // Execute optimized queries in parallel
    const [bookings, total] = await Promise.all([
      this.prisma.booking.findMany({
        where,
        skip,
        take,
        orderBy: { startTime: 'desc' },
        select: {
          id: true,
          startTime: true,
          endTime: true,
          status: true,
          price: true,
          notes: true,
          createdAt: true,
          client: {
            select: {
              id: true,
              name: true,
              email: true,
              phone: true
            }
          },
          professional: {
            select: {
              id: true,
              user: {
                select: {
                  name: true,
                  email: true
                }
              }
            }
          },
          service: {
            select: {
              id: true,
              name: true,
              duration: true,
              price: true
            }
          }
        }
      }),
      this.prisma.booking.count({ where })
    ]);

    return this.buildPaginationResult(bookings, total, page, limit);
  }

  /**
   * Optimized availability query
   */
  async getAvailabilityOptimized(
    professionalId: string,
    date: Date,
    serviceId?: string
  ): Promise<any[]> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    // Get schedule and bookings in parallel
    const [schedules, bookings, service] = await Promise.all([
      this.prisma.schedule.findMany({
        where: {
          professionalId,
          dayOfWeek: date.getDay(),
          isActive: true
        },
        include: {
          exceptions: {
            where: {
              date: {
                gte: startOfDay,
                lte: endOfDay
              }
            }
          }
        }
      }),
      this.prisma.booking.findMany({
        where: {
          professionalId,
          startTime: {
            gte: startOfDay,
            lte: endOfDay
          },
          status: {
            not: 'CANCELLED'
          }
        },
        select: {
          startTime: true,
          endTime: true
        },
        orderBy: {
          startTime: 'asc'
        }
      }),
      serviceId ? this.prisma.service.findUnique({
        where: { id: serviceId },
        select: { duration: true }
      }) : null
    ]);

    // Process availability logic here
    // This is a simplified version - full implementation would be more complex
    return [];
  }

  /**
   * Optimized dashboard metrics query
   */
  async getDashboardMetricsOptimized(
    tenantId: string,
    startDate: Date,
    endDate: Date
  ): Promise<any> {
    // Use raw queries for better performance on aggregations
    const [
      totalBookings,
      completedBookings,
      cancelledBookings,
      revenue,
      topServices
    ] = await Promise.all([
      this.prisma.booking.count({
        where: {
          tenantId,
          createdAt: {
            gte: startDate,
            lte: endDate
          }
        }
      }),
      this.prisma.booking.count({
        where: {
          tenantId,
          status: 'COMPLETED',
          startTime: {
            gte: startDate,
            lte: endDate
          }
        }
      }),
      this.prisma.booking.count({
        where: {
          tenantId,
          status: 'CANCELLED',
          startTime: {
            gte: startDate,
            lte: endDate
          }
        }
      }),
      this.prisma.booking.aggregate({
        where: {
          tenantId,
          status: 'COMPLETED',
          startTime: {
            gte: startDate,
            lte: endDate
          }
        },
        _sum: {
          price: true
        }
      }),
      this.prisma.booking.groupBy({
        by: ['serviceId'],
        where: {
          tenantId,
          startTime: {
            gte: startDate,
            lte: endDate
          }
        },
        _count: {
          id: true
        },
        orderBy: {
          _count: {
            id: 'desc'
          }
        },
        take: 5
      })
    ]);

    return {
      totalBookings,
      completedBookings,
      cancelledBookings,
      revenue: revenue._sum.price || 0,
      topServices
    };
  }

  /**
   * Optimized user search with full-text capabilities
   */
  async searchUsersOptimized(
    tenantId: string,
    searchTerm: string,
    options: QueryOptimizationOptions = {}
  ): Promise<PaginationResult<any>> {
    const { page = 1, limit = 10 } = options;
    const { skip, take } = this.createPagination(page, limit);

    // For SQLite, we use LIKE queries. For PostgreSQL, we could use full-text search
    const where = {
      tenantId,
      OR: [
        { name: { contains: searchTerm } },
        { email: { contains: searchTerm } },
        { phone: { contains: searchTerm } }
      ]
    };

    const [users, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        skip,
        take,
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
          isActive: true,
          createdAt: true,
          professional: {
            select: {
              id: true
            }
          }
        },
        orderBy: {
          name: 'asc'
        }
      }),
      this.prisma.user.count({ where })
    ]);

    return this.buildPaginationResult(users, total, page, limit);
  }

  /**
   * Batch operations for better performance
   */
  async batchUpdateBookingStatus(
    bookingIds: string[],
    status: string,
    tenantId: string
  ): Promise<number> {
    const result = await this.prisma.booking.updateMany({
      where: {
        id: {
          in: bookingIds
        },
        tenantId
      },
      data: {
        status,
        updatedAt: new Date()
      }
    });

    return result.count;
  }

  /**
   * Optimized analytics query with proper aggregations
   */
  async getAnalyticsOptimized(
    tenantId: string,
    type: 'daily' | 'weekly' | 'monthly',
    startDate: Date,
    endDate: Date
  ): Promise<any[]> {
    // This would use raw SQL for better performance in production
    // For now, using Prisma aggregations
    
    const bookings = await this.prisma.booking.findMany({
      where: {
        tenantId,
        startTime: {
          gte: startDate,
          lte: endDate
        }
      },
      select: {
        startTime: true,
        status: true,
        price: true
      }
    });

    // Group by date periods
    const grouped = bookings.reduce((acc, booking) => {
      let key: string;
      const date = new Date(booking.startTime);
      
      switch (type) {
        case 'daily':
          key = date.toISOString().split('T')[0];
          break;
        case 'weekly':
          const weekStart = new Date(date);
          weekStart.setDate(date.getDate() - date.getDay());
          key = weekStart.toISOString().split('T')[0];
          break;
        case 'monthly':
          key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
          break;
        default:
          key = date.toISOString().split('T')[0];
      }

      if (!acc[key]) {
        acc[key] = {
          date: key,
          totalBookings: 0,
          completedBookings: 0,
          cancelledBookings: 0,
          revenue: 0
        };
      }

      acc[key].totalBookings++;
      if (booking.status === 'COMPLETED') {
        acc[key].completedBookings++;
        acc[key].revenue += booking.price;
      } else if (booking.status === 'CANCELLED') {
        acc[key].cancelledBookings++;
      }

      return acc;
    }, {} as Record<string, any>);

    return Object.values(grouped);
  }

  /**
   * Connection pooling optimization
   */
  async executeInTransaction<T>(
    operations: (prisma: PrismaClient) => Promise<T>
  ): Promise<T> {
    return await this.prisma.$transaction(async (tx) => {
      return await operations(tx);
    });
  }

  /**
   * Query performance monitoring
   */
  async monitorQuery<T>(
    queryName: string,
    queryFn: () => Promise<T>
  ): Promise<T> {
    const startTime = Date.now();
    
    try {
      const result = await queryFn();
      const duration = Date.now() - startTime;
      
      console.log(`Query ${queryName} completed in ${duration}ms`);
      
      // Log slow queries (> 1 second)
      if (duration > 1000) {
        console.warn(`Slow query detected: ${queryName} took ${duration}ms`);
      }
      
      return result;
    } catch (error) {
      const duration = Date.now() - startTime;
      console.error(`Query ${queryName} failed after ${duration}ms:`, error);
      throw error;
    }
  }
}

// Export singleton instance
export const queryOptimizationService = new QueryOptimizationService(new PrismaClient());