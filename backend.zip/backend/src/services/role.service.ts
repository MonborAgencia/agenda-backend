import { PrismaClient } from '@prisma/client';
import { CreateRoleInput, UpdateRoleInput, CreatePermissionInput } from '../types/user.types';

export class RoleService {
  constructor(private readonly prisma: PrismaClient) {}

  /**
   * Create a new role with permissions
   */
  async createRole(data: CreateRoleInput) {
    const { permissionIds, ...roleData } = data;

    return this.prisma.$transaction(async (tx) => {
      // Create role
      const role = await tx.role.create({
        data: roleData,
      });

      // Assign permissions if provided
      if (permissionIds && permissionIds.length > 0) {
        await tx.rolePermission.createMany({
          data: permissionIds.map(permissionId => ({
            roleId: role.id,
            permissionId,
          })),
        });
      }

      // Return role with permissions
      return this.getRoleById(role.id);
    });
  }

  /**
   * Get role by ID with permissions
   */
  async getRoleById(id: string) {
    return this.prisma.role.findUnique({
      where: { id },
      include: {
        rolePermissions: {
          include: {
            permission: true,
          },
        },
        userRoles: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
      },
    });
  }

  /**
   * Get role by name
   */
  async getRoleByName(name: string) {
    return this.prisma.role.findUnique({
      where: { name },
      include: {
        rolePermissions: {
          include: {
            permission: true,
          },
        },
      },
    });
  }

  /**
   * Update role
   */
  async updateRole(id: string, data: UpdateRoleInput) {
    const { permissionIds, ...updateData } = data;

    return this.prisma.$transaction(async (tx) => {
      // Update role data
      await tx.role.update({
        where: { id },
        data: updateData,
      });

      // Update permissions if provided
      if (permissionIds !== undefined) {
        // Remove existing permissions
        await tx.rolePermission.deleteMany({
          where: { roleId: id },
        });

        // Add new permissions
        if (permissionIds.length > 0) {
          await tx.rolePermission.createMany({
            data: permissionIds.map(permissionId => ({
              roleId: id,
              permissionId,
            })),
          });
        }
      }

      return this.getRoleById(id);
    });
  }

  /**
   * Delete role
   */
  async deleteRole(id: string): Promise<void> {
    await this.prisma.$transaction(async (tx) => {
      // Remove role permissions
      await tx.rolePermission.deleteMany({
        where: { roleId: id },
      });

      // Remove user roles
      await tx.userRole.deleteMany({
        where: { roleId: id },
      });

      // Delete role
      await tx.role.delete({
        where: { id },
      });
    });
  }

  /**
   * Get all roles with pagination
   */
  async getRoles(params: {
    page?: number;
    limit?: number;
    isActive?: boolean;
    search?: string;
  } = {}) {
    const { page = 1, limit = 10, isActive, search } = params;
    const skip = (page - 1) * limit;

    const where: any = {};

    if (isActive !== undefined) {
      where.isActive = isActive;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [roles, total] = await Promise.all([
      this.prisma.role.findMany({
        where,
        skip,
        take: limit,
        include: {
          rolePermissions: {
            include: {
              permission: true,
            },
          },
          _count: {
            select: {
              userRoles: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.role.count({ where }),
    ]);

    return {
      roles,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Add permission to role
   */
  async addPermissionToRole(roleId: string, permissionId: string) {
    return this.prisma.rolePermission.create({
      data: {
        roleId,
        permissionId,
      },
    });
  }

  /**
   * Remove permission from role
   */
  async removePermissionFromRole(roleId: string, permissionId: string) {
    return this.prisma.rolePermission.delete({
      where: {
        roleId_permissionId: {
          roleId,
          permissionId,
        },
      },
    });
  }

  /**
   * Create a new permission
   */
  async createPermission(data: CreatePermissionInput) {
    return this.prisma.permission.create({
      data,
    });
  }

  /**
   * Get permission by ID
   */
  async getPermissionById(id: string) {
    return this.prisma.permission.findUnique({
      where: { id },
      include: {
        rolePermissions: {
          include: {
            role: true,
          },
        },
      },
    });
  }

  /**
   * Get all permissions with pagination
   */
  async getPermissions(params: {
    page?: number;
    limit?: number;
    resource?: string;
    action?: string;
    search?: string;
  } = {}) {
    const { page = 1, limit = 50, resource, action, search } = params;
    const skip = (page - 1) * limit;

    const where: any = {};

    if (resource) {
      where.resource = resource;
    }

    if (action) {
      where.action = action;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { resource: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [permissions, total] = await Promise.all([
      this.prisma.permission.findMany({
        where,
        skip,
        take: limit,
        include: {
          _count: {
            select: {
              rolePermissions: true,
            },
          },
        },
        orderBy: [
          { resource: 'asc' },
          { action: 'asc' },
        ],
      }),
      this.prisma.permission.count({ where }),
    ]);

    return {
      permissions,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Update permission
   */
  async updatePermission(id: string, data: Partial<CreatePermissionInput>) {
    return this.prisma.permission.update({
      where: { id },
      data,
    });
  }

  /**
   * Delete permission
   */
  async deletePermission(id: string): Promise<void> {
    await this.prisma.$transaction(async (tx) => {
      // Remove role permissions
      await tx.rolePermission.deleteMany({
        where: { permissionId: id },
      });

      // Delete permission
      await tx.permission.delete({
        where: { id },
      });
    });
  }

  /**
   * Get permissions by resource
   */
  async getPermissionsByResource(resource: string) {
    return this.prisma.permission.findMany({
      where: { resource },
      orderBy: { action: 'asc' },
    });
  }

  /**
   * Check if role has permission
   */
  async roleHasPermission(roleId: string, permissionId: string): Promise<boolean> {
    const rolePermission = await this.prisma.rolePermission.findUnique({
      where: {
        roleId_permissionId: {
          roleId,
          permissionId,
        },
      },
    });

    return !!rolePermission;
  }
}