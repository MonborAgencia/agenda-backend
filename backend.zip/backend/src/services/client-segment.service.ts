import { PrismaClient } from '@prisma/client';
import {
  ClientSegment,
  CreateClientSegmentDto,
  UpdateClientSegmentDto,
  SegmentationCriteria
} from '../types/campaign.types';

const prisma = new PrismaClient();

export class ClientSegmentService {
  // Criar novo segmento
  async createSegment(data: CreateClientSegmentDto): Promise<ClientSegment> {
    const segment = await prisma.clientSegment.create({
      data: {
        name: data.name,
        description: data.description,
        tenantId: data.tenantId,
        criteria: JSON.stringify(data.criteria),
      },
    });

    // Calcular contagem de clientes
    const clientCount = await this.calculateSegmentSize(segment.id);
    
    const updatedSegment = await prisma.clientSegment.update({
      where: { id: segment.id },
      data: { clientCount },
    });

    return this.mapSegmentFromDb(updatedSegment);
  }

  // Buscar segmentos por tenant
  async getSegmentsByTenant(tenantId: string): Promise<ClientSegment[]> {
    const segments = await prisma.clientSegment.findMany({
      where: { tenantId },
      orderBy: { createdAt: 'desc' },
    });

    return segments.map(this.mapSegmentFromDb);
  }

  // Buscar segmento por ID
  async getSegmentById(id: string): Promise<ClientSegment | null> {
    const segment = await prisma.clientSegment.findUnique({
      where: { id },
    });

    return segment ? this.mapSegmentFromDb(segment) : null;
  }

  // Atualizar segmento
  async updateSegment(id: string, data: UpdateClientSegmentDto): Promise<ClientSegment> {
    const updateData: any = {
      name: data.name,
      description: data.description,
      isActive: data.isActive,
      lastUpdated: new Date(),
    };

    if (data.criteria) {
      updateData.criteria = JSON.stringify(data.criteria);
    }

    const segment = await prisma.clientSegment.update({
      where: { id },
      data: updateData,
    });

    // Recalcular contagem se os critérios mudaram
    if (data.criteria) {
      const clientCount = await this.calculateSegmentSize(id);
      await prisma.clientSegment.update({
        where: { id },
        data: { clientCount },
      });
      segment.clientCount = clientCount;
    }

    return this.mapSegmentFromDb(segment);
  }

  // Deletar segmento
  async deleteSegment(id: string): Promise<void> {
    await prisma.clientSegment.delete({
      where: { id },
    });
  }

  // Calcular tamanho do segmento
  async calculateSegmentSize(segmentId: string): Promise<number> {
    const segment = await this.getSegmentById(segmentId);
    if (!segment) return 0;

    const userIds = await this.getUsersInSegment(segment);
    return userIds.length;
  }

  // Buscar usuários que fazem parte do segmento
  async getUsersInSegment(segment: ClientSegment): Promise<string[]> {
    const criteria = segment.criteria;
    const whereClause: any = {
      tenantId: segment.tenantId,
      isActive: true,
    };

    // Aplicar critérios demográficos
    if (criteria.gender && criteria.gender.length > 0) {
      // Assumindo que gender está no profile
      whereClause.profile = {
        ...whereClause.profile,
        // Implementar quando tivermos campo gender no profile
      };
    }

    // Critérios comportamentais
    if (criteria.lastBookingDays) {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - criteria.lastBookingDays);
      
      whereClause.bookings = {
        some: {
          createdAt: {
            gte: cutoffDate,
          },
        },
      };
    }

    if (criteria.totalBookings) {
      const users = await prisma.user.findMany({
        where: {
          ...whereClause,
          bookings: {
            some: {},
          },
        },
        include: {
          _count: {
            select: { bookings: true },
          },
        },
      });

      return users
        .filter(user => {
          const bookingCount = user._count.bookings;
          const min = criteria.totalBookings?.min ?? 0;
          const max = criteria.totalBookings?.max ?? Infinity;
          return bookingCount >= min && bookingCount <= max;
        })
        .map(user => user.id);
    }

    if (criteria.totalSpent) {
      const users = await prisma.user.findMany({
        where: {
          ...whereClause,
          bookings: {
            some: {},
          },
        },
        include: {
          bookings: {
            select: { price: true },
          },
        },
      });

      return users
        .filter(user => {
          const totalSpent = user.bookings.reduce((sum, booking) => sum + booking.price, 0);
          const min = criteria.totalSpent?.min ?? 0;
          const max = criteria.totalSpent?.max ?? Infinity;
          return totalSpent >= min && totalSpent <= max;
        })
        .map(user => user.id);
    }

    // Critérios temporais
    if (criteria.registrationDate) {
      const dateRange: any = {};
      if (criteria.registrationDate.from) dateRange.gte = criteria.registrationDate.from;
      if (criteria.registrationDate.to) dateRange.lte = criteria.registrationDate.to;
      
      whereClause.createdAt = dateRange;
    }

    if (criteria.lastLoginDays) {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - criteria.lastLoginDays);
      
      whereClause.lastLoginAt = {
        gte: cutoffDate,
      };
    }

    // Critérios de serviços
    if (criteria.preferredServices && criteria.preferredServices.length > 0) {
      whereClause.bookings = {
        ...whereClause.bookings,
        some: {
          serviceId: {
            in: criteria.preferredServices,
          },
        },
      };
    }

    if (criteria.preferredProfessionals && criteria.preferredProfessionals.length > 0) {
      whereClause.bookings = {
        ...whereClause.bookings,
        some: {
          professionalId: {
            in: criteria.preferredProfessionals,
          },
        },
      };
    }

    // Status do cliente
    if (criteria.isActive !== undefined) {
      whereClause.isActive = criteria.isActive;
    }

    if (criteria.hasNoShow) {
      whereClause.bookings = {
        ...whereClause.bookings,
        some: {
          status: 'NO_SHOW',
        },
      };
    }

    const users = await prisma.user.findMany({
      where: whereClause,
      select: { id: true },
    });

    return users.map(user => user.id);
  }

  // Buscar clientes de um segmento com detalhes
  async getSegmentClients(segmentId: string, page: number = 1, limit: number = 50) {
    const segment = await this.getSegmentById(segmentId);
    if (!segment) {
      throw new Error('Segmento não encontrado');
    }

    const userIds = await this.getUsersInSegment(segment);
    const skip = (page - 1) * limit;
    const paginatedIds = userIds.slice(skip, skip + limit);

    const clients = await prisma.user.findMany({
      where: {
        id: { in: paginatedIds },
      },
      include: {
        profile: true,
        _count: {
          select: {
            bookings: true,
          },
        },
        bookings: {
          select: {
            price: true,
            createdAt: true,
          },
          orderBy: {
            createdAt: 'desc',
          },
          take: 1,
        },
      },
    });

    return {
      clients: clients.map(client => ({
        id: client.id,
        name: client.name,
        email: client.email,
        phone: client.phone,
        avatar: client.profile?.avatar,
        totalBookings: client._count.bookings,
        totalSpent: client.bookings.reduce((sum, booking) => sum + booking.price, 0),
        lastBooking: client.bookings[0]?.createdAt,
        createdAt: client.createdAt,
      })),
      pagination: {
        page,
        limit,
        total: userIds.length,
        totalPages: Math.ceil(userIds.length / limit),
      },
    };
  }

  // Atualizar contagens de todos os segmentos de um tenant
  async updateAllSegmentCounts(tenantId: string): Promise<void> {
    const segments = await this.getSegmentsByTenant(tenantId);
    
    for (const segment of segments) {
      const clientCount = await this.calculateSegmentSize(segment.id);
      await prisma.clientSegment.update({
        where: { id: segment.id },
        data: { 
          clientCount,
          lastUpdated: new Date(),
        },
      });
    }
  }

  // Buscar segmentos sugeridos baseados em padrões
  async getSuggestedSegments(tenantId: string): Promise<CreateClientSegmentDto[]> {
    const suggestions: CreateClientSegmentDto[] = [];

    // Clientes inativos (sem agendamento nos últimos 90 dias)
    suggestions.push({
      name: 'Clientes Inativos',
      description: 'Clientes que não fazem agendamentos há mais de 90 dias',
      tenantId,
      criteria: {
        lastBookingDays: 90,
      },
    });

    // Clientes VIP (mais de 10 agendamentos e gasto acima de R$ 1000)
    suggestions.push({
      name: 'Clientes VIP',
      description: 'Clientes com mais de 10 agendamentos e gasto total acima de R$ 1000',
      tenantId,
      criteria: {
        totalBookings: { min: 10 },
        totalSpent: { min: 1000 },
      },
    });

    // Novos clientes (cadastrados nos últimos 30 dias)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    suggestions.push({
      name: 'Novos Clientes',
      description: 'Clientes cadastrados nos últimos 30 dias',
      tenantId,
      criteria: {
        registrationDate: { from: thirtyDaysAgo },
      },
    });

    // Clientes com histórico de faltas
    suggestions.push({
      name: 'Clientes com Faltas',
      description: 'Clientes que já faltaram em agendamentos',
      tenantId,
      criteria: {
        hasNoShow: true,
      },
    });

    return suggestions;
  }

  // Mapper
  private mapSegmentFromDb(segment: any): ClientSegment {
    return {
      id: segment.id,
      name: segment.name,
      description: segment.description,
      tenantId: segment.tenantId,
      criteria: JSON.parse(segment.criteria),
      isActive: segment.isActive,
      lastUpdated: segment.lastUpdated,
      clientCount: segment.clientCount,
      createdAt: segment.createdAt,
      updatedAt: segment.updatedAt,
    };
  }
}