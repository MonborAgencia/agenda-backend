import logger from '../config/logger';

export interface AuditLogData {
  userId?: string;
  tenantId?: string;
  action: string;
  resource: string;
  resourceId?: string;
  oldValues?: any;
  newValues?: any;
  ipAddress?: string;
  userAgent?: string;
  sessionId?: string;
  success: boolean;
  errorMessage?: string;
  metadata?: Record<string, any>;
}

export class AuditService {
  /**
   * Registra uma ação de auditoria
   */
  static log(data: AuditLogData): void {
    const auditEntry = {
      ...data,
      timestamp: new Date().toISOString(),
      level: 'audit'
    };

    logger.log('audit', 'Audit log entry', auditEntry);
  }

  /**
   * Log de autenticação
   */
  static logAuth(data: {
    userId?: string;
    email?: string;
    action: 'LOGIN' | 'LOGOUT' | 'LOGIN_FAILED' | 'PASSWORD_RESET' | 'REGISTER';
    ipAddress?: string;
    userAgent?: string;
    success: boolean;
    errorMessage?: string;
  }): void {
    this.log({
      userId: data.userId,
      action: data.action,
      resource: 'AUTH',
      ipAddress: data.ipAddress,
      userAgent: data.userAgent,
      success: data.success,
      errorMessage: data.errorMessage,
      metadata: {
        email: data.email
      }
    });
  }

  /**
   * Log de operações CRUD
   */
  static logCrud(data: {
    userId: string;
    tenantId?: string;
    action: 'CREATE' | 'READ' | 'UPDATE' | 'DELETE';
    resource: string;
    resourceId?: string;
    oldValues?: any;
    newValues?: any;
    ipAddress?: string;
    success: boolean;
    errorMessage?: string;
  }): void {
    this.log({
      ...data,
      metadata: {
        operation: 'CRUD'
      }
    });
  }

  /**
   * Log de operações de agendamento
   */
  static logBooking(data: {
    userId: string;
    tenantId: string;
    action: 'BOOK' | 'RESCHEDULE' | 'CANCEL' | 'CONFIRM' | 'NO_SHOW';
    bookingId: string;
    professionalId?: string;
    serviceId?: string;
    oldDateTime?: Date;
    newDateTime?: Date;
    ipAddress?: string;
    success: boolean;
    errorMessage?: string;
  }): void {
    this.log({
      userId: data.userId,
      tenantId: data.tenantId,
      action: data.action,
      resource: 'BOOKING',
      resourceId: data.bookingId,
      oldValues: data.oldDateTime ? { dateTime: data.oldDateTime } : undefined,
      newValues: data.newDateTime ? { dateTime: data.newDateTime } : undefined,
      ipAddress: data.ipAddress,
      success: data.success,
      errorMessage: data.errorMessage,
      metadata: {
        professionalId: data.professionalId,
        serviceId: data.serviceId
      }
    });
  }

  /**
   * Log de operações de pagamento
   */
  static logPayment(data: {
    userId: string;
    tenantId: string;
    action: 'PAYMENT_ATTEMPT' | 'PAYMENT_SUCCESS' | 'PAYMENT_FAILED' | 'REFUND';
    bookingId?: string;
    amount: number;
    currency: string;
    paymentMethod: string;
    transactionId?: string;
    ipAddress?: string;
    success: boolean;
    errorMessage?: string;
  }): void {
    this.log({
      userId: data.userId,
      tenantId: data.tenantId,
      action: data.action,
      resource: 'PAYMENT',
      resourceId: data.transactionId,
      ipAddress: data.ipAddress,
      success: data.success,
      errorMessage: data.errorMessage,
      metadata: {
        bookingId: data.bookingId,
        amount: data.amount,
        currency: data.currency,
        paymentMethod: data.paymentMethod
      }
    });
  }

  /**
   * Log de acesso a dados sensíveis
   */
  static logDataAccess(data: {
    userId: string;
    tenantId?: string;
    action: 'VIEW' | 'EXPORT' | 'DOWNLOAD';
    resource: string;
    resourceId?: string;
    dataType: 'PERSONAL_DATA' | 'FINANCIAL_DATA' | 'HEALTH_DATA' | 'CONTACT_DATA';
    ipAddress?: string;
    success: boolean;
    errorMessage?: string;
  }): void {
    this.log({
      ...data,
      metadata: {
        dataType: data.dataType,
        sensitiveData: true
      }
    });
  }

  /**
   * Log de configurações do sistema
   */
  static logSystemConfig(data: {
    userId: string;
    tenantId?: string;
    action: 'CONFIG_CHANGE' | 'PERMISSION_CHANGE' | 'ROLE_CHANGE';
    resource: string;
    resourceId?: string;
    oldValues?: any;
    newValues?: any;
    ipAddress?: string;
    success: boolean;
    errorMessage?: string;
  }): void {
    this.log({
      ...data,
      metadata: {
        systemOperation: true
      }
    });
  }

  /**
   * Log de tentativas de acesso não autorizado
   */
  static logSecurityEvent(data: {
    userId?: string;
    action: 'UNAUTHORIZED_ACCESS' | 'SUSPICIOUS_ACTIVITY' | 'RATE_LIMIT_EXCEEDED' | 'INVALID_TOKEN';
    resource: string;
    ipAddress?: string;
    userAgent?: string;
    details: string;
  }): void {
    this.log({
      userId: data.userId,
      action: data.action,
      resource: data.resource,
      ipAddress: data.ipAddress,
      userAgent: data.userAgent,
      success: false,
      errorMessage: data.details,
      metadata: {
        securityEvent: true,
        severity: 'HIGH'
      }
    });
  }
}

export default AuditService;