import { PrismaClient } from '@prisma/client';
import {
  Campaign,
  CampaignExecution,
  CampaignTarget,
  CampaignMetric,
  CreateCampaignDto,
  UpdateCampaignDto,
  CampaignType,
  CampaignStatus,
  ExecutionStatus,
  TargetStatus,
  TargetAudience,
  SegmentationCriteria,
  CampaignReport,
  CampaignAnalytics
} from '../types/campaign.types';

const prisma = new PrismaClient();

export class CampaignService {
  // Criar nova campanha
  async createCampaign(data: CreateCampaignDto): Promise<Campaign> {
    const campaign = await prisma.campaign.create({
      data: {
        name: data.name,
        description: data.description,
        type: data.type,
        tenantId: data.tenantId,
        templateId: data.templateId,
        targetAudience: data.targetAudience ? JSON.stringify(data.targetAudience) : null,
        startDate: data.startDate,
        endDate: data.endDate,
        frequency: data.frequency,
      },
    });

    return this.mapCampaignFromDb(campaign);
  }

  // Buscar campanhas por tenant
  async getCampaignsByTenant(tenantId: string): Promise<Campaign[]> {
    const campaigns = await prisma.campaign.findMany({
      where: { tenantId },
      orderBy: { createdAt: 'desc' },
    });

    return campaigns.map(this.mapCampaignFromDb);
  }

  // Buscar campanha por ID
  async getCampaignById(id: string): Promise<Campaign | null> {
    const campaign = await prisma.campaign.findUnique({
      where: { id },
    });

    return campaign ? this.mapCampaignFromDb(campaign) : null;
  }

  // Atualizar campanha
  async updateCampaign(id: string, data: UpdateCampaignDto): Promise<Campaign> {
    const campaign = await prisma.campaign.update({
      where: { id },
      data: {
        name: data.name,
        description: data.description,
        status: data.status,
        templateId: data.templateId,
        targetAudience: data.targetAudience ? JSON.stringify(data.targetAudience) : undefined,
        startDate: data.startDate,
        endDate: data.endDate,
        frequency: data.frequency,
      },
    });

    return this.mapCampaignFromDb(campaign);
  }

  // Deletar campanha
  async deleteCampaign(id: string): Promise<void> {
    await prisma.campaign.delete({
      where: { id },
    });
  }

  // Executar campanha
  async executeCampaign(campaignId: string): Promise<CampaignExecution> {
    const campaign = await this.getCampaignById(campaignId);
    if (!campaign) {
      throw new Error('Campanha não encontrada');
    }

    if (campaign.status !== CampaignStatus.ACTIVE) {
      throw new Error('Apenas campanhas ativas podem ser executadas');
    }

    // Criar execução
    const execution = await prisma.campaignExecution.create({
      data: {
        campaignId,
        status: ExecutionStatus.PENDING,
      },
    });

    // Buscar público-alvo
    const targets = await this.getTargetAudience(campaign);
    
    // Criar targets para a execução
    const campaignTargets = await Promise.all(
      targets.map(userId =>
        prisma.campaignTarget.create({
          data: {
            executionId: execution.id,
            userId,
            status: TargetStatus.PENDING,
          },
        })
      )
    );

    // Atualizar execução com total de targets
    const updatedExecution = await prisma.campaignExecution.update({
      where: { id: execution.id },
      data: {
        totalTargets: campaignTargets.length,
        status: ExecutionStatus.RUNNING,
        startedAt: new Date(),
      },
    });

    // Processar envios (em background)
    this.processExecution(execution.id).catch(console.error);

    return this.mapExecutionFromDb(updatedExecution);
  }

  // Processar execução da campanha
  private async processExecution(executionId: string): Promise<void> {
    try {
      const execution = await prisma.campaignExecution.findUnique({
        where: { id: executionId },
        include: {
          campaign: {
            include: {
              template: true,
            },
          },
          targets: {
            where: { status: TargetStatus.PENDING },
            include: { user: true },
          },
        },
      });

      if (!execution) return;

      let successCount = 0;
      let failureCount = 0;

      // Processar cada target
      for (const target of execution.targets) {
        try {
          // Aqui integraria com o serviço de notificações
          // Por enquanto, simular envio bem-sucedido
          await prisma.campaignTarget.update({
            where: { id: target.id },
            data: {
              status: TargetStatus.SENT,
              sentAt: new Date(),
            },
          });

          successCount++;
        } catch (error) {
          await prisma.campaignTarget.update({
            where: { id: target.id },
            data: {
              status: TargetStatus.FAILED,
              failureReason: error instanceof Error ? error.message : 'Erro desconhecido',
            },
          });

          failureCount++;
        }
      }

      // Atualizar execução
      await prisma.campaignExecution.update({
        where: { id: executionId },
        data: {
          status: ExecutionStatus.COMPLETED,
          completedAt: new Date(),
          successCount,
          failureCount,
        },
      });

      // Atualizar métricas da campanha
      await this.updateCampaignMetrics(execution.campaignId, successCount);

    } catch (error) {
      await prisma.campaignExecution.update({
        where: { id: executionId },
        data: {
          status: ExecutionStatus.FAILED,
          errorMessage: error instanceof Error ? error.message : 'Erro desconhecido',
        },
      });
    }
  }

  // Buscar público-alvo baseado nos critérios
  private async getTargetAudience(campaign: Campaign): Promise<string[]> {
    if (!campaign.targetAudience) {
      return [];
    }

    const criteria = campaign.targetAudience.criteria;
    if (!criteria) {
      return [];
    }

    // Construir query baseada nos critérios
    const whereClause: any = {
      tenantId: campaign.tenantId,
      isActive: true,
    };

    // Aplicar critérios de segmentação
    if (criteria.lastBookingDays) {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - criteria.lastBookingDays);
      
      whereClause.bookings = {
        some: {
          createdAt: {
            gte: cutoffDate,
          },
        },
      };
    }

    if (criteria.totalBookings) {
      const bookingCount: any = {};
      if (criteria.totalBookings.min) bookingCount.gte = criteria.totalBookings.min;
      if (criteria.totalBookings.max) bookingCount.lte = criteria.totalBookings.max;
      
      whereClause.bookings = {
        ...whereClause.bookings,
        _count: bookingCount,
      };
    }

    if (criteria.registrationDate) {
      const dateRange: any = {};
      if (criteria.registrationDate.from) dateRange.gte = criteria.registrationDate.from;
      if (criteria.registrationDate.to) dateRange.lte = criteria.registrationDate.to;
      
      whereClause.createdAt = dateRange;
    }

    if (criteria.lastLoginDays) {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - criteria.lastLoginDays);
      
      whereClause.lastLoginAt = {
        gte: cutoffDate,
      };
    }

    const users = await prisma.user.findMany({
      where: whereClause,
      select: { id: true },
    });

    return users.map(user => user.id);
  }

  // Atualizar métricas da campanha
  private async updateCampaignMetrics(campaignId: string, sentCount: number): Promise<void> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    await prisma.campaignMetric.upsert({
      where: {
        campaignId_date: {
          campaignId,
          date: today,
        },
      },
      update: {
        sent: {
          increment: sentCount,
        },
      },
      create: {
        campaignId,
        date: today,
        sent: sentCount,
      },
    });

    // Atualizar totais da campanha
    await prisma.campaign.update({
      where: { id: campaignId },
      data: {
        totalSent: {
          increment: sentCount,
        },
      },
    });
  }

  // Buscar execuções de uma campanha
  async getCampaignExecutions(campaignId: string): Promise<CampaignExecution[]> {
    const executions = await prisma.campaignExecution.findMany({
      where: { campaignId },
      orderBy: { createdAt: 'desc' },
    });

    return executions.map(this.mapExecutionFromDb);
  }

  // Buscar relatório de campanha
  async getCampaignReport(campaignId: string): Promise<CampaignReport> {
    const campaign = await this.getCampaignById(campaignId);
    if (!campaign) {
      throw new Error('Campanha não encontrada');
    }

    const metrics = await prisma.campaignMetric.findMany({
      where: { campaignId },
      orderBy: { date: 'asc' },
    });

    const totalMetrics = metrics.reduce(
      (acc, metric) => ({
        sent: acc.sent + metric.sent,
        delivered: acc.delivered + metric.delivered,
        opened: acc.opened + metric.opened,
        clicked: acc.clicked + metric.clicked,
        converted: acc.converted + metric.converted,
        revenue: acc.revenue + metric.revenue,
      }),
      { sent: 0, delivered: 0, opened: 0, clicked: 0, converted: 0, revenue: 0 }
    );

    const deliveryRate = totalMetrics.sent > 0 ? (totalMetrics.delivered / totalMetrics.sent) * 100 : 0;
    const openRate = totalMetrics.delivered > 0 ? (totalMetrics.opened / totalMetrics.delivered) * 100 : 0;
    const clickRate = totalMetrics.opened > 0 ? (totalMetrics.clicked / totalMetrics.opened) * 100 : 0;
    const conversionRate = totalMetrics.clicked > 0 ? (totalMetrics.converted / totalMetrics.clicked) * 100 : 0;

    return {
      campaign,
      metrics: {
        totalSent: totalMetrics.sent,
        totalDelivered: totalMetrics.delivered,
        totalOpened: totalMetrics.opened,
        totalClicked: totalMetrics.clicked,
        totalConverted: totalMetrics.converted,
        deliveryRate,
        openRate,
        clickRate,
        conversionRate,
        revenue: totalMetrics.revenue,
        roi: 0, // Calcular ROI baseado no custo da campanha
      },
      timeline: metrics.map(this.mapMetricFromDb),
    };
  }

  // Buscar analytics gerais de campanhas
  async getCampaignAnalytics(tenantId: string): Promise<CampaignAnalytics> {
    const campaigns = await prisma.campaign.findMany({
      where: { tenantId },
    });

    const activeCampaigns = campaigns.filter(c => c.status === CampaignStatus.ACTIVE);

    const recentExecutions = await prisma.campaignExecution.findMany({
      where: {
        campaign: { tenantId },
      },
      orderBy: { createdAt: 'desc' },
      take: 10,
    });

    // Calcular médias (implementação simplificada)
    const totalSent = campaigns.reduce((acc, c) => acc + c.totalSent, 0);
    const totalOpened = campaigns.reduce((acc, c) => acc + c.totalOpened, 0);
    const totalClicked = campaigns.reduce((acc, c) => acc + c.totalClicked, 0);
    const totalConverted = campaigns.reduce((acc, c) => acc + c.totalConverted, 0);

    return {
      totalCampaigns: campaigns.length,
      activeCampaigns: activeCampaigns.length,
      averageOpenRate: totalSent > 0 ? (totalOpened / totalSent) * 100 : 0,
      averageClickRate: totalOpened > 0 ? (totalClicked / totalOpened) * 100 : 0,
      averageConversionRate: totalClicked > 0 ? (totalConverted / totalClicked) * 100 : 0,
      totalRevenue: 0, // Implementar cálculo de receita
      recentExecutions: recentExecutions.map(this.mapExecutionFromDb),
    };
  }

  // Pausar campanha
  async pauseCampaign(id: string): Promise<Campaign> {
    return this.updateCampaign(id, { status: CampaignStatus.PAUSED });
  }

  // Reativar campanha
  async activateCampaign(id: string): Promise<Campaign> {
    return this.updateCampaign(id, { status: CampaignStatus.ACTIVE });
  }

  // Cancelar campanha
  async cancelCampaign(id: string): Promise<Campaign> {
    return this.updateCampaign(id, { status: CampaignStatus.CANCELLED });
  }

  // Mappers
  private mapCampaignFromDb(campaign: any): Campaign {
    return {
      id: campaign.id,
      name: campaign.name,
      description: campaign.description,
      type: campaign.type as CampaignType,
      status: campaign.status as CampaignStatus,
      tenantId: campaign.tenantId,
      templateId: campaign.templateId,
      targetAudience: campaign.targetAudience ? JSON.parse(campaign.targetAudience) : undefined,
      startDate: campaign.startDate,
      endDate: campaign.endDate,
      frequency: campaign.frequency,
      totalSent: campaign.totalSent,
      totalOpened: campaign.totalOpened,
      totalClicked: campaign.totalClicked,
      totalConverted: campaign.totalConverted,
      createdAt: campaign.createdAt,
      updatedAt: campaign.updatedAt,
    };
  }

  private mapExecutionFromDb(execution: any): CampaignExecution {
    return {
      id: execution.id,
      campaignId: execution.campaignId,
      status: execution.status as ExecutionStatus,
      startedAt: execution.startedAt,
      completedAt: execution.completedAt,
      totalTargets: execution.totalTargets,
      successCount: execution.successCount,
      failureCount: execution.failureCount,
      errorMessage: execution.errorMessage,
      metadata: execution.metadata ? JSON.parse(execution.metadata) : undefined,
      createdAt: execution.createdAt,
      updatedAt: execution.updatedAt,
    };
  }

  private mapMetricFromDb(metric: any): CampaignMetric {
    return {
      id: metric.id,
      campaignId: metric.campaignId,
      date: metric.date,
      sent: metric.sent,
      delivered: metric.delivered,
      opened: metric.opened,
      clicked: metric.clicked,
      converted: metric.converted,
      revenue: metric.revenue,
      createdAt: metric.createdAt,
    };
  }
}