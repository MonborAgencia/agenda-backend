import { cacheService, CacheMetrics } from './cache.service';
import { redisClient } from '../config/redis';

export interface DetailedCacheMetrics extends CacheMetrics {
  memoryUsage: number;
  keyCount: number;
  expiredKeys: number;
  evictedKeys: number;
  connectionStatus: string;
  uptime: number;
}

export interface CachePerformanceReport {
  overall: DetailedCacheMetrics;
  byCategory: Record<string, CacheMetrics>;
  topKeys: Array<{
    key: string;
    hits: number;
    misses: number;
    hitRate: number;
  }>;
  recommendations: string[];
}

export class CacheMetricsService {
  private performanceHistory: Array<{
    timestamp: Date;
    metrics: DetailedCacheMetrics;
  }> = [];

  /**
   * Get detailed cache metrics
   */
  async getDetailedMetrics(): Promise<DetailedCacheMetrics> {
    const basicMetrics = cacheService.getMetrics();
    
    try {
      // Get Redis info
      const info = await redisClient.info();
      const infoLines = info.split('\r\n');
      const infoObj: Record<string, string> = {};
      
      infoLines.forEach(line => {
        const [key, value] = line.split(':');
        if (key && value) {
          infoObj[key] = value;
        }
      });

      // Get key count
      const keyCount = await this.getKeyCount();

      const detailedMetrics: DetailedCacheMetrics = {
        ...basicMetrics,
        memoryUsage: parseInt(infoObj.used_memory || '0'),
        keyCount,
        expiredKeys: parseInt(infoObj.expired_keys || '0'),
        evictedKeys: parseInt(infoObj.evicted_keys || '0'),
        connectionStatus: redisClient.status,
        uptime: parseInt(infoObj.uptime_in_seconds || '0')
      };

      // Store in history
      this.performanceHistory.push({
        timestamp: new Date(),
        metrics: detailedMetrics
      });

      // Keep only last 100 entries
      if (this.performanceHistory.length > 100) {
        this.performanceHistory = this.performanceHistory.slice(-100);
      }

      return detailedMetrics;
    } catch (error) {
      console.error('Error getting detailed cache metrics:', error);
      return {
        ...basicMetrics,
        memoryUsage: 0,
        keyCount: 0,
        expiredKeys: 0,
        evictedKeys: 0,
        connectionStatus: 'error',
        uptime: 0
      };
    }
  }

  /**
   * Get cache performance report
   */
  async getPerformanceReport(): Promise<CachePerformanceReport> {
    const overall = await this.getDetailedMetrics();
    
    // Get metrics by category
    const categories = ['user', 'schedule', 'booking', 'analytics', 'tenant'];
    const byCategory: Record<string, CacheMetrics> = {};
    
    categories.forEach(category => {
      byCategory[category] = cacheService.getMetrics(category);
    });

    // Get top performing keys (mock data for now - would need Redis monitoring)
    const topKeys = await this.getTopKeys();

    // Generate recommendations
    const recommendations = this.generateRecommendations(overall, byCategory);

    return {
      overall,
      byCategory,
      topKeys,
      recommendations
    };
  }

  /**
   * Get cache hit rate trend
   */
  getHitRateTrend(minutes: number = 60): Array<{
    timestamp: Date;
    hitRate: number;
  }> {
    const cutoff = new Date(Date.now() - minutes * 60 * 1000);
    
    return this.performanceHistory
      .filter(entry => entry.timestamp >= cutoff)
      .map(entry => ({
        timestamp: entry.timestamp,
        hitRate: entry.metrics.hitRate
      }));
  }

  /**
   * Get memory usage trend
   */
  getMemoryUsageTrend(minutes: number = 60): Array<{
    timestamp: Date;
    memoryUsage: number;
  }> {
    const cutoff = new Date(Date.now() - minutes * 60 * 1000);
    
    return this.performanceHistory
      .filter(entry => entry.timestamp >= cutoff)
      .map(entry => ({
        timestamp: entry.timestamp,
        memoryUsage: entry.metrics.memoryUsage
      }));
  }

  /**
   * Clear performance history
   */
  clearHistory(): void {
    this.performanceHistory = [];
  }

  /**
   * Get cache health status
   */
  async getHealthStatus(): Promise<{
    status: 'healthy' | 'warning' | 'critical';
    issues: string[];
    score: number;
  }> {
    const metrics = await this.getDetailedMetrics();
    const issues: string[] = [];
    let score = 100;

    // Check hit rate
    if (metrics.hitRate < 50) {
      issues.push('Low cache hit rate (< 50%)');
      score -= 30;
    } else if (metrics.hitRate < 70) {
      issues.push('Moderate cache hit rate (< 70%)');
      score -= 15;
    }

    // Check memory usage (assuming 100MB limit)
    const memoryLimitMB = 100 * 1024 * 1024;
    if (metrics.memoryUsage > memoryLimitMB * 0.9) {
      issues.push('High memory usage (> 90%)');
      score -= 25;
    } else if (metrics.memoryUsage > memoryLimitMB * 0.75) {
      issues.push('Moderate memory usage (> 75%)');
      score -= 10;
    }

    // Check connection status
    if (metrics.connectionStatus !== 'ready') {
      issues.push('Redis connection not ready');
      score -= 40;
    }

    // Check evicted keys
    if (metrics.evictedKeys > 100) {
      issues.push('High number of evicted keys');
      score -= 20;
    }

    let status: 'healthy' | 'warning' | 'critical';
    if (score >= 80) {
      status = 'healthy';
    } else if (score >= 60) {
      status = 'warning';
    } else {
      status = 'critical';
    }

    return { status, issues, score };
  }

  /**
   * Get key count from Redis
   */
  private async getKeyCount(): Promise<number> {
    try {
      const info = await redisClient.info('keyspace');
      const match = info.match(/keys=(\d+)/);
      return match ? parseInt(match[1]) : 0;
    } catch (error) {
      console.error('Error getting key count:', error);
      return 0;
    }
  }

  /**
   * Get top performing keys (simplified version)
   */
  private async getTopKeys(): Promise<Array<{
    key: string;
    hits: number;
    misses: number;
    hitRate: number;
  }>> {
    // This is a simplified version - in production you'd want to use Redis monitoring
    const mockTopKeys = [
      { key: 'user:profile', hits: 150, misses: 20, hitRate: 88.2 },
      { key: 'schedule:availability', hits: 120, misses: 30, hitRate: 80.0 },
      { key: 'booking:list', hits: 100, misses: 40, hitRate: 71.4 },
      { key: 'analytics:dashboard', hits: 80, misses: 15, hitRate: 84.2 },
      { key: 'tenant:config', hits: 200, misses: 5, hitRate: 97.6 }
    ];

    return mockTopKeys.sort((a, b) => b.hitRate - a.hitRate);
  }

  /**
   * Generate performance recommendations
   */
  private generateRecommendations(
    overall: DetailedCacheMetrics,
    byCategory: Record<string, CacheMetrics>
  ): string[] {
    const recommendations: string[] = [];

    // Hit rate recommendations
    if (overall.hitRate < 70) {
      recommendations.push('Consider increasing cache TTL for frequently accessed data');
      recommendations.push('Review cache key patterns to avoid unnecessary cache misses');
    }

    // Memory recommendations
    if (overall.memoryUsage > 50 * 1024 * 1024) { // 50MB
      recommendations.push('Consider implementing cache size limits or LRU eviction');
      recommendations.push('Review large cached objects and consider compression');
    }

    // Category-specific recommendations
    Object.entries(byCategory).forEach(([category, metrics]) => {
      if (metrics.hitRate < 50) {
        recommendations.push(`Improve ${category} cache strategy - low hit rate detected`);
      }
    });

    // Eviction recommendations
    if (overall.evictedKeys > 50) {
      recommendations.push('High eviction rate detected - consider increasing memory limit');
    }

    // Performance recommendations
    if (overall.avgResponseTime > 10) {
      recommendations.push('High average response time - consider optimizing cache operations');
    }

    return recommendations;
  }
}

// Export singleton instance
export const cacheMetricsService = new CacheMetricsService();