// Type declarations for external modules

declare module 'express' {
  export interface Request {
    headers: any;
    body: any;
    params: any;
    query: any;
    originalUrl: string;
    user?: any;
    requestId?: string;
    ip?: string;
    socket?: {
      remoteAddress?: string;
    };
    file?: {
      filename: string;
      path: string;
      mimetype: string;
      size: number;
    };
  }
  
  export interface Response {
    status(code: number): Response;
    json(obj: any): Response;
    send(data: any): Response;
  }
  
  export interface NextFunction {
    (error?: any): void;
  }
  
  export interface Application {
    use(...args: any[]): void;
    get(path: string, ...handlers: any[]): void;
    post(path: string, ...handlers: any[]): void;
    put(path: string, ...handlers: any[]): void;
    delete(path: string, ...handlers: any[]): void;
    listen(port: number, callback?: () => void): any;
  }
  
  export interface Router {
    use(...args: any[]): void;
    get(path: string, ...handlers: any[]): void;
    post(path: string, ...handlers: any[]): void;
    put(path: string, ...handlers: any[]): void;
    delete(path: string, ...handlers: any[]): void;
  }
  
  export function Router(): Router;
  
  export namespace express {
    export function json(options?: any): any;
    export function urlencoded(options?: any): any;
    export interface Request extends Request {}
    export interface Response extends Response {}
    export interface NextFunction extends NextFunction {}
  }
  
  function express(): Application;
  export = express;
}

declare module 'cors' {
  import { RequestHandler } from 'express';
  function cors(options?: any): RequestHandler;
  export = cors;
}

declare module 'helmet' {
  import { RequestHandler } from 'express';
  function helmet(options?: any): RequestHandler;
  export = helmet;
}

declare module 'dotenv' {
  export function config(options?: any): any;
}

declare module 'http' {
  export function createServer(app: any): any;
}

declare module 'socket.io' {
  export class Server {
    constructor(server: any, options?: any);
    on(event: string, callback: (socket: any) => void): void;
  }
}

declare module '@prisma/client' {
  export class PrismaClient {
    constructor();
    user: any;
    role: any;
    permission: any;
    userRole: any;
    rolePermission: any;
    userProfile: any;
    tenant: any;
    professional: any;
    service: any;
    schedule: any;
    scheduleException: any;
    booking: any;
    $transaction: any;
    $disconnect: any;
  }
}

declare module 'bcryptjs' {
  export function hash(data: string, saltOrRounds: number): Promise<string>;
  export function compare(data: string, encrypted: string): Promise<boolean>;
}

declare module 'jsonwebtoken' {
  export function sign(payload: any, secret: string, options?: any): string;
  export function verify(token: string, secret: string, options?: any): any;
  export function decode(token: string): any;
  export class TokenExpiredError extends Error {}
  export class JsonWebTokenError extends Error {}
}

declare module 'zod' {
  export interface ZodType<T = any> {
    parse(input: any): T;
    safeParse(input: any): { success: boolean; data?: T; error?: any };
    optional(): ZodType<T | undefined>;
    nullable(): ZodType<T | null>;
    default(value: T): ZodType<T>;
    min(value: number, message?: string): ZodType<T>;
    max(value: number, message?: string): ZodType<T>;
    email(message?: string): ZodType<T>;
    regex(pattern: RegExp, message?: string): ZodType<T>;
    url(message?: string): ZodType<T>;
    refine(fn: (data: T) => boolean, options?: any): ZodType<T>;
  }

  export interface ZodObject<T = any> extends ZodType<T> {
    extend(shape: any): ZodObject<any>;
    partial(): ZodObject<any>;
  }
  export interface ZodString extends ZodType<string> {
    url(message?: string): ZodString;
  }
  export interface ZodNumber extends ZodType<number> {}
  export interface ZodBoolean extends ZodType<boolean> {}
  export interface ZodArray<T> extends ZodType<T[]> {}
  export interface ZodRecord<T> extends ZodType<Record<string, T>> {}
  export interface ZodEnum<T> extends ZodType<T> {}

  export const z: {
    object: (shape: any) => ZodObject;
    string: () => ZodString;
    number: () => ZodNumber;
    boolean: () => ZodBoolean;
    array: (type: any) => ZodArray<any>;
    record: (type: any) => ZodRecord<any>;
    enum: (values: any) => ZodEnum<any>;
    any: () => ZodType<any>;
    infer: <T>(schema: T) => any;
  };

  export type infer<T> = T extends ZodType<infer U> ? U : never;
}

declare module 'winston' {
  export const winston: any;
}

declare module 'redis' {
  export const redis: any;
}

declare module 'supertest' {
  export default function request(app: any): any;
}

// Jest globals
declare global {
  function describe(name: string, fn: () => void): void;
  function it(name: string, fn: () => void | Promise<void>): void;
  function beforeEach(fn: () => void | Promise<void>): void;
  function afterEach(fn: () => void | Promise<void>): void;
  function expect(actual: any): any;
  
  namespace jest {
    function fn(): any;
    function mock(moduleName: string): any;
    function clearAllMocks(): void;
    function spyOn(object: any, method: string): any;
    function setTimeout(timeout: number): void;
  }
  
  const jest: typeof jest;
}