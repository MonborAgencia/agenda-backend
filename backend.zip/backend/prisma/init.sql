-- Initial database setup
-- This file is executed when the PostgreSQL container starts

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create indexes for better performance (will be created by Prisma migrations)
-- This is just a placeholder for any custom SQL needed during initialization